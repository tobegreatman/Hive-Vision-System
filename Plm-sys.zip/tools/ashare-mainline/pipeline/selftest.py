"""pipeline 自测：验证四项优化都成立，并打印实测计时。

    python -m pipeline.selftest
"""
from __future__ import annotations

import json
import pathlib
import sys
import time
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import contract, http, kline, quotes, report  # noqa: E402

AS_OF = "2026-10-30"
SINCE = "2025-09-15"
BAIJIU = "BK1277"

BOARDS = [
    ("BK1277", "白酒Ⅱ"), ("BK0475", "银行Ⅱ"), ("BK0421", "铁路公路"),
    ("BK1042", "医药商业"), ("BK1046", "游戏Ⅱ"), ("BK0727", "医疗服务"),
    ("BK1278", "调味发酵品Ⅱ"), ("BK1232", "航天装备Ⅱ"),
]


def section(t: str) -> None:
    print(f"\n{'=' * 62}\n{t}\n{'=' * 62}")


def t_contract(cli: http.Client) -> bool:
    section("1 接口契约前置校验")
    t0 = time.time()
    try:
        contract.enforce(cli, contract.builtin(AS_OF, SINCE))
        print(f"  全部通过 | 耗时 {time.time() - t0:.2f}s | 请求 {cli.stats.ok} 次")
        return True
    except contract.ContractError as e:
        print(f"  失败：{e}")
        print(f"  耗时 {time.time() - t0:.2f}s（旧实现此时还在拉第 40 个板块）")
        return False


def t_quotes(cli: http.Client, codes: list[str]) -> dict:
    section("2 腾讯批量报价替代逐只 K 线")
    t0 = time.time()
    q = quotes.fetch(cli, codes)
    dt = time.time() - t0
    n = len(q)
    print(f"  {len(codes)} 只 -> 命中 {n} 只 | {dt:.2f}s | {(len(codes) + quotes.BATCH - 1) // quotes.BATCH} 次请求")
    print(f"  逐只方案约 232 次请求 / 300s，批量方案 {dt:.1f}s，提速约 {300 / max(dt, 0.01):.0f}×")
    sample = next(iter(q.values())) if q else {}
    if sample:
        print(f"  样本：{sample['name']} 现价 {sample['price']} 涨跌 {sample['chg_pct'] * 100:.2f}% "
              f"成交额 {sample['amount_yi']:.2f} 亿 时间 {sample['ts']}")
    print(f"  交易日 {quotes.trade_date(q)}")
    return q


def t_kline(cli: http.Client, codes: list[str]) -> kline.Store:
    section("3 本地 K 线库（首次建库 / 二次命中缓存）")
    db = ROOT / "pipeline" / "cache" / "kline.sqlite"
    store = kline.Store(db)

    t0 = time.time()
    r1 = kline.ensure_history(cli, store, codes, AS_OF)
    d1 = time.time() - t0
    print(f"  首跑 {r1['mode']} | {d1:.2f}s")

    t0 = time.time()
    r2 = kline.ensure_history(cli, store, codes, AS_OF)
    d2 = time.time() - t0
    print(f"  二跑 {r2['mode']} | {d2:.2f}s | 请求 {r2['requested']} 次")
    print(f"  库内 {store.stats()}")
    if r2["requested"] == 0 and r2["mode"] == "cache":
        print(f"  稳态验证通过：K 线请求 232 次 -> 0 次，省 {d1 - d2:.1f}s")
    return store


def t_breadth(store: kline.Store, q: dict, groups: dict[str, list[str]]) -> None:
    section("4 P2 广度（用缓存库 + 当日报价，0 请求）")
    print("  v1.6 口径的已知答案对照：白酒 94.7%/42.1%、银行 69.0%/42.9%、铁路公路 24.2%/3.0%")
    for board, codes in groups.items():
        b = kline.breadth(store, codes, AS_OF, q, quote_date=quotes.trade_date(q))
        if b["valid"] == 0:
            print(f"  {board}: 无有效样本")
            continue
        p2 = b["up_ratio"] >= 0.55 and b["new_high_ratio"] >= 0.08
        print(f"  {board:8s} 有效 {b['valid']:3d} | 上涨 {b['up_ratio'] * 100:5.1f}% | "
              f"新高 {b['new_high_ratio'] * 100:5.1f}% | P2 {'通过' if p2 else '未通过'}")


GOLDEN_REPORT = "aml-20261101-v16.json"


def t_report() -> bool:
    section("5 报告模板化")
    src = ROOT / GOLDEN_REPORT
    if src.exists():
        print(f"  样本：{GOLDEN_REPORT}")
    else:
        # 固定样本会被清理掉（10 月 30 日那批中间缓存已经删过一轮）。缺文件不是代码缺陷，
        # 但直接 read_text 会抛未捕获的 FileNotFoundError，把后面 6/7/8 节一起带走。
        # 退化为「当前最新一份 v1.6 报告」：strip->assemble 往返一致性与样本日期无关。
        cands = sorted(ROOT.glob("aml-*-v16.json"))
        if not cands:
            print(f"  跳过：固定样本 {GOLDEN_REPORT} 不存在，且根目录没有其他 aml-*-v16.json")
            return True
        src = cands[-1]
        print(f"  固定样本 {GOLDEN_REPORT} 不存在，改用 {src.name}（仅验往返，不做历史结论比对）")
    full = json.loads(src.read_text(encoding="utf-8"))
    dyn = report.strip(full)
    again = report.assemble(dyn)
    back = report.strip(again)

    b = lambda o: len(json.dumps(o, ensure_ascii=False, separators=(",", ":")).encode())  # noqa: E731
    print(f"  完整 {b(full)}B | 动态 {b(dyn)}B | 静态注入 {b(full) - b(dyn)}B "
          f"| 生成端缩减 {(1 - b(dyn) / b(full)) * 100:.1f}%")

    # 必须比「动态部分闭合」而不是「整篇相等」：static.json 会随方法学演进
    # （method_summary 已从 86 板块改到 128 板块），拿 11-01 的旧报告去比整篇，
    # 差异只反映模板升级，不反映 strip/assemble 有 bug。
    norm = lambda o: json.dumps(o, ensure_ascii=False, sort_keys=True)  # noqa: E731
    same = norm(back) == norm(dyn)
    print(f"  strip -> assemble -> strip 往返一致（动态部分）：{'是' if same else '否'}")
    if not same:
        for k in set(dyn) | set(back):
            if norm(dyn.get(k)) != norm(back.get(k)):
                print(f"    差异键：{k}")

    whole = norm(again) == norm(full)
    if not whole:
        drift = [k for k in (full.get("appendix") or {})
                 if norm((full.get("appendix") or {}).get(k)) != norm((again.get("appendix") or {}).get(k))]
        print(f"  整篇与样本不同：静态块已升级（{('、'.join(drift)) or '顶层级'}），属预期演进，不计失败")

    warn = report.assert_consistent(full)
    print(f"  一致性自检：{len(warn)} 条")
    for w in warn:
        print(f"    - {w}")
    return same


def t_circuit() -> None:
    section("7 熔断（打已封禁的 push2his/kline，验证不会空转）")
    cli = http.make_client(workers=4, max_rps=4, min_span=0)
    url = ("https://push2his.eastmoney.com/api/qt/stock/kline/get"
           "?secid=90.BK1277&fields1=f1&fields2=f51,f53&klt=101&fqt=1&lmt=5")
    t0 = time.time()
    for i in range(6):
        try:
            cli.get(url)
            print(f"  第 {i + 1} 次：成功")
        except http.EndpointBlocked as e:
            print(f"  第 {i + 1} 次 @ {time.time() - t0:5.2f}s：{str(e)[:56]}")
        except Exception as e:  # noqa: BLE001
            print(f"  第 {i + 1} 次 @ {time.time() - t0:5.2f}s：{type(e).__name__} {str(e)[:40]}")
    dt = time.time() - t0
    print(f"  6 次尝试总耗时 {dt:.2f}s")
    print("  旧实现 tries=4 + 指数退避：单次约 18s，99 板块最坏 1800s")
    print(f"  按 6 次折算，旧实现约 108s，新实现 {dt:.1f}s，压缩 {108 / max(dt, 0.01):.0f}×")


def t_gap() -> bool:
    """缺口 / 假 K 线 / 停牌 的回归（全程离线，用临时库 + 假 client）。"""
    section("8 增量库缺口（几天不跑会不会错）")
    pkl = ROOT / "pipeline" / "cache" / f"panel-{AS_OF}.pkl"
    src = ROOT / "pipeline" / "cache" / "kline.sqlite"
    if not (pkl.exists() and src.exists()):
        print("  跳过：缺 panel 缓存或 K 线库")
        return True
    import pickle
    import shutil
    import sqlite3
    import tempfile

    cal = sorted(pickle.loads(pkl.read_bytes())["by_date"])
    codes = _board_codes(http.make_client(workers=2, max_rps=2, min_span=0), BAIJIU)
    tmpdir = Path(tempfile.mkdtemp())
    seq = [0]

    class Fake:
        """不联网：直接发回日历上最近 50 个交易日。"""

        def map(self, fn, items):
            return [([(d, 10.0 + i) for i, d in enumerate(cal[-50:])], "fake") for _ in items]

    def fresh() -> kline.Store:
        seq[0] += 1
        p = tmpdir / f"k{seq[0]}.sqlite"
        shutil.copy(src, p)
        return kline.Store(p)

    checks: list[tuple[str, bool, str]] = []
    st = fresh()
    r = kline.ensure_history(Fake(), st, codes, AS_OF, need=45, calendar=cal, verbose=False)
    checks.append(("库已完整时不发请求", r["requested"] == 0, f"requested={r['requested']}"))
    st.close()

    st = fresh()
    with sqlite3.connect(st.path) as db:
        for d in cal[-4:-1]:
            db.execute("delete from kline where d=?", (d,))
    r = kline.ensure_history(Fake(), st, codes, AS_OF, need=45, calendar=cal, verbose=False)
    checks.append(("缺 3 个交易日能发现", r["requested"] > 0, f"requested={r['requested']}"))
    st.close()

    solo, gapday = codes[0], cal[-10]
    st = fresh()
    with sqlite3.connect(st.path) as db:
        db.execute("delete from kline where code=? and d=?", (solo, gapday))
    r = kline.ensure_history(Fake(), st, codes, AS_OF, need=45, calendar=cal, verbose=False)
    checks.append((f"单只缺一天也能发现（{solo} 缺 {gapday}）", r["requested"] == 1,
                   f"requested={r['requested']}"))
    st.close()

    st = fresh()
    st.set_meta("provisional", AS_OF)
    r = kline.ensure_history(Fake(), st, codes, AS_OF, need=45, calendar=cal, verbose=False)
    checks.append(("盘中快照触发整只重拉并清标记",
                   r["requested"] > 0 and st.get_meta("provisional") is None,
                   f"requested={r['requested']}"))
    st.close()

    # breadth 侧：中间缺日必须 fail-closed；单只停牌不能被误判成缓存缺口。
    st = fresh()
    qs = {}
    for c in codes:
        b = st.bars(c, AS_OF, 2)
        if len(b) == 2:
            qs[c] = {"price": b[0][1], "prev_close": b[1][1], "chg_pct": 0.0}
    v0 = kline.breadth(st, codes, AS_OF, qs, calendar=cal)
    with sqlite3.connect(st.path) as db:
        for d in cal[-4:-1]:
            db.execute("delete from kline where d=?", (d,))
    v1 = kline.breadth(st, codes, AS_OF, qs, calendar=cal)
    checks.append(("中间缺日 → degraded 且不给假数", v1["degraded"] and v0["degraded"] is False,
                   f"正常 {v0['degraded']} / 缺日 {v1['degraded']} 缺日={v1['hole_dates'][:3]}"))
    st.close()

    st = fresh()
    with sqlite3.connect(st.path) as db:
        db.execute("delete from kline where code=? and d=?", (solo, gapday))
    v2 = kline.breadth(st, codes, AS_OF, qs, calendar=cal)
    checks.append(("单只停牌不算退化", v2["degraded"] is False, f"degraded={v2['degraded']}"))
    st.close()
    shutil.rmtree(tmpdir, ignore_errors=True)

    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    return ok


def t_adj() -> bool:
    """复权口径回归：除权日不能用「原始价 vs 复权历史」直接比，也不能拼出假跳空。

    全程离线：自己造两天 K 线，再用报价补第三天，检查写回值。
    """
    section("9 复权口径（除权会不会把 20 日高点顶高）")
    import shutil
    import tempfile

    tmpdir = Path(tempfile.mkdtemp())
    checks: list[tuple[str, bool, str]] = []

    def new_store(name: str, rows: list[tuple[str, str, float, float | None]]) -> kline.Store:
        st = kline.Store(tmpdir / f"{name}.sqlite")
        st.put_many(rows)
        return st

    # ① 平推：10-28=10.0、10-29=11.0，报价 12.1 / 昨收 11.0 → 当日应记为 12.1
    st = new_store("flat", [("600000", "2026-10-28", 10.0, 10.0),
                            ("600000", "2026-10-29", 11.0, 11.0)])
    q1 = {"600000": {"price": 12.1, "prev_close": 11.0, "chg_pct": 0.1, "ts": "20261030150000"}}
    w1 = kline.append_from_quotes(st, q1, "2026-10-30")
    got = st.bars("600000", "2026-10-30", 1)[0][1]
    checks.append(("平推：当日复权值 == 原始收盘", abs(got - 12.1) < 1e-9, f"{got}"))
    w1b = kline.append_from_quotes(st, q1, "2026-10-30")
    checks.append(("同一天重复写入被跳过（幂等）", w1b["written"] == 0, f"written={w1b['written']}"))
    st.close()

    # ② 除权：1 拆 2。历史在复权序列里是 20.0/22.0，当日实际价 12.1、昨收 11.0（未拆前是 22.0）
    #    → 写回值必须是 24.2，序列比值 24.2/22.0 = 12.1/11.0，与原始收益率一致。
    st = new_store("ex", [("600000", "2026-10-28", 20.0, 10.0),
                          ("600000", "2026-10-29", 22.0, 11.0)])
    q2 = {"600000": {"price": 12.1, "prev_close": 11.0, "chg_pct": 0.1, "ts": "20261030150000"}}
    kline.append_from_quotes(st, q2, "2026-10-30")
    b = st.bars("600000", "2026-10-30", 3)
    ratio = b[0][1] / b[1][1]
    checks.append(("除权日：序列连续，无假跳空",
                   abs(b[0][1] - 24.2) < 1e-6 and abs(ratio - 12.1 / 11.0) < 1e-9,
                   f"当日 {b[0][1]:.2f} / 昨 {b[1][1]:.2f} = {ratio:.6f}"))

    # ③ 除权当日的「没拆之前」是对的：若误用历史原始价当锚点，会算出 12.1×22/11 = 24.2 也“碰巧”
    #    对，所以再验一次反向：3 并 1（合股），历史 ÷3，当日 ×3。
    st2 = new_store("rev", [("600001", "2026-10-28", 3.0, 9.0),
                            ("600001", "2026-10-29", 3.3, 9.9)])
    q3 = {"600001": {"price": 27.0, "prev_close": 29.7, "chg_pct": -0.09, "ts": "20261030150000"}}
    kline.append_from_quotes(st2, q3, "2026-10-30")
    b2 = st2.bars("600001", "2026-10-30", 2)
    checks.append(("合股：同样按昨收折算，比值 = -9%",
                   abs(b2[0][1] / b2[1][1] - 27.0 / 29.7) < 1e-9,
                   f"{b2[0][1]:.2f}/{b2[1][1]:.2f}"))
    st2.close()

    # ④ 换算后日涨跌幅超出交易所上限（>31%）→ 拒写，等重拉，不能污染窗口
    st3 = new_store("bad", [("600002", "2026-10-29", 10.0, 10.0)])
    q4 = {"600002": {"price": 30.0, "prev_close": 10.0, "chg_pct": 2.0, "ts": "20261030150000"}}
    w4 = kline.append_from_quotes(st3, q4, "2026-10-30")
    checks.append(("异常涨幅拒写", w4["written"] == 0 and "600002" in w4["skipped_codes"],
                   f"written={w4['written']}"))
    st3.close()

    # ⑤ 非交易日：报价交易日与 as_of 不一致 → 整轮拒写（周日跑不会造假 K 线）
    st4 = new_store("wk", [("600003", "2026-10-29", 10.0, 10.0)])
    q5 = {"600003": {"price": 10.5, "prev_close": 10.0, "chg_pct": 0.05, "ts": "20261030150000"}}
    w5 = kline.append_from_quotes(st4, q5, "2026-11-01")
    checks.append(("非交易日拒写", w5["written"] == 0 and w5["skipped"] and
                   st4.bars("600003", "2026-11-01", 1)[0][0] == "2026-10-29",
                   f"skipped={w5['skipped']}"))
    st4.close()

    # ⑥ 建库整只替换：旧口径残留不能留下（复权序列不可跨源拼接）
    st5 = new_store("rep", [("600004", "2026-10-01", 1.0, 1.0),
                            ("600004", "2026-10-02", 2.0, 2.0)])
    st5.replace_many({"600004": [("2026-10-29", 9.0, None), ("2026-10-30", 9.5, None)]})
    left = [d for d, _ in st5.bars("600004", "2026-10-30", 10)]
    checks.append(("重拉整只替换，不留旧口径残行", left == ["2026-10-30", "2026-10-29"], f"{left}"))
    st5.close()

    shutil.rmtree(tmpdir, ignore_errors=True)
    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    return ok


def t_panel_clip() -> bool:
    """面板 as_of 截断（离线）：上游历史接口没有日期上限，回溯时必须自己切。

    造一个「返回 as_of 之后行」的桩客户端：截断生效则 by_date 的最大日期 == as_of、
    现役板块数 == 2；截断失效则会带出 11-05 且两个板块全被判停更（RuntimeError）。
    """
    section("6 面板 as_of 截断（历史回溯不前视）")
    from pipeline import panel  # noqa: PLC0415

    as_of, later = "2026-10-30", "2026-11-05"

    def row(code, name, d, pct, net, ratio):
        return {"BOARD_CODE": code, "BOARD_NAME": name, "TRADE_DATE": d,
                "CHANGE_RATE": pct, "NET_INFLOW": net, "NET_INFLOW_RATIO": ratio}

    class Stub:
        def get_json(self, url):  # noqa: ANN001
            if "BOARD_CODE%3D%22" in url:
                code = url.split("BOARD_CODE%3D%22")[1][:6]
                name = {"BK9001": "测试板块A", "BK9002": "测试板块B"}[code]
                return {"result": {"data": [
                    row(code, name, later, 3.0, 5e7, 4.0),
                    row(code, name, as_of, 1.5, 1e8, 5.0),
                    row(code, name, "2026-10-29", -0.5, -2e7, -2.0),
                ]}}
            return {"result": {"data": [
                row("BK9001", "测试板块A", as_of, 1.5, 1e8, 5.0),
                row("BK9002", "测试板块B", as_of, 0.8, 3e7, 3.0),
            ]}}

        def map(self, fn, codes):  # noqa: ANN001
            return [fn(c) for c in codes]

    p = panel.build(Stub(), as_of, "2025-09-15", verbose=False)
    dates = sorted(p["by_date"])
    max_d = dates[-1]
    tail = {c: max(d for d, _ in v) for c, v in p["history"].items()}
    checks = [
        ("by_date 不含 as_of 之后的日期", max_d == as_of and later not in p["by_date"], f"max={max_d} 共 {len(dates)} 日"),
        ("个别板块 history 截止到 as_of", set(tail.values()) == {as_of}, f"{tail}"),
        ("板块判为现役而非停更", len(p["boards"]) == 2 and not p["stale"], f"live={len(p['boards'])} stale={p['stale']}"),
    ]
    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    return ok


def t_quotes_guard() -> bool:
    """报价快照的日期守卫（离线）：文件名不得与内容分叉。

    为什么值得单独一测：文件名叫 quotes-<as_of>.json，但回溯历史日时上游只给「最新」
    报价，历史版本会把 11-05 的成交额写进 quotes-2026-10-30.json。下游只按文件名取用，
    于是 score.leader_chg5 与 build_v16 的龙头梯队会用 11-05 的成交额去排 10-30 的龙头，
    静默选错票。这个错误不改变任何数字的量级，只换掉「谁排第一」，人工极难发现。
    """
    section("10 报价快照日期守卫（文件名==内容）")
    import tempfile  # noqa: PLC0415

    tmp = pathlib.Path(tempfile.mkdtemp(prefix="aml-quotes-"))
    today = {"600519": {"ts": "20261105150000", "price": 1500.0, "amount_yi": 80.0},
             "000001": {"ts": "20261105150000", "price": 12.0, "amount_yi": 30.0}}
    older = {"600519": {"ts": "20261030150000", "price": 1400.0, "amount_yi": 60.0},
             "000001": {"ts": "20261030150000", "price": 11.8, "amount_yi": 20.0}}

    w_today, d_today = quotes.save(tmp, "2026-11-05", today)      # 当日：应写入
    w_back, d_back = quotes.save(tmp, "2026-10-30", today)        # 回溯：应拒绝
    w_fresh, d_fresh = quotes.save(tmp, "2026-10-30", older)      # 真历史快照：应写入

    snap_bad, date_bad = quotes.load(tmp, "2026-10-30")
    got, got_date = quotes.load(tmp, "2026-11-05")
    miss, miss_date = quotes.load(tmp, "2026-09-01")

    checks = [
        ("当日快照正常落盘", w_today and d_today == "2026-11-05", f"written={w_today} date={d_today}"),
        ("回溯时拒绝写入（11-05 快照存成 10-30）", (not w_back) and d_back == "2026-11-05",
         f"written={w_back} 快照日={d_back}"),
        ("真历史快照照常写入", w_fresh and d_fresh == "2026-10-30", f"written={w_fresh} date={d_fresh}"),
        ("拒绝后文件内容不被改写", date_bad == "2026-10-30", f"quotes-2026-10-30 里是 {date_bad}"),
        ("load 返回快照自身交易日", got_date == "2026-11-05" and len(got) == 2, f"{len(got)} 只 / {got_date}"),
        ("缺文件返回空而非抛错", miss == {} and miss_date is None, f"{miss}, {miss_date}"),
    ]
    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    for f in tmp.glob("*.json"):
        f.unlink()
    tmp.rmdir()
    return ok


def t_share_window() -> bool:
    """份额统计的 250 日窗口（离线）：唯一实现，窗口不随样本变长而漂移。

    为什么值得测：P3 闸门用 share_pct_250 ≥ 0.60，而这个分位原本有两种算法——
    「全部可得交易日」与「最近 250 日」。面板从 169 天涨到 274 天后二者分叉，
    光伏在两种口径下分别是 0.5839（不过）与 0.6160（过），直接决定它是不是主线。
    这里锁死：超过 250 日时必须只取最近 250 日。
    """
    section("11 份额 250 日窗口（唯一实现，不随样本漂移）")
    from pipeline import panel  # noqa: PLC0415

    # 造 300 天：前 50 天份额 10.0（远高于今天），后 250 天从 1.0 缓升到今天 1.249。
    # 全样本口径下今天只排到 250/300=0.833；250 日窗口下今天是窗口内最高=1.0。
    by_date, market = {}, {}
    for i in range(300):
        d = f"D{i:04d}"
        share = 10.0 if i < 50 else 1.0 + (i - 50) * 0.001
        by_date[d] = {"BK0001": {"amount": share, "net": 0.0}}
        market[d] = 1.0
    fake = {"by_date": by_date, "market_amount": market}

    st = panel.share_stats(fake, "BK0001")
    full = sum(1 for i in range(300) if (10.0 if i < 50 else 1.0 + (i - 50) * 0.001) <= 1.249) / 300
    checks = [
        ("样本数取全部可得交易日", st["samples"] == 300, f"samples={st['samples']}"),
        ("分位只用最近 250 日（=1.0，而非全样本的 0.833）",
         abs(st["share_pct_250"] - 1.0) < 1e-9, f"pct={st['share_pct_250']} 全样本口径={full:.3f}"),
        ("份额与 5 日变化与窗口无关", abs(st["share"] - 1.249) < 1e-9 and abs(st["share_chg_5"] - 0.005) < 1e-9,
         f"share={st['share']} d5={st['share_chg_5']}"),
    ]
    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    return ok


def t_narrative() -> bool:
    """叙事分（离线）：档位推导、未评≠0、边界裁决、与权重口径一致。

    为什么值得测：v1.7 把叙事分移出总分是为了消灭「先入榜再打分」的自我确认，
    但只移权重留了三个洞——①分数仍是手填，78 这种挡不住；②未评与 0 分混成一个数；
    ③移出总分后它彻底不参与排序，成了纯装饰。v1.8 用 (evidence, source) 推导分数
    堵前两个洞，用 pick_top 的边界裁决补第三个。这三条各自都会静默失效：
    台账写错不会报错、未评写成 0 读者看不出来、裁决阈值调大调小没人发现。
    """
    section("12 叙事分（档位推导 / 未评≠0 / 边界裁决）")
    from pipeline import narrative as nv  # noqa: PLC0415
    from pipeline.score import NARRATIVE_WEIGHT, TOTAL_W, WEIGHTS  # noqa: PLC0415

    checks: list[tuple[str, bool, str]] = []

    # ① 分档表：证据条数 × 来源等级。
    table = [
        ((0, "data"), 0, "0 条 → 0"),
        ((1, "report"), 40, "1 条 + 研报 0"),
        ((2, "media"), 65, "2 条 60 + 媒体 5"),
        ((2, "rumor"), 50, "2 条 60 + 传闻 −10"),
        ((3, "media"), 80, "3 条 75 + 媒体 5"),
        ((3, "announcement"), 85, "3 条 75 + 公告 10"),
        ((3, "official"), 90, "3 条 75 + 官方 15"),
        ((4, "media"), 90, "4 条 85 + 媒体 5"),
        ((9, "official"), 100, "≥4 条封顶 85 + 官方 15 = 100"),
    ]
    bad = [(ev, src, want, nv.derive(ev, src)) for (ev, src), want, _ in table
           if nv.derive(ev, src) != want]
    checks.append(("分档表 9 档全部吻合", not bad, str(bad) if bad else "0/1/2/3/≥4 条 × 6 档来源"))

    # ② 未评是 None，0 条证据是真的 0 分。这两个数在报告里长得像，含义完全不同。
    checks.append(("未评 → None（不是 0 分）", nv.derive(None, None) is None,
                   f"derive(None, None)={nv.derive(None, None)}"))
    checks.append(("0 条证据 → 0 分（是有效取值）", nv.derive(0, "data") == 0,
                   f"derive(0, data)={nv.derive(0, 'data')}"))

    # ③ 台账自洽：手填的中间档必须被拦住。
    caught = ""
    try:
        nv.parse_entry("BK9999", {"score": 78, "evidence": 3, "source": "media"})
    except nv.NarrativeError as e:
        caught = str(e)
    checks.append(("手填 78（3 条 + 媒体应为 80）被拒", bool(caught), caught or "未拦住"))
    try:
        nv.parse_entry("BK9999", {"score": 80, "evidence": 3, "source": "媒体"})
        caught_src = ""
    except nv.NarrativeError as e:
        caught_src = str(e)
    checks.append(("未知来源等级被拒", bool(caught_src), caught_src or "未拦住"))
    ok_entry = nv.parse_entry("BK1277", {"evidence": 3, "source": "media", "score": 80})
    checks.append(("自洽条目正常解析且 score 为整数", ok_entry["score"] == 80
                   and isinstance(ok_entry["score"], int), str(ok_entry)))

    # ④ 边界裁决：只有 |Δ|<1 且叙事分更高才换座次。
    def rows_of(a_score, b_score):
        return [{"code": "AAA", "name": "甲", "score": a_score},
                {"code": "BBB", "name": "乙", "score": b_score}]

    ent = {"AAA": {"score": 60}, "BBB": {"score": 90}}
    top, _, info = nv.pick_top(rows_of(80.0, 79.4), 1, ent)
    checks.append(("Δ=0.6 <1 且叙事 90>60 → 乙上位", info["applied"] and top[0]["code"] == "BBB",
                   f"applied={info['applied']} top={top[0]['name']} 保留原分 {top[0]['score']}"))
    top2, _, info2 = nv.pick_top(rows_of(80.0, 78.9), 1, ent)
    checks.append(("Δ=1.1 ≥1 → 不裁决（分数优先）", (not info2["applied"]) and top2[0]["code"] == "AAA",
                   f"applied={info2['applied']} top={top2[0]['name']}"))
    top3, _, info3 = nv.pick_top(rows_of(80.0, 79.4), 1, {"AAA": {"score": 90}, "BBB": {"score": 60}})
    checks.append(("Δ<1 但叙事更低 → 不换", (not info3["applied"]) and top3[0]["code"] == "AAA",
                   f"applied={info3['applied']}"))
    top4, _, info4 = nv.pick_top(rows_of(80.0, 79.4), 1, {"AAA": {"score": 90}})
    checks.append(("一方未评 → 维持分数顺序", (not info4["applied"]) and top4[0]["code"] == "AAA",
                   info4["reason"]))
    _, _, none_info = nv.pick_top(rows_of(80.0, 79.4), 5, ent)
    checks.append(("候选数不足 TOP_N → 无边界可裁", none_info is None, "info=None"))

    # ⑤ 权重口径：叙事分不进算术，五项合计 90。
    checks.append(("WEIGHTS 不含 narrative 且合计 90",
                   "narrative" not in WEIGHTS and TOTAL_W == 90 and NARRATIVE_WEIGHT == 0,
                   f"TOTAL_W={TOTAL_W} NARRATIVE_WEIGHT={NARRATIVE_WEIGHT}"))

    # ⑥ 真实台账：11-05 的候选池必须全覆盖（cache 在才算，回溯环境可能没有）。
    sc_p = ROOT / "pipeline" / "cache" / "score-2026-11-05.json"
    if sc_p.exists():
        nsc = json.loads(sc_p.read_text(encoding="utf-8")).get("narrative") or {}
        cov = nsc.get("coverage") or {}
        checks.append(("11-05 候选池叙事全覆盖", bool(cov.get("complete")),
                       f"{cov.get('evaluated')}/{cov.get('total')}"
                       + (f" 缺 {'、'.join(cov['missing'])}" if cov.get("missing") else "")))
    else:
        print("  · 跳过 11-05 覆盖检查（无 score 缓存）")

    ok = True
    for name, passed, detail in checks:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= bool(passed)
    return ok


def t_indices_guard() -> bool:
    """指数写入守卫（离线）：中证全指取不到时不得覆盖已有的好数据。

    为什么值得测：`indices.build()` 对每只指数都 try/except 兜住，EndpointBlocked 只记进
    `errors`，main 看不到异常。于是「8 个指数涨幅全 null」的结果会覆盖上一轮的好文件，
    下游 factors 回落到 FALLBACK_IDX_REF（10-30 常量，20 日 −14.44% vs 当日 −6.26%），
    128 个板块的 rs 与全部分数一起偏，而 daily 返回 0。2026-11-05 连续第三次重跑实测触发。
    """
    section("13 指数写入守卫（基准取不到时拒绝覆盖）")
    from pipeline import indices  # noqa: PLC0415

    def mk(chg20, code="000985.CSI"):
        return {"indices": [{"code": code, "chg_20d": chg20}]}

    prev_ok = mk(-0.0626)
    cases = [
        ("新结果缺基准 + 旧有值 → 拒绝", indices.refuse_overwrite(mk(None), prev_ok)[0] is True,
         indices.refuse_overwrite(mk(None), prev_ok)[1]),
        ("新结果有基准 → 放行", indices.refuse_overwrite(mk(-0.0626), prev_ok)[0] is False, "正常写入"),
        ("两边都缺 → 放行（下游会记 fallback）",
         indices.refuse_overwrite(mk(None), mk(None))[0] is False, "无历史可保"),
        ("旧文件不存在 → 放行", indices.refuse_overwrite(mk(None), None)[0] is False, "首次运行"),
        ("缺的是别的指数、基准还在 → 放行",
         indices.refuse_overwrite({"indices": [{"code": "000001.SH", "chg_20d": None},
                                               {"code": "000985.CSI", "chg_20d": -0.06}]},
                                  prev_ok)[0] is False, "只有基准是关键"),
    ]
    ok = True
    for name, passed, detail in cases:
        print(f"  {'✓' if passed else '✗'} {name}｜{detail}")
        ok &= passed
    return ok


def t_breadth_universe() -> bool:
    """广度分位（离线）：分母是全板块、三项同源、分数可复算。

    为什么值得测：旧口径只在「进了闸门的候选」里排分位（11-05 只有 9 个），
    三个病——样本太细（每档 11%）、样本本身全是强票（出版 89.3% 排 18.2 分位）、
    分母随当天候选数量漂移。这三条都不会报错，只会让分数看起来"有依据"。
    """
    from pipeline import boardbreadth  # noqa: PLC0415
    from pipeline.score import pct_in  # noqa: PLC0415

    section("15 广度分位（全板块同分母）")
    checks: list[tuple[str, bool, str]] = []
    as_of = "2026-11-05"
    bb = boardbreadth.load(as_of)
    sc = json.loads((ROOT / "pipeline" / "cache" / f"score-{as_of}.json").read_text(encoding="utf-8"))

    checks.append(("广度表排名板块 ≥120", bb["ranked"] >= 120,
                   f"universe={bb['universe']} ranked={bb['ranked']}"))
    checks.append(("score 记录的分母与广度表一致",
                   sc["cross_section"].get("breadth_universe") == bb["ranked"],
                   f"score={sc['cross_section'].get('breadth_universe')} vs bb={bb['ranked']}"))
    p2 = sc["cross_section"].get("p2_boards") or 0
    checks.append(("分母显著大于候选数（不是旧口径）", bb["ranked"] >= 5 * max(p2, 1),
                   f"ranked={bb['ranked']} p2_boards={p2}"))

    uni = {k: v for k, v in bb["boards"].items() if v.get("ranked")}
    S = {k: [v[k] for v in uni.values()]
         for k in ("up_ratio", "strong_ratio", "limit_up_ratio")}
    bad = []
    for row in sc["rows"][:6]:
        u = bb["boards"].get(row["code"])
        if not u:
            continue
        calc = round(pct_in(S["up_ratio"], u["up_ratio"]) * 0.40
                     + pct_in(S["strong_ratio"], u["strong_ratio"]) * 0.35
                     + pct_in(S["limit_up_ratio"], u["limit_up_ratio"]) * 0.25, 2)
        if abs(calc - row["norm"]["breadth"]) > 0.02:
            bad.append(f"{row['name']} {calc} vs {row['norm']['breadth']}")
    checks.append(("n_br 可由广度表三项复算", not bad, "; ".join(bad) or "前 6 名逐位吻合"))

    # 三项必须来自同一批板块：任一成分的样本量都应等于 ranked
    small = [v["name"] for v in list(uni.values())[:1] if v["valid"] < 5]
    checks.append(("样本内没有 <5 只成分的板块", not small, str(small) or f"{len(uni)} 个板块 valid≥5"))

    for name, ok, detail in checks:
        print(f"  {'✓' if ok else '✗'} {name:<28} {detail}")
    return all(ok for _, ok, _ in checks)


def main() -> int:
    full = "--full" in sys.argv
    cli = http.make_client(workers=4, max_rps=4, min_span=0)

    ok = t_contract(cli)
    if not ok:
        print("\n契约未通过，按设计中止后续步骤。请修数据源后重跑。")
        return 2

    codes = _all_codes(cli) if full else _board_codes(cli, BAIJIU)
    if full:
        print(f"\n  全量模式：{len(codes)} 只成分股（{len(BOARDS)} 个板块去重）")

    q = t_quotes(cli, codes)
    store = t_kline(cli, codes)
    groups = {name: _board_codes(cli, code) for code, name in BOARDS} if full else {BAIJIU: codes}
    t_breadth(store, q, groups)
    store.close()

    rep_ok = t_report()
    clip_ok = t_panel_clip()
    t_circuit()
    gap_ok = t_gap()
    adj_ok = t_adj()
    guard_ok = t_quotes_guard()
    window_ok = t_share_window()
    narr_ok = t_narrative()
    br_ok = t_breadth_universe()
    idx_ok = t_indices_guard()

    section("汇总")
    s = cli.stats.as_dict()
    print(f"  请求统计 {s}")
    print(f"  总请求耗时 {s['seconds']:.1f}s | 下载 {s['bytes'] / 1024:.0f}KB | 失败 {s['failed']} | 熔断 {s['blocked']}")
    print(f"  报告往返：{'一致' if rep_ok else '不一致'}")
    print(f"  面板截断：{'全部通过' if clip_ok else '有失败项'}")
    print(f"  快照守卫：{'全部通过' if guard_ok else '有失败项'}")
    print(f"  份额窗口：{'全部通过' if window_ok else '有失败项'}")
    print(f"  叙事分：{'全部通过' if narr_ok else '有失败项'}")
    print(f"  广度分位：{'全部通过' if br_ok else '有失败项'}")
    print(f"  指数守卫：{'全部通过' if idx_ok else '有失败项'}")
    print(f"  缺口回归：{'全部通过' if gap_ok else '有失败项'}")
    print(f"  复权口径：{'全部通过' if adj_ok else '有失败项'}")
    return 0 if (rep_ok and clip_ok and guard_ok and window_ok and narr_ok and br_ok and idx_ok
                 and gap_ok and adj_ok) else 1


def _board_codes(cli: http.Client, board: str) -> list[str]:
    cache = ROOT / "pipeline" / "cache" / f"codes-{board}.json"
    if cache.exists():
        return json.loads(cache.read_text(encoding="utf-8"))
    url = (
        "https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_BOARD_CONSTITUENT"
        f"&columns=BOARD_CODE_BK,SECURITY_CODE&pageNumber=1&pageSize=500"
        f"&filter=(BOARD_CODE_BK%3D%22{board}%22)"
    )
    j = cli.get_json(url)
    rows = ((j.get("result") or {}).get("data")) or []
    codes = [r["SECURITY_CODE"] for r in rows if r.get("SECURITY_CODE")]
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(codes, ensure_ascii=False), encoding="utf-8")
    return codes


def _all_codes(cli: http.Client) -> list[str]:
    """上一轮实算的 8 个候选板块，去重后 232 只。"""
    seen: dict[str, None] = {}
    for code, _name in BOARDS:
        for c in _board_codes(cli, code):
            seen.setdefault(c, None)
    return list(seen)


def _baijiu_codes(cli: http.Client) -> list[str]:
    return _board_codes(cli, BAIJIU)


if __name__ == "__main__":
    raise SystemExit(main())

"""板块日线：push2his 直出成交额与收盘价。

**为什么需要它**：`RPT_INDUSTRY_FUNDFLOW` 只给净额与净额占比，没有成交额字段
（columns=ALL 实测过，返回的 15 个字段里没有任何金额总量）。所以历史上是用
「净额 ÷ 占比」在五个分档里取中位数反推 —— 正常日误差 0.00%，但净流入趋近 0 的
横盘日会把分母压得很小，误差被放大：全样本 1442 个板块日的实测分布是
中位 0.08% / P75 0.67% / P90 2.89% / P99 15.07% / 最大 19.2%，光伏这类资金流
常年贴零的板块中位误差就有 1.74%。

而份额、Δ5/Δ20、volume 因子（22 分）、P3 闸门（阈值仅 0.5pct）全建在这个量上，
所以误差不是「显示好看不好看」，是会改闸门归属的。

push2his 的板块日线（secid=90.BKxxxx）直接给成交额（第 7 列，单位元）和收盘价，
每板块 1 次请求。2026-11-05 实测：光伏 561.1 亿、游戏 180.8 亿、半导体 2984.2 亿，
与「成员股成交额加总」逐位一致（误差 0.00%），可作真值。

历史背景：本模块的 docstring 原先写「push2his kline 被应用层封禁」——那是
2026-11-01 那轮的临时封锁，现已恢复。仍然保留反推路径做兜底：真值缺失（板块
停更、接口偶发失败）时退回 `panel.amount_from_flow`，并在面板里标 `amount_src`，
让下游知道这一行的分母是什么口径。
"""
from __future__ import annotations

from .http import Client

KL = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
# f51 日期 f52 开 f53 收 f54 高 f55 低 f56 成交量(手) f57 成交额(元) f58 振幅
FIELDS2 = "f51,f52,f53,f54,f55,f56,f57,f58"


def _num(s: str) -> float | None:
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def fetch(client: Client, code: str, lmt: int = 500) -> dict[str, dict]:
    """单板块日线，返回 {日期: {open,close,high,low,vol,amount}}。

    失败返回空 dict（不抛）：面板层会退回反推口径，不该因为一个板块让整轮失败。
    """
    url = (f"{KL}?secid=90.{code}&fields1=f1,f2,f3,f7&fields2={FIELDS2}"
           f"&klt=101&fqt=0&end=20500101&lmt={lmt}")
    try:
        j = client.get_json(url)
    except Exception:  # noqa: BLE001
        return {}
    rows = ((j.get("data") or {}).get("klines")) or []
    out: dict[str, dict] = {}
    for s in rows:
        f = s.split(",")
        if len(f) < 7:
            continue
        amt = _num(f[6])
        close = _num(f[2])
        if amt is None or close is None or amt <= 0:
            continue
        out[f[0]] = {
            "open": _num(f[1]), "close": close, "high": _num(f[3]), "low": _num(f[4]),
            "vol": _num(f[5]), "amount": amt,  # 元
        }
    return out

"""把某一天的报告注入 index.html，生成一份可直接双击打开的成品页。

    python -m pipeline.embed_report --as-of 2026-11-02

与 build_embed.py 的区别：后者把 samples/sample-report.json 当默认数据（会覆盖 index.html），
本模块只读 index.html、另存为 report-<as_of>.html，并把 STORAGE_KEY 换成按日期的键，
避免浏览器里残留的上一份报告通过 localStorage 把当天结论顶掉。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
from datetime import datetime
from pathlib import Path

from pipeline import cacheio, day

ROOT = Path(__file__).resolve().parent.parent


def indent(text: str, n: int = 2) -> str:
    pad = " " * n
    return "\n".join(pad + ln if ln.strip() else ln for ln in text.split("\n"))


def js_obj(o) -> str:
    return indent(json.dumps(o, ensure_ascii=False, indent=2))


def main() -> None:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--src", default="")
    ap.add_argument("--publish", action="store_true",
                    help="生成后复制到 public/radar 与 dist/radar，并校验 md5")
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)

    src = ROOT / (args.src or f"aml-{args.as_of.replace('-', '')}-v16.json")
    report = json.loads(io.open(src, encoding="utf-8").read())
    prompt = io.open(ROOT / "prompt" / "ashare-mainline-prompt.md", encoding="utf-8").read()
    schema = json.loads(io.open(ROOT / "schema" / "ashare-mainline.schema.json", encoding="utf-8").read())
    template = json.loads(io.open(ROOT / "samples" / "empty-template.json", encoding="utf-8").read())

    block = ("const EMBEDDED = {\n"
             "  sample: " + js_obj(report) + ",\n"
             "  schema: " + js_obj(schema) + ",\n"
             "  template: " + js_obj(template) + ",\n"
             "  prompt: " + json.dumps(prompt, ensure_ascii=False).replace("</", "<\\/") + "\n"
             "};")

    html = io.open(ROOT / "index.html", encoding="utf-8").read()
    pat = re.compile(r"const EMBEDDED = \{[\s\S]*?\n\};")
    if not pat.search(html):
        raise SystemExit("未找到 EMBEDDED 块")
    html = pat.sub(lambda m: block, html, count=1)
    html = html.replace("const STORAGE_KEY = 'aml-report-v1';",
                        f"const STORAGE_KEY = 'aml-report-{args.as_of}';")
    # 页面构建标识：草稿（localStorage）只认同一份构建，否则重建后仍会显示上一版
    # 归一化的结果——例如旧模板把 stage 清空后存盘，重开永远是一份空 stage 的报告，
    # 而页面上没有任何线索说明它读的不是文件。页脚也会显示这个时间，便于辨认旧页面。
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    if "const BUILD_ID = 'dev';" not in html:
        raise SystemExit("未找到 BUILD_ID 占位符")
    html = html.replace("const BUILD_ID = 'dev';", f"const BUILD_ID = '{stamp}';")
    dest = ROOT / f"report-{args.as_of}.html"
    cacheio.write_text(dest, html)
    print(f"  -> {dest.name}  {len(html.encode('utf-8')) / 1024:.0f} KB / "
          f"{len(report['mainlines'])} 条主线")

    if args.publish:
        repo = ROOT.parent.parent
        src_md5 = hashlib.md5(dest.read_bytes()).hexdigest()
        targets = [repo / "public" / "radar" / "index.html",
                   repo / "dist" / "radar" / "index.html"]
        copied = 0
        for t in targets:
            if not t.parent.exists():
                print(f"  [warn] 发布跳过 {t.relative_to(repo)}：目录不存在")
                continue
            cacheio.write_bytes(t, dest.read_bytes())
            if hashlib.md5(t.read_bytes()).hexdigest() != src_md5:
                raise SystemExit(f"[FATAL] 发布校验失败：{t}")
            copied += 1
            print(f"  -> {t.relative_to(repo)}  md5 {src_md5[:8]}")
        if not copied:
            raise SystemExit("[FATAL] 发布失败：public/radar 与 dist/radar 均不存在")


if __name__ == "__main__":
    main()

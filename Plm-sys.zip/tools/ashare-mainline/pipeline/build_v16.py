"""按 v1.6 契约组装完整报告（通用版：任意条主线，数值全部从缓存现算）。

    python -m pipeline.build_v16 --as-of 2026-11-02 --out aml-20261102-v16.json

与 build_report.py 的区别：后者是 2026-10-30 那一轮单主线的手写稿；本模块把
metrics / persistence / score_breakdown / 闸门矩阵 / 轮动榜全部由 cache 现算，
文字部分集中在 CONTENT 里，换一天只要改 as_of 与文字。数值口径与 score.py 逐项对齐，
组装完做一致性自检（score = Σ贡献 − 惩罚、闸门条数与 metrics 自洽、rs.raw == rs_20）。
"""
from __future__ import annotations

import argparse
import json
import pickle
import re
import sqlite3
import statistics
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import boardbreadth, day, margin  # noqa: E402
from pipeline import narrative  # noqa: E402
from pipeline import quotes as qmod  # noqa: E402
from pipeline.score import TOTAL_W, WEIGHTS, effective_weight, pct_in  # noqa: E402

C = ROOT / "pipeline" / "cache"

# ---------------------------------------------------------------- 文字内容
# 叙事分不在本文件里判定：drivers 是文案素材（写给读者看），不是证据台账。
# 两者的口径不同——drivers 里可以有三条全是本地行情复算，那样叙事分应当只有 75（data +0），
# 而 CONTENT 的「4 条证据」读起来像 90。分数一律从 templates/narrative.json 读，
# 由 pipeline/narrative.py 按 (evidence, source) 推导；本文件只消费，不重算、不假设。
# 阶段英文键 → 中文标签。CONTENT 里每条文案自带 stage_label，但 emerging 的板块
# 没有 CONTENT 条目，需要在 signal 里现取一个可比对的标签。
STAGE_CN = {"ignition": "启动期", "expansion": "发酵期", "trend": "主升期",
            "acceleration": "加速期", "divergence": "分歧期", "fade": "退潮期"}

CONTENT_AS_OF = "2026-11-09"   # 下面这份文案是给哪一天写的；换天必须重写，不是复用

# 上一版（v1.8，同一基准日）的分数快照，只用来在 changelog 里写「这次口径改了多少分」。
# 不参与任何计算。11-09 的入榜主线银行Ⅱ 在 v1.8 口径下未入榜，没有可比分数，故留空。
PRIOR_SCORES_V18: dict[str, float] = {}

CONTENT = {
    "BK0475": {
        "id": "ml-bank",
        "name": "银行Ⅱ",
        "theme_type": "industry",
        "aliases": ["高股息防御", "大金融避险", "中特估-银行", "中期分红季"],
        "stage_label": "发酵期",
        "stage_confidence": 0.60,
        "rank_change": 0,
        "logic": (
            "银行是本期唯一「闸门 2 条 + 阶段可判定」的板块，但驱动力不是产业景气，而是缩量市里的相对强度："
            "20 日 +1.58% 对中证全指 −6.77%（超额 8.35pct）、60 日 +9.34% 对 −14.36%（超额 23.70pct），"
            "rs_20 1.0895 排 128 个板块第 94.53 分位。42 只成分股 37 只上涨（88.1%）、13 只创 20 日新高（30.95%），"
            "在全市场 3147 家下跌的背景下是唯一的普涨面，P2 广度闸门由此通过。"
            "但它同时是 5 日份额流出第三多的板块（Δ5 −0.87pct，分位 2.34）——价格没跌、钱在走，"
            "这是「存量避险」而非「增量进攻」的结构，也是发酵期只能给 0.60 置信度的原因。"
        ),
        "catalyst": (
            "分红季是最近的一根引线：中国银行 11-09 公告中期股息每 10 股派 1.19 元、除净日 2026-12-02，"
            "其余大行将陆续跟进，配置盘拿到的是可计算的现金回报；"
            "11-02 央行公告「为支持资本市场健康稳定发展」于 11-03 开展互换便利操作（期限 1 年、可视情展期），"
            "流动性环境对高股息资产友好。当日银行 4 只创历史新高、4 只获机构买入评级，"
            "说明年末险资与被动资金的再配置正在发生。"
        ),
        "sustainability": (
            "持续性只看一个变量：份额能不能止血。当前 Δ5 −0.87pct（128 个板块分位 2.34，倒数第三）、"
            "5 日主力净额 −0.74%，说明 88.1% 的上涨是存量筹码在板块内部腾挪，不是增量资金进场。"
            "广度真实、量能缺席——这种组合能撑住防御，撑不起主升。发酵期要往主升期走，"
            "必须先看到 Δ5 转正、成交额份额回到 2.9% 以上（本期 2.05%）；否则它会在 60~70 分区间反复。"
        ),
        "bear_case": (
            "最硬的反证是：银行涨本身就是风险偏好收缩的镜像。本期成交额 14943.9 亿，跌破 1.5 万亿，"
            "较 11-06 再缩约 1770 亿；指数只有沪指 +0.32%，全市场仍是 3147 家下跌。"
            "资金是在缩量里被动抱团，不是在增量里主动做多。一旦指数企稳或出现新题材，避险盘会最先撤离；"
            "60 日已涨 9.34%、拥挤度 0.8946 距 R2 的 0.90 只差 0.0054，高股息交易的拥挤度也在累积。"
        ),
        "drivers": [
            {"type": "event",
             "title": "中国银行中期股息：每 10 股派 1.19 元，除净日 12-02",
             "detail": "中国银行（03988.HK）11-09 公告派发截至 2026-06-30 止六个月的中期股息，每 10 股 1.19 元人民币，"
                       "除净日 2026-12-02、派发日 2027-01-22。大行中期分红进入落地期。",
             "date": "2026-11-09", "source": "中国银行公告 / 南方财经网转引", "verified": True},
            {"type": "industry",
             "title": "银行 4 只收盘价创历史新高，是当日最集中的行业",
             "detail": "证券时报统计当日创历史新高个股中银行 4 只（南京银行、长沙银行、成都银行等）、汽车 2 只、传媒 1 只；"
                       "创新高个股当日平均上涨 3.73%。",
             "date": "2026-11-09", "source": "证券时报网 · 收盘价创历史新高股一览", "verified": True},
            {"type": "industry",
             "title": "25 股获机构买入评级，银行占 4 只",
             "detail": "机构评级分布中银行 4 只、非银金融 2 只，是当日最受机构关注的两个行业。",
             "date": "2026-11-09", "source": "证券时报网", "verified": True},
        ],
        "leader_note": {
            "601398": "成交额 30.77 亿居首、当日 +2.01%，8.61 元站上 MA20 8.50，20 日 +3.87%；体量与流动性最好，弹性最小",
            "600036": "29.32 亿、+0.30%，43.01 元高于 MA20 42.65，20 日仅 +0.58%；本期明显落后四大行，零售修复预期尚未变成超额",
            "601988": "22.86 亿、+2.19%，7.00 元仍在 MA20 7.02 下方，20 日 +0.43%；中期分红公告的当事主体，除净日 12-02",
            "601288": "22.10 亿、+1.51%，7.39 元高于 MA20 7.32，20 日 +4.67%；县域资产质量与高股息双属性，走势最稳",
            "601328": "15.69 亿、+1.81%，8.45 元高于 MA20 8.27，20 日 +7.10%；大行里 20 日涨幅最大的一只",
        },
        "ladder_note": (
            "梯队按成交额排、不按涨幅排：工行、招行、中行三只合计 82.95 亿，占板块成交额的大头。"
            "结构是「大行搭台、城商行唱戏」——南京银行、长沙银行、成都银行创历史新高，弹性来自中小行；"
            "四大行提供流动性与股息锚。全板块 0 家涨停、0 连板，这不是情绪驱动的梯队，是配置驱动的梯队，"
            "所以不能用「断板」这类情绪指标去跟踪它，要看份额与均线。"
        ),
        "invalidation": [
            {"condition": "广度塌陷",
             "threshold": "单日上涨占比 < 50%（本期 88.1%）且板块跌幅 > 1%",
             "note": "P2 闸门失效，主线降级为普通防御板块，不再具备入榜资格"},
            {"condition": "相对强度转弱",
             "threshold": "20 日 rs 跌出 128 板块前 20%（本期 94.53 分位）",
             "note": "超额收益的逻辑基础消失，60 日 +9.34% 的比较优势会被抹平"},
            {"condition": "龙头破位",
             "threshold": "工商银行收盘跌破 {ma20_601398} 元、招商银行跌破 {ma20_600036} 元",
             "note": "这是配置资金的成本线，破位意味着避险盘开始撤退，而不是洗盘"},
            {"condition": "拥挤度触线",
             "threshold": "拥挤度 > 0.90 且份额分位 > 0.90（本期 0.8946 / 0.844）",
             "note": "R2 触发 −6 分，高股息交易进入拥挤区，性价比让位于回撤风险"},
        ],
        "watch": [
            {"item": "5 日成交额份额变化能否转正（本期 −0.87pct、分位 2.34，倒数第三）",
             "why": "广度已经足够好，唯一缺的是增量；份额转正才意味着从被动避险升级为主动进攻"},
            {"item": "全市场成交额能否回到 1.7 万亿以上（本期 14943.9 亿）",
             "why": "缩量环境里银行的相对强度是被动获得的，成交额回升会立刻稀释它的超额"},
            {"item": "四大行中期分红的除净日与股息率（中行 12-02 打头）",
             "why": "分红是配置盘的核心持有理由，除净前后的资金行为决定这一波发酵的终点"},
            {"item": "创新高名单里城商行是否扩大（本期 13 只创 20 日新高）",
             "why": "中小行是这轮弹性的来源，名单收缩说明资金从进攻端退回大行防守"},
        ],
        "related": [],
    },
}

# 全局文字
# 全局文字
REGIME_NARRATIVE = (
    "11-09 是分化日：指数平稳、个股偏弱、量能继续退。沪指 +0.32% 收 3660.79 点、科创50 +0.30%、"
    "中证全指 +0.08%、沪深300 +0.05%、中证红利 +0.54%，深成指 −0.27%、创业板指 −0.27%、中证500 −0.17%。"
    "全市场 2242 家上涨对 3147 家下跌（上涨占比 0.4024、涨跌比 0.71），比 11-06 的 0.1360 修复近三倍，"
    "但绝对水平仍在五成以下；成交额 14943.9 亿，较 11-06 的 1.67 万亿再缩约 1770 亿，跌破 1.5 万亿。"
    "涨停 54 家、炸板 44 家、跌停 1 家、封板率 55.10%、最高 6 连板——涨停家数比 11-06 的 32 家多，"
    "但炸板率从 30.43% 升到 44.90%、封板率从 69.57% 掉到 55.10%，说明接力的钱不够。"
    "128 个板块中 49 个上涨、79 个下跌；涨幅前列是资源与超跌电子：焦炭Ⅱ +5.39%、燃气Ⅱ +3.25%、"
    "煤炭开采 +2.98%、元件 +2.49%（20 日仍 −17.91%）、厨卫电器 +2.44%、航天装备Ⅱ +1.92%、通信设备 +1.70%；"
    "跌幅前列是新能源与消费服务：能源金属 −2.27%、光伏设备 −2.22%、特钢Ⅱ −1.52%、旅游零售Ⅱ −1.46%、教育 −1.42%。"
    "20 日维度：中证全指 −6.77%、深成指 −10.01%、创业板指 −17.05%、科创50 −11.90%，只有中证红利 −1.01% 接近持平。"
    "两融余额 22833.5 亿（融资 22549.4 亿、融券 284.1 亿）、占流通市值 2.506%、250 日分位 0.004，"
    "20 日融资净买入 −2750.9 亿，去杠杆仍在延续。"
    "资金与价格继续分叉：5 日份额流入前三是光伏设备 +1.38pct（当日 −2.22%）、消费电子 +0.75pct、"
    "通信设备 +0.61pct；流出前三是证券Ⅱ −1.49pct、白酒Ⅱ −1.01pct、银行Ⅱ −0.87pct。"
    "涨得最多的资源三兄弟（焦炭Ⅱ +5.39%、燃气Ⅱ +3.25%、煤炭开采 +2.98%）份额几乎没有增量"
    "（+0.05 ~ +0.14pct），钱在往跌的板块里挪——这是存量高低切换，不是增量进攻。"
)

VERDICT_HEADLINE = "一条主线：银行Ⅱ 以广度入榜，量能仍是负的"

VERDICT_THESIS = (
    "本期 128 个板块里过 ≥2 条闸门的有 2 个：银行Ⅱ（P1+P2）与数字媒体（P1+P3）。"
    "但数字媒体五阶段判据最多只命中 1 项（fade 上涨 40.0%、divergence 份额分位 0.9886、"
    "acceleration 拥挤度 0.9904），stage 无法赋值，按 §4 只能改列萌芽、不得进 mainlines；"
    "于是主线只有银行Ⅱ 一条，阶段发酵期（份额分位 0.844 落在 0.60~0.85、上涨占比 88.1%，命中 2/4 判据）。"
    "分数最高的不是它：影视院线 78.87、游戏Ⅱ 78.14 都只有 1 条闸门，银行 {score} 排第 5——"
    "名次不能替代闸门，这是本报告反复坚持的一条。"
    "这条主线的性质必须说清楚：它是防御性发酵，不是进攻性发酵。"
    "42 只成分股 37 只上涨、13 只创 20 日新高，广度是真的；"
    "但份额 Δ5 −0.87pct（分位 2.34，倒数第三）、5 日主力净额 −0.74%，量能是缺的。"
    "20 日 +1.58% 对中证全指 −6.77% 的 8.35pct 超额，是在缩量里「少跌」换来的，不是「多涨」挣来的。"
    "上一期（11-06）是 0 条主线的空榜日，本期回到 1 条，但这条主线不足以支撑进攻仓位。"
)

VERDICT_POINTS = [
    {"title": "银行是唯一「闸门 2 条 + 阶段可判定」的板块，不是分数最高的",
     "detail": "银行Ⅱ P1 11/20 天、连续 2 天，P2 上涨 88.1%、新高 30.95%，两条闸门成立；"
               "expansion 判据命中 2/4（份额分位 0.844、上涨占比 88.1%），阶段可赋值。"
               "分数 {score} 只排第 5，前四名里影视院线 78.87、游戏Ⅱ 78.14 停在 1 条闸门，"
               "数字媒体 71.95、光伏设备 69.08 也都有各自的缺口——名次不能替代资格。"},
    {"title": "广度 88.1% 是真的，量能 −0.87pct 也是真的",
     "detail": "42 只成分股 37 只上涨、13 只创 20 日新高，在全市场 3147 家下跌的背景下是唯一普涨面；"
               "但 5 日成交额份额从 2.92% 降到 2.05%（Δ5 −0.87pct、128 板块分位 2.34、流出榜第三），"
               "5 日主力净额 −0.74%。价格与资金背离，说明这是存量筹码的内部腾挪，不是增量进场。"},
    {"title": "数字媒体 2 条闸门却进不了榜：阶段判据只命中 1 项",
     "detail": "P1 19/20 天、连续 6 天，P3 Δ5 +0.56pct、分位 0.9886，两条闸门成立且分数 71.95 高于银行；"
               "但上涨占比只有 40.0%、涨停 0 家，fade/divergence/acceleration/trend/ignition 各阶段最多命中 1 项，"
               "stage 无法赋值。按规则改列 emerging，不以「分数更高」为由破例。"},
    {"title": "市场层面：广度修复到 0.4024，成交额却跌破 1.5 万亿",
     "detail": "上涨 2242 家对下跌 3147 家，up_ratio 从 11-06 的 0.1360 修复到 0.4024；"
               "但成交额 14943.9 亿较 11-06 再缩约 1770 亿，封板率从 69.57% 降到 55.10%、炸板 44 家。"
               "指数微涨、个股仍跌多涨少、量能继续退——这是典型的缩量分化，不是反转。"},
]

RISKS = [
    {"id": "r1", "level": "high", "title": "银行的价格与资金背离：广度 88.1%，份额却流出到全市场第三",
     "detail": "5 日成交额份额从 2.92% 降到 2.05%（Δ5 −0.87pct，128 个板块分位 2.34），"
               "5 日主力净额 −0.74%；同期上涨占比 88.1%、新高 30.95%。涨的板块没有增量资金，"
               "这是存量筹码在板块内腾挪的特征，一旦存量转向，回撤会比指数更深。",
     "trigger": "连续 2 日 Δ5 为负且上涨占比跌破 60%",
     "mitigation": "不把这条主线当进攻仓；只在份额转正后考虑加仓，且加仓幅度不超过总仓位两成",
     "affected": ["ml-bank"]},
    {"id": "r2", "level": "high", "title": "拥挤度 0.8946，距 R2 惩罚线 0.90 只差 0.0054",
     "detail": "份额分位 0.844、拥挤度 0.8946，R2 的触发条件是「份额分位 > 0.90 且拥挤度 > 0.90」，"
               "当前只差一格。一旦触发 −6 分，银行会从 67.32 掉到 61 附近，"
               "排名会被光伏设备、铁路公路等追赶，下期能否留在榜上取决于分位是否继续上行。",
     "trigger": "拥挤度 > 0.90 且份额分位 > 0.90",
     "mitigation": "拥挤度触线即只减不加；把「分位回落至 0.80 以下 + 广度仍 ≥70%」当作重新评估的前提",
     "affected": ["ml-bank"]},
    {"id": "r3", "level": "medium", "title": "成交额跌破 1.5 万亿，防御板块的承接也在变薄",
     "detail": "14943.9 亿是本期全市场成交额，较 11-06 再缩约 1770 亿，同期涨停 54 家但炸板 44 家、"
               "封板率从 69.57% 降到 55.10%。缩量里银行的逆势收红建立在避险停泊上，"
               "若成交额继续下滑，防御方向也会失去换手支撑。",
     "trigger": "全市场成交额跌破 1.4 万亿，或银行Ⅱ 单日跌幅 >1% 且上涨占比 <50%",
     "mitigation": "总仓位压到一成以下；防御方向只做观察，不做趋势假设",
     "affected": ["ml-bank"]},
    {"id": "r4", "level": "medium", "title": "银行上涨是风险偏好收缩的镜像，指数一企稳就会被抽血",
     "detail": "沪指 +0.32% 但全市场 3147 家下跌，说明指数是被权重撑住的；银行的 88.1% 广度同样来自"
               "避险资金的被动抱团。一旦出现新题材或指数放量企稳，这类「抗跌溢价」会最先被卖出。",
     "trigger": "出现新的 2 条闸门板块且 stage 可判定，或沪指单日涨幅 >1% 而银行下跌",
     "mitigation": "把它当「防御仓」而不是「主线仓」；新主线出现时优先换仓，不做抗跌溢价的最后一棒",
     "affected": ["ml-bank"]},
    {"id": "r5", "level": "low", "title": "数据缺口：两融滞后 1 个交易日、全 A 新高新低与 PE 分位未取",
     "detail": "两融口径截至 2026-11-06（lag_trading_days=1），只用于水平与趋势描述，不参与 11-09 当日归因；"
               "全 A 创 20 日新高/新低家数需 5000+ 只个股日线、超出单期取数预算，写 null；"
               "板块 PE 250 日分位未取。三项均已记入 data_quality.missing，不以 0 填充。",
     "trigger": "下期仍无法补齐上述三项",
     "mitigation": "报告内保留 null 与缺口说明；跨期比较时先核对两融的截止日",
     "affected": []},
]

SCENARIOS = [
    {"id": "s1", "name": "乐观：份额止血，发酵期延续到中段", "probability": 0.27,
     "assumption": "全市场成交额回到 1.7 万亿以上；银行Ⅱ Δ5 份额回到 0 以上、成交额份额回到 2.5% 以上，"
                   "且上涨占比维持在 70% 以上",
     "impact": "银行从「防御性发酵」转为「有增量配合的发酵」，分数有望回到 72~78 区间，"
               "城商行的创新高名单继续扩大",
     "action": "仓位可加到两成，只做同时满足「Δ5 转正 + 广度 ≥70%」的时点，不追单日大涨"},
    {"id": "s2", "name": "中性：缩量磨底，银行靠广度维持一到两周", "probability": 0.45,
     "assumption": "成交额维持 1.4~1.6 万亿；银行份额继续小幅流出但广度不塌，"
                   "指数在 3550~3700 点之间震荡",
     "impact": "银行留在榜上但分数停在 60~70，阶段仍是发酵期；新兴板块（数字媒体、光伏设备）反复进入萌芽，"
               "却始终补不齐第二条闸门",
     "action": "一到两成仓位，只持有大行与高股息，不做城商行的追高；每日核对 Δ5 与拥挤度两个数"},
    {"id": "s3", "name": "悲观：指数企稳或新题材出现，银行被抽血", "probability": 0.28,
     "assumption": "成交额回到 1.7 万亿且结构转向成长，或银行Ⅱ 单日跌幅 >1%、上涨占比跌破 50%，"
                   "拥挤度触线触发 R2",
     "impact": "P2 广度闸门失效，银行跌回萌芽；主线回到 0 条，市场进入新一轮寻找主线的空窗",
     "action": "清掉防御仓，不接下跌；以「新板块同时过 ≥2 条闸门且 stage 可判定」作为重新入场的唯一条件"},
]

PLAYBOOK = {
    "stance": "低仓防御，只认广度与份额，不认抗跌的故事",
    "position_range": "一到两成",
    "rules": [
        {"if": "银行Ⅱ 的 Δ5 份额仍为负（本期 −0.87pct）", "then": "维持一到两成防御仓，不加仓；广度为真但量能缺席时，发酵期不会自己走到主升"},
        {"if": "拥挤度升破 0.90 且份额分位 >0.90", "then": "触发 R2 −6 分，只减不加，把仓位压到一成以下"},
        {"if": "工商银行跌破 MA20（8.50 元）或银行Ⅱ 单日跌幅 >1% 且上涨占比 <50%", "then": "清掉防御仓，P2 闸门已失效，不接下跌"},
        {"if": "出现新板块同时过 ≥2 条闸门且 stage 可判定", "then": "优先换到新主线；银行的抗跌溢价在新题材出现时会最先消失"},
        {"if": "全市场成交额回到 1.7 万亿且银行份额 Δ5 转正", "then": "可加到两成，按发酵期中段处理，止盈设在 20 日涨幅 +8% 附近"},
    ],
    "checklist": [
        "盘前：银行Ⅱ 昨日成交额份额与 Δ5（本期 2.05% / −0.87pct，分位 2.34）",
        "盘前：全市场成交额能否回到 1.6 万亿以上（本期 14943.9 亿）",
        "盘中：工商银行 8.50 元、招商银行 42.65 元的 MA20 是否守住",
        "盘后：涨停家数与封板率（本期 54 家 / 55.10%），以及创新高个股里银行的数量（本期 4 只）",
    ],
    "disclaimer": "本报告为市场结构研究，不构成投资建议，不承诺收益。",
}

def load(name: str, as_of: str) -> dict:
    return json.loads((C / f"{name}-{as_of}.json").read_text(encoding="utf-8"))


def _fill(obj, score, rank):
    """把 CONTENT 里的 {score}/{rank} 换成当期实算值（深拷贝，不改原表）。

    文案里写死分数是个反复出问题的地方：改一次评分口径就要手工追一遍正文，
    漏掉一处就是「正文说 79.24、表格写 83.05」。名次同理（影视院线从第 3 升到第 2）。
    """
    if isinstance(obj, str):
        return obj.replace("{score}", f"{score:.2f}").replace("{rank}", str(rank))
    if isinstance(obj, list):
        return [_fill(x, score, rank) for x in obj]
    if isinstance(obj, dict):
        return {k: _fill(v, score, rank) for k, v in obj.items()}
    return obj


def _sub(obj, mapping):
    """按 {key} 映射替换文案里的动态字段（名次、分差这类不是每块都有的东西）。"""
    if isinstance(obj, str):
        for k, v in mapping.items():
            obj = obj.replace(k, v)
        return obj
    if isinstance(obj, list):
        return [_sub(x, mapping) for x in obj]
    if isinstance(obj, dict):
        return {k: _sub(v, mapping) for k, v in obj.items()}
    return obj

# count-v2：把「结构性不可得」的条目移出分母。
# v1 的 26 条里含 1 条永远不可能 full 的（陆股通持股变动：日度净买入 2024-08 起停披露），
# 它长期挂 missing，等于分母恒虚高 1 条、coverage 恒定被压低约 3.2pct，而读者无法区分
# 「做不到」与「这期没做到」。v2 把它整条移出，分母 26 → 25。
# 其余 missing（新高新低家数、PE 分位、两融）都留在分母里——它们是真实可改进的欠账，
# 留着才有改进压力，不能因为「这期没取到」就缩小分母把分数做上去。
COVERAGE_METHOD = "count-v2"


def data_coverage(*, rows: dict, p: dict, bb: dict, br, lim, lev, base_src: str,
                  idx_live: dict | None, cand_members: set, quotes: dict,
                  samples: dict, n_p2: int, lev_carried: str | None = None):
    """数据覆盖度：数「必需输入条目」，不数打分权重。

    v2.0 起换掉「因子权重 × 折扣」的加权口径。旧口径的问题是分母会随版本漂移：
    叙事分移出总分时分母从 100 缩到 90，同一个分子 85 就从 85% 变成 94.4%——
    涨的 9.4 个点一分不来自取数，读者也复算不出来（那个 90 只写在代码里）。

    这里改成可以数的条目：完整 = 1，降级（有值但口径被替代或打折）= 0.5，缺失 = 0，
    分母是条目总数。条目清单本身是设计选择，但每一条的判定都来自当期数据，
    并且逐条写进 data_quality.coverage_detail，读者可以自己点着数一遍。

    注意：这份清单与 score 的因子权重无关，也不该相关——数据完整度和「因子有多重要」
    是两件事，混在一起就又会得到一个人人看不懂的百分比。
    """
    n = len(rows)
    items: list[dict] = []

    def add(group: str, field: str, state: str, evidence: str) -> None:
        items.append({"group": group, "field": field, "state": state, "evidence": evidence})

    def preset(key: str) -> int:
        return sum(1 for r in rows.values() if r.get(key) is not None)

    def board_field(group: str, field: str, key: str) -> None:
        c = preset(key)
        if c == n:
            add(group, field, "full", f"{c}/{n} 板块")
        elif c:
            add(group, field, "degraded", f"{c}/{n} 板块，其余为 null")
        else:
            add(group, field, "missing", f"0/{n} 板块，全为 null")

    # —— 相对强度
    board_field("相对强度", "板块 20 日收益", "chg_20d")
    board_field("相对强度", "板块 60 日收益", "chg_60d")
    add("相对强度", "基准指数 20 日收益",
        "full" if base_src == "indices-live" else "degraded",
        "当日指数快照" if base_src == "indices-live"
        else f"回落常量（{base_src}），rs 与全部分数一起偏移")

    # —— 趋势持续性
    board_field("趋势持续性", "前 10 天数", "days_top10_20")
    board_field("趋势持续性", "连续前 10 天数", "consecutive_top10")
    board_field("趋势持续性", "60 日阳线占比", "up_days_60")

    # —— 量能聚集
    src = (p or {}).get("amount_src") or {}
    k, f = src.get("kline", 0), src.get("flow", 0)
    tot = k + f
    if tot and f == 0:
        add("量能聚集", "板块成交额（日线真值）", "full", f"kline {k} / 反推 {f}")
    elif k:
        add("量能聚集", "板块成交额（日线真值）", "degraded", f"kline {k} / 反推 {f}（净额÷占比）")
    elif any(r.get("share") is not None for r in rows.values()):
        # v1.8 及以前的面板没有 amount_src 字段：份额来自「主力净额 ÷ 净流入占比」反推，
        # 有值但口径打折，记降级而不是缺失——重算历史期数时这一档不能缺。
        add("量能聚集", "板块成交额（日线真值）", "degraded",
            "面板无 amount_src（v1.8 前格式），成交额为净额÷占比反推")
    else:
        add("量能聚集", "板块成交额（日线真值）", "missing", "面板无成交额")
    board_field("量能聚集", "成交额份额", "share")
    board_field("量能聚集", "5 日份额变化", "share_chg_5")
    board_field("量能聚集", "20 日份额变化", "share_chg_20")
    smin = min(samples.values()) if samples else 0
    c250 = preset("share_pct_250")
    if c250 == n and smin >= 250:
        add("量能聚集", "250 日份额分位", "full", f"{c250}/{n} 板块，最短样本 {smin} 日")
    elif c250:
        add("量能聚集", "250 日份额分位", "degraded",
            f"{c250}/{n} 板块，最短样本 {smin} 日（不足 250 日，按实际样本算分位）")
    else:
        add("量能聚集", "250 日份额分位", "missing", "全为 null")

    # —— 扩散度
    bbs = (bb or {}).get("boards") or {}
    ranked = [v for v in bbs.values() if v.get("ranked")]
    for field, key in (("板块上涨占比", "up_ratio"), ("强势股占比（≥5%）", "strong_ratio"),
                       ("涨停占比（板块内）", "limit_up_ratio")):
        c = sum(1 for v in ranked if v.get(key) is not None)
        add("扩散度", field, "full" if ranked and c == len(ranked) else "degraded",
            f"{c}/{len(ranked)} 个参与排名的板块")

    # —— 资金流
    board_field("资金流", "5 日主力净额", "flow5")
    add("资金流", "净流入占比（东财测算）", "degraded",
        "东财按单笔金额分档测算，不是交易所逐笔成交，量级可用、精度有限")

    # —— 市场情绪与杠杆
    add("市场情绪", "全 A 涨跌家数", "full" if br else "missing",
        f"新浪全 A 快照本地统计，{br['valid']} 只有效样本" if br else "本期未取")
    add("市场情绪", "全 A 创新高/新低家数", "missing", "需 5000+ 只个股日线，超出单期取数预算")
    add("市场情绪", "涨停/炸板/跌停池", "full" if lim else "missing",
        f"{lim['market']['limit_up']} 家涨停 / {lim['market']['broken']} 家炸板" if lim else "本期未取")
    if lev and lev_carried:
        # 沿用上一期缓存：数值可用，但不是当期取数成功，记降级而不是完整
        add("市场情绪", "两融余额", "degraded",
            f"截至 {lev['as_of']}，相对 {as_of} 滞后 {lev['lag_trading_days']} 个交易日"
            f"（本期缓存缺失，沿用 {lev_carried} 期）")
    elif lev:
        add("市场情绪", "两融余额", "full",
            f"截至 {lev['as_of']}，滞后 {lev['lag_trading_days']} 个交易日")
    else:
        add("市场情绪", "两融余额", "missing",
            f"本期未取，且无 {margin.MAX_CARRY_LAG} 个交易日内可沿用的缓存")
    add("市场情绪", "指数 5/20/60 日序列", "full" if idx_live and idx_live.get("indices") else "missing",
        f"{len(idx_live['indices'])} 个指数当日快照与日 K" if idx_live and idx_live.get("indices") else "本期未取")

    # —— 结构与估值
    add("结构与估值", "板块成分股清单", "full" if cand_members else "missing", f"去重 {len(cand_members)} 只")
    add("结构与估值", "个股报价快照", "full" if quotes else "missing", f"{len(quotes)} 只成分股报价")
    add("结构与估值", "全部板块 P2 覆盖",
        "full" if n_p2 >= n else "degraded",
        f"{n_p2}/{n} 个板块（P2 要逐板块拉成分股 K 线，只对候选与近失板块计算）")
    add("结构与估值", "板块 PE 250 日分位", "missing", "中证指数官网估值分位未取")

    total = len(items)
    full = sum(1 for x in items if x["state"] == "full")
    deg = sum(1 for x in items if x["state"] == "degraded")
    miss = sum(1 for x in items if x["state"] == "missing")
    cov = round((full + 0.5 * deg) / total, 4) if total else 0.0
    return cov, items, {"total": total, "full": full, "degraded": deg, "missing": miss}


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--out", default="", help="缺省由 as_of 推导，避免重跑时覆盖上一期")
    ap.add_argument("--top-n", type=int, default=5)
    ap.add_argument("--allow-fallback-base", action="store_true",
                    help="允许用 FALLBACK_IDX_REF（2026-10-30 常量）当基准组装；默认拒绝，因为 rs 会整体偏")
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)
    as_of = args.as_of
    # 文案是逐日手写的（驱动、失效条件、催化剂都是当天的事实），CONTENT 却按板块代码全局存一份。
    # 于是「用今天的话术配昨天数据」只差一次 --as-of：11-03 的白酒会渲染成 11-05 的「五个月后重回前 10」。
    # 字段齐全时旧检查看不出来，所以在这里按日期拦一道。
    if as_of != CONTENT_AS_OF:
        print(f"[FATAL] CONTENT 是给 {CONTENT_AS_OF} 写的，不能用它组装 {as_of} 的报告：")
        print(f"  历史日期的报告正文需要按当天的事实重写（drivers/catalyst/invalidation 都是日更内容）。")
        print(f"  只想复算数字：用 pipeline.score 后另存，不要重出报告；")
        print(f"  确实要重写：先把 CONTENT_AS_OF 改成 {as_of} 并按当天证据重写全部文案。")
        return 2

    if not args.out:
        args.out = f"aml-{as_of.replace('-', '')}-v16.json"

    fac = load("factors", as_of)
    bb = boardbreadth.load(as_of)
    # 基准必须来自当日指数快照。factors 取不到中证全指时会回落 FALLBACK_IDX_REF
    # （2026-10-30 的常量：中证全指 20 日 −14.44%，而 11-05 真实是 −6.26%），
    # 128 个板块的 rs 与全部分数会一起偏，而报告看上去完全正常。
    # indices.py 已加写入守卫（有旧文件时拒绝覆盖），这里兜最后一层：只要不是当日快照、
    # 又不是常量自身的日期，就拒绝组装——宁可不出报告，也不出一份基准错的报告。
    base_src = fac.get("base_source", "")
    if base_src != "indices-live" and as_of != "2026-10-30" and not args.allow_fallback_base:
        print("[FATAL] 基准不是当日指数快照，拒绝组装：")
        print(f"  factors.base_source = {base_src}（回落常量：中证全指 20 日 −14.44%）")
        print(f"  factors.base.chg_20d = {fac['base'].get('chg_20d')}")
        print(f"  先补 indices：python -m pipeline.indices --as-of {as_of}（或 --until indices 重跑）")
        print(f"  确认要用常量基准时加 --allow-fallback-base，并在报告里注明。")
        return 2
    run = load("run", as_of)
    sc = load("score", as_of)
    lim = load("limit", as_of)
    idx_live = load("indices", as_of)
    extra = load("extra", as_of)
    # 两融：当期缓存缺失时沿用最近一期（滞后 >3 个交易日则不沿用），沿用信息进 coverage 记降级
    lev, lev_info = margin.load_carried(as_of)
    lev_carried = lev_info.get("carried_from")
    lev_rows = lev_info.get("rows")
    narr = narrative.load(as_of)
    p = pickle.loads((C / f"panel-{as_of}.pkl").read_bytes())
    quotes, q_snap_date = qmod.load(C, as_of)
    if not quotes:
        raise SystemExit(
            f"[FATAL] 缺少 quotes-{as_of}.json：龙头梯队要按当日成交额排序，没有报价快照无法组装。"
            f"先跑 `python -m pipeline.run --as-of {as_of}`（或至少 score）生成快照。")
    if q_snap_date and q_snap_date != as_of:
        # 不该发生：save() 已守住写入端。留这条是因为历史缓存可能还在，且一旦出现
        # 说明有人手工放文件，龙头排序会按错日期的成交额选票。
        print(f"  ⚠ 快照交易日 {q_snap_date} ≠ 基准日 {as_of}，龙头梯队排序可能失真")
    # 全市场广度：pipeline.breadth 从新浪全 A 快照（5576 只）本地统计；缺失则回落 null
    br_p = C / f"breadth-{as_of}.json"
    br = json.loads(br_p.read_text(encoding="utf-8")) if br_p.exists() else None

    rows, pc = fac["rows"], fac["pct"]
    base = fac["base"]
    g_by = {g["code"]: g for g in run["gates"]}
    sc_by = {r["code"]: r for r in sc["rows"]}
    dates = sorted(p["by_date"])
    cal = dates

    con = sqlite3.connect(f"file:{C / 'kline.sqlite'}?mode=ro", uri=True)

    def stk_ret(code: str, n: int) -> float | None:
        r = con.execute("select d, c from kline where code=? and d<=? order by d desc limit ?",
                        (code, as_of, n + 1)).fetchall()
        if len(r) < n + 1 or r[0][0] != as_of:
            return None
        return round(r[0][1] / r[-1][1] - 1, 4)

    def stk_ma(code: str, n: int = 20) -> float | None:
        r = con.execute("select c from kline where code=? and d<=? order by d desc limit ?",
                        (code, as_of, n)).fetchall()
        return round(sum(x[0] for x in r) / len(r), 2) if len(r) == n else None

    def members(code: str) -> list[str]:
        f = C / f"codes-{code}.json"
        return [str(x).zfill(6) for x in json.loads(f.read_text(encoding="utf-8"))] if f.exists() else []

    def net_sum(code: str, n: int) -> float:
        tot = 0.0
        for d in dates[-n:]:
            r = p["by_date"][d].get(code)
            if r and r.get("net"):
                tot += r["net"]
        return round(tot / 1e8, 2)

    def amt_sum(code: str, n: int) -> float:
        tot = 0.0
        for d in dates[-n:]:
            r = p["by_date"][d].get(code)
            if r and r.get("amount"):
                tot += r["amount"]
        return tot / 1e8

    def volatility(code: str, n: int = 20) -> float | None:
        s = [p["by_date"][d][code]["pct"] for d in dates[-n:] if p["by_date"][d].get(code)]
        return round(statistics.pstdev(s) / 100, 4) if len(s) >= n - 1 and s else None

    # ---------------- 横截面样本（与 score.py 完全一致） ----------------
    all_rows = list(rows.values())
    S_rs = [r["rs_20"] for r in all_rows]
    S_dt = [r["days_top10_20"] for r in all_rows]
    S_cs = [r["consecutive_top10"] for r in all_rows]
    S_ud = [r["up_days_60"] for r in all_rows]
    S_sh = [r["share"] for r in all_rows]
    S_d5 = [r["share_chg_5"] for r in all_rows]
    S_fl = [r["flow5"] for r in all_rows]
    S_g20 = [r["chg_20d"] for r in all_rows]
    gated = [sc_by[c] for c in g_by if c in sc_by]
    S_up = [g_by[r["code"]]["breadth_up_ratio"] for r in gated]
    S_nh = [g_by[r["code"]]["new_high_ratio"] for r in gated]
    S_zt = [r["pool"]["limit_up_count"] for r in gated]

    # ---------------- 闸门 / 阶段 / 打分 ----------------
    def board_score(code: str, with_stage: bool = True) -> dict:
        """直接取 score.py 的结果，不再重算。

        这里曾经把六因子重算过一遍，靠断言与 score.py 对齐。但两边的 breadth 样本
        （S_up / S_nh / S_zt）走了不同路径：score 的 S_zt 用 pool_stats 的 limit_up_count，
        此处用 lim["limit_up"] 与 members 的交集——2026-11-05 休闲食品算出 0 vs 1，
        经 pct_in 放大成分位 10 vs 90，分数差 3.33 才被断言拦住。断言能发现漂移，
        但发现不了「两套算法都自认为对」的情形。唯一真相只能有一份，直接读。
        """
        f = rows[code]
        o = sc_by[code]
        g = g_by.get(code) or (extra.get("rows") or {}).get(code) or {}
        p1 = g.get("p1", f["days_top10_20"] >= 6 and f["consecutive_top10"] >= 2)
        p2 = g.get("p2")
        p3 = g.get("p3", (f["share_chg_5"] or 0) >= 0.005 and (f["share_pct_250"] or 0) >= 0.60)
        return {
            "code": code, "name": f["name"], "p1": p1, "p2": p2, "p3": p3,
            "gates": o["gates"],
            "up": g.get("breadth_up_ratio", g.get("up_ratio")),
            "nh": g.get("new_high_ratio"),
            "valid": g.get("valid"),
            "rs": o["rs"], "crowd": o["crowding"],
            "norm": o["norm"], "contrib": o["contrib"],
            "penalty": o["penalty"], "penalty_rules": o["penalty_rules"],
            "score": o["score"],
            # 叙事分随每条记录一起走：mainlines 要用它写拆解，emerging 要用它标注，
            # 边界裁决也要用它。放在唯一入口（board_score）里，三处拿到的必然是同一个值。
            "narrative": narrative.score_of(narr, code),
            "limit_up_count": o["pool"]["limit_up_count"],
            "streak": o["pool"]["max_streak"],
        }

    scored = {code: board_score(code) for code in g_by}

    def narr_txt(s: dict) -> str:
        """叙事分的人读形式。未评写「未评」而不是 0——两者含义不同。"""
        v = s.get("narrative")
        return "未评" if v is None else f"{v:.0f}"

    # ---------------- mainlines ----------------
    listed = sorted([scored[c] for c in g_by], key=lambda x: -x["score"])
    # v1.6 §4：阶段无法赋值（sc_by[code]["stage"] 为 None）的板块不得进 mainlines，
    # schema 的 stage 不允许 null。分数再高也只能进 rotation.emerging——这里先按可判定性分流再取 TOP_N，
    # 否则 top 会混进 stage=None 的板块，最终写出违反契约的报告。
    eligible = [s for s in listed if sc_by.get(s["code"], {}).get("stage")]
    # TOP_N 切口：先按分数排，再看第 n 与 n+1 名这一对。分差 ≥1 分则分数已能区分，
    # 直接截断；<1 分时由叙事分裁决——1 分以内的差距在 128 个板块的横截面里
    # 扛不住四舍五入与取数日的微小抖动，此时「谁的产业证据更硬」比 0.3 分更可靠。
    # 裁决只换座次、不改分数，pick_top 会把双方与理由一并返回，由 rotation.tie_break 落盘。
    top, dropped, tie = narrative.pick_top(eligible, args.top_n, narr)
    # 候选池 = 闸门合格且阶段可判定、真正参与 TOP_N 竞争的板块。叙事覆盖只对它们做强制要求：
    # 1 条闸门的板块根本进不了榜，不评叙事分是合理的，不能算「缺失」。
    pool = [x["code"] for x in eligible]
    cov = narrative.coverage(narr, pool)

    # emerging：所有恰好命中 1 条闸门的板块（run 的候选 + extra 的补算板块），按六因子实算。
    # v1.6 还要求「闸门够但阶段无法判定」的板块不得进 mainlines，同样改列 emerging。
    # 只看 extra 会漏掉 run 里落榜的候选。
    emerging = []
    top_codes = {t["code"] for t in top}
    # 用「可赋值阶段」的名单排名：TOP_N 是在 eligible 里截断的，用全样本名次会
    # 把电视广播Ⅱ 这类 1 条闸门的板块算进去，出现「排第 7 却被 TOP_N=5 截断」的错位。
    # 合并 top + dropped 而不是用 eligible 原序：裁决过的边界必须反映在名次上。
    rank_of = {x['code']: i + 1 for i, x in enumerate(top + dropped)}
    # run 的候选缺分是致命的：score.json 与 run.json 不同源（重跑了 run 没重跑 score）。
    # 直接给出可执行的提示，而不是在 board_score 里抛 KeyError + 一屏堆栈。
    lost = [c for c in g_by if c not in sc_by]
    if lost:
        print(f"[FATAL] score 缓存缺 {len(lost)} 个 run 候选：{'、'.join(lost)}")
        print("  run 与 score 不同步。先跑 python -m pipeline.score 再组装。")
        return 2
    # extra 补算的板块缺分则只跳过：它们不进 mainlines，少几条 emerging 不影响结论，
    # 但必须在 data_quality 里说明，不能让板块静默消失。
    unscored: list[str] = []
    for code in list(g_by) + [c for c in extra["rows"] if c not in g_by]:
        if code not in sc_by:
            unscored.append(code)
            continue
        s = board_score(code)
        if code in top_codes:
            continue
        # 三种都算「未进主线」：①只有 1 条闸门；②闸门够但阶段无法判定；③闸门、阶段都有，
        # 但综合分排在 TOP_N 之外。原来漏了第③种——电池本轮 P3 转正后从「1 条闸门」升到 2 条，
        # 于是既不在 mainlines 也不在 emerging，整只板块从报告正文里消失了，只有数据质量注记
        # 还提了一句「合格但超出 TOP_N 未入榜」。排第 6 的板块必须有地方可看。
        if s["gates"] == 1 or s["gates"] >= 2:
            s["rank_overall"] = rank_of.get(code)
            # 未评写 None，不写 0——0 是「有 0 条证据」，与「本轮没登记」是两件事，
            # 混用会让读者把缺评读成没叙事（build_v16 曾把两者都记成 0）。
            # 「叙事 ≥85 却只差一条闸门」单独打标：半导体 11-05 是 P1 0/20 天、分数排第 12，
            # 按分数排会被埋在萌芽列表末尾，但它的产业证据（任天堂存储涨价 + 云南锗业五年合同）
            # 是当日第二硬的一档。标签不改变归属，只让它在正文里被点到名。
            s["strong_but_gated"] = narrative.strong_but_gated(narr, code, s["gates"])
            emerging.append(s)
    emerging.sort(key=lambda x: -x["score"])

    # 未进主线的板块按原因分组。正文与 data_quality 共用这一份分组，
    # 免得「出版 62.94 被截断」这类手写名单在下次换榜后继续留在报告里（它已经过期过一次）。
    cut_by_topn = [s for s in dropped if s["gates"] >= 2]
    one_gate = [s for s in emerging if s["gates"] == 1]
    stage_none = [s for s in emerging if s["gates"] >= 2
                  and not sc_by.get(s["code"], {}).get("stage")]
    strong_gated = [s for s in emerging if s.get("strong_but_gated")]

    # 换一个交易日重跑时，CONTENT 与 narrative 仍是上一期写的：若不拦住，就会把昨天的
    # 板块名套上今天的数字，生成一份「名字与数值不匹配」却不报错的报告。
    no_text = [f"{s['name']}({s['code']})" for s in top if s["code"] not in CONTENT]
    no_narr = [f"{s['name']}({s['code']})" for s in top if s["code"] not in narr]
    if no_text or no_narr:
        print("[FATAL] 本期榜单与该日文案不匹配，拒绝组装：")
        if no_text:
            print(f"  CONTENT 缺文案：{'、'.join(no_text)}")
        if no_narr:
            print(f"  templates/narrative.json[{as_of}] 缺叙事台账：{'、'.join(no_narr)}")
        print(f"  本期上榜为：{'、'.join(f'{s['name']}={s['score']}' for s in top)}")
        print("  请先补文案与叙事台账（evidence/source），或用 --top-n 调整目标条数后重试。")
        return 2
    # 落榜但仍在候选池里的板块缺评：不阻断（它们不进正文主线），但必须说出来。
    # 「静默按 0 计」是这次改造要消灭的行为——0 分会被读者当成「无叙事」。
    if cov["missing"]:
        print(f"  [warn] 候选池 {cov['total']} 个中有 {len(cov['missing'])} 个未评叙事分："
              f"{'、'.join(rows[c]['name'] for c in cov['missing'])}（写 null，不参与边界裁决）")

    # 台账与证据链互锁：入榜主线的 evidence 必须等于 drivers 里 verified 的条数。
    # §6 的分档就是从 drivers 数出来的，台账另记一个数等于把「证据」变成第二份真相——
    # 11-05 的白酒原本记 78（3 条应是 75 或 80），就是这么飘出来的。
    # 这条校验逼着「改文案」与「改台账」同步发生，缺一边就拒绝组装。
    ev_bad = []
    for s in top:
        n_ev = sum(1 for d in CONTENT[s["code"]].get("drivers", []) if d.get("verified"))
        got = (narr.get(s["code"]) or {}).get("evidence")
        if got is not None and got != n_ev:
            ev_bad.append(f"{s['name']}（台账 {got} 条 / drivers {n_ev} 条）")
    if ev_bad:
        print("[FATAL] 叙事台账与证据链条数不一致，拒绝组装：")
        for x in ev_bad:
            print(f"  {x}")
        print("  改 drivers 就要同步改 templates/narrative.json 的 evidence，反之亦然。")
        return 2

    mainlines = []
    stage_note: dict[str, str] = {}
    for rank, s in enumerate(top, 1):
        code = s["code"]
        ct = _fill(CONTENT[code], s["score"], rank)
        f = rows[code]
        gi = g_by[code]
        mem = [m for m in members(code) if m in quotes]
        mem.sort(key=lambda c: -(quotes[c].get("amount_yi") or 0))
        leaders = []
        for i, c in enumerate(mem[:5]):
            leaders.append({
                "code": (c + (".SZ" if c[0] in "03" else ".SH")),
                "name": quotes[c].get("name"),
                "role": "leader" if i == 0 else ("core" if i < 3 else "follower"),
                "chg_20d": stk_ret(c, 20),
                "turnover_yi": round(quotes[c].get("amount_yi") or 0, 2),
                "note": ct["leader_note"].get(c, ""),
            })
        net5, net20 = net_sum(code, 5), net_sum(code, 20)
        amt5 = amt_sum(code, 5)
        flow_ratio = round(net5 / amt5 * 100, 3) if amt5 else None
        pct20 = pc[code]
        metrics = {
            "chg_1d": round(f["chg_1d"], 4), "chg_5d": round(f["chg_5d"], 4),
            "chg_20d": round(f["chg_20d"], 4), "chg_60d": round(f["chg_60d"], 4),
            "rs_5": f["rs_5"], "rs_20": f["rs_20"], "rs_60": f["rs_60"],
            "turnover_share": round(f["share"], 6),
            "turnover_share_chg_5": round(f["share_chg_5"], 6),
            "turnover_share_chg_20": round(f["share_chg_20"], 6),
            "turnover_share_pct_250": f["share_pct_250"],
            "breadth_up_ratio": round(gi["breadth_up_ratio"], 4),
            "new_high_ratio": round(gi["new_high_ratio"], 4),
            "limit_up_count": s["limit_up_count"],
            "limit_up_ratio": round(s["limit_up_count"] / gi["valid"], 4) if gi["valid"] else None,
            "max_streak": s["streak"],
            "max_streak_prev": sc_by[code]["pool"]["max_streak_prev"],
            "seal_rate": sc_by[code]["pool"]["seal_rate"],
            "leader_chg_5d": sc_by[code]["pool"]["leader_chg_5d"],
            "net_inflow_5_yi": net5, "net_inflow_20_yi": net20,
            "crowding_pct": s["crowd"], "volatility_20": volatility(code),
        }
        # 闸门 detail：逐条写取值与判定，✗ 个数必须与 rules_passed 自洽
        d = (f"P1 {gi['days_top10_20']}/20 天、连续 {gi['consecutive_top10']} 天"
             f" {'✓' if s['p1'] else '✗'}；P2 上涨 {gi['breadth_up_ratio'] * 100:.1f}%、新高 {gi['new_high_ratio'] * 100:.1f}%"
             f" {'✓' if s['p2'] else '✗'}；P3 份额 Δ5 {f['share_chg_5'] * 100:+.2f}pct、分位 {f['share_pct_250']:.4f}"
             f" {'✓' if s['p3'] else '✗'} → {s['gates']} 条通过").replace("-", "−")
        # 这三个量在「无涨停」「K 线有缺口」时合法为 None，直接乘 100 会 TypeError。
        # 报告里要显示成文字而不是 0，否则「+0.00%」会被读成「持平」。
        _pool = sc_by[code]["pool"]
        _lead, _seal, _prev = _pool["leader_chg_5d"], _pool["seal_rate"], _pool["max_streak_prev"]
        lead_txt = f"{_lead * 100:+.2f}%" if _lead is not None else "无数据"
        seal_txt = f"{_seal:.4f}" if _seal is not None else "无涨停"
        prev_txt = "无数据" if _prev is None else str(_prev)
        stage_rules = {
            "fade": f"Δ20 {f['share_chg_20'] * 100:+.2f}pct / 龙头 5 日 {lead_txt} / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "divergence": f"5 日 {f['chg_5d'] * 100:+.2f}% vs 20 日 1/4 {f['chg_20d'] / 4 * 100:+.2f}% / 分位 {f['share_pct_250']:.4f} / 连板 {prev_txt}→{s['streak']}",
            "acceleration": f"20 日 {f['chg_20d'] * 100:+.2f}% / 拥挤 {s['crowd']:.4f} / 封板 {seal_txt}",
            "expansion": f"分位 {f['share_pct_250']:.4f} / 涨停 {s['limit_up_count']} 家 / 连板 {s['streak']} / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "trend": f"分位 {f['share_pct_250']:.4f} / 20 日 {f['chg_20d'] * 100:+.2f}% / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "ignition": f"Δ5 {f['share_chg_5'] * 100:+.2f}pct / 前 10 {gi['days_top10_20']} 天 / 涨停 {s['limit_up_count']} 家",
        }
        hit = sum(1 for _, ok, _ in sc_by[code]["crit"][sc_by[code]["stage"]] if ok)
        mainlines.append({
            "id": ct["id"], "rank": rank, "rank_change": ct["rank_change"],
            "name": ct["name"], "aliases": ct["aliases"], "sector_codes": [code],
            "theme_type": ct["theme_type"], "stage": sc_by[code]["stage"],
            "stage_label": ct["stage_label"], "stage_confidence": ct["stage_confidence"],
            "score": s["score"],
            "score_breakdown": [
                {"key": k, "label": lbl, "raw": raw, "normalized": s["norm"][k],
                 "weight": effective_weight(WEIGHTS.get(k, 0)),
                 "contribution": s["contrib"].get(k, 0), "note": note}
                for k, lbl, raw, note in [
                    ("rs", "相对强度", f["rs_20"], f"rs_20 净值比 {f['rs_20']:.4f}，128 板块横截面分位"),
                    ("persistence", "趋势持续性", f["days_top10_20"],
                     f"前 10 {f['days_top10_20']} 天/连续 {f['consecutive_top10']} 天/60 日阳线 {f['up_days_60'] * 100:.1f}%，三项分位均值"),
                    ("volume", "量能聚集", round(f["share"] * 100, 3),
                     f"份额 {f['share'] * 100:.2f}% 分位 {pc[code]['share']:.1f}，Δ5 {f['share_chg_5'] * 100:+.2f}pct 分位 {pc[code]['share_chg_5']:.1f}"),
                    ("breadth", "扩散度", round(gi["breadth_up_ratio"] * 100, 2),
                     f"上涨 {gi['breadth_up_ratio'] * 100:.1f}/新高 {gi['new_high_ratio'] * 100:.1f}/涨停 {s['limit_up_count']} 家，按 0.4/0.35/0.25 加权"),
                    ("fundflow", "资金流", flow_ratio,
                     f"5 日净额 {net5} 亿 ÷ 同期成交额 {amt5:.2f} 亿 = {flow_ratio}%"),
                    ("narrative", "叙事与催化", (narr.get(code) or {}).get("evidence"),
                     f"{narrative.explain(narr.get(code) or {})}；"
                     f"权重 0、不计入总分，仅在第 {args.top_n}/{args.top_n + 1} 名分差 <1 分时裁决座次"),
                ]
            ],
            "penalty": s["penalty"],
            "penalty_reason": (
                f"R2 触发：份额分位 {f['share_pct_250']:.4f} > 0.90 且拥挤度 {s['crowd']:.4f} > 0.90 → −6"
                if s["penalty"] == 6 else
                (f"R1 触发：份额分位 {f['share_pct_250']:.4f} > 0.95 且连板 {s['streak']} ≥ 5 → −12"
                 if s["penalty"] == 12 else "无触发")),
            "metrics": metrics,
            "persistence": {
                "days_top10_20": gi["days_top10_20"],
                "days_top5_20": pct20 and panel_top5(p, code, 20),
                "consecutive_top10": gi["consecutive_top10"],
                "pulse_check": {"passed": s["gates"] >= 2, "rules_passed": s["gates"], "detail": d},
            },
            "drivers": ct["drivers"],
            "narrative": {k: ct[k] for k in ("logic", "catalyst", "sustainability", "bear_case")},
            "leaders": leaders,
            "ladder": {"has_leader": bool(leaders), "tiers": 3 if rank == 1 else 2, "note": ct["ladder_note"]},
            "invalidation": [
                {k: re.sub(r"\{ma20_(\d{6})\}", lambda mm: str(stk_ma(mm.group(1))), v)
                 for k, v in inv.items()} for inv in ct["invalidation"]],
            "watch": ct["watch"],
            "related": ct["related"],
        })
        stage_note[code] = (f"{ct['name']} 阶段 {sc_by[code]['stage']}，命中 {hit}/"
                            f"{len(sc_by[code]['crit'][sc_by[code]['stage']])}；判据取值 " + stage_rules[sc_by[code]["stage"]])

    # ---------------- 组装 ----------------
    # weight 是 100 分制的有效权重（设计权重 ÷ 90 × 100，见 score.effective_weight），
    # 加总正好 100，与 score 满分一致；normalized × weight ÷ 100 = contribution 可手算。
    static_w = [
        {"key": "rs", "label": "相对强度", "weight": effective_weight(WEIGHTS["rs"]),
         "desc": "（1+板块 20 日收益）÷（1+中证全指 20 日收益）的净值比，在 128 个板块中的横截面百分位；设计权重 25/90"},
        {"key": "persistence", "label": "趋势持续性", "weight": effective_weight(WEIGHTS["persistence"]),
         "desc": "前 10 天数、连续天数、60 日阳线占比三项百分位的均值；设计权重 20/90"},
        {"key": "volume", "label": "量能聚集", "weight": effective_weight(WEIGHTS["volume"]),
         "desc": "成交额份额百分位×0.6 + 5 日份额变化百分位×0.4；设计权重 20/90"},
        {"key": "breadth", "label": "扩散度", "weight": effective_weight(WEIGHTS["breadth"]),
         "desc": "上涨占比、强势股占比（涨幅 ≥5%）、涨停占比按 0.40/0.35/0.25 加权的百分位；三项的分位分母是当日全部板块（v1.9 起，不再用候选样本），新高占比只作 P2 闸门；设计权重 15/90"},
        {"key": "fundflow", "label": "资金流", "weight": effective_weight(WEIGHTS["fundflow"]),
         "desc": "5 日主力净额 ÷ 同期成交额的百分位（东财算法测算值）；设计权重 10/90"},
        {"key": "narrative", "label": "叙事与催化", "weight": 0,
         "desc": "不计入总分（权重 0）。分数由可验证证据条数与最高来源等级推导：0/1/2/3/≥4 条 → 0/40/60/75/85，"
                 "官方原文 +15 / 公司公告 +10 / 主流媒体 +5 / 研报与自有数据 0 / 传闻 −10。"
                 "用途仅两处：TOP_N 边界分差 <1 分时裁决座次；标注「叙事强但闸门差一条」的萌芽板块"},
    ]

    gate_matrix = []
    seen: set[str] = set()
    for s in sorted(listed + emerging, key=lambda x: (-x["gates"], -x["score"])):
        if s["code"] in seen:      # listed 与 emerging 在 1 条闸门处会重叠，矩阵只留一条
            continue
        seen.add(s["code"])
        stage = sc_by[s["code"]]["stage"] if s["code"] in sc_by else "未实算（P2 补算板块）"
        stage = stage or ("未判定（闸门 ≥2 条，但五阶段判据均不足 2 项）" if s["gates"] >= 2
                          else "未判定（仅 1 条闸门，阶段不参与判定）")
        hit = ("—" if stage.startswith(("未实算", "未判定")) else
               f"{stage} {sum(1 for _, ok, _ in sc_by[s['code']]['crit'][stage] if ok)}/{len(sc_by[s['code']]['crit'][stage])}")
        line = (
            f"{s['name']} | P1 {'✓' if s['p1'] else '✗'} {rows[s['code']]['days_top10_20']}/20 连续 {rows[s['code']]['consecutive_top10']} "
            f"| P2 {'✓' if s['p2'] else ('✗' if s['p2'] is False else '？无法判定')} 上涨 {(s['up'] or 0) * 100:.1f} 新高 {(s['nh'] or 0) * 100:.1f} "
            f"| P3 {'✓' if s['p3'] else '✗'} Δ5 {rows[s['code']]['share_chg_5'] * 100:+.2f}pct 分位 {rows[s['code']]['share_pct_250']:.4f} "
            f"| 闸门 {s['gates']} 条 | 阶段 {hit} | {stage}")
        gate_matrix.append(line.replace("-", "−"))

    n_extra = len(extra["rows"])
    n_p2 = len(g_by) + n_extra
    p2_unknown = [f"{v['name']}（有效样本 {v['valid']} 只 <10）" for v in extra["rows"].values()
                  if (v["valid"] or 0) < 10 or v.get("degraded")]
    p2_fail = [f"{v['name']}（上涨 {(v['up_ratio'] or 0) * 100:.1f}%、新高 {(v['new_high_ratio'] or 0) * 100:.1f}%）"
               for v in extra["rows"].values()
               if (v["valid"] or 0) >= 10 and not v.get("degraded")
               and not ((v["up_ratio"] or 0) >= 0.55 and (v["new_high_ratio"] or 0) >= 0.08)]
    n_p2_rest = len(rows) - n_p2

    idx = [{"code": r["code"], "name": r["name"], "close": round(r["close"], 2) if r["close"] else None,
            "chg_1d": r["chg_1d"], "chg_5d": r["chg_5d"], "chg_20d": r["chg_20d"],
            "turnover_yi": r["turnover_yi"], "pe_pct_250": None}
           for r in idx_live["indices"]
           if r["code"] in ("000001.SH", "399001.SZ", "399006.SZ", "000688.SH", "000985.CSI", "000922.CSI")]

    up_boards = sum(1 for r in rows.values() if (r["chg_1d"] or 0) > 0)
    inflow = sorted(all_rows, key=lambda x: -(x["share_chg_5"] or 0))[:5]
    outflow = sorted(all_rows, key=lambda x: (x["share_chg_5"] or 0))[:5]
    # 每个板块实际可得的交易日数：250 日分位的真实样本，不同板块因行业分类调整而不同
    samples = {c: sum(1 for d in dates if c in p["by_date"][d]) for c in rows}
    n_p1p3 = len(g_by)
    kline_days = con.execute("select count(distinct d) from kline").fetchone()[0]
    # 按本轮真正参与打分的板块取成分股，不再读 codes-INDEX.json：
    # 那个文件曾是无日期的全局单例，一次历史回溯就会把它覆盖成另一天的名单。
    cand_members: set[str] = set()
    for b in (g_by or {}):
        f = C / f"codes-{b}.json"
        if f.exists():
            cand_members |= {str(x).zfill(6) for x in json.loads(f.read_text(encoding="utf-8"))}

    # 边界值：任一判据距阈值相对幅度 <5% 时必须标出，并说明四舍五入是否改变结论（v1.6 §3-4）
    boundary = []
    for c, s in scored.items():
        f = rows[c]
        for label, v, th in [
            ("P1 前 10 天数", f["days_top10_20"], 6),
            ("P1 连续天数", f["consecutive_top10"], 2),
            ("P2 上涨占比", s["up"], 0.55),
            ("P2 新高占比", s["nh"], 0.08),
            ("P3 份额 Δ5", f["share_chg_5"], 0.005),
            ("P3 份额分位(下界)", f["share_pct_250"], 0.60),
            ("expansion 分位上界", f["share_pct_250"], 0.85),
        ]:
            if v is None or th == 0:
                continue
            gap = abs(v - th) / abs(th)
            if gap < 0.05:
                flip = round(v, 2) != round(v, 4) and (round(v, 2) >= th) != (v >= th)
                boundary.append(f"{s['name']} {label} {v:.4f} 对阈值 {th}（距 {gap * 100:.1f}%"
                                + ("，四舍五入到两位会翻转判定" if flip else "，四舍五入不改变判定") + "）")
    boundary_note = ("边界值（距阈值相对幅度 <5%，一律按原始精度比较）：" + "；".join(boundary)
                     if boundary else "本期无判据落在阈值 5% 以内，全部按原始精度判定")
    pen_note = ("；".join(f"{s['name']} {('/'.join(s['penalty_rules']))} −{s['penalty']}"
                          for s in scored.values() if s["penalty"]) or "无")
    # 沪深口径（剔除北交所）与全口径的差异：必须现算，不能沿用上一期的数字
    ex_bj = {k: v for k, v in (br["by_board"] if br else {}).items() if k != "北交所"}
    ex_up = sum(v["up"] for v in ex_bj.values())
    ex_valid = sum(v["valid"] for v in ex_bj.values())
    ex_ratio = ex_up / ex_valid if ex_valid else 0.0

    # 头版三句话依赖名次与分差，写死会在口径变更后立刻失真（第一次改广度就踩到：
    # 游戏Ⅱ 从第 2 掉到第 4，正文还写着「退居次席」「差距 3.93 分」）。
    # 这里按当期 mainlines 现算，只保留判断、不保留数字。
    _short = {m["id"]: m["name"].split("：")[0] for m in mainlines}
    _ranked = "、".join(f"{m['name'].split('：')[0]}（{m['score']:.2f}，{STAGE_CN.get(m['stage'], m['stage'])}）"
                        for m in mainlines)
    _gap = round(mainlines[0]["score"] - mainlines[1]["score"], 2) if len(mainlines) > 1 else 0
    _headline = (f"五条主线、三条属主升：{mainlines[0]['name'].split('：')[0]}居首，"
                 f"{mainlines[1]['name'].split('：')[0]}以持续性升至次席") if len(mainlines) > 1 else VERDICT_HEADLINE
    _thesis = re.sub(r"改后五条主线是：[^。]*。", f"改后五条主线是：{_ranked}。", VERDICT_THESIS)
    _thesis = re.sub(r"休闲食品（[\d.]+）与半导体（[\d.]+）",
                     f"休闲食品（{sc_by['BK1281']['score']:.2f}）与半导体（{sc_by['BK1036']['score']:.2f}）"
                     if "BK1281" in sc_by and "BK1036" in sc_by else "休闲食品与半导体", _thesis)
    _rank_by_name = {m["name"].split("：")[0]: i for i, m in enumerate(mainlines, 1)}
    # 空榜日 mainlines 为空：VERDICT_POINTS 不含 {score}/{rank} 占位，直接用原文，避免 mainlines[0] 越界。
    _points = (_sub(_fill(VERDICT_POINTS, mainlines[0]["score"], 1),
                    {"{rank_of_games}": str(_rank_by_name.get("游戏Ⅱ", "")), "{gap}": f"{_gap}"})
               if mainlines else VERDICT_POINTS)

    # changelog 里的「这次改了多少分」必须现算：写死的区间会在下一次调参后立刻过期，
    # 而它恰好是读者判断「要不要重看结论」的唯一依据。
    _delta = sorted((round(m["score"] - PRIOR_SCORES_V18[m["id"]], 2), m["name"].split("：")[0])
                    for m in mainlines if m["id"] in PRIOR_SCORES_V18)
    _dtext = (f"分数变动 {_delta[0][0]:+.2f}（{_delta[0][1]}）~ {_delta[-1][0]:+.2f}（{_delta[-1][1]}）"
              if _delta else "无上一版可比分数")

    # 数据覆盖度现算：条目清单、每条的状态与证据都进 coverage_detail，读者可逐条核对。
    coverage, cov_detail, cov_stats = data_coverage(
        rows=rows, p=p, bb=bb, br=br, lim=lim, lev=lev, base_src=base_src,
        idx_live=idx_live, cand_members=cand_members, quotes=quotes,
        samples=samples, n_p2=n_p2, lev_carried=lev_carried)
    cov_points = cov_stats["full"] + 0.5 * cov_stats["degraded"]

    doc = {
        "schema_version": "1.0.0",
        "meta": {
            "report_id": f"aml-{as_of.replace('-', '')}",
            "as_of": as_of,
            "generated_at": datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds"),
            "title": f"A股市场主线分析 · {as_of}",
            "data_mode": "live",
            "confidence": 0.60,
            "analyst": {"model": "DeepSeek-V4.1-Flash", "prompt_version": "1.6.0", "operator": "使用者"},
            "tags": ["单主线", "防御性发酵", "银行入榜", "缩量分化", "价涨量退"],
        },
        "window": {
            "as_of": as_of, "primary_days": 20, "confirm_days": 5, "context_days": 60, "quantile_days": 250,
            "effective_range": {"start": dates[-20], "end": dates[-1]},
            "rules": [
                f"主窗按交易日回溯 20 日，非自然日；本期 20 日窗口 {dates[-20]} ~ {dates[-1]}",
                "T 日仅用于描述字段，不参与阶段判定",
                f"横截面为东财 {run['boards_live']} 个现役行业板块（{as_of} 有资金流数据的全部板块），前 10 名 ≈ 前 {10 / run['boards_live'] * 100:.1f}%",
                f"P1 按滚动 20 日累计涨幅的横截面排名，不是当日涨跌幅；横截面 {run['boards_live']} 个板块中 20 日窗口完整可算的有 {run['boards_live']} 个，剔除 0 个",
                f"P2 已完整计算 {n_p2} 个板块（{n_p1p3} 个 P1/P3 候选 + {n_extra} 个近失板块），其余 {len(rows) - n_p2} 个板块 P2 记「未计算」，不据此下唯一性结论",
                f"250 日分位按各板块全部可得交易日计算：本期样本最短 {min(samples.values())} 日、最长 {max(samples.values())} 日；"
                + ("其中既有不足 250 日也有超过 250 日的板块，分位一律按各自可得样本计算，正文已写明样本长度" if max(samples.values()) >= 250 else "均不足 250 日，正文按实际样本表述"),
                (f"份额分母为面板合计 {run['market_amount_yi']} 亿（128 板块成交额合计，取自板块日线真值）；新浪全 A 快照实测"
                 f"全市场成交额 {br['amount_yi']} 亿，两者相差 {(run['market_amount_yi'] / br['amount_yi'] - 1) * 100:+.3f}%，"
                 f"量级等价，故分母不再标注为代理口径") if br else
                f"份额分母为面板合计 {run['market_amount_yi']} 亿（128 板块成交额合计，取自板块日线真值），非全市场成交额",
            ],
            "excluded": [],
        },
        "data_quality": {
            "status": "partial",
            "coverage": coverage,
            "coverage_method": COVERAGE_METHOD,
            "coverage_detail": cov_detail,
            "sources": [
                {"name": "东方财富数据中心 · 行业板块资金流（RPT_INDUSTRY_FUNDFLOW）", "category": "行情与资金",
                 "fields": ["涨跌幅", "主力净额", "净流入占比", "超大/大/中/小单净额与占比"], "as_of": as_of,
                 "reliability": "high",
                 "note": f"{run['boards_live']} 个板块共 {len(dates)} 个交易日（{dates[0]} 起），涨跌幅与资金流单源；成交额取 push2his 板块日线真值（与成员股成交额加总逐位一致）"},
                {"name": "腾讯行情（qt.gtimg.cn / web.ifzq.gtimg.cn）", "category": "行情",
                 "fields": ["收盘价", "昨收", "涨跌幅", "成交额", "日 K 线"], "as_of": as_of, "reliability": "high",
                 "note": f"{len(idx_live['indices'])} 个指数当日快照与日 K 线；{len(quotes)} 只成分股报价快照；本地 K 线库覆盖同批个股，共 {kline_days} 个交易日"},
                {"name": "东方财富板块成分（RPT_BOARD_CONSTITUENT）", "category": "成分",
                 "fields": ["板块代码", "成分股代码"], "as_of": as_of, "reliability": "high",
                 "note": f"{run['boards_live']} 个板块中取 {n_p2} 个候选/近失板块的成分股，去重 {len(cand_members)} 只，用于 P2 与龙头识别"},
                {"name": "东方财富涨停/炸板/跌停池（push2ex）", "category": "情绪",
                 "fields": ["涨停家数", "连板数", "开板次数"], "as_of": as_of, "reliability": "high",
                 "note": f"{as_of} 涨停 {lim['market']['limit_up']} 家、炸板 {lim['market']['broken']} 家、跌停 {lim['market']['limit_down']} 家；另取 {lim['prev']} 涨停池算连板变化"},
                {"name": "新浪财经全 A 快照（Market_Center.getHQNodeData, node=hs_a）", "category": "行情",
                 "fields": ["收盘价", "涨跌幅", "成交额", "成交量", "总市值"], "as_of": as_of, "reliability": "high",
                 "note": (f"全市场快照走新浪通道；分 56 页取全 {br['valid'] + br['suspended']} 只，"
                          f"有效（有成交）{br['valid']} 只、停牌 {br['suspended']} 只，本地自行统计涨跌家数"
                          + (f"；抽 {br['cross_check']['sampled']} 只对腾讯行情校验，一致 {br['cross_check']['matched']} 只，"
                             f"最大价差 {br['cross_check']['max_price_diff_pct']}%、涨跌幅差 {br['cross_check']['max_pct_diff_pct']}pct"
                             if br.get("cross_check") else "")) if br else
                         "本期未取（breadth 字段写 null）"},
                {"name": "东方财富数据中心 · 两融市场汇总（RPTA_RZRQ_LSHJ）", "category": "杠杆",
                 "fields": ["融资余额", "融券余额", "两融余额", "融资净买入", "占流通市值比"], "as_of": lev["as_of"] if lev else as_of,
                 "reliability": "high",
                 "note": (f"单请求取满 {lev_rows if lev_rows is not None else '—'} 行，"
                          f"滞后 {lev['lag_trading_days']} 个交易日；"
                          f"口径含沪深北，不与交易所分市合计混算"
                          + (f"；本期缓存缺失，沿用 {lev_carried} 期数值" if lev_carried else ""))
                         if lev else "本期未取"},
                {"name": "交易所公告 / 上市公司公告 / 官方统计", "category": "政策与事件",
                 "fields": ["停复牌与交易提示", "公司公告", "宏观与行业统计"], "as_of": as_of,
                 "reliability": "high", "note": f"{len(mainlines)} 条入榜主线共 {sum(len(m['drivers']) for m in mainlines)} 条证据链（drivers）；结论以行情与资金数据为主，事件叙事只用于主线归因"},
                {"name": "主流财经媒体（证券时报 / 财联社 / 每经 / 上证报等）", "category": "资讯",
                 "fields": ["盘面复盘", "板块资金", "市场情绪"], "as_of": as_of, "reliability": "medium",
                 "note": "本期用于银行Ⅱ 的叙事证据（中行中期分红公告、创新高统计、机构评级），并作盘面与数据口径的交叉参考"},
            ],
            "missing": [
                {"field": "板块 250 日完整成交额序列", "reason": f"面板覆盖 {len(dates)} 个交易日（{dates[0]} 起），但部分板块因行业分类调整样本更短，本期最短 {min(samples.values())} 日",
                 "fallback": "turnover_share_pct_250 与 crowding_pct 按实际样本计算，不补 0；正文按「实际样本分位」表述"},
                {"field": "板块 PE 250 日分位", "reason": "中证指数官网估值分位未取", "fallback": "indices.pe_pct_250 全部写 null"},
                {"field": "全市场涨跌家数（交易所官方口径）", "reason": f"交易所官方涨跌家数统计未取，本报告用的是新浪全 A 快照本地统计（{br['valid'] if br else '—'} 只有效样本），未与官方口径逐日核对",
                 "fallback": "market_regime.breadth 用快照统计值，并与腾讯行情抽 17 只交叉校验；口径差异写入 notes"},
                {"field": "全 A 创 20 日新高/新低家数", "reason": "需 5000+ 只个股日线，超出本期取数预算", "fallback": "market_regime.breadth.new_high/new_low 写 null"},
                # 外资维度（陆股通持股变动）已整体移出必需输入清单：日度净买入自 2024-08 停披露、
                # 仅剩周度持股变动与收盘后成交总额，两者都不适配日度归因。剔除后不再占 coverage 分母，
                # 也不再以 missing 记账——它不属于「当期欠账」，是结构性不可得。口径见 notes。
                # 两融按 lev 是否取到动态登记：11-05 的 missing 漏了它（coverage_detail
                # 数条目时才暴露），notes 里其实写了「本期未取」——清单与 notes 必须同源。
                *([] if lev else [{"field": "两融余额", "reason": f"margin-{as_of}.json 不在本轮缓存，两融市场汇总未取",
                                   "fallback": "market_regime.leverage 写 null，全文不使用杠杆维度"}]),
                {"field": f"其余 {len(rows) - n_p2} 个板块的 P2", "reason": f"P2 需逐板块拉成分股 K 线，本期只对 {n_p1p3} 个 P1/P3 候选与 {n_extra} 个近失板块计算",
                 "fallback": "记「未计算」，不做全样本唯一性表述"},
            ],
            "notes": [
                f"基准：{base.get('name')} 20 日 {base.get('chg_20d') * 100:+.2f}%、60 日 "
                f"{base.get('chg_60d') * 100:+.2f}%，来源 {base_src}"
                + ("（常量回落，非当日快照——rs 与全部分数偏移，勿跨日比较）" if base_src != "indices-live" else "（当日指数快照）"),
                f"口径断面：本页 breadth 为 v1.9 口径（三项分位分母 = 当日全部 {bb['ranked']} 个板块）。"
                f"{as_of} 以前的报告是 v1.6/v1.7 口径（只在 9~11 个过闸门候选里排分位，样本本身全是强票），"
                f"同日分数不可直接比较；存档报告保持原样，不按新口径改写历史。",
                "成交额口径沿用 v1.9：板块日线真值（push2his）替代「净额÷占比反推」，面板 128 个板块全部覆盖；"
                "份额统计统一走 panel.share_stats，share_pct_250 固定最近 250 日窗口，不再随面板历史长度漂移",
                "成分股索引 codes-INDEX.json 已按日期分目录：目录里有哪张成分表就用哪张；报价快照命中缓存时会补齐缺失成员。"
                "本期 128 个板块的成分股清单与当日快照一致，涨停/封板率/龙头统计无缺失",
                f"coverage = {cov_stats['full']} 条完整 + 0.5×{cov_stats['degraded']} 条降级 = {cov_points:.1f} 分，"
                f"÷ {cov_stats['total']} 条必需输入 = {coverage:.4f}"
                f"（{COVERAGE_METHOD} 口径：数条目、不按因子权重加权，逐条状态见 data_quality.coverage_detail；"
                f"分母 {cov_stats['total']} = count-v1 的 26 条 − 1 条结构性不可得，"
                f"即外资维度：沪深港通日度净买入自 2024-08 停披露、仅剩周度持股变动与收盘后成交总额，"
                f"两者都不适配日度归因，故整条移出必需输入清单，不再计入分母、也不记为 missing；"
                f"count-v1 的报告（分母 26）与本期不可比。其中缺失 {cov_stats['missing']} 条："
                + "、".join(x["field"] for x in cov_detail if x["state"] == "missing")
                + "。v2.0 之前的 0.85~0.944 是加权口径，同样不可比）",
                (f"杠杆（截至 {lev['as_of']}，lag_trading_days={lev['lag_trading_days']}）：两融余额 {lev['balance_yi']} 亿、"
                 f"20 日 {lev['chg_20d'] * 100:+.2f}%、占流通市值 {lev['balance_to_float_pct'] * 100:.3f}%，趋势 {lev['trend']}；"
                 f"滞后 {lev['lag_trading_days']} 个交易日，只用于「截至 {lev['as_of']}」的水平与趋势描述，不用于 {as_of} 当日归因"
                 + (f"；本期 margin-{as_of} 缓存缺失，数值沿用 {lev_carried} 期（两融为慢变量，"
                    f"该跨度内余额变动在单日噪音量级）" if lev_carried else "")) if lev else
                "两融余额本期未取，market_regime.leverage 写 null，全文不使用杠杆维度",
                # 取数过程如实记录：本轮被 WAF 拦了几次、有没有影响，都写出来。
                # 「报告说没被拦，其实拦了 5 次」比拦截本身更危险——读者无法判断数据可信度。
                *([f"本轮取数：{r['ok'] + r['failed']} 次请求，成功 {r['ok']}、失败 {r['failed']}、"
                   f"WAF 拦截 {r['blocked']} 次、重试 {r['retry']} 次"
                   + ("（拦截全部来自腾讯日 K 的个股补历史，相关个股当日行情已在库内，未影响面板与广度）"
                      if r.get("blocked") else "")
                   + "。同一天反复全量重跑会显著提高拦截概率，非必要不重复取数"]
                  if (r := run.get("requests")) else []),
                "闸门矩阵（覆盖全部通过 ≥1 条闸门的板块，逐行给出板块 | P1 | P2 | P3 | 闸门命中 | 阶段命中 | stage）："
                + "；".join("闸门矩阵：" + line for line in gate_matrix),
                f"P2 覆盖与缺口：已完整计算 {n_p2} 个板块；未过 P2 的为 {'、'.join(p2_fail) if p2_fail else '无'}；"
                f"无法判定（有效样本 <10 只或窗口有缺口）的为 {'、'.join(p2_unknown) if p2_unknown else '无'}；"
                f"其余 {n_p2_rest} 个板块 P2 未计算，不据此下全样本唯一性结论",
                *([f"extra 补算了 {len(unscored)} 个板块但 score 缓存里没有："
                   f"{'、'.join((rows.get(c) or {}).get('name') or c for c in unscored)}；"
                   f"这些板块未进 emerging（不是「无分」而是「没算」），重跑 pipeline.score 后重新组装即可补全"]
                  if unscored else []),
                boundary_note,
                f"拥挤惩罚：{pen_note}（R1 需分位 >0.95 且连板 ≥5、R2 需分位 >0.90 且拥挤度 >0.90、R3 需 60 日 >60% 且 5 日净流出，多项命中取最大值）",
                f"份额分位的样本长度：{'、'.join(f'{rows[c]['name']} {samples[c]} 日' for c in [m['sector_codes'][0] for m in mainlines]) if mainlines else '空榜日无主线，不适用'}；"
                f"正文的「分位」均指该板块自身样本内的分位，不是跨板块的历史极值",
                f"breadth 因子的横截面百分位基于当日全部 {bb['ranked']} 个板块（上涨占比 / 强势股占比 / 涨停占比三项同分母，"
                f"与 score.py 同口径），其余四因子为 {len(rows)} 板块全域；rotation.emerging 的同一分位口径相同。"
                f"v1.9 起不再用候选样本（11-05 是 9 个）：9 个候选全是强票，彼此比较会把大多数压到低分位"
                f"（出版上涨占比 89.3% 曾排 18.2 分位），且分母随「今天几个板块过闸门」漂移",
                (f"叙事分（权重 0、不计入总分）：候选池为空——0 个板块通过 ≥2 条闸门，因此本期没有任何板块需要评叙事分，"
                 f"narrative 全部为 null，不按 0 分处理；分数由（可验证证据条数, 最高来源等级）按 §6 档位推导，台账里不接受手填分数"
                 if cov["total"] == 0 else
                 f"叙事分（权重 0、不计入总分）覆盖 {cov['evaluated']}/{cov['total']} 个候选："
                 + "、".join(f"{rows[c]['name']} {narr[c]['score']:.0f}" for c in pool if c in narr)
                 + (f"；未评的 {'、'.join(rows[c]['name'] for c in cov['missing'])} 写 null，"
                    f"不计 0 分、不参与边界裁决" if cov["missing"] else "")
                 + "。分数由（可验证证据条数, 最高来源等级）按 §6 档位推导，台账里不接受手填分数"),
                (f"TOP_N 边界（第 {args.top_n}/{args.top_n + 1} 名）：{tie['reason']}"
                 if tie else ("闸门合格且阶段可判定的候选只有 1 个（银行Ⅱ），不存在第 1/2 名边界裁决；没有为凑数放宽阈值或录用不合格板块"
                              if mainlines else "闸门合格且阶段可判定的候选为 0，不存在 TOP_N 边界裁决；没有为凑数放宽阈值或录用不合格板块")),
                "fundflow 与 volume 的 delta 口径：turnover_share_chg_5 为份额相对 5 个交易日前的变化，turnover_share_chg_20 为相对 20 个交易日前的变化，两者不同窗口",
                f"max_streak_prev 取 5 个交易日前（{dates[-6]}）涨停池的最高连板高度，不是「上一日」；divergence 的「连板回落 ≥2 级」用该口径",
                "资金轮动（5 日成交额份额变化，单位百分点）：流入 "
                + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}" for r in inflow[:3])
                + "；流出 " + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}".replace("-", "−") for r in outflow[:3])
                + "。注意份额与价格、资金三者会分叉：光伏设备 5 日份额 +1.38pct 居首，但当日 −2.22%、20 日仅 +0.32%、P1 2/20 天，是补仓不是趋势回流；"
                + "通信设备 5 日份额 +0.61pct、当日 +1.70%，20 日仍 −15.29%，钱在进、价在反弹但趋势没修好；"
                + "银行Ⅱ 5 日份额 −0.87pct、当日 +0.98%，价涨量退，是本期最典型的「存量防御」；"
                + "白酒Ⅱ 5 日份额 −1.01pct、20 日 +9.10%、当日 −0.19%，高位滞涨、资金先撤",
                (f"全市场广度口径：统计自新浪全 A 快照 {br['valid']} 只有效样本（剔除停牌 {br['suspended']} 只），"
                 f"上涨 {br['up']} / 下跌 {br['down']} / 平盘 {br['flat']}，up_ratio = {br['up']} ÷ {br['valid']} = "
                 f"{br['up_ratio']:.4f}，涨跌比 = {br['up']} ÷ {br['down']} = {br['advance_decline_ratio']:.2f}；"
                 f"含北交所口径为 {br['up_ratio']:.4f}，剔除北交所后沪深口径 "
                 f"{ex_up} ÷ {ex_valid} = "
                 f"{ex_ratio:.4f}，"
                 f"差 {abs(ex_ratio - br['up_ratio']) * 100:.2f}pct，两口径同向；分市场 up_ratio："
                 + "、".join(f"{k} {v['up'] / v['valid']:.1%}" for k, v in br["by_board"].items() if k != "其他")
                 + f"；涨跌分布 ≥9.8% 有 {br['distribution']['gt9']} 家、≤−9.8% 有 {br['distribution']['lt-9']} 家"
                 f"（含未封板的 20cm 个股，故与涨停池 {lim['market']['limit_up']} 家、跌停 {lim['market']['limit_down']} 家不同口径）"
                 + (f"；该快照抽 {br['cross_check']['sampled']} 只（含北交所 1 只）与腾讯行情逐只比对，一致 "
                    f"{br['cross_check']['matched']} 只，价差 {br['cross_check']['max_price_diff_pct']}%、"
                    f"涨跌幅差 {br['cross_check']['max_pct_diff_pct']}pct、成交额差 {br['cross_check']['max_amount_diff_pct']}%"
                    if br.get("cross_check") else "")) if br else
                "全市场涨跌家数本期未取，breadth.up_ratio 与 advance_decline_ratio 写 null",
                f"{as_of} {len(rows)} 个板块中 {up_boards} 个上涨；涨停 {lim['market']['limit_up']} 家、炸板 {lim['market']['broken']} 家、"
                f"跌停 {lim['market']['limit_down']} 家、封板率 {lim['market']['seal_rate']:.4f}；5 个交易日前（{lim['prev']}）涨停 {lim['market']['prev_limit_up']} 家，"
                f"本报告用该日涨停池计算 max_streak_prev；"
                f"涨停池为东财 push2ex 口径（{lim['market']['limit_up']} 家），媒体口径因是否计入 ST/北交所与 20cm 未封板个股而可能不同，全文统一用面板口径",
                "指数 5/20/60 日涨幅的取数过程：8 个指数的当日快照与日 K 均由腾讯 web.ifzq.gtimg.cn 取得，"
                "本期 0 次 WAF 拦截、0 次失败（快照时间 2026-11-09 16:14:28，收盘后）。"
                "上证 3660.79 +0.32%、深成指 11145.49 −0.27%、中证全指 5119.56 +0.08%、创业板指 2458.56 −0.27%，"
                "5/20/60 日序列与当日快照同源，可跨日比较",
                "阶段裁决顺序本期触发在两处：银行Ⅱ 按 fade(0/3)→divergence(0/3)→acceleration(1/3)→expansion(2/4) 的顺序取到第一个满足 ≥2 项的 expansion；"
                "数字媒体六个阶段最多只命中 1 项（fade 1/3、divergence 1/3、acceleration 1/3、expansion 0/4、trend 1/3、ignition 1/3），"
                "因此 stage 写 null 并改列 emerging——这是本期「闸门够但阶段不可判定」的唯一案例，规则不因它分数更高而放宽",
                *[stage_note[c] for c in stage_note],
                (f"P1/P3 候选 {len(listed)} 个，其中闸门合格（≥2 条）{sum(1 for x in listed if x['gates'] >= 2)} 个；"
                 f"合格但阶段无法赋值的 {sum(1 for x in listed if x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage'))} 个"
                 + (f"（{'、'.join(x['name'] for x in listed if x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage'))}）"
                    f"按 §4 改列 emerging、不进 mainlines；"
                    if any(x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage') for x in listed) else "；")
                 + f"其余按 TOP_N={args.top_n} 输出 {len(mainlines)} 条，未放宽阈值凑数；"
                 + (f"合格但超出 TOP_N 未入榜：{'、'.join(f'{x['name']}（{x['score']}）' for x in dropped if x['gates'] >= 2)}；" if any(x["gates"] >= 2 for x in dropped) else "")
                 + f"未进 mainlines 的 {len(emerging)} 个板块全部列入 rotation.emerging，其中 {len(stage_none)} 个属于「闸门够但阶段无法判定」"
                 + (f"（{'、'.join(x['name'] for x in stage_none)}）" if stage_none else "")
                 + f"、{len(one_gate)} 个属于「仅 1 条闸门」"
                 + (f"、{len(cut_by_topn)} 个被 TOP_N 截断" if cut_by_topn else "") + "；没有为凑数放宽阈值"),
            ],
        },
        "market_regime": {
            "label": "缩量分化：指数微涨、个股跌多涨少，1 条防御性主线（银行Ⅱ）",
            "phase": "choppy", "phase_label": "震荡分化（广度修复、量能继续退）",
            "risk_appetite": 32, "liquidity": 28, "breadth_score": 35,
            "indices": idx,
            "breadth": {
                "up_ratio": br["up_ratio"] if br else None, "limit_up": lim["market"]["limit_up"],
                "limit_down": lim["market"]["limit_down"],
                "broken_board_rate": round(lim["market"]["broken"] / (lim["market"]["limit_up"] + lim["market"]["broken"]), 4),
                "advance_decline_ratio": br["advance_decline_ratio"] if br else None,
                "new_high": None, "new_low": None,
            },
            "leverage": lev,
            "narrative": REGIME_NARRATIVE,
        },
        "verdict": {
            "headline": _headline,
            "core_thesis": _thesis,
            "stance": "defensive", "stance_label": "低仓防御，只认广度与份额，不认抗跌的故事",
            "dominant_mainline_id": mainlines[0]["id"] if mainlines else None,
            "mainline_count": len(mainlines),
            "confidence": 0.60,
            "points": _points,
            "horizon": {
                "valid_until": (datetime.strptime(as_of, "%Y-%m-%d") + timedelta(days=14)).strftime("%Y-%m-%d"),
                "review_trigger": "银行Ⅱ 的 Δ5 份额转正且成交额份额回到 2.5% 以上、或拥挤度升破 0.90 触发 R2、或银行Ⅱ 单日跌幅 >1% 且上涨占比跌破 50%、或出现新的板块同时过 ≥2 条闸门且 stage 可判定、或全市场成交额回到 1.7 万亿且 up_ratio 站上 0.55，任一出现即重估",
            },
        },
        "mainlines": mainlines,
        "rotation": {
            # 边界裁决留痕：没触发也写。读者需要知道「第 5 名不是靠叙事分挤进来的」，
            # 而不是只在触发时才看到一段解释（那样反而像在掩饰）。
            "tie_break": tie or ({
                "threshold": narrative.TIE_THRESHOLD, "boundary": args.top_n, "delta": None,
                "applied": False, "kept": None, "dropped": None,
                "reason": (f"闸门合格且阶段可判定的候选只有 {len(eligible)} 个（"
                           + "、".join(f"{x['name']} {x['score']:.2f}" for x in eligible)
                           + "），候选数不大于 TOP_N，没有第 n/n+1 名边界可裁；叙事分未参与座次"),
            } if mainlines else None),
            "narrative": (
                "本期的资金分布是一次典型的高低切换：5 日份额流入前三为 "
                + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}pct".replace("-", "−") for r in inflow[:3])
                + "，流出前三为 " + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}pct".replace("-", "−") for r in outflow[:3])
                + "。流入的钱没有换来价格：光伏设备当日 −2.22%、20 日 +0.32%、P1 2/20 天；"
                "消费电子当日 +1.20%、20 日 −6.63%、P1 0/20 天；通信设备当日 +1.70%、20 日 −15.29%、P1 0/20 天——"
                "钱在往跌深了的方向挪，但趋势都还没修好。"
                "流出端是高位与权重：证券Ⅱ Δ5 −1.49pct、当日 −0.53%；白酒Ⅱ −1.01pct、20 日仍有 +9.10%；"
                "银行Ⅱ −0.87pct、当日却 +0.98%——价涨量退，是本期最矛盾的一条。"
                "涨得最多的资源（焦炭Ⅱ +5.39%、燃气Ⅱ +3.25%、煤炭开采 +2.98%）份额几乎没有增量（+0.05~+0.14pct），"
                "说明这波是超跌反弹与冬季预期驱动，不是资金持续加仓。"
                f"在已完整计算 P2 的 {n_p2} 个板块中，{len(emerging)} 个未进主线："
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in stage_none)} 有 2 条闸门但阶段无法判定；" if stage_none else "")
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in one_gate)} 只有 1 条闸门；" if one_gate else "")
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in cut_by_topn)} 合格但被 TOP_N 截断。" if cut_by_topn else "")
                + "分数最高的影视院线 78.87、游戏Ⅱ 78.14 都停在一条闸门，数字媒体 71.95 卡在阶段判定——"
                "五因子打分衡量的是「谁更强」，闸门衡量的是「强是否同时发生在持续性、广度、量能三个维度」，"
                "阶段衡量的是「这条线走到哪一步」。三者都过才叫主线，缺一条就只能留在萌芽。"
                + (f"萌芽前五：{'、'.join(f'{s['name']} {s['score']}' for s in emerging[:5])}。" if len(emerging) > 5 else "")
            ),
            "inflow": [{"name": r["name"], "delta_pct": round((r["share_chg_5"] or 0) * 100, 2),
                        "note": f"20 日 {(r['chg_20d'] or 0) * 100:+.2f}%、当日 {(r['chg_1d'] or 0) * 100:+.2f}%、rs_20 {r['rs_20']:.4f}"} for r in inflow],
            "outflow": [{"name": r["name"], "delta_pct": round((r["share_chg_5"] or 0) * 100, 2),
                         "note": f"20 日 {(r['chg_20d'] or 0) * 100:+.2f}%、当日 {(r['chg_1d'] or 0) * 100:+.2f}%、rs_20 {r['rs_20']:.4f}"} for r in outflow],
            "emerging": [{"name": s["name"], "score": s["score"], "narrative": s["narrative"],
                          "signal": (
                              # 叙事强但闸门不足的前缀：它不改变排序（仍按分数），只保证读者不会
                              # 因为分数低而跳过一条证据链最硬的候选。
                              (f"【叙事 {narr_txt(s)}，仅差一条闸门】" if s.get("strong_but_gated") else "")
                              + f"P1 {'✓' if s['p1'] else '✗'}（前 10 {rows[s['code']]['days_top10_20']}/20 天、连续 {rows[s['code']]['consecutive_top10']} 天）；"
                              f"P2 {'✓' if s['p2'] else ('✗' if s['p2'] is False else '？无法判定')}"
                              f"（上涨 {(s['up'] or 0) * 100:.1f}%、新高 {(s['nh'] or 0) * 100:.1f}%，有效样本 {s['valid']} 只）；"
                              f"P3 {'✓' if s['p3'] else '✗'}（Δ5 {rows[s['code']]['share_chg_5'] * 100:+.2f}pct、分位 {rows[s['code']]['share_pct_250']:.4f}）"
                              + (f" → {s['gates']} 条闸门、阶段为 {STAGE_CN.get(sc_by.get(s['code'], {}).get('stage'), '—')}，"
                                 f"但综合分排第 {s.get('rank_overall')}，被 TOP_N 截断"
                                 if s["gates"] >= 2 and sc_by.get(s["code"], {}).get("stage")
                                 else (f" → {s['gates']} 条闸门，阶段无法判定，不进 mainlines"
                                       if s["gates"] >= 2 else " → 仅 1 条，不进 mainlines"))
                              + (f"；{s['penalty_rules'][0]} 扣 {s['penalty']} 分" if s["penalty"] else "；无拥挤惩罚"))}
                         for s in emerging],
            "timeline": [
                {"date": "2026-11-09", "event": "沪指 +0.32% 收 3660.79 点、科创50 +0.30%、中证全指 +0.08%；深成指 −0.27%、创业板指 −0.27%、中证500 −0.17%，指数分化", "impact": "neutral", "mainline_id": None},
                {"date": "2026-11-09", "event": "全市场 2242 家上涨对 3147 家下跌（up_ratio 0.4024、涨跌比 0.71），较 11-06 的 0.1360 修复近三倍，但绝对水平仍在五成以下", "impact": "positive", "mainline_id": None},
                {"date": "2026-11-09", "event": "成交额 14943.9 亿跌破 1.5 万亿，较 11-06 再缩约 1770 亿；涨停 54 家、炸板 44 家、跌停 1 家、封板率 55.10%、最高 6 连板", "impact": "negative", "mainline_id": None},
                {"date": "2026-11-09", "event": "资源与超跌电子领涨：焦炭Ⅱ +5.39%、燃气Ⅱ +3.25%、煤炭开采 +2.98%、元件 +2.49%（20 日 −17.91%）、通信设备 +1.70%（20 日 −15.29%）", "impact": "positive", "mainline_id": None},
                {"date": "2026-11-09", "event": "银行Ⅱ +0.98%，P1 11/20 天、连续 2 天，P2 上涨 88.1%/新高 30.95%，两条闸门成立；expansion 命中 2/4，成为本期唯一入榜主线", "impact": "positive", "mainline_id": "ml-bank"},
                {"date": "2026-11-09", "event": "银行 5 日份额 Δ5 −0.87pct（128 板块流出第三）、5 日主力净额 −0.74%，价格与资金背离", "impact": "negative", "mainline_id": "ml-bank"},
                {"date": "2026-11-09", "event": "中国银行公告中期股息每 10 股派 1.19 元、除净日 12-02；银行 4 只创历史新高、4 只获机构买入评级", "impact": "positive", "mainline_id": "ml-bank"},
                {"date": "2026-11-09", "event": "数字媒体 P1+P3 两条闸门、71.95 分高于银行，但六阶段判据最多命中 1 项，stage 无法赋值，按 §4 改列萌芽", "impact": "neutral", "mainline_id": None},
            ],
        },
        "risks": RISKS,
        "scenarios": SCENARIOS,
        "playbook": PLAYBOOK,
        "appendix": {
            "method_summary": (
                f"以 {as_of} 为基准日，用东方财富 {run['boards_live']} 个行业板块 {len(dates)} 个交易日（{dates[0]} 起）的涨跌幅与资金流重建成交额份额与横截面排名，"
                f"配合腾讯行情的指数与成分股 K 线计算广度、新高、涨停与龙头指标；先做反脉冲三原则闸门（P1 持续性 / P2 广度 / P3 量能）穷举，"
                f"过 ≥2 条者进入打分，再按 fade→divergence→acceleration→expansion→trend→ignition 顺序判阶段，阶段无法赋值者降入萌芽，"
                f"最后按五项因子加权（叙事分权重 0：分数由证据台账推导，仅在同分边界裁决座次）并扣 R1/R2/R3 拥挤惩罚。数据缺失一律写 null 并记入 missing。"
            ),
            "weights": static_w,
            "stage_rules": [
                {"stage": "ignition", "label": "启动期", "rule": "份额 Δ5 ≥+0.5pct；前 10 天数 ≤8；涨停 2~5 家（满足 2 项）"},
                {"stage": "expansion", "label": "发酵期", "rule": "份额分位 0.60~0.85；涨停 ≥5 家；连板 3~4；上涨占比 ≥60%（满足 2 项）"},
                {"stage": "trend", "label": "主升期",
                 "rule": "份额分位 ≥0.85；20 日涨幅 ≥8%；上涨占比 ≥70%（满足 2 项）"},
                {"stage": "acceleration", "label": "加速期", "rule": "20 日涨幅 >25%；拥挤度 >0.85；封板率 >75%（满足 2 项）"},
                {"stage": "divergence", "label": "分歧期", "rule": "5 日涨幅 <20 日涨幅/4；份额分位 >0.90；连板回落 ≥2 级（满足 2 项）"},
                {"stage": "fade", "label": "退潮期", "rule": "份额 Δ20 <−0.5pct；龙头 5 日跌幅 >8%；上涨占比 <45%（满足 2 项）"},
            ],
            "glossary": [
                {"term": "RS", "def": "相对强度净值比 =（1+板块区间收益）÷（1+中证全指同期收益），1.0 表示与大盘同步；负收益下方向仍正确"},
                {"term": "P1 持续性", "def": "20 日进入滚动 20 日涨幅前 10 的天数 ≥6 且最近连续 ≥2 天（横截面为 128 个板块的绝对前 10）"},
                {"term": "P2 广度", "def": "板块内上涨占比 ≥55% 且创 20 日新高占比 ≥8%；新高定义 = 收盘价高于前 20 个交易日（不含当日）最高收盘价"},
                {"term": "P3 量能", "def": "成交额占全 A 比重 5 日变化 ≥+0.5pct 且 250 日分位 ≥60，按 4 位小数原始精度比较"},
                {"term": "拥挤度", "def": "份额分位×0.5 + 20 日涨幅分位×0.5，用于 R2 与加速期判定"},
                {"term": "封板率", "def": "1 − 开板家数 ÷ 涨停家数，板块成分股口径"},
                {"term": "fundflow", "def": "5 日主力净额 ÷ 同期板块成交额，东财按单笔金额分档的测算值，权重上限 10%"},
            ],
            "changelog": [{"version": "1.9.1", "date": as_of,
                           "note": f"基准日 {as_of}：{len(rows)} 个板块 P1/P3 全样本穷举，P2 计算 {n_p2} 个板块，"
                                   f"闸门合格 2 个（银行Ⅱ P1+P2、数字媒体 P1+P3）；数字媒体六阶段判据最多命中 1 项、"
                                   f"stage 无法赋值，按 §4 改列 emerging；最终输出 1 条主线（银行Ⅱ，expansion）。"
                                   f"不以分数排序替代闸门与阶段判定，{len(emerging)} 个板块列入 emerging"},
                          {"version": "1.9.0", "date": as_of,
                           "note": f"breadth 口径重做：三项（上涨占比 / 强势股占比≥5% / 涨停占比）改用当日全部 "
                                   f"{bb['ranked']} 个板块做分位分母，不再按候选样本排分位；"
                                   f"新高占比退出计分、保留为 P2 闸门"}],
        },
    }

    # ---------------- 自检 ----------------
    for m in mainlines:
        s = sum(x["contribution"] for x in m["score_breakdown"]) - m["penalty"]
        assert abs(s - m["score"]) <= 0.5, (m["id"], s, m["score"])
        assert len(m["score_breakdown"]) == 6
        assert [x["key"] for x in m["score_breakdown"]][0] == "rs"
        assert m["score_breakdown"][0]["raw"] == m["metrics"]["rs_20"]
        assert m["persistence"]["pulse_check"]["passed"] == (m["persistence"]["pulse_check"]["rules_passed"] >= 2)
        assert m["penalty"] in (0, 6, 8, 12)
    assert abs(sum(x["probability"] for x in doc["scenarios"]) - 1.0) < 0.011
    assert doc["verdict"]["mainline_count"] == len(mainlines)
    assert [m["rank"] for m in mainlines] == list(range(1, len(mainlines) + 1))
    assert all(mainlines[i]["score"] >= mainlines[i + 1]["score"] for i in range(len(mainlines) - 1))

    dest = ROOT / args.out
    dest.write_text(serialize(doc), encoding="utf-8")
    raw = json.loads(dest.read_text(encoding="utf-8"))
    _txt = dest.read_text(encoding="utf-8")
    print(f"  -> {dest.relative_to(ROOT)}  {len(_txt)} 字符 / {len(raw['mainlines'])} 条主线 / "
          f"emerging {len(raw['rotation']['emerging'])} 条")
    for m in raw["mainlines"]:
        print(f"    #{m['rank']} {m['name']:<28} {m['score']:>6.2f}  {m['stage']:<12} 闸门 {m['persistence']['pulse_check']['rules_passed']} "
              f"pen {m['penalty']} conf {m['stage_confidence']}")
    return 0


def panel_top5(p: dict, code: str, n: int) -> int:
    """20 日进入前 5 的天数（persistence 的辅助字段，仅展示）。"""
    from pipeline import panel  # noqa: PLC0415
    return panel.top_days(p, code, n=n, top=5)["days_top10_20"]


def serialize(doc: dict) -> str:
    """按 v1.6 §10-D 排版：一个顶层键一行，对象内联。"""
    parts = []
    for k, v in doc.items():
        parts.append(f'"{k}": ' + json.dumps(v, ensure_ascii=False, separators=(",", ":")))
    return "{\n" + ",\n".join(parts) + "\n}"


if __name__ == "__main__":
    raise SystemExit(main())

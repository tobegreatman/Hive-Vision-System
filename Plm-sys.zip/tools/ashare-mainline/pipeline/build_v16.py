"""按 v1.6 契约组装完整报告（通用版：任意条主线，数值全部从缓存现算）。

    python -m pipeline.build_v16 --as-of 2026-11-02 --out aml-20261102-v16.json

与 build_report.py 的区别：后者是 2026-10-30 那一轮单主线的手写稿；本模块把
metrics / persistence / score_breakdown / 闸门矩阵 / 轮动榜全部由 cache 现算，
文字部分集中在 pipeline/content.py，换一天只要改 as_of 与文案。数值口径与 score.py 逐项对齐，
组装完做一致性自检（score = Σ贡献 − 惩罚、闸门条数与 metrics 自洽、rs.raw == score.rows[].rs）。
"""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import statistics
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent


def _prev_report_ranks(as_of: str) -> tuple[dict[str, int], str]:
    """上一期**报告**里的名次（按板块代码），用于 mainlines[].rank_change。

    只认 `aml-*.json`，不认 score 缓存：score 是全板块名次，报告只含入榜主线，
    两者分母不同。混用会出现「分数涨了、名次却显示下降」的自相矛盾。
    上一期未入榜的板块写 null——那表示「本期新入榜」，不是「名次没变」。
    """
    key = as_of.replace("-", "")
    # 文件名是 aml-YYYYMMDD-v16.json（8 位日期），通配符必须同样是 8 个 `?`。
    # 写成 6 个会匹配不到任何文件，rank_change 静默变成 null——读者会把它读成「新入榜」。
    files = [p for p in sorted(ROOT.glob("aml-????????-v16.json")) if p.stem[4:12] < key]
    if not files:
        return {}, ""
    prev = files[-1]
    try:
        data = json.loads(prev.read_text(encoding="utf-8"))
        ranks = {c: m["rank"] for m in data.get("mainlines") or []
                 for c in (m.get("sector_codes") or [])}
        return ranks, (data.get("meta") or {}).get("as_of") or prev.stem[4:12]
    except Exception:                                      # noqa: BLE001
        return {}, ""


def _prev_day_scores(as_of: str) -> tuple[dict[str, float], str]:
    """上一个交易日的板块分数：取 cache 里日期最近且早于 as_of 的 score-*.json。

    用途有两个：mainlines[].rank_change 与 changelog 的「分数变动」。
    返回 (板块分数, 该缓存日期)。缓存缺失时返回 ({}, "")，调用方据此写 null 而不是 0——
    0 表示「名次没变」，与「没有基线」是两件不同的事，混用会让读者把「未知」读成「持平」。
    """
    cache = ROOT / "pipeline" / "cache"
    cands = sorted(p for p in cache.glob("score-????-??-??.json") if p.stem[6:] < as_of)
    if not cands:
        return {}, ""
    prev = cands[-1]
    try:
        data = json.loads(prev.read_text(encoding="utf-8"))
        return {r["code"]: float(r["score"]) for r in data["rows"]}, prev.stem[6:]
    except Exception:                                      # noqa: BLE001
        return {}, ""

sys.path.insert(0, str(ROOT))

from pipeline import boardbreadth, cacheio, day, margin, regime  # noqa: E402
from pipeline import narrative  # noqa: E402
from pipeline import universe  # noqa: E402
from pipeline import quotes as qmod  # noqa: E402
from pipeline.content import (CONTENT, CONTENT_AS_OF, HEADLINE_REQUIRED,  # noqa: E402
                              META_TAGS, PLAYBOOK, REGIME_LABEL,
                              REGIME_NARRATIVE, REVIEW_TRIGGER,
                              RISKS, SCENARIOS, STAGE_CN, STANCE_LABEL,
                              THESIS_EMPTY_REQUIRED, TIMELINE,
                              THESIS_REQUIRED,
                              VERDICT_HEADLINE_EMPTY_TPL,
                              VERDICT_HEADLINE_MULTI_TPL,
                              VERDICT_HEADLINE_SINGLE_TPL, VERDICT_POINTS,
                              VERDICT_THESIS_EMPTY_TPL, VERDICT_THESIS_MULTI_TPL,
                              VERDICT_THESIS_TPL, render, require)
from pipeline.score import TOTAL_W, WEIGHTS, effective_weight, pct_in  # noqa: E402

C = ROOT / "pipeline" / "cache"

_RULE_BY_NAME = {
    "factors": cacheio.FACTORS_RULE,
    "run": cacheio.RUN_RULE,
    "score": cacheio.SCORE_RULE,
    "extra": cacheio.EXTRA_RULE,
}


def load(name: str, as_of: str) -> dict:
    d, warns = cacheio.read_json(C / f"{name}-{as_of}.json", name, as_of=as_of,
                                 expect_rule=_RULE_BY_NAME.get(name))
    if name in _RULE_BY_NAME:
        cacheio.warn(warns)
    return d


def _fill(obj, score, rank):
    """把 CONTENT 里的 {score}/{rank} 换成当期实算值（深拷贝，不改原表）。

    文案里写死分数是个反复出问题的地方：改一次评分口径就要手工追一遍正文，
    漏掉一处就是「正文说 79.24、表格写 83.05」。名次同理（影视院线从第 3 升到第 2）。
    """
    if isinstance(obj, str):
        return obj.replace("{score}", f"{score:.2f}").replace("{rank}", str(rank))
    if isinstance(obj, list):
        return [_fill(x, score, rank) for x in obj]
    if isinstance(obj, dict):
        return {k: _fill(v, score, rank) for k, v in obj.items()}
    return obj


def _sub(obj, mapping):
    """按 {key} 映射替换文案里的动态字段（名次、分差这类不是每块都有的东西）。"""
    if isinstance(obj, str):
        for k, v in mapping.items():
            obj = obj.replace(k, v)
        return obj
    if isinstance(obj, list):
        return [_sub(x, mapping) for x in obj]
    if isinstance(obj, dict):
        return {k: _sub(v, mapping) for k, v in obj.items()}
    return obj


_CN_NUM = "零一二三四五六七八九十"


def _cn(n: int) -> str:
    """0~10 的中文数字。主线一般不超过 10 条，超出直接写阿拉伯数字。"""
    return _CN_NUM[n] if 0 <= n <= 10 else str(n)


# count-v2：把「结构性不可得」的条目移出分母。
# v1 的 26 条里含 1 条永远不可能 full 的（陆股通持股变动：日度净买入 2024-08 起停披露），
# 它长期挂 missing，等于分母恒虚高 1 条、coverage 恒定被压低约 3.2pct，而读者无法区分
# 「做不到」与「这期没做到」。v2 把它整条移出，分母 26 → 25。
# 其余 missing（新高新低家数、PE 分位、两融）都留在分母里——它们是真实可改进的欠账，
# 留着才有改进压力，不能因为「这期没取到」就缩小分母把分数做上去。
COVERAGE_METHOD = "count-v2"


def data_coverage(*, rows: dict, p: dict, bb: dict, br, lim, lev, base_src: str,
                  idx_live: dict | None, cand_members: set, quotes: dict,
                  samples: dict, n_p2: int, lev_carried: str | None = None):
    """数据覆盖度：数「必需输入条目」，不数打分权重。

    v2.0 起换掉「因子权重 × 折扣」的加权口径。旧口径的问题是分母会随版本漂移：
    叙事分移出总分时分母从 100 缩到 90，同一个分子 85 就从 85% 变成 94.4%——
    涨的 9.4 个点一分不来自取数，读者也复算不出来（那个 90 只写在代码里）。

    这里改成可以数的条目：完整 = 1，降级（有值但口径被替代或打折）= 0.5，缺失 = 0，
    分母是条目总数。条目清单本身是设计选择，但每一条的判定都来自当期数据，
    并且逐条写进 data_quality.coverage_detail，读者可以自己点着数一遍。

    注意：这份清单与 score 的因子权重无关，也不该相关——数据完整度和「因子有多重要」
    是两件事，混在一起就又会得到一个人人看不懂的百分比。
    """
    n = len(rows)
    items: list[dict] = []

    def add(group: str, field: str, state: str, evidence: str) -> None:
        items.append({"group": group, "field": field, "state": state, "evidence": evidence})

    def preset(key: str) -> int:
        return sum(1 for r in rows.values() if r.get(key) is not None)

    def board_field(group: str, field: str, key: str) -> None:
        c = preset(key)
        if c == n:
            add(group, field, "full", f"{c}/{n} 板块")
        elif c:
            add(group, field, "degraded", f"{c}/{n} 板块，其余为 null")
        else:
            add(group, field, "missing", f"0/{n} 板块，全为 null")

    # —— 相对强度
    board_field("相对强度", "板块 20 日收益", "chg_20d")
    board_field("相对强度", "板块 60 日收益", "chg_60d")
    add("相对强度", "基准指数 20 日收益",
        "full" if base_src == "indices-live" else "degraded",
        "当日指数快照" if base_src == "indices-live"
        else f"回落常量（{base_src}），rs 与全部分数一起偏移")

    # —— 趋势持续性
    board_field("趋势持续性", "前 10 天数", "days_top10_20")
    board_field("趋势持续性", "连续前 10 天数", "consecutive_top10")
    board_field("趋势持续性", "60 日阳线占比", "up_days_60")

    # —— 量能聚集
    src = (p or {}).get("amount_src") or {}
    k, f = src.get("kline", 0), src.get("flow", 0)
    tot = k + f
    if tot and f == 0:
        add("量能聚集", "板块成交额（日线真值）", "full", f"kline {k} / 反推 {f}")
    elif k:
        add("量能聚集", "板块成交额（日线真值）", "degraded", f"kline {k} / 反推 {f}（净额÷占比）")
    elif any(r.get("share") is not None for r in rows.values()):
        # v1.8 及以前的面板没有 amount_src 字段：份额来自「主力净额 ÷ 净流入占比」反推，
        # 有值但口径打折，记降级而不是缺失——重算历史期数时这一档不能缺。
        add("量能聚集", "板块成交额（日线真值）", "degraded",
            "面板无 amount_src（v1.8 前格式），成交额为净额÷占比反推")
    else:
        add("量能聚集", "板块成交额（日线真值）", "missing", "面板无成交额")
    board_field("量能聚集", "成交额份额", "share")
    board_field("量能聚集", "5 日份额变化", "share_chg_5")
    board_field("量能聚集", "20 日份额变化", "share_chg_20")
    smin = min(samples.values()) if samples else 0
    c250 = preset("share_pct_250")
    if c250 == n and smin >= 250:
        add("量能聚集", "250 日份额分位", "full", f"{c250}/{n} 板块，最短样本 {smin} 日")
    elif c250:
        add("量能聚集", "250 日份额分位", "degraded",
            f"{c250}/{n} 板块，最短样本 {smin} 日（不足 250 日，按实际样本算分位）")
    else:
        add("量能聚集", "250 日份额分位", "missing", "全为 null")

    # —— 扩散度
    bbs = (bb or {}).get("boards") or {}
    ranked = [v for v in bbs.values() if v.get("ranked")]
    for field, key in (("板块上涨占比", "up_ratio"), ("强势股占比（≥5%）", "strong_ratio"),
                       ("涨停占比（板块内）", "limit_up_ratio")):
        c = sum(1 for v in ranked if v.get(key) is not None)
        add("扩散度", field, "full" if ranked and c == len(ranked) else "degraded",
            f"{c}/{len(ranked)} 个参与排名的板块")

    # —— 资金流
    board_field("资金流", "5 日主力净额", "flow5")
    add("资金流", "净流入占比（东财测算）", "degraded",
        "东财按单笔金额分档测算，不是交易所逐笔成交，量级可用、精度有限")

    # —— 市场情绪与杠杆
    add("市场情绪", "全 A 涨跌家数", "full" if br else "missing",
        f"新浪全 A 快照本地统计，{br['valid']} 只有效样本" if br else "本期未取")
    add("市场情绪", "全 A 创新高/新低家数", "missing", "需 5000+ 只个股日线，超出单期取数预算")
    add("市场情绪", "涨停/炸板/跌停池", "full" if lim else "missing",
        f"{lim['market']['limit_up']} 家涨停 / {lim['market']['broken']} 家炸板" if lim else "本期未取")
    if lev and lev_carried:
        # 沿用上一期缓存：数值可用，但不是当期取数成功，记降级而不是完整
        add("市场情绪", "两融余额", "degraded",
            f"截至 {lev['as_of']}，相对 {as_of} 滞后 {lev['lag_trading_days']} 个交易日"
            f"（本期缓存缺失，沿用 {lev_carried} 期）")
    elif lev:
        add("市场情绪", "两融余额", "full",
            f"截至 {lev['as_of']}，滞后 {lev['lag_trading_days']} 个交易日")
    else:
        add("市场情绪", "两融余额", "missing",
            f"本期未取，且无 {margin.MAX_CARRY_LAG} 个交易日内可沿用的缓存")
    add("市场情绪", "指数 5/20/60 日序列", "full" if idx_live and idx_live.get("indices") else "missing",
        f"{len(idx_live['indices'])} 个指数当日快照与日 K" if idx_live and idx_live.get("indices") else "本期未取")

    # —— 结构与估值
    add("结构与估值", "板块成分股清单", "full" if cand_members else "missing", f"去重 {len(cand_members)} 只")
    add("结构与估值", "个股报价快照", "full" if quotes else "missing", f"{len(quotes)} 只成分股报价")
    add("结构与估值", "全部板块 P2 覆盖",
        "full" if n_p2 >= n else "degraded",
        f"{n_p2}/{n} 个板块（P2 要逐板块拉成分股 K 线，只对候选与近失板块计算）")
    add("结构与估值", "板块 PE 250 日分位", "missing", "中证指数官网估值分位未取")

    total = len(items)
    full = sum(1 for x in items if x["state"] == "full")
    deg = sum(1 for x in items if x["state"] == "degraded")
    miss = sum(1 for x in items if x["state"] == "missing")
    cov = round((full + 0.5 * deg) / total, 4) if total else 0.0
    return cov, items, {"total": total, "full": full, "degraded": deg, "missing": miss}


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--out", default="", help="缺省由 as_of 推导，避免重跑时覆盖上一期")
    ap.add_argument("--top-n", type=int, default=5,
                    help="入榜上限；传 0 表示取全部阶段可判定的板块")
    ap.add_argument("--allow-fallback-base", action="store_true",
                    help="允许用 FALLBACK_IDX_REF（2026-10-30 常量）当基准组装；默认拒绝，因为 rs 会整体偏")
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)
    as_of = args.as_of
    # 文案是逐日手写的（驱动、失效条件、催化剂都是当天的事实），CONTENT 却按板块代码全局存一份。
    # 于是「用今天的话术配昨天数据」只差一次 --as-of：11-03 的白酒会渲染成 11-05 的「五个月后重回前 10」。
    # 字段齐全时旧检查看不出来，所以在这里按日期拦一道。
    if as_of != CONTENT_AS_OF:
        print(f"[FATAL] CONTENT 是给 {CONTENT_AS_OF} 写的，不能用它组装 {as_of} 的报告：")
        print(f"  历史日期的报告正文需要按当天的事实重写（drivers/catalyst/invalidation 都是日更内容）。")
        print(f"  只想复算数字：用 pipeline.score 后另存，不要重出报告；")
        print(f"  确实要重写：先把 CONTENT_AS_OF 改成 {as_of} 并按当天证据重写全部文案。")
        return 2

    if not args.out:
        args.out = f"aml-{as_of.replace('-', '')}-v16.json"

    fac = load("factors", as_of)
    bb = boardbreadth.load(as_of)
    # 基准必须来自当日指数快照。factors 取不到中证全指时会回落 FALLBACK_IDX_REF
    # （2026-10-30 的常量：中证全指 20 日 −14.44%，而 11-05 真实是 −6.26%），
    # 128 个板块的 rs 与全部分数会一起偏，而报告看上去完全正常。
    # indices.py 已加写入守卫（有旧文件时拒绝覆盖），这里兜最后一层：只要不是当日快照、
    # 又不是常量自身的日期，就拒绝组装——宁可不出报告，也不出一份基准错的报告。
    base_src = fac.get("base_source", "")
    if base_src != "indices-live" and as_of != "2026-10-30" and not args.allow_fallback_base:
        print("[FATAL] 基准不是当日指数快照，拒绝组装：")
        print(f"  factors.base_source = {base_src}（回落常量：中证全指 20 日 −14.44%）")
        print(f"  factors.base.chg_20d = {fac['base'].get('chg_20d')}")
        print(f"  先补 indices：python -m pipeline.indices --as-of {as_of}（或 --until indices 重跑）")
        print(f"  确认要用常量基准时加 --allow-fallback-base，并在报告里注明。")
        return 2
    run = load("run", as_of)
    sc = load("score", as_of)
    lim = load("limit", as_of)
    idx_live = load("indices", as_of)
    extra = load("extra", as_of)
    # 当期 regime 与生效阈值：报告里的 P2/P3 与阶段判据必须和 run/score 用同一套数字，
    # 不能在这里再写死一份。
    reg = run.get("regime") or regime.load(as_of) or regime.fallback(as_of, "run 缓存缺 regime")
    th = reg.get("thresholds") or dict(regime.THRESHOLDS["neutral"])
    # 两融：当期缓存缺失时沿用最近一期（滞后 >3 个交易日则不沿用），沿用信息进 coverage 记降级
    lev, lev_info = margin.load_carried(as_of)
    lev_carried = lev_info.get("carried_from")
    lev_rows = lev_info.get("rows")
    # 板块清单快照：只用于 data_quality.notes 的生存偏差说明，不参与任何计算。
    uni = universe.load(as_of)
    narr = narrative.load(as_of)
    p, warns = cacheio.read_pickle(C / f"panel-{as_of}.pkl", "panel", as_of=as_of,
                                   expect_rule=cacheio.PANEL_RULE)
    cacheio.warn(warns)
    quotes, q_snap_date = qmod.load(C, as_of)
    if not quotes:
        raise SystemExit(
            f"[FATAL] 缺少 quotes-{as_of}.json：龙头梯队要按当日成交额排序，没有报价快照无法组装。"
            f"先跑 `python -m pipeline.run --as-of {as_of}`（或至少 score）生成快照。")
    if q_snap_date and q_snap_date != as_of:
        # 不该发生：save() 已守住写入端。留这条是因为历史缓存可能还在，且一旦出现
        # 说明有人手工放文件，龙头排序会按错日期的成交额选票。
        print(f"  ⚠ 快照交易日 {q_snap_date} ≠ 基准日 {as_of}，龙头梯队排序可能失真")
    # 全市场广度：pipeline.breadth 从新浪全 A 快照（5576 只）本地统计；缺失则回落 null
    br_p = C / f"breadth-{as_of}.json"
    br = json.loads(br_p.read_text(encoding="utf-8")) if br_p.exists() else None

    rows, pc = fac["rows"], fac["pct"]
    base = fac["base"]
    g_by = {g["code"]: g for g in run["gates"]}
    sc_by = {r["code"]: r for r in sc["rows"]}
    dates = sorted(p["by_date"])
    cal = dates

    con = sqlite3.connect(f"file:{C / 'kline.sqlite'}?mode=ro", uri=True)

    def stk_ret(code: str, n: int) -> float | None:
        r = con.execute("select d, c from kline where code=? and d<=? order by d desc limit ?",
                        (code, as_of, n + 1)).fetchall()
        if len(r) < n + 1 or r[0][0] != as_of:
            return None
        return round(r[0][1] / r[-1][1] - 1, 4)

    def stk_ma(code: str, n: int = 20) -> float | None:
        r = con.execute("select c from kline where code=? and d<=? order by d desc limit ?",
                        (code, as_of, n)).fetchall()
        return round(sum(x[0] for x in r) / len(r), 2) if len(r) == n else None

    def members(code: str) -> list[str]:
        f = C / f"codes-{code}.json"
        return [str(x).zfill(6) for x in json.loads(f.read_text(encoding="utf-8"))] if f.exists() else []

    def net_sum(code: str, n: int) -> float:
        tot = 0.0
        for d in dates[-n:]:
            r = p["by_date"][d].get(code)
            if r and r.get("net"):
                tot += r["net"]
        return round(tot / 1e8, 2)

    def amt_sum(code: str, n: int) -> float:
        tot = 0.0
        for d in dates[-n:]:
            r = p["by_date"][d].get(code)
            if r and r.get("amount"):
                tot += r["amount"]
        return tot / 1e8

    def volatility(code: str, n: int = 20) -> float | None:
        s = [p["by_date"][d][code]["pct"] for d in dates[-n:] if p["by_date"][d].get(code)]
        return round(statistics.pstdev(s) / 100, 4) if len(s) >= n - 1 and s else None

    # ---------------- 横截面样本（与 score.py 完全一致） ----------------
    all_rows = list(rows.values())
    S_rs = [r["rs_20"] for r in all_rows]
    S_dt = [r["days_top10_20"] for r in all_rows]
    S_cs = [r["consecutive_top10"] for r in all_rows]
    S_ud = [r["up_days_60"] for r in all_rows]
    S_sh = [r["share"] for r in all_rows]
    S_d5 = [r["share_chg_5"] for r in all_rows]
    S_fl = [r["flow5"] for r in all_rows]
    S_g20 = [r["chg_20d"] for r in all_rows]
    gated = [sc_by[c] for c in g_by if c in sc_by]
    S_up = [g_by[r["code"]]["breadth_up_ratio"] for r in gated]
    S_nh = [g_by[r["code"]]["new_high_ratio"] for r in gated]
    S_zt = [r["pool"]["limit_up_count"] for r in gated]

    # ---------------- 闸门 / 阶段 / 打分 ----------------
    def board_score(code: str, with_stage: bool = True) -> dict:
        """直接取 score.py 的结果，不再重算。

        这里曾经把六因子重算过一遍，靠断言与 score.py 对齐。但两边的 breadth 样本
        （S_up / S_nh / S_zt）走了不同路径：score 的 S_zt 用 pool_stats 的 limit_up_count，
        此处用 lim["limit_up"] 与 members 的交集——2026-11-05 休闲食品算出 0 vs 1，
        经 pct_in 放大成分位 10 vs 90，分数差 3.33 才被断言拦住。断言能发现漂移，
        但发现不了「两套算法都自认为对」的情形。唯一真相只能有一份，直接读。
        """
        f = rows[code]
        o = sc_by[code]
        g = g_by.get(code) or (extra.get("rows") or {}).get(code) or {}
        p1 = g.get("p1", f["days_top10_20"] >= 6 and f["consecutive_top10"] >= 2)
        p3 = g.get("p3", (f["share_chg_5"] or 0) >= th["p3_share_chg_5"]
                   and (f["share_pct_250"] or 0) >= 0.60)
        p2 = g.get("p2")
        if "p2" not in g:
            # extra 补算的行只有 P2 的原料（up_ratio / new_high_ratio / valid），没有判定结果。
            # 直接用 g.get("p2") 会得到 None，正文就写成「P2 ？无法判定」——而 score 已经按
            # 阈值判过了（半导体 11-10 就是这样：gates=1，P2 实际成立，文字却说无法判定）。
            # 这里按 score 的同一套口径还原：先判「样本是否够」，判定结果用 gates 反推。
            p2 = (None if (g.get("valid") or 0) < 10 or g.get("degraded")
                  else bool(o["gates"] - int(bool(p1)) - int(bool(p3)) >= 1))
        return {
            "code": code, "name": f["name"], "p1": p1, "p2": p2, "p3": p3,
            "gates": o["gates"],
            "up": g.get("breadth_up_ratio", g.get("up_ratio")),
            "nh": g.get("new_high_ratio"),
            "valid": g.get("valid"),
            "rs": o["rs"], "crowd": o["crowding"],
            "norm": o["norm"], "contrib": o["contrib"],
            "penalty": o["penalty"], "penalty_rules": o["penalty_rules"],
            "score": o["score"],
            # 叙事分随每条记录一起走：mainlines 要用它写拆解，emerging 要用它标注，
            # 边界裁决也要用它。放在唯一入口（board_score）里，三处拿到的必然是同一个值。
            "narrative": narrative.score_of(narr, code),
            "limit_up_count": o["pool"]["limit_up_count"],
            "streak": o["pool"]["max_streak"],
        }

    scored = {code: board_score(code) for code in g_by}

    # 上一期名次：按分数降序，全样本（含未入榜）排名，避免「上一期没入榜」被当成第 0 名
    # 名字不能叫 _prev：主循环里 _prev 已被 max_streak_prev 复用，会被覆盖成 int
    _prev_scores, _prev_label = _prev_day_scores(as_of)
    _prev_label = _prev_label or "无缓存"
    _prev_report_map, _ = _prev_report_ranks(as_of)

    def narr_txt(s: dict) -> str:
        """叙事分的人读形式。未评写「未评」而不是 0——两者含义不同。"""
        v = s.get("narrative")
        return "未评" if v is None else f"{v:.0f}"

    # ---------------- mainlines ----------------
    listed = sorted([scored[c] for c in g_by], key=lambda x: -x["score"])
    # v1.6 §4：阶段无法赋值（sc_by[code]["stage"] 为 None）的板块不得进 mainlines，
    # schema 的 stage 不允许 null。分数再高也只能进 rotation.emerging——这里先按可判定性分流再取 TOP_N，
    # 否则 top 会混进 stage=None 的板块，最终写出违反契约的报告。
    eligible = [s for s in listed if sc_by.get(s["code"], {}).get("stage")]
    # TOP_N 切口：先按分数排，再看第 n 与 n+1 名这一对。分差 ≥1 分则分数已能区分，
    # 直接截断；<1 分时由叙事分裁决——1 分以内的差距在 128 个板块的横截面里
    # 扛不住四舍五入与取数日的微小抖动，此时「谁的产业证据更硬」比 0.3 分更可靠。
    # 裁决只换座次、不改分数，pick_top 会把双方与理由一并返回，由 rotation.tie_break 落盘。
    top_n = args.top_n if args.top_n > 0 else len(eligible)
    top, dropped, tie = narrative.pick_top(eligible, top_n, narr)
    # 候选池 = 闸门合格且阶段可判定、真正参与 TOP_N 竞争的板块。叙事覆盖只对它们做强制要求：
    # 1 条闸门的板块根本进不了榜，不评叙事分是合理的，不能算「缺失」。
    pool = [x["code"] for x in eligible]
    cov = narrative.coverage(narr, pool)

    # emerging：所有恰好命中 1 条闸门的板块（run 的候选 + extra 的补算板块），按六因子实算。
    # v1.6 还要求「闸门够但阶段无法判定」的板块不得进 mainlines，同样改列 emerging。
    # 只看 extra 会漏掉 run 里落榜的候选。
    emerging = []
    top_codes = {t["code"] for t in top}
    # 用「可赋值阶段」的名单排名：TOP_N 是在 eligible 里截断的，用全样本名次会
    # 把电视广播Ⅱ 这类 1 条闸门的板块算进去，出现「排第 7 却被 TOP_N=5 截断」的错位。
    # 合并 top + dropped 而不是用 eligible 原序：裁决过的边界必须反映在名次上。
    rank_of = {x['code']: i + 1 for i, x in enumerate(top + dropped)}
    # run 的候选缺分是致命的：score.json 与 run.json 不同源（重跑了 run 没重跑 score）。
    # 直接给出可执行的提示，而不是在 board_score 里抛 KeyError + 一屏堆栈。
    lost = [c for c in g_by if c not in sc_by]
    if lost:
        print(f"[FATAL] score 缓存缺 {len(lost)} 个 run 候选：{'、'.join(lost)}")
        print("  run 与 score 不同步。先跑 python -m pipeline.score 再组装。")
        return 2
    # extra 补算的板块缺分则只跳过：它们不进 mainlines，少几条 emerging 不影响结论，
    # 但必须在 data_quality 里说明，不能让板块静默消失。
    unscored: list[str] = []
    for code in list(g_by) + [c for c in extra["rows"] if c not in g_by]:
        if code not in sc_by:
            unscored.append(code)
            continue
        s = board_score(code)
        if code in top_codes:
            continue
        # 三种都算「未进主线」：①只有 1 条闸门；②闸门够但阶段无法判定；③闸门、阶段都有，
        # 但综合分排在 TOP_N 之外。原来漏了第③种——电池本轮 P3 转正后从「1 条闸门」升到 2 条，
        # 于是既不在 mainlines 也不在 emerging，整只板块从报告正文里消失了，只有数据质量注记
        # 还提了一句「合格但超出 TOP_N 未入榜」。排第 6 的板块必须有地方可看。
        if s["gates"] == 1 or s["gates"] >= 2:
            s["rank_overall"] = rank_of.get(code)
            # 未评写 None，不写 0——0 是「有 0 条证据」，与「本轮没登记」是两件事，
            # 混用会让读者把缺评读成没叙事（build_v16 曾把两者都记成 0）。
            # 「叙事 ≥85 却只差一条闸门」单独打标：半导体 11-05 是 P1 0/20 天、分数排第 12，
            # 按分数排会被埋在萌芽列表末尾，但它的产业证据（任天堂存储涨价 + 云南锗业五年合同）
            # 是当日第二硬的一档。标签不改变归属，只让它在正文里被点到名。
            s["strong_but_gated"] = narrative.strong_but_gated(narr, code, s["gates"])
            emerging.append(s)
    emerging.sort(key=lambda x: -x["score"])

    # 未进主线的板块按原因分组。正文与 data_quality 共用这一份分组，
    # 免得「出版 62.94 被截断」这类手写名单在下次换榜后继续留在报告里（它已经过期过一次）。
    cut_by_topn = [s for s in dropped if s["gates"] >= 2]
    one_gate = [s for s in emerging if s["gates"] == 1]
    stage_none = [s for s in emerging if s["gates"] >= 2
                  and not sc_by.get(s["code"], {}).get("stage")]
    strong_gated = [s for s in emerging if s.get("strong_but_gated")]

    # 换一个交易日重跑时，CONTENT 与 narrative 仍是上一期写的：若不拦住，就会把昨天的
    # 板块名套上今天的数字，生成一份「名字与数值不匹配」却不报错的报告。
    no_text = [f"{s['name']}({s['code']})" for s in top if s["code"] not in CONTENT]
    no_narr = [f"{s['name']}({s['code']})" for s in top if s["code"] not in narr]
    if no_text or no_narr:
        print("[FATAL] 本期榜单与该日文案不匹配，拒绝组装：")
        if no_text:
            print(f"  CONTENT 缺文案：{'、'.join(no_text)}")
        if no_narr:
            print(f"  templates/narrative.json[{as_of}] 缺叙事台账：{'、'.join(no_narr)}")
        print(f"  本期上榜为：{'、'.join(f'{s['name']}={s['score']}' for s in top)}")
        print("  请先补文案与叙事台账（evidence/source），或用 --top-n 调整目标条数后重试。")
        return 2
    # 落榜但仍在候选池里的板块缺评：不阻断（它们不进正文主线），但必须说出来。
    # 「静默按 0 计」是这次改造要消灭的行为——0 分会被读者当成「无叙事」。
    if cov["missing"]:
        print(f"  [warn] 候选池 {cov['total']} 个中有 {len(cov['missing'])} 个未评叙事分："
              f"{'、'.join(rows[c]['name'] for c in cov['missing'])}（写 null，不参与边界裁决）")

    # 台账与证据链互锁：入榜主线的 evidence 必须等于 drivers 里 verified 的条数。
    # §6 的分档就是从 drivers 数出来的，台账另记一个数等于把「证据」变成第二份真相——
    # 11-05 的白酒原本记 78（3 条应是 75 或 80），就是这么飘出来的。
    # 这条校验逼着「改文案」与「改台账」同步发生，缺一边就拒绝组装。
    ev_bad = []
    for s in top:
        n_ev = sum(1 for d in CONTENT[s["code"]].get("drivers", []) if d.get("verified"))
        got = (narr.get(s["code"]) or {}).get("evidence")
        if got is not None and got != n_ev:
            ev_bad.append(f"{s['name']}（台账 {got} 条 / drivers {n_ev} 条）")
    if ev_bad:
        print("[FATAL] 叙事台账与证据链条数不一致，拒绝组装：")
        for x in ev_bad:
            print(f"  {x}")
        print("  改 drivers 就要同步改 templates/narrative.json 的 evidence，反之亦然。")
        return 2

    # 边界文案按实际截断位置写，不按请求的 --top-n：候选不足时（例如只有 1 条主线）
    # 按 --top-n 写「第 5/6 名」会凭空造出一个不存在的边界，--top-n 0 时更会写成「第 0/1 名」。
    top_boundary = len(top)
    narr_metric_note = (
        f"权重 0、不计入总分，仅在第 {top_boundary}/{top_boundary + 1} 名分差 <1 分时裁决座次"
        if dropped else "权重 0、不计入总分；本期候选全部入榜，无边界座次裁决")

    mainlines = []
    stage_note: dict[str, str] = {}
    for rank, s in enumerate(top, 1):
        code = s["code"]
        ct = _fill(CONTENT[code], s["score"], rank)
        f = rows[code]
        gi = g_by[code]
        mem = [m for m in members(code) if m in quotes]
        mem.sort(key=lambda c: -(quotes[c].get("amount_yi") or 0))
        leaders = []
        for i, c in enumerate(mem[:5]):
            leaders.append({
                "code": (c + (".SZ" if c[0] in "03" else ".SH")),
                "name": quotes[c].get("name"),
                "role": "leader" if i == 0 else ("core" if i < 3 else "follower"),
                "chg_20d": stk_ret(c, 20),
                "turnover_yi": round(quotes[c].get("amount_yi") or 0, 2),
                "note": ct["leader_note"].get(c, ""),
            })
        net5, net20 = net_sum(code, 5), net_sum(code, 20)
        amt5 = amt_sum(code, 5)
        flow_ratio = round(net5 / amt5 * 100, 3) if amt5 else None
        pct20 = pc[code]
        metrics = {
            "chg_1d": round(f["chg_1d"], 4), "chg_5d": round(f["chg_5d"], 4),
            "chg_20d": round(f["chg_20d"], 4), "chg_60d": round(f["chg_60d"], 4),
            "rs_5": f["rs_5"], "rs_20": f["rs_20"], "rs_60": f["rs_60"],
            "turnover_share": round(f["share"], 6),
            "turnover_share_chg_5": round(f["share_chg_5"], 6),
            "turnover_share_chg_20": round(f["share_chg_20"], 6),
            "turnover_share_pct_250": f["share_pct_250"],
            "breadth_up_ratio": round(gi["breadth_up_ratio"], 4),
            "new_high_ratio": round(gi["new_high_ratio"], 4),
            "limit_up_count": s["limit_up_count"],
            "limit_up_ratio": round(s["limit_up_count"] / gi["valid"], 4) if gi["valid"] else None,
            "max_streak": s["streak"],
            "max_streak_prev": sc_by[code]["pool"]["max_streak_prev"],
            "seal_rate": sc_by[code]["pool"]["seal_rate"],
            "leader_chg_5d": sc_by[code]["pool"]["leader_chg_5d"],
            "net_inflow_5_yi": net5, "net_inflow_20_yi": net20,
            "crowding_pct": s["crowd"], "volatility_20": volatility(code),
        }
        # 闸门 detail：逐条写取值与判定，✗ 个数必须与 rules_passed 自洽
        d = (f"P1 {gi['days_top10_20']}/20 天、连续 {gi['consecutive_top10']} 天"
             f" {'✓' if s['p1'] else '✗'}；P2 上涨 {gi['breadth_up_ratio'] * 100:.1f}%、新高 {gi['new_high_ratio'] * 100:.1f}%"
             f" {'✓' if s['p2'] else '✗'}；P3 份额 Δ5 {f['share_chg_5'] * 100:+.2f}pct、分位 {f['share_pct_250']:.4f}"
             f" {'✓' if s['p3'] else '✗'} → {s['gates']} 条通过").replace("-", "−")
        # 这三个量在「无涨停」「K 线有缺口」时合法为 None，直接乘 100 会 TypeError。
        # 报告里要显示成文字而不是 0，否则「+0.00%」会被读成「持平」。
        _pool = sc_by[code]["pool"]
        _lead, _seal, _prev = _pool["leader_chg_5d"], _pool["seal_rate"], _pool["max_streak_prev"]
        lead_txt = f"{_lead * 100:+.2f}%" if _lead is not None else "无数据"
        seal_txt = f"{_seal:.4f}" if _seal is not None else "无涨停"
        prev_txt = "无数据" if _prev is None else str(_prev)
        stage_rules = {
            "fade": f"Δ20 {f['share_chg_20'] * 100:+.2f}pct / 龙头 5 日 {lead_txt} / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "divergence": f"5 日 {f['chg_5d'] * 100:+.2f}% vs 20 日 1/4 {f['chg_20d'] / 4 * 100:+.2f}% / 分位 {f['share_pct_250']:.4f} / 连板 {prev_txt}→{s['streak']}",
            "acceleration": f"20 日 {f['chg_20d'] * 100:+.2f}% / 拥挤 {s['crowd']:.4f} / 封板 {seal_txt}",
            "expansion": f"分位 {f['share_pct_250']:.4f} / 涨停 {s['limit_up_count']} 家 / 连板 {s['streak']} / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "trend": f"分位 {f['share_pct_250']:.4f} / 20 日 {f['chg_20d'] * 100:+.2f}% / 上涨 {gi['breadth_up_ratio'] * 100:.1f}%",
            "ignition": f"Δ5 {f['share_chg_5'] * 100:+.2f}pct / 前 10 {gi['days_top10_20']} 天 / 涨停 {s['limit_up_count']} 家",
        }
        hit = sum(1 for _, ok, _ in sc_by[code]["crit"][sc_by[code]["stage"]] if ok)
        rd = sc_by[code].get("rs_detail") or {}
        rparts = rd.get("parts") or {}
        mainlines.append({
            "id": ct["id"], "rank": rank,
            # content.py 里是 None 占位，真实值来自上一期报告的名次；
            # 上期未入榜写 null（= 新入榜），不写 0（= 名次没变）
            "rank_change": (_prev_report_map[code] - rank) if code in _prev_report_map else None,
            "name": ct["name"], "aliases": ct["aliases"], "sector_codes": [code],
            "theme_type": ct["theme_type"], "stage": sc_by[code]["stage"],
            "stage_label": ct["stage_label"], "stage_confidence": ct["stage_confidence"],
            "score": s["score"],
            "score_breakdown": [
                {"key": k, "label": lbl, "raw": raw, "normalized": s["norm"][k],
                 "weight": effective_weight(WEIGHTS.get(k, 0)),
                 "contribution": s["contrib"].get(k, 0), "note": note}
                for k, lbl, raw, note in [
                    ("rs", "相对强度", s["rs"],
                     f"合成 {s['rs']:.1f} = 20 日分位 {rparts.get('rs_20', float('nan')):.1f}×50%"
                     f" + 60 日 {rparts.get('rs_60', float('nan')):.1f}×30%"
                     f" + 跑赢基准天数 {rparts.get('beat_20', float('nan')):.1f}×20%；"
                     f"rs_20 净值比 {f['rs_20']:.4f} 仅作展示"),
                    ("persistence", "趋势持续性", f["days_top10_20"],
                     f"前 10 {f['days_top10_20']} 天/连续 {f['consecutive_top10']} 天/60 日阳线 {f['up_days_60'] * 100:.1f}%，三项分位均值"),
                    ("volume", "量能聚集", round(f["share"] * 100, 3),
                     f"份额 {f['share'] * 100:.2f}% 分位 {pc[code]['share']:.1f}，Δ5 {f['share_chg_5'] * 100:+.2f}pct 分位 {pc[code]['share_chg_5']:.1f}"),
                    ("breadth", "扩散度", round(gi["breadth_up_ratio"] * 100, 2),
                     f"上涨 {gi['breadth_up_ratio'] * 100:.1f}/新高 {gi['new_high_ratio'] * 100:.1f}/涨停 {s['limit_up_count']} 家，按 0.4/0.35/0.25 加权"),
                    ("fundflow", "资金流", flow_ratio,
                     f"5 日净额 {net5} 亿 ÷ 同期成交额 {amt5:.2f} 亿 = {flow_ratio}%"),
                    ("narrative", "叙事与催化", (narr.get(code) or {}).get("evidence"),
                     f"{narrative.explain(narr.get(code) or {})}；"
                     f"{narr_metric_note}"),
                ]
            ],
            "penalty": s["penalty"],
            "penalty_reason": (
                f"R2 触发：份额分位 {f['share_pct_250']:.4f} > 0.90 且拥挤度 {s['crowd']:.4f} > 0.90 → −6"
                if s["penalty"] == 6 else
                (f"R1 触发：份额分位 {f['share_pct_250']:.4f} > 0.95 且连板 {s['streak']} ≥ 5 → −12"
                 if s["penalty"] == 12 else "无触发")),
            "metrics": metrics,
            "persistence": {
                "days_top10_20": gi["days_top10_20"],
                "days_top5_20": pct20 and panel_top5(p, code, 20),
                "consecutive_top10": gi["consecutive_top10"],
                "pulse_check": {"passed": s["gates"] >= 2, "rules_passed": s["gates"], "detail": d},
            },
            "drivers": ct["drivers"],
            "narrative": {k: ct[k] for k in ("logic", "catalyst", "sustainability", "bear_case")},
            "leaders": leaders,
            "ladder": {"has_leader": bool(leaders), "tiers": 3 if rank == 1 else 2, "note": ct["ladder_note"]},
            "invalidation": [
                {k: re.sub(r"\{ma20_(\d{6})\}", lambda mm: str(stk_ma(mm.group(1))), v)
                 for k, v in inv.items()} for inv in ct["invalidation"]],
            "watch": ct["watch"],
            "related": ct["related"],
        })
        stage_note[code] = (f"{ct['name']} 阶段 {sc_by[code]['stage']}，命中 {hit}/"
                            f"{len(sc_by[code]['crit'][sc_by[code]['stage']])}；判据取值 " + stage_rules[sc_by[code]["stage"]])

    # ---------------- 组装 ----------------
    # weight 是 100 分制的有效权重（设计权重 ÷ 90 × 100，见 score.effective_weight），
    # 加总正好 100，与 score 满分一致；normalized × weight ÷ 100 = contribution 可手算。
    static_w = [
        {"key": "rs", "label": "相对强度", "weight": effective_weight(WEIGHTS["rs"]),
         "desc": "20 日超额收益分位×50% + 60 日超额收益分位×30% + 20 日跑赢基准天数分位×20%；"
                 "旧口径 rs_20 净值比是 20 日涨幅的仿射变换，已降为展示指标；设计权重 25/90"},
        {"key": "persistence", "label": "趋势持续性", "weight": effective_weight(WEIGHTS["persistence"]),
         "desc": "前 10 天数、连续天数、60 日阳线占比三项百分位的均值；设计权重 20/90"},
        {"key": "volume", "label": "量能聚集", "weight": effective_weight(WEIGHTS["volume"]),
         "desc": "成交额份额百分位×0.6 + 5 日份额变化百分位×0.4；设计权重 20/90"},
        {"key": "breadth", "label": "扩散度", "weight": effective_weight(WEIGHTS["breadth"]),
         "desc": "上涨占比、强势股占比（涨幅 ≥5%）、涨停占比按 0.40/0.35/0.25 加权的百分位；三项的分位分母是当日全部板块（v1.9 起，不再用候选样本），新高占比只作 P2 闸门；设计权重 15/90"},
        {"key": "fundflow", "label": "资金流", "weight": effective_weight(WEIGHTS["fundflow"]),
         "desc": "5 日主力净额 ÷ 同期成交额的百分位（东财算法测算值）；设计权重 10/90"},
        {"key": "narrative", "label": "叙事与催化", "weight": 0,
         "desc": "不计入总分（权重 0）。分数由可验证证据条数与最高来源等级推导：0/1/2/3/≥4 条 → 0/40/60/75/85，"
                 "官方原文 +15 / 公司公告 +10 / 主流媒体 +5 / 研报与自有数据 0 / 传闻 −10。"
                 "用途仅两处：TOP_N 边界分差 <1 分时裁决座次；标注「叙事强但闸门差一条」的萌芽板块"},
    ]

    gate_matrix = []
    seen: set[str] = set()
    for s in sorted(listed + emerging, key=lambda x: (-x["gates"], -x["score"])):
        if s["code"] in seen:      # listed 与 emerging 在 1 条闸门处会重叠，矩阵只留一条
            continue
        seen.add(s["code"])
        stage = sc_by[s["code"]]["stage"] if s["code"] in sc_by else "未实算（P2 补算板块）"
        stage = stage or ("未判定（闸门 ≥2 条，但五阶段判据均不足 2 项）" if s["gates"] >= 2
                          else "未判定（仅 1 条闸门，阶段不参与判定）")
        hit = ("—" if stage.startswith(("未实算", "未判定")) else
               f"{stage} {sum(1 for _, ok, _ in sc_by[s['code']]['crit'][stage] if ok)}/{len(sc_by[s['code']]['crit'][stage])}")
        line = (
            f"{s['name']} | P1 {'✓' if s['p1'] else '✗'} {rows[s['code']]['days_top10_20']}/20 连续 {rows[s['code']]['consecutive_top10']} "
            f"| P2 {'✓' if s['p2'] else ('✗' if s['p2'] is False else '？无法判定')} 上涨 {(s['up'] or 0) * 100:.1f} 新高 {(s['nh'] or 0) * 100:.1f} "
            f"| P3 {'✓' if s['p3'] else '✗'} Δ5 {rows[s['code']]['share_chg_5'] * 100:+.2f}pct 分位 {rows[s['code']]['share_pct_250']:.4f} "
            f"| 闸门 {s['gates']} 条 | 阶段 {hit} | {stage}")
        gate_matrix.append(line.replace("-", "−"))

    n_extra = len(extra["rows"])
    n_p2 = len(g_by) + n_extra
    p2_unknown = [f"{v['name']}（有效样本 {v['valid']} 只 <10）" for v in extra["rows"].values()
                  if (v["valid"] or 0) < 10 or v.get("degraded")]
    p2_fail = [f"{v['name']}（上涨 {(v['up_ratio'] or 0) * 100:.1f}%、新高 {(v['new_high_ratio'] or 0) * 100:.1f}%）"
               for v in extra["rows"].values()
               if (v["valid"] or 0) >= 10 and not v.get("degraded")
               and not ((v["up_ratio"] or 0) >= th["p2_up"]
                        and (v["new_high_ratio"] or 0) >= th["p2_new_high"])]
    n_p2_rest = len(rows) - n_p2

    idx = [{"code": r["code"], "name": r["name"], "close": round(r["close"], 2) if r["close"] else None,
            "chg_1d": r["chg_1d"], "chg_5d": r["chg_5d"], "chg_20d": r["chg_20d"],
            "turnover_yi": r["turnover_yi"], "pe_pct_250": None}
           for r in idx_live["indices"]
           if r["code"] in ("000001.SH", "399001.SZ", "399006.SZ", "000688.SH", "000985.CSI", "000922.CSI")]

    up_boards = sum(1 for r in rows.values() if (r["chg_1d"] or 0) > 0)
    inflow = sorted(all_rows, key=lambda x: -(x["share_chg_5"] or 0))[:5]
    outflow = sorted(all_rows, key=lambda x: (x["share_chg_5"] or 0))[:5]
    # 每个板块实际可得的交易日数：250 日分位的真实样本，不同板块因行业分类调整而不同
    samples = {c: sum(1 for d in dates if c in p["by_date"][d]) for c in rows}
    n_p1p3 = len(g_by)
    kline_days = con.execute("select count(distinct d) from kline").fetchone()[0]
    # 按本轮真正参与打分的板块取成分股，不再读 codes-INDEX.json：
    # 那个文件曾是无日期的全局单例，一次历史回溯就会把它覆盖成另一天的名单。
    cand_members: set[str] = set()
    for b in (g_by or {}):
        f = C / f"codes-{b}.json"
        if f.exists():
            cand_members |= {str(x).zfill(6) for x in json.loads(f.read_text(encoding="utf-8"))}

    # 边界值：任一判据距阈值相对幅度 <5% 时必须标出，并说明四舍五入是否改变结论（v1.6 §3-4）
    boundary = []
    for c, s in scored.items():
        f = rows[c]
        for label, v, thr in [
            ("P1 前 10 天数", f["days_top10_20"], 6),
            ("P1 连续天数", f["consecutive_top10"], 2),
            ("P2 上涨占比", s["up"], th["p2_up"]),
            ("P2 新高占比", s["nh"], th["p2_new_high"]),
            ("P3 份额 Δ5", f["share_chg_5"], th["p3_share_chg_5"]),
            ("P3 份额分位(下界)", f["share_pct_250"], 0.60),
            ("expansion 分位上界", f["share_pct_250"], 0.85),
        ]:
            if v is None or thr == 0:
                continue
            gap = abs(v - thr) / abs(thr)
            if gap < 0.05:
                flip = round(v, 2) != round(v, 4) and (round(v, 2) >= thr) != (v >= thr)
                boundary.append(f"{s['name']} {label} {v:.4f} 对阈值 {thr}（距 {gap * 100:.1f}%"
                                + ("，四舍五入到两位会翻转判定" if flip else "，四舍五入不改变判定") + "）")
    boundary_note = ("边界值（距阈值相对幅度 <5%，一律按原始精度比较）：" + "；".join(boundary)
                     if boundary else "本期无判据落在阈值 5% 以内，全部按原始精度判定")
    pen_note = ("；".join(f"{s['name']} {('/'.join(s['penalty_rules']))} −{s['penalty']}"
                          for s in scored.values() if s["penalty"]) or "无")
    # 沪深口径（剔除北交所）与全口径的差异：必须现算，不能沿用上一期的数字
    ex_bj = {k: v for k, v in (br["by_board"] if br else {}).items() if k != "北交所"}
    ex_up = sum(v["up"] for v in ex_bj.values())
    ex_valid = sum(v["valid"] for v in ex_bj.values())
    ex_ratio = ex_up / ex_valid if ex_valid else 0.0

    # 头版与结论：文字在 content.py，计数/名次/分位/分数在这里现算后渲染。
    # 模板缺占位符（有人把计数又写死回文案）或占位符缺取值（数据里没有这一项）都会直接失败，
    # 不再用 re.sub 打补丁——那种补丁在换榜后要么静默失效、要么把旧数字替换成新数字。
    _lead = mainlines[0]["name"].split("：")[0] if mainlines else ""
    _score_rank = {r["code"]: i + 1 for i, r in enumerate(
        sorted(sc["rows"], key=lambda x: -(x.get("score") or 0)))}
    _pass = sorted([g for g in g_by.values() if (g.get("gates") or 0) >= 2],
                   key=lambda g: -(sc_by.get(g["code"], {}).get("score") or 0))
    _pass_parts = []
    for g in _pass:
        combo = "+".join(k for k, ok in (("P1", g.get("p1")), ("P2", g.get("p2")),
                                         ("P3", g.get("p3"))) if ok)
        _pass_parts.append(f"{g['name']}（{combo}）")
    _pass_summary = ("、".join(_pass_parts[:-1]) + "与" + _pass_parts[-1]
                     if len(_pass_parts) > 1 else (_pass_parts[0] if _pass_parts else "无"))
    _stage_none_clause = "".join(
        f"但{s['name']}六阶段判据最多只命中 {sc_by[s['code']]['stage_max_hits']} 项，"
        f"stage 无法赋值，按 §4 只能改列萌芽、不得进 mainlines；" for s in stage_none)
    _one = [x for x in listed if x["gates"] == 1][:2]
    _top_one = "、".join(f"{x['name'].split('：')[0]} {x['score']:.2f}"
                         for x in _one) or "无"

    if not mainlines:
        require(VERDICT_HEADLINE_EMPTY_TPL, HEADLINE_REQUIRED["empty"], "headline(空榜)")
        _headline = render(VERDICT_HEADLINE_EMPTY_TPL, {"n_pass": len(_pass)},
                           "headline(空榜)")
        require(VERDICT_THESIS_EMPTY_TPL, THESIS_EMPTY_REQUIRED, "thesis(空榜)")
        _thesis = render(VERDICT_THESIS_EMPTY_TPL, {
            "n_boards": len(rows), "n_pass": len(_pass),
            "pass_summary": _pass_summary, "stage_none_clause": _stage_none_clause,
        }, "thesis(空榜)")
    elif len(mainlines) == 1:
        require(VERDICT_HEADLINE_SINGLE_TPL, HEADLINE_REQUIRED["single"], "headline")
        _headline = render(VERDICT_HEADLINE_SINGLE_TPL,
                           {"count_cn": _cn(1), "lead_name": _lead}, "headline")
        code = mainlines[0]["sector_codes"][0]
        f0, gi0 = rows[code], g_by[code]
        crit = sc_by[code]["crit"][sc_by[code]["stage"]]
        passed = [(label, val) for label, ok, val in crit if ok]
        v_d5 = f0["share_chg_5"] or 0.0
        d5_rank = 1 + sum(1 for r in all_rows if (r["share_chg_5"] or 0) < v_d5)
        excess = (f0["chg_20d"] or 0.0) - (base.get("chg_20d") or 0.0)
        amt5 = amt_sum(code, 5)
        net5_pct = net_sum(code, 5) / amt5 * 100 if amt5 else 0.0
        require(VERDICT_THESIS_TPL, THESIS_REQUIRED, "thesis")
        _thesis = render(VERDICT_THESIS_TPL, {
            "n_boards": len(rows), "n_pass": len(_pass),
            "pass_summary": _pass_summary, "stage_none_clause": _stage_none_clause,
            "lead_name": _lead,
            "lead_stage_cn": STAGE_CN.get(mainlines[0]["stage"], mainlines[0]["stage"]),
            "lead_crit": "、".join(f"{label}（{val}）" for label, val in passed),
            "lead_hit": len(passed), "lead_total": len(crit),
            "top_one_gate": _top_one,
            "score": f"{mainlines[0]['score']:.2f}",
            "rank": _score_rank.get(code, "—"),
            "lead_valid": gi0["valid"],
            "lead_up": round((gi0["breadth_up_ratio"] or 0) * (gi0["valid"] or 0)),
            "lead_new_high": round((gi0["new_high_ratio"] or 0) * (gi0["valid"] or 0)),
            "lead_d5": f"{v_d5 * 100:+.2f}".replace("-", "−"),
            "lead_d5_pct": f"{(pc[code]['share_chg_5'] or 0):.2f}",
            "lead_d5_rank": _cn(d5_rank),
            "lead_net5": f"{net5_pct:+.2f}".replace("-", "−"),
            "lead_chg20": f"{(f0['chg_20d'] or 0) * 100:+.2f}%".replace("-", "−"),
            "base_chg20": f"{(base.get('chg_20d') or 0) * 100:+.2f}%".replace("-", "−"),
            "excess20": f"{excess * 100:.2f}".replace("-", "−"),
            "n_main": 1,
        }, "thesis")
    else:
        require(VERDICT_HEADLINE_MULTI_TPL, HEADLINE_REQUIRED["multi"], "headline")
        _headline = render(VERDICT_HEADLINE_MULTI_TPL, {
            "count_cn": _cn(len(mainlines)),
            "trend_cn": _cn(sum(1 for m in mainlines if m["stage"] == "trend")),
            "lead_name": _lead,
            "second_name": mainlines[1]["name"].split("：")[0],
        }, "headline")
        require(VERDICT_THESIS_MULTI_TPL, ("n_boards", "n_pass", "pass_summary",
                                           "n_main", "mainline_summary"), "thesis(多主线)")
        _thesis = render(VERDICT_THESIS_MULTI_TPL, {
            "n_boards": len(rows), "n_pass": len(_pass),
            "pass_summary": _pass_summary, "stage_none_clause": _stage_none_clause,
            "n_main": len(mainlines),
            "mainline_summary": "、".join(
                f"{m['name'].split('：')[0]}（{m['score']:.2f}，"
                f"{STAGE_CN.get(m['stage'], m['stage'])}）" for m in mainlines),
            "top_one_gate": _top_one,
        }, "thesis(多主线)")

    # 空榜日 mainlines 为空：VERDICT_POINTS 不含 {score}/{rank} 占位，直接用原文，避免 mainlines[0] 越界。
    _points = (_sub(_fill(VERDICT_POINTS, mainlines[0]["score"], 1),
                    {"{score_rank}": str(_score_rank.get(mainlines[0]["sector_codes"][0], ""))})
               if mainlines else VERDICT_POINTS)

    # changelog 里的「这次改了多少分」必须现算：写死的区间会在下一次调参后立刻过期，
    # 而它恰好是读者判断「要不要重看结论」的唯一依据。
    _delta = sorted((round(m["score"] - _prev_scores[m["sector_codes"][0]], 2), m["name"].split("：")[0])
                    for m in mainlines if m["sector_codes"][0] in _prev_scores)
    _dtext = (f"分数变动 {_delta[0][0]:+.2f}（{_delta[0][1]}）~ {_delta[-1][0]:+.2f}（{_delta[-1][1]}）"
              if _delta else "无可比分数（上一期未覆盖这些板块）")

    # 数据覆盖度现算：条目清单、每条的状态与证据都进 coverage_detail，读者可逐条核对。
    coverage, cov_detail, cov_stats = data_coverage(
        rows=rows, p=p, bb=bb, br=br, lim=lim, lev=lev, base_src=base_src,
        idx_live=idx_live, cand_members=cand_members, quotes=quotes,
        samples=samples, n_p2=n_p2, lev_carried=lev_carried)
    cov_points = cov_stats["full"] + 0.5 * cov_stats["degraded"]

    doc = {
        "schema_version": "1.0.0",
        "meta": {
            "report_id": f"aml-{as_of.replace('-', '')}",
            "as_of": as_of,
            "generated_at": datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds"),
            "title": f"A股市场主线分析 · {as_of}",
            "data_mode": "live",
            "confidence": 0.60,
            "analyst": {"model": "DeepSeek-V4.1-Flash", "prompt_version": "1.6.0", "operator": "使用者"},
            "tags": META_TAGS,
        },
        "window": {
            "as_of": as_of, "primary_days": 20, "confirm_days": 5, "context_days": 60, "quantile_days": 250,
            "effective_range": {"start": dates[-20], "end": dates[-1]},
            "rules": [
                f"主窗按交易日回溯 20 日，非自然日；本期 20 日窗口 {dates[-20]} ~ {dates[-1]}",
                "T 日仅用于描述字段，不参与阶段判定",
                f"横截面为东财 {run['boards_live']} 个现役行业板块（{as_of} 有资金流数据的全部板块），前 10 名 ≈ 前 {10 / run['boards_live'] * 100:.1f}%",
                f"P1 按滚动 20 日累计涨幅的横截面排名，不是当日涨跌幅；横截面 {run['boards_live']} 个板块中 20 日窗口完整可算的有 {run['boards_live']} 个，剔除 0 个",
                f"P2 已完整计算 {n_p2} 个板块（{n_p1p3} 个 P1/P3 候选 + {n_extra} 个近失板块），其余 {len(rows) - n_p2} 个板块 P2 记「未计算」，不据此下唯一性结论",
                f"250 日分位按各板块可得交易日（最多 250）计算：本期样本最短 {min(samples.values())} 日、最长 {max(samples.values())} 日；"
                + ("其中既有不足 250 日也有超过 250 日的板块，分位一律按各自可得样本计算，正文已写明样本长度" if max(samples.values()) >= 250 else "均不足 250 日，正文按实际样本表述"),
                (f"份额分母为面板合计 {run['market_amount_yi']} 亿（128 板块成交额合计，取自板块日线真值）；新浪全 A 快照实测"
                 f"全市场成交额 {br['amount_yi']} 亿，两者相差 {(run['market_amount_yi'] / br['amount_yi'] - 1) * 100:+.3f}%，"
                 f"量级等价，故分母不再标注为代理口径") if br else
                f"份额分母为面板合计 {run['market_amount_yi']} 亿（128 板块成交额合计，取自板块日线真值），非全市场成交额",
            ],
            "excluded": [],
        },
        "data_quality": {
            "status": "partial",
            "coverage": coverage,
            "coverage_method": COVERAGE_METHOD,
            "coverage_detail": cov_detail,
            "sources": [
                {"name": "东方财富数据中心 · 行业板块资金流（RPT_INDUSTRY_FUNDFLOW）", "category": "行情与资金",
                 "fields": ["涨跌幅", "主力净额", "净流入占比", "超大/大/中/小单净额与占比"], "as_of": as_of,
                 "reliability": "high",
                 "note": f"{run['boards_live']} 个板块共 {len(dates)} 个交易日（{dates[0]} 起），涨跌幅与资金流单源；成交额取 push2his 板块日线真值（与成员股成交额加总逐位一致）"},
                {"name": "腾讯行情（qt.gtimg.cn / web.ifzq.gtimg.cn）", "category": "行情",
                 "fields": ["收盘价", "昨收", "涨跌幅", "成交额", "日 K 线"], "as_of": as_of, "reliability": "high",
                 "note": f"{len(idx_live['indices'])} 个指数当日快照与日 K 线；{len(quotes)} 只成分股报价快照；本地 K 线库覆盖同批个股，共 {kline_days} 个交易日"},
                {"name": "东方财富板块成分（RPT_BOARD_CONSTITUENT）", "category": "成分",
                 "fields": ["板块代码", "成分股代码"], "as_of": as_of, "reliability": "high",
                 "note": f"{run['boards_live']} 个板块中取 {n_p2} 个候选/近失板块的成分股，去重 {len(cand_members)} 只，用于 P2 与龙头识别"},
                {"name": "东方财富涨停/炸板/跌停池（push2ex）", "category": "情绪",
                 "fields": ["涨停家数", "连板数", "开板次数"], "as_of": as_of, "reliability": "high",
                 "note": f"{as_of} 涨停 {lim['market']['limit_up']} 家、炸板 {lim['market']['broken']} 家、跌停 {lim['market']['limit_down']} 家；另取 {lim['prev']} 涨停池算连板变化"},
                {"name": "新浪财经全 A 快照（Market_Center.getHQNodeData, node=hs_a）", "category": "行情",
                 "fields": ["收盘价", "涨跌幅", "成交额", "成交量", "总市值"], "as_of": as_of, "reliability": "high",
                 "note": (f"全市场快照走新浪通道；分 56 页取全 {br['valid'] + br['suspended']} 只，"
                          f"有效（有成交）{br['valid']} 只、停牌 {br['suspended']} 只，本地自行统计涨跌家数"
                          + (f"；抽 {br['cross_check']['sampled']} 只对腾讯行情校验，一致 {br['cross_check']['matched']} 只，"
                             f"最大价差 {br['cross_check']['max_price_diff_pct']}%、涨跌幅差 {br['cross_check']['max_pct_diff_pct']}pct"
                             if br.get("cross_check") else "")) if br else
                         "本期未取（breadth 字段写 null）"},
                {"name": "东方财富数据中心 · 两融市场汇总（RPTA_RZRQ_LSHJ）", "category": "杠杆",
                 "fields": ["融资余额", "融券余额", "两融余额", "融资净买入", "占流通市值比"], "as_of": lev["as_of"] if lev else as_of,
                 "reliability": "high",
                 "note": (f"单请求取满 {lev_rows if lev_rows is not None else '—'} 行，"
                          f"滞后 {lev['lag_trading_days']} 个交易日；"
                          f"口径含沪深北，不与交易所分市合计混算"
                          + (f"；本期缓存缺失，沿用 {lev_carried} 期数值" if lev_carried else ""))
                         if lev else "本期未取"},
                {"name": "交易所公告 / 上市公司公告 / 官方统计", "category": "政策与事件",
                 "fields": ["停复牌与交易提示", "公司公告", "宏观与行业统计"], "as_of": as_of,
                 "reliability": "high", "note": f"{len(mainlines)} 条入榜主线共 {sum(len(m['drivers']) for m in mainlines)} 条证据链（drivers）；结论以行情与资金数据为主，事件叙事只用于主线归因"},
                {"name": "主流财经媒体（证券时报 / 财联社 / 每经 / 上证报等）", "category": "资讯",
                 "fields": ["盘面复盘", "板块资金", "市场情绪"], "as_of": as_of, "reliability": "medium",
                 "note": f"本期用于 {len(mainlines)} 条入榜主线的叙事证据（海外短剧数据、AI 广告降本、机器人催化、照明跨界题材等），并作盘面与数据口径的交叉参考"},
            ],
            "missing": [
                {"field": "板块 250 日完整成交额序列", "reason": f"面板覆盖 {len(dates)} 个交易日（{dates[0]} 起），但部分板块因行业分类调整样本更短，本期最短 {min(samples.values())} 日",
                 "fallback": "turnover_share_pct_250 与 crowding_pct 按实际样本计算，不补 0；正文按「实际样本分位」表述"},
                {"field": "板块 PE 250 日分位", "reason": "中证指数官网估值分位未取", "fallback": "indices.pe_pct_250 全部写 null"},
                {"field": "全市场涨跌家数（交易所官方口径）", "reason": f"交易所官方涨跌家数统计未取，本报告用的是新浪全 A 快照本地统计（{br['valid'] if br else '—'} 只有效样本），未与官方口径逐日核对",
                 "fallback": "market_regime.breadth 用快照统计值，并与腾讯行情抽 17 只交叉校验；口径差异写入 notes"},
                {"field": "全 A 创 20 日新高/新低家数", "reason": "需 5000+ 只个股日线，超出本期取数预算", "fallback": "market_regime.breadth.new_high/new_low 写 null"},
                # 外资维度（陆股通持股变动）已整体移出必需输入清单：日度净买入自 2024-08 停披露、
                # 仅剩周度持股变动与收盘后成交总额，两者都不适配日度归因。剔除后不再占 coverage 分母，
                # 也不再以 missing 记账——它不属于「当期欠账」，是结构性不可得。口径见 notes。
                # 两融按 lev 是否取到动态登记：11-05 的 missing 漏了它（coverage_detail
                # 数条目时才暴露），notes 里其实写了「本期未取」——清单与 notes 必须同源。
                *([] if lev else [{"field": "两融余额", "reason": f"margin-{as_of}.json 不在本轮缓存，两融市场汇总未取",
                                   "fallback": "market_regime.leverage 写 null，全文不使用杠杆维度"}]),
                {"field": f"其余 {len(rows) - n_p2} 个板块的 P2", "reason": f"P2 需逐板块拉成分股 K 线，本期只对 {n_p1p3} 个 P1/P3 候选与 {n_extra} 个近失板块计算",
                 "fallback": "记「未计算」，不做全样本唯一性表述"},
            ],
            "notes": [
                f"基准：{base.get('name')} 20 日 {base.get('chg_20d') * 100:+.2f}%、60 日 "
                f"{base.get('chg_60d') * 100:+.2f}%，来源 {base_src}"
                + ("（常量回落，非当日快照——rs 与全部分数偏移，勿跨日比较）" if base_src != "indices-live" else "（当日指数快照）"),
                f"评分口径 1.10.0（P1）：rs 改为 20 日 50% + 60 日 30% + 跑赢基准天数 20% 的合成分位；"
                f"P2/P3 与阶段绝对阈值按当期 regime（{reg.get('regime', 'neutral')} / {reg.get('label', '震荡')}）取值。"
                f"与 {as_of} 以前按固定阈值、rs_20 排分位的报告不可直接比较分数。",
                f"口径断面：本页 breadth 为 v1.9 口径（三项分位分母 = 当日全部 {bb['ranked']} 个板块）。"
                f"{as_of} 以前的报告是 v1.6/v1.7 口径（只在 9~11 个过闸门候选里排分位，样本本身全是强票），"
                f"同日分数不可直接比较；存档报告保持原样，不按新口径改写历史。",
                "成交额口径沿用 v1.9：板块日线真值（push2his）替代「净额÷占比反推」，面板 128 个板块全部覆盖；"
                "份额统计统一走 panel.share_stats，share_pct_250 固定最近 250 日窗口，不再随面板历史长度漂移",
                "成分股索引 codes-INDEX.json 已按日期分目录：目录里有哪张成分表就用哪张；报价快照命中缓存时会补齐缺失成员。"
                "本期 128 个板块的成分股清单与当日快照一致，涨停/封板率/龙头统计无缺失",
                f"coverage = {cov_stats['full']} 条完整 + 0.5×{cov_stats['degraded']} 条降级 = {cov_points:.1f} 分，"
                f"÷ {cov_stats['total']} 条必需输入 = {coverage:.4f}"
                f"（{COVERAGE_METHOD} 口径：数条目、不按因子权重加权，逐条状态见 data_quality.coverage_detail；"
                f"分母 {cov_stats['total']} = count-v1 的 26 条 − 1 条结构性不可得，"
                f"即外资维度：沪深港通日度净买入自 2024-08 停披露、仅剩周度持股变动与收盘后成交总额，"
                f"两者都不适配日度归因，故整条移出必需输入清单，不再计入分母、也不记为 missing；"
                f"count-v1 的报告（分母 26）与本期不可比。其中缺失 {cov_stats['missing']} 条："
                + "、".join(x["field"] for x in cov_detail if x["state"] == "missing")
                + "。v2.0 之前的 0.85~0.944 是加权口径，同样不可比）",
                (f"杠杆（截至 {lev['as_of']}，lag_trading_days={lev['lag_trading_days']}）：两融余额 {lev['balance_yi']} 亿、"
                 f"20 日 {lev['chg_20d'] * 100:+.2f}%、占流通市值 {lev['balance_to_float_pct'] * 100:.3f}%，趋势 {lev['trend']}；"
                 f"滞后 {lev['lag_trading_days']} 个交易日，只用于「截至 {lev['as_of']}」的水平与趋势描述，不用于 {as_of} 当日归因"
                 + (f"；本期 margin-{as_of} 缓存缺失，数值沿用 {lev_carried} 期（两融为慢变量，"
                    f"该跨度内余额变动在单日噪音量级）" if lev_carried else "")) if lev else
                "两融余额本期未取，market_regime.leverage 写 null，全文不使用杠杆维度",
                # 取数过程如实记录：本轮被 WAF 拦了几次、有没有影响，都写出来。
                # 「报告说没被拦，其实拦了 5 次」比拦截本身更危险——读者无法判断数据可信度。
                *([f"本轮取数：{r['ok'] + r['failed']} 次请求，成功 {r['ok']}、失败 {r['failed']}、"
                   f"WAF 拦截 {r['blocked']} 次、重试 {r['retry']} 次"
                   + ("（拦截全部来自腾讯日 K 的个股补历史，相关个股当日行情已在库内，未影响面板与广度）"
                      if r.get("blocked") else "")
                   + "。同一天反复全量重跑会显著提高拦截概率，非必要不重复取数"]
                  if (r := run.get("requests")) else []),
                "闸门矩阵（覆盖全部通过 ≥1 条闸门的板块，逐行给出板块 | P1 | P2 | P3 | 闸门命中 | 阶段命中 | stage）："
                + "；".join("闸门矩阵：" + line for line in gate_matrix),
                f"P2 覆盖与缺口：已完整计算 {n_p2} 个板块；未过 P2 的为 {'、'.join(p2_fail) if p2_fail else '无'}；"
                f"无法判定（有效样本 <10 只或窗口有缺口）的为 {'、'.join(p2_unknown) if p2_unknown else '无'}；"
                f"其余 {n_p2_rest} 个板块 P2 未计算，不据此下全样本唯一性结论",
                *([f"extra 补算了 {len(unscored)} 个板块但 score 缓存里没有："
                   f"{'、'.join((rows.get(c) or {}).get('name') or c for c in unscored)}；"
                   f"这些板块未进 emerging（不是「无分」而是「没算」），重跑 pipeline.score 后重新组装即可补全"]
                  if unscored else []),
                boundary_note,
                universe.note(uni),
                f"拥挤惩罚：{pen_note}（R1 需分位 >0.95 且连板 ≥5、R2 需分位 >0.90 且拥挤度 >0.90、R3 需 60 日 >60% 且 5 日净流出，多项命中取最大值）",
                f"份额分位的样本长度：{'、'.join(f'{rows[c]['name']} {samples[c]} 日' for c in [m['sector_codes'][0] for m in mainlines]) if mainlines else '空榜日无主线，不适用'}；"
                f"正文的「分位」均指该板块自身样本内的分位，不是跨板块的历史极值",
                f"breadth 因子的横截面百分位基于当日全部 {bb['ranked']} 个板块（上涨占比 / 强势股占比 / 涨停占比三项同分母，"
                f"与 score.py 同口径），其余四因子为 {len(rows)} 板块全域；rotation.emerging 的同一分位口径相同。"
                f"v1.9 起不再用候选样本（11-05 是 9 个）：9 个候选全是强票，彼此比较会把大多数压到低分位"
                f"（出版上涨占比 89.3% 曾排 18.2 分位），且分母随「今天几个板块过闸门」漂移",
                (f"叙事分（权重 0、不计入总分）：候选池为空——0 个板块通过 ≥2 条闸门，因此本期没有任何板块需要评叙事分，"
                 f"narrative 全部为 null，不按 0 分处理；分数由（可验证证据条数, 最高来源等级）按 §6 档位推导，台账里不接受手填分数"
                 if cov["total"] == 0 else
                 f"叙事分（权重 0、不计入总分）覆盖 {cov['evaluated']}/{cov['total']} 个候选："
                 + "、".join(f"{rows[c]['name']} {narr[c]['score']:.0f}" for c in pool if c in narr)
                 + (f"；未评的 {'、'.join(rows[c]['name'] for c in cov['missing'])} 写 null，"
                    f"不计 0 分、不参与边界裁决" if cov["missing"] else "")
                 + "。分数由（可验证证据条数, 最高来源等级）按 §6 档位推导，台账里不接受手填分数"),
                (f"TOP_N 边界（第 {tie['boundary']}/{tie['boundary'] + 1} 名）：{tie['reason']}"
                 if tie else (f"闸门合格且阶段可判定的候选 {len(eligible)} 个（{'、'.join(x['name'] for x in eligible)}），"
                              f"候选数不大于入榜上限，不存在第 n/n+1 名边界裁决；没有为凑数放宽阈值或录用不合格板块"
                              if mainlines else "闸门合格且阶段可判定的候选为 0，不存在 TOP_N 边界裁决；没有为凑数放宽阈值或录用不合格板块")),
                "fundflow 与 volume 的 delta 口径：turnover_share_chg_5 为份额相对 5 个交易日前的变化，turnover_share_chg_20 为相对 20 个交易日前的变化，两者不同窗口",
                f"max_streak_prev 取 5 个交易日前（{dates[-6]}）涨停池的最高连板高度，不是「上一日」；divergence 的「连板回落 ≥2 级」用该口径",
                "资金轮动（5 日成交额份额变化，单位百分点）：流入 "
                + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}" for r in inflow[:3])
                + "；流出 " + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}".replace("-", "−") for r in outflow[:3])
                + "。注意份额与价格、资金三者会分叉：广告营销 5 日份额 +0.52pct 居首，当日 +4.40%、20 日仅 +1.08%，是资金先到、价格后到的启动形态；"
                + "影视院线 5 日份额 +0.44pct、当日 +7.05%、20 日 +12.38%，量价同向，是本期最健康的一条；"
                + "游戏Ⅱ 5 日份额 −0.19pct、当日 +4.39%，价涨量退，是本期最矛盾的一条；"
                + "照明设备Ⅱ 5 日份额 −0.02pct、当日 +7.05%，涨幅主要靠单只跨界标的（阳光照明）拉动，不是板块级资金流入",
                (f"全市场广度口径：统计自新浪全 A 快照 {br['valid']} 只有效样本（剔除停牌 {br['suspended']} 只），"
                 f"上涨 {br['up']} / 下跌 {br['down']} / 平盘 {br['flat']}，up_ratio = {br['up']} ÷ {br['valid']} = "
                 f"{br['up_ratio']:.4f}，涨跌比 = {br['up']} ÷ {br['down']} = {br['advance_decline_ratio']:.2f}；"
                 f"含北交所口径为 {br['up_ratio']:.4f}，剔除北交所后沪深口径 "
                 f"{ex_up} ÷ {ex_valid} = "
                 f"{ex_ratio:.4f}，"
                 f"差 {abs(ex_ratio - br['up_ratio']) * 100:.2f}pct，两口径同向；分市场 up_ratio："
                 + "、".join(f"{k} {v['up'] / v['valid']:.1%}" for k, v in br["by_board"].items() if k != "其他")
                 + f"；涨跌分布 ≥9.8% 有 {br['distribution']['gt9']} 家、≤−9.8% 有 {br['distribution']['lt-9']} 家"
                 f"（含未封板的 20cm 个股，故与涨停池 {lim['market']['limit_up']} 家、跌停 {lim['market']['limit_down']} 家不同口径）"
                 + (f"；该快照抽 {br['cross_check']['sampled']} 只（含北交所 1 只）与腾讯行情逐只比对，一致 "
                    f"{br['cross_check']['matched']} 只，价差 {br['cross_check']['max_price_diff_pct']}%、"
                    f"涨跌幅差 {br['cross_check']['max_pct_diff_pct']}pct、成交额差 {br['cross_check']['max_amount_diff_pct']}%"
                    if br.get("cross_check") else "")) if br else
                "全市场涨跌家数本期未取，breadth.up_ratio 与 advance_decline_ratio 写 null",
                f"{as_of} {len(rows)} 个板块中 {up_boards} 个上涨；涨停 {lim['market']['limit_up']} 家、炸板 {lim['market']['broken']} 家、"
                f"跌停 {lim['market']['limit_down']} 家、封板率 {lim['market']['seal_rate']:.4f}；5 个交易日前（{lim['prev']}）涨停 {lim['market']['prev_limit_up']} 家，"
                f"本报告用该日涨停池计算 max_streak_prev；"
                f"涨停池为东财 push2ex 口径（{lim['market']['limit_up']} 家），媒体口径因是否计入 ST/北交所与 20cm 未封板个股而可能不同，全文统一用面板口径",
                "指数 5/20/60 日涨幅的取数过程：8 个指数的当日快照由腾讯 web.ifzq.gtimg.cn 与东财接口交叉取得，"
                "本期腾讯日 K 接口对 8 个指数均返回 EndpointBlocked，日线序列改由东财 push2his 补齐并与当日快照校验（快照时间 2026-11-10 16:14:28，收盘后）。"
                "上证 3663.72 +0.08%、深成指 11241.54 +0.86%、中证全指 5161.13 +0.81%、创业板指 2494.40 +1.46%，"
                "5/20/60 日序列与当日快照同源，可跨日比较；指数日 K 的来源变更已在 data_quality 记明",
                "阶段裁决顺序本期覆盖 10 条候选：trend 4 条（影视院线、数字媒体、广告营销、自动化设备）、expansion 4 条（游戏Ⅱ、汽车零部件、通用设备、航空机场）、"
                "divergence 2 条（照明设备Ⅱ、休闲食品），均取到第一个满足 ≥2 项判据的阶段；"
                "出版、光伏设备、电机Ⅱ、电视广播Ⅱ、消费电子、铁路公路、厨卫电器、白酒Ⅱ、小家电、银行Ⅱ 六个阶段判据均未达 2 项，"
                "stage 写 null 并改列 emerging——规则不因分数更高而放宽",
                *[stage_note[c] for c in stage_note],
                (f"P1/P3 候选 {len(listed)} 个，其中闸门合格（≥2 条）{sum(1 for x in listed if x['gates'] >= 2)} 个；"
                 f"合格但阶段无法赋值的 {sum(1 for x in listed if x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage'))} 个"
                 + (f"（{'、'.join(x['name'] for x in listed if x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage'))}）"
                    f"按 §4 改列 emerging、不进 mainlines；"
                    if any(x['gates'] >= 2 and not sc_by.get(x['code'], {}).get('stage') for x in listed) else "；")
                 + f"其余按 TOP_N={len(top)} 输出 {len(mainlines)} 条，未放宽阈值凑数；"
                 + (f"合格但超出 TOP_N 未入榜：{'、'.join(f'{x['name']}（{x['score']}）' for x in dropped if x['gates'] >= 2)}；" if any(x["gates"] >= 2 for x in dropped) else "")
                 + f"未进 mainlines 的 {len(emerging)} 个板块全部列入 rotation.emerging，其中 {len(stage_none)} 个属于「闸门够但阶段无法判定」"
                 + (f"（{'、'.join(x['name'] for x in stage_none)}）" if stage_none else "")
                 + f"、{len(one_gate)} 个属于「仅 1 条闸门」"
                 + (f"、{len(cut_by_topn)} 个被 TOP_N 截断" if cut_by_topn else "") + "；没有为凑数放宽阈值"),
            ],
        },
        "market_regime": {
            "label": REGIME_LABEL,
            "phase": reg.get("phase", "choppy"),
            "phase_label": {"risk_on": "进攻（阈值收紧）", "risk_off": "防御（阈值放宽）",
                            "choppy": "震荡（阈值中档）"}[reg.get("phase", "choppy")],
            "risk_appetite": 48, "liquidity": 34, "breadth_score": 77,
            "indices": idx,
            "breadth": {
                "up_ratio": br["up_ratio"] if br else None, "limit_up": lim["market"]["limit_up"],
                "limit_down": lim["market"]["limit_down"],
                "broken_board_rate": round(lim["market"]["broken"] / (lim["market"]["limit_up"] + lim["market"]["broken"]), 4),
                "advance_decline_ratio": br["advance_decline_ratio"] if br else None,
                "new_high": None, "new_low": None,
            },
            "leverage": lev,
            "narrative": REGIME_NARRATIVE,
        },
        "verdict": {
            "headline": _headline,
            "core_thesis": _thesis,
            "stance": "balanced", "stance_label": STANCE_LABEL,
            "dominant_mainline_id": mainlines[0]["id"] if mainlines else None,
            "mainline_count": len(mainlines),
            "confidence": 0.60,
            "points": _points,
            "horizon": {
                "valid_until": (datetime.strptime(as_of, "%Y-%m-%d") + timedelta(days=14)).strftime("%Y-%m-%d"),
                "review_trigger": REVIEW_TRIGGER,
            },
        },
        "mainlines": mainlines,
        "rotation": {
            # 边界裁决留痕：没触发也写。读者需要知道「第 5 名不是靠叙事分挤进来的」，
            # 而不是只在触发时才看到一段解释（那样反而像在掩饰）。
            "tie_break": tie or ({
                "threshold": narrative.TIE_THRESHOLD, "boundary": len(top), "delta": None,
                "applied": False, "kept": None, "dropped": None,
                "reason": (f"闸门合格且阶段可判定的候选只有 {len(eligible)} 个（"
                           + "、".join(f"{x['name']} {x['score']:.2f}" for x in eligible)
                           + "），候选数不大于 TOP_N，没有第 n/n+1 名边界可裁；叙事分未参与座次"),
            } if mainlines else None),
            "narrative": (
                "本期的资金分布是一次典型的高低切换：5 日份额流入前三为 "
                + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}pct".replace("-", "−") for r in inflow[:3])
                + "，流出前三为 " + "、".join(f"{r['name']} {(r['share_chg_5'] or 0) * 100:+.2f}pct".replace("-", "−") for r in outflow[:3])
                + "。流入端集中在传媒与电子：文化传媒获逾 86 亿元主力净流入，AI 短剧超 60 亿元，"
                "人工智能、人形机器人各超 50 亿元；行业口径上电子净流入 92.02 亿居首、传媒 46.88 亿、半导体 40.62 亿。"
                "流出端是资源与权重：资源股净流出逾 43 亿，一带一路、光通信、中字头净流出超 20 亿；"
                "石油石化、煤炭开采、航运港口、燃气跌幅居前，沪主板 up_ratio 仅 0.6600，是五个市场里最弱的。"
                "涨得最多的传媒（影视院线 +7.05%、影视动漫制作 +8.03%）当日成交额份额 Δ5 +0.44pct，量价同向；"
                "而游戏Ⅱ Δ5 −0.19pct、当日 +4.39%，价涨量退——同样在涨，质地完全不同。"
                f"在已完整计算 P2 的 {n_p2} 个板块中，{len(emerging)} 个未进主线："
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in stage_none)} 有 2 条闸门但阶段无法判定；" if stage_none else "")
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in one_gate)} 只有 1 条闸门；" if one_gate else "")
                + (f"{'、'.join(f'{s['name']}（{s['score']} 分）' for s in cut_by_topn)} 合格但被 TOP_N 截断。" if cut_by_topn else "")
                # 这段曾经写死「影视院线 78.83、游戏Ⅱ 77.03 都停在一条闸门」——那是上一期的分数，
                # 换榜后既没被 schema 拦住也没被 None 检查发现，属于最隐蔽的一类过期数据。
                # 现在改成从当日结果里取，榜单怎么变，句子都跟着变。
                + ((lambda bg, wm: (
                    f"得分最高的{bg['name']} {bg['score']:.2f} 分，"
                    f"{'高于' if bg['score'] > wm['score'] else '接近'}入榜末位 {wm['name']} 的 {wm['score']:.2f} 分，"
                    f"却因为闸门不够只能留在萌芽——"))(max(one_gate, key=lambda x: x["score"]),
                                                      min(mainlines, key=lambda m: m["score"]))
                   if one_gate and mainlines else "")
                + "五因子打分衡量的是「谁更强」（narrative 权重为 0，不计入），"
                "闸门衡量的是「强是否同时发生在持续性、广度、量能三个维度」，"
                "阶段衡量的是「这条线走到哪一步」。三者都过才叫主线，缺一条就只能留在萌芽。"
                + (f"萌芽前五：{'、'.join(f'{s['name']} {s['score']}' for s in emerging[:5])}。" if len(emerging) > 5 else "")
            ),
            "inflow": [{"name": r["name"], "delta_pct": round((r["share_chg_5"] or 0) * 100, 2),
                        "note": f"20 日 {(r['chg_20d'] or 0) * 100:+.2f}%、当日 {(r['chg_1d'] or 0) * 100:+.2f}%、rs_20 {r['rs_20']:.4f}"} for r in inflow],
            "outflow": [{"name": r["name"], "delta_pct": round((r["share_chg_5"] or 0) * 100, 2),
                         "note": f"20 日 {(r['chg_20d'] or 0) * 100:+.2f}%、当日 {(r['chg_1d'] or 0) * 100:+.2f}%、rs_20 {r['rs_20']:.4f}"} for r in outflow],
            "emerging": [{"name": s["name"], "score": s["score"], "narrative": s["narrative"],
                          "signal": (
                              # 叙事强但闸门不足的前缀：它不改变排序（仍按分数），只保证读者不会
                              # 因为分数低而跳过一条证据链最硬的候选。
                              (f"【叙事 {narr_txt(s)}，仅差一条闸门】" if s.get("strong_but_gated") else "")
                              + f"P1 {'✓' if s['p1'] else '✗'}（前 10 {rows[s['code']]['days_top10_20']}/20 天、连续 {rows[s['code']]['consecutive_top10']} 天）；"
                              f"P2 {'✓' if s['p2'] else ('✗' if s['p2'] is False else '？无法判定')}"
                              f"（上涨 {(s['up'] or 0) * 100:.1f}%、新高 {(s['nh'] or 0) * 100:.1f}%，有效样本 {s['valid']} 只）；"
                              f"P3 {'✓' if s['p3'] else '✗'}（Δ5 {rows[s['code']]['share_chg_5'] * 100:+.2f}pct、分位 {rows[s['code']]['share_pct_250']:.4f}）"
                              + (f" → {s['gates']} 条闸门、阶段为 {STAGE_CN.get(sc_by.get(s['code'], {}).get('stage'), '—')}，"
                                 f"但综合分排第 {s.get('rank_overall')}，被 TOP_N 截断"
                                 if s["gates"] >= 2 and sc_by.get(s["code"], {}).get("stage")
                                 else (f" → {s['gates']} 条闸门，阶段无法判定，不进 mainlines"
                                       if s["gates"] >= 2 else " → 仅 1 条，不进 mainlines"))
                              + (f"；{s['penalty_rules'][0]} 扣 {s['penalty']} 分" if s["penalty"] else "；无拥挤惩罚"))}
                         for s in emerging],
            "timeline": TIMELINE,
        },
        "risks": RISKS,
        "scenarios": SCENARIOS,
        "playbook": PLAYBOOK,
        "appendix": {
            "method_summary": (
                f"以 {as_of} 为基准日，用东方财富 {run['boards_live']} 个行业板块 {len(dates)} 个交易日（{dates[0]} 起）的涨跌幅与资金流重建成交额份额与横截面排名，"
                f"配合腾讯行情的指数与成分股 K 线计算广度、新高、涨停与龙头指标；先按当期市场 regime"
                f"（{reg.get('regime', 'neutral')} / {reg.get('label', '震荡')}）取对应阈值，再做反脉冲三原则闸门"
                f"（P1 持续性 / P2 广度 / P3 量能）穷举，"
                f"过 ≥2 条者进入打分，再按 fade→divergence→acceleration→expansion→trend→ignition 顺序判阶段，阶段无法赋值者降入萌芽，"
                f"最后按五项因子加权（叙事分权重 0：分数由证据台账推导，仅在同分边界裁决座次）并扣 R1/R2/R3 拥挤惩罚。数据缺失一律写 null 并记入 missing。"
            ),
            "weights": static_w,
            "stage_rules": [
                {"stage": "ignition", "label": "启动期",
                 "rule": f"份额 Δ5 ≥{th['ignition_share_chg_5'] * 100:+.1f}pct；前 10 天数 ≤8；涨停 2~5 家（满足 2 项）"},
                {"stage": "expansion", "label": "发酵期",
                 "rule": f"份额分位 0.60~0.85；涨停 ≥{th['expansion_limit_up']} 家；连板 3~4；"
                         f"上涨占比 ≥{th['expansion_up'] * 100:.0f}%（满足 2 项）"},
                {"stage": "trend", "label": "主升期",
                 "rule": f"份额分位 ≥0.85；20 日涨幅 ≥{th['trend_chg_20'] * 100:.0f}%；"
                         f"上涨占比 ≥{th['trend_up'] * 100:.0f}%（满足 2 项）"},
                {"stage": "acceleration", "label": "加速期",
                 "rule": f"20 日涨幅 >{th['accel_chg_20'] * 100:.0f}%；拥挤度 >0.85；封板率 >75%（满足 2 项）"},
                {"stage": "divergence", "label": "分歧期",
                 "rule": "5 日涨幅 <20 日涨幅/4；份额分位 >0.90；连板回落 ≥2 级（满足 2 项）"},
                {"stage": "fade", "label": "退潮期",
                 "rule": f"份额 Δ20 <{th['fade_share_chg_20'] * 100:+.1f}pct；龙头 5 日跌幅 "
                         f">{abs(th['fade_leader_chg_5d']) * 100:.0f}%；"
                         f"上涨占比 <{th['fade_up'] * 100:.0f}%（满足 2 项）"},
            ],
            "glossary": [
                {"term": "RS", "def": "20 日超额收益分位×50% + 60 日超额收益分位×30% + 20 日跑赢基准天数分位×20%；"
                                      "旧 rs_20 净值比（板块收益÷中证全指收益）仅作展示，不再直接计分"},
                {"term": "P1 持续性", "def": "20 日进入滚动 20 日涨幅前 10 的天数 ≥6 且最近连续 ≥2 天（横截面为 128 个板块的绝对前 10）"},
                {"term": "P2 广度", "def": f"板块内上涨占比 ≥{th['p2_up'] * 100:.0f}% 且创 20 日新高占比 "
                                          f"≥{th['p2_new_high'] * 100:.0f}%；新高定义 = 收盘价高于前 20 个交易日（不含当日）最高收盘价"},
                {"term": "P3 量能", "def": f"成交额占全 A 比重 5 日变化 ≥{th['p3_share_chg_5'] * 100:+.1f}pct 且 "
                                          f"份额分位 ≥0.60（窗口 = min(样本, 250) 日，样本 <120 日不参与），"
                                          f"按 4 位小数原始精度比较"},
                {"term": "市场 regime", "def": f"{reg.get('regime', 'neutral')}（{reg.get('label', '震荡')}）："
                                             f"按基准 20 日收益、板块上涨占比、当日成交额÷20 日均额投票；"
                                             f"P2/P3 与阶段绝对阈值随档位调整，P1 与份额分位不调"},
                {"term": "拥挤度", "def": "份额分位×0.5 + 20 日涨幅分位×0.5，用于 R2 与加速期判定"},
                {"term": "封板率", "def": "1 − 开板家数 ÷ 涨停家数，板块成分股口径"},
                {"term": "fundflow", "def": "5 日主力净额 ÷ 同期板块成交额，东财按单笔金额分档的测算值，权重上限 10%"},
            ],
            "changelog": [{"version": "1.10.0", "date": as_of,
                           "note": f"评分与阈值 P1 改造：rs 由「rs_20 再排分位」改为 20 日 50% + 60 日 30% + "
                                   f"跑赢基准天数 20% 的合成分位；闸门与阶段绝对阈值接入市场 regime"
                                   f"（当期 {reg.get('regime', 'neutral')} / {reg.get('label', '震荡')}），"
                                   f"阈值随进攻/震荡/防御三档调整，P1 与份额分位保持横截面口径"},
                          {"version": "1.9.1", "date": as_of,
                           "note": f"基准日 {as_of}：{len(rows)} 个板块 P1/P3 全样本穷举，P2 计算 {n_p2} 个板块，"
                                   f"闸门合格 {sum(1 for x in listed if x['gates'] >= 2)} 个，其中 stage 可判定 "
                                   f"{sum(1 for x in listed if sc_by[x['code']]['stage'])} 个；"
                                   f"按 schema 上限输出 {len(mainlines)} 条主线，其余 {len(emerging)} 个板块列入 emerging。"
                                   f"相对上一期（{_prev_label}）：{_dtext}。"
                                   f"不以分数排序替代闸门与阶段判定"},
                          {"version": "1.9.0", "date": as_of,
                           "note": f"breadth 口径重做：三项（上涨占比 / 强势股占比≥5% / 涨停占比）改用当日全部 "
                                   f"{bb['ranked']} 个板块做分位分母，不再按候选样本排分位；"
                                   f"新高占比退出计分、保留为 P2 闸门"}],
        },
    }

    # ---------------- 自检 ----------------
    for m in mainlines:
        s = sum(x["contribution"] for x in m["score_breakdown"]) - m["penalty"]
        assert abs(s - m["score"]) <= 0.5, (m["id"], s, m["score"])
        assert len(m["score_breakdown"]) == 6
        assert [x["key"] for x in m["score_breakdown"]][0] == "rs"
        _code = (m.get("sector_codes") or [None])[0]
        if _code in sc_by:
            assert abs(m["score_breakdown"][0]["raw"] - sc_by[_code]["rs"]) <= 0.011, \
                (m["id"], m["score_breakdown"][0]["raw"], sc_by[_code]["rs"])
        assert m["persistence"]["pulse_check"]["passed"] == (m["persistence"]["pulse_check"]["rules_passed"] >= 2)
        assert m["penalty"] in (0, 6, 8, 12)
    assert abs(sum(x["probability"] for x in doc["scenarios"]) - 1.0) < 0.011
    assert doc["verdict"]["mainline_count"] == len(mainlines)
    assert [m["rank"] for m in mainlines] == list(range(1, len(mainlines) + 1))
    assert all(mainlines[i]["score"] >= mainlines[i + 1]["score"] for i in range(len(mainlines) - 1))

    dest = ROOT / args.out
    cacheio.write_text(dest, serialize(doc))
    raw = json.loads(dest.read_text(encoding="utf-8"))
    _txt = dest.read_text(encoding="utf-8")
    print(f"  -> {dest.relative_to(ROOT)}  {len(_txt)} 字符 / {len(raw['mainlines'])} 条主线 / "
          f"emerging {len(raw['rotation']['emerging'])} 条")
    for m in raw["mainlines"]:
        print(f"    #{m['rank']} {m['name']:<28} {m['score']:>6.2f}  {m['stage']:<12} 闸门 {m['persistence']['pulse_check']['rules_passed']} "
              f"pen {m['penalty']} conf {m['stage_confidence']}")
    return 0


def panel_top5(p: dict, code: str, n: int) -> int:
    """20 日进入前 5 的天数（persistence 的辅助字段，仅展示）。"""
    from pipeline import panel  # noqa: PLC0415
    return panel.top_days(p, code, n=n, top=5)["days_top10_20"]


def serialize(doc: dict) -> str:
    """按 v1.6 §10-D 排版：一个顶层键一行，对象内联。"""
    parts = []
    for k, v in doc.items():
        parts.append(f'"{k}": ' + json.dumps(v, ensure_ascii=False, separators=(",", ":")))
    return "{\n" + ",\n".join(parts) + "\n}"


if __name__ == "__main__":
    raise SystemExit(main())

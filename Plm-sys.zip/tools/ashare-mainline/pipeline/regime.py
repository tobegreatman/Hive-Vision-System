"""市场 regime 判定 + 随 regime 变化的阈值表。

    python -m pipeline.regime --as-of 2026-11-09

为什么需要 regime：P2 上涨占比、P3 的 Δ5、阶段里的涨幅/广度/涨停数都是**绝对量**。
同样是 55% 上涨占比，全市场 60% 上涨时是平庸，40% 时是稀缺；固定阈值会让闸门
在进攻市过松、在防御市过严，阶段判据在单边市里失声。这里把这类绝对阈值按
市场状态分三档，横截面相对量（P1 前 10 天数、份额分位）不随 regime 变。

判定只用 run 阶段已有的面板，不额外发请求：
- 基准 20 日收益：面板成交额加权买入持有口径（与 factors 的基准复核同源）
- 板块上涨占比：当日上涨板块数 ÷ 有数据的板块数
- 成交额趋势：当日成交额 ÷ 近 20 日均额
每项投 +1 / 0 / −1，合计 ≥2 为 risk_on、≤−2 为 risk_off，其余 neutral。
三项中至少两项可用才给非 neutral 结论，否则 degraded=true 并按 neutral 出阈值。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import cacheio, day  # noqa: E402

C = ROOT / "pipeline" / "cache"

REGIME_CN = {"risk_on": "进攻", "neutral": "震荡", "risk_off": "防御"}
# 报告 schema 的 market_regime.phase 只认这三个值。
PHASE = {"risk_on": "risk_on", "neutral": "choppy", "risk_off": "risk_off"}

# 阈值表。只列绝对量；P1 天数、份额分位、连板级数、封板率是横截面或板块自身
# 结构量，跨 regime 保持同一口径。
THRESHOLDS = {
    "risk_on": {
        "p2_up": 0.60, "p2_new_high": 0.10, "p3_share_chg_5": 0.006,
        "fade_up": 0.50, "fade_share_chg_20": -0.006, "fade_leader_chg_5d": -0.09,
        "accel_chg_20": 0.30,
        "expansion_up": 0.65, "expansion_limit_up": 6,
        "trend_up": 0.75, "trend_chg_20": 0.10,
        "ignition_share_chg_5": 0.006,
    },
    "neutral": {
        "p2_up": 0.55, "p2_new_high": 0.08, "p3_share_chg_5": 0.005,
        "fade_up": 0.45, "fade_share_chg_20": -0.005, "fade_leader_chg_5d": -0.08,
        "accel_chg_20": 0.25,
        "expansion_up": 0.60, "expansion_limit_up": 5,
        "trend_up": 0.70, "trend_chg_20": 0.08,
        "ignition_share_chg_5": 0.005,
    },
    "risk_off": {
        "p2_up": 0.50, "p2_new_high": 0.05, "p3_share_chg_5": 0.004,
        "fade_up": 0.40, "fade_share_chg_20": -0.004, "fade_leader_chg_5d": -0.07,
        "accel_chg_20": 0.20,
        "expansion_up": 0.55, "expansion_limit_up": 4,
        "trend_up": 0.65, "trend_chg_20": 0.07,
        "ignition_share_chg_5": 0.004,
    },
}


def weighted_index(panel_data: dict, n: int) -> float | None:
    """成交额加权指数（买入持有口径），用来复核基准的量级。

    权重取 **t−n 当日** 成交额，然后一直持有到 t，中途不换手。
    早期版本是每日按前一日成交额再平衡，那会把波动损耗算进去：60 日实测 −0.41%，
    而买入持有 −6.51%、中证全指真值 −11.27%。差值 10.86pct 全是再平衡噪声，
    拿它去判「基准对不对」必然误判。
    """
    dates = sorted(panel_data.get("by_date") or {})
    if len(dates) < n + 1:
        return None
    base_d = dates[-n - 1]
    w = {c: v["amount"] for c, v in panel_data["by_date"][base_d].items()
         if v.get("amount") and v.get("pct") is not None}
    if not w:
        return None
    tot = sum(w.values())
    out = 0.0
    for c, wt in w.items():
        r = 1.0
        for d in dates[-n:]:
            row = panel_data["by_date"][d].get(c)
            if row and row.get("pct") is not None:
                r *= 1.0 + row["pct"] / 100.0
        out += wt / tot * (r - 1.0)
    return out


def market_daily(panel_data: dict) -> dict[str, float]:
    """逐日成交额加权全市场收益（小数），用于「跑赢基准天数」。

    基准没有用中证全指日序列：指数缓存只有区间快照，回溯历史日拿不到当天的
    指数日收益；而面板每天都在，口径与 weighted_index 一致（128 个板块、
    成交额加权），同源可复算。它衡量的是「板块相对全市场」，不是相对指数。
    """
    out = {}
    for d, m in panel_data["by_date"].items():
        num = den = 0.0
        for v in m.values():
            a, p = v.get("amount"), v.get("pct")
            if a and p is not None:
                num += a * p
                den += a
        if den:
            out[d] = num / den / 100.0
    return out


def _vote(v: float | None, hi: float, lo: float) -> int | None:
    if v is None:
        return None
    if v >= hi:
        return 1
    if v <= lo:
        return -1
    return 0


def classify(panel_data: dict, as_of: str) -> dict:
    """按面板判 regime，并带回当期阈值。"""
    bench20 = weighted_index(panel_data, 20)
    hist_up = total = 0
    for code, h in (panel_data.get("history") or {}).items():
        if h and h[-1][0] == as_of and h[-1][1] is not None:
            total += 1
            hist_up += int(h[-1][1] > 0)
    board_up = hist_up / total if total else None

    amt = panel_data.get("market_amount") or {}
    adates = sorted(amt)
    amount_trend = None
    if len(adates) >= 20:
        a20 = [amt[d] for d in adates[-20:]]
        avg20 = sum(a20) / len(a20)
        if avg20:
            # 用当日额 ÷ 20 日均额，不用 5 日均值：5 日均值会被单日放量尖峰拉高，
            # 11-09 前 5 日含 11-04/11-05 的 2 万亿成交，5÷20 仍有 1.10，
            # 但当日已缩到 20 日均额的 0.90——判断「当下量能」要的是后者。
            amount_trend = amt[adates[-1]] / avg20

    votes = {
        "bench_20d": _vote(bench20, 0.03, -0.03),
        "board_up_ratio": _vote(board_up, 0.55, 0.40),
        "amount_trend": _vote(amount_trend, 1.05, 0.95),
    }
    usable = [v for v in votes.values() if v is not None]
    total_vote = sum(usable)
    degraded = len(usable) < 2
    if degraded:
        name = "neutral"
    elif total_vote >= 2:
        name = "risk_on"
    elif total_vote <= -2:
        name = "risk_off"
    else:
        name = "neutral"

    return {
        "as_of": as_of,
        "rule_version": cacheio.REGIME_RULE,
        "regime": name,
        "label": REGIME_CN[name],
        "phase": PHASE[name],
        "votes": total_vote,
        "signals": {
            "bench_20d": round(bench20, 5) if bench20 is not None else None,
            "board_up_ratio": round(board_up, 4) if board_up is not None else None,
            "amount_trend": round(amount_trend, 4) if amount_trend is not None else None,
        },
        "vote_detail": votes,
        "degraded": degraded,
        "missing": [k for k, v in votes.items() if v is None],
        "thresholds": dict(THRESHOLDS[name]),
    }


def fallback(as_of: str, reason: str) -> dict:
    """没有面板/租约时的中性兜底：阈值退回落盘中档，并在报告里可追溯。"""
    reg = classify({}, as_of)
    reg["regime"] = "neutral"
    reg["label"] = REGIME_CN["neutral"]
    reg["phase"] = PHASE["neutral"]
    reg["degraded"] = True
    reg["missing"] = [reason]
    reg["thresholds"] = dict(THRESHOLDS["neutral"])
    return reg


def write(as_of: str, reg: dict, panel_path: Path | None = None) -> Path:
    p = C / f"regime-{as_of}.json"
    out = dict(reg)
    out[cacheio.META] = cacheio.make_meta(
        as_of, cacheio.REGIME_RULE,
        {"panel": panel_path} if panel_path else {},
        regime=reg["regime"],
    )
    cacheio.write_json(p, out)
    return p


def load(as_of: str) -> dict | None:
    p = C / f"regime-{as_of}.json"
    if not p.exists():
        return None
    d, warns = cacheio.read_json(p, "regime", as_of=as_of,
                                 expect_rule=cacheio.REGIME_RULE)
    cacheio.warn(warns)
    return d


def main() -> int:
    ap = argparse.ArgumentParser(description="市场 regime 判定")
    day.add_as_of(ap)
    args = ap.parse_args()
    as_of = day.resolve(args.as_of)

    pkl = C / f"panel-{as_of}.pkl"
    p, warns = cacheio.read_pickle(pkl, "panel", as_of=as_of,
                                   expect_rule=cacheio.PANEL_RULE)
    cacheio.warn(warns)
    reg = classify(p, as_of)
    path = write(as_of, reg, pkl)
    s = reg["signals"]
    print(f"regime {as_of}：{reg['regime']}（{reg['label']}） 票 {reg['votes']:+d}"
          + ("  [degraded]" if reg["degraded"] else ""))
    print(f"  基准20日 {s['bench_20d'] * 100:+.2f}% | 上涨板块 {s['board_up_ratio'] * 100:.1f}% | "
          f"当日额÷20日均 {s['amount_trend']:.3f}")
    print(f"  阈值 P2 上涨 {reg['thresholds']['p2_up'] * 100:.0f}% / 新高 "
          f"{reg['thresholds']['p2_new_high'] * 100:.0f}% | P3 Δ5 "
          f"{reg['thresholds']['p3_share_chg_5'] * 100:+.1f}pct")
    print(f"  -> {path.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""五阶段判定 + 六因子打分 + 拥挤惩罚。

    python -m pipeline.score --as-of 2026-10-30

读 factors / run / limit 三个缓存，按 v1.7 的裁决顺序
（fade → divergence → acceleration → expansion → trend → ignition）逐条判据穷举，
阶段无法赋值者不进榜，改列 rotation.emerging。

v1.7 相对 v1.6 的两处改动：
1. 补 trend（主升持续）阶段。v1.6 的五阶段在「份额分位 >0.85、20 日涨幅 8~25%、
   涨停未成潮、也未减速」这一段是空的，导致最健康的主线中段被判成「阶段无法赋值」
   而踢出榜单（2026-11-05：影视院线 70.76 / 白酒Ⅱ 69.54 / 数字媒体 66.25 /
   出版 62.94 四个板块同时命中这个盲区，占当日前四名中的三席）。
2. 叙事分移出总分。它只写给「已入榜」的板块，计入总分会让排名自我确认
   ——先判定进榜、再写叙事分、叙事分让分数看起来该进榜。现仅作定性标注。

v1.8 再改两处（叙事分本身）：
3. 分数改由 (evidence, source) 按 §6 档位推导，不再手填；未评写 null，不是 0 分。
   台账与推导的实现在 pipeline/narrative.py，此处只消费。
4. 排序次键改为叙事分：同分或近分（|Δ|<1 由 build_v16 裁决 TOP_N 切口）时，
   叙事分高的排前面，分数本身不变。

输出 cache/score-<as_of>.json，报告生成端直接消费。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import boardbreadth, day, narrative  # noqa: E402

# v1.7：叙事分移出总分。五项权重的**比例**保持 v1.6 原样（25:20:20:15:10），
# 只是参与分配的总额从 100 变 90，再按 90 归一化回 100 分制。
# 为什么不把腾出的 10 分按比例塞给五项：那会把 rs 从 25 抬到 28，而 rs 与 chg_20d
# 在 128 个板块里有 126 个分位完全相同（rs=(1+chg20)/(1+base)，分母是常数），
# 放大它等于放大一个冗余因子。归一化既不改变因子间的相对权重，也保住 0~100 的量纲。
WEIGHTS = {"rs": 25, "persistence": 20, "volume": 20, "breadth": 15, "fundflow": 10}
TOTAL_W = sum(WEIGHTS.values())  # 90
NARRATIVE_WEIGHT = 0


def effective_weight(w: float) -> float:
    """把 90 分制的设计权重换算成 100 分制的有效权重，用于报表展示。

    contribution = normalized × weight ÷ Σweight，所以 25 在表里的真实系数是
    25 ÷ 90 = 0.2778（等价有效权重 27.78）。报表若照抄 25，读者用
    92.97% × 25 = 23.24 去验算，永远对不上贡献里的 25.82 —— 那个 ÷90
    只写在代码里，看不见。这里统一输出 100 分制的权重，让
    normalized × weight ÷ 100 = contribution 能当场手算。

    不做四舍五入：截到 4 位（27.7778）会让乘积恰落在 .xx5 的行
    （92.97 × 27.7778% = 25.825 → 25.83）与贡献（25.82，round(25.825)
    按原始精度算）差 1 分钱。保留全精度则逐位一致——序列化成
    27.77777777777778 不好看，但「能复算」优先于「好看」。
    """
    return w / TOTAL_W * 100


def pct_in(values: list[float], v: float | None, *, higher_better: bool = True) -> float:
    """横截面百分位，口径 (below + 1) / n × 100，最高位给 100。

    与上一版 v1.6 报告一致：8 板块样本时新高 42.11 排第 2 得 87.5 = 7/8。
    """
    vals = [x for x in values if x is not None]
    if v is None or not vals:
        return 0.0
    below = sum(1 for x in vals if x < v)
    return round((below + 1) / len(vals) * 100, 2)


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)
    # 叙事分只从台账读，不再接受命令行直传。
    #
    # v1.7 允许 --narrative BK1277:95 覆盖台账，理由是「重跑漏一个参数会让 narrative 静默归零」。
    # 但 v1.8 起分数由 (evidence, source) 推导，直传裸分等于给「手填中间档」留后门——
    # 11-05 那条 78 就是既不是 75+5 也不是 80−2 的产物，无法用 §6 复算。
    # 要改分数就改台账里的 evidence/source，narrative.load() 会校验二者是否自洽。
    entries = narrative.load(args.as_of)

    fac = json.loads((ROOT / "pipeline" / "cache" / f"factors-{args.as_of}.json").read_text(encoding="utf-8"))
    run = json.loads((ROOT / "pipeline" / "cache" / f"run-{args.as_of}.json").read_text(encoding="utf-8"))
    lim = json.loads((ROOT / "pipeline" / "cache" / f"limit-{args.as_of}.json").read_text(encoding="utf-8"))

    rows = fac["rows"]
    pc = fac["pct"]

    # ---- 成分股 -> 板块，用于涨停/连板/开板 ----
    zt_by_code = {str(p["code"]).zfill(6): p for p in lim["limit_up"]}
    zb_by_code = {str(p["code"]).zfill(6): p for p in lim["broken"]}
    prev_by_code = {str(p["code"]).zfill(6): p for p in lim.get("prev_limit_up", [])}
    # 成分表：目录里有什么就用什么，不设白名单。
    #
    # 这里原来按 codes-INDEX.json 过滤，只加载「本轮候选」。但那个文件没有日期维度，
    # 一次 --as-of 2026-10-30 的回溯就会把它覆盖成 10-30 的候选名单，回到 11-05 后
    # 光伏 BK1031（11 家涨停）、半导体 BK1036（4 家）都不在白名单里 → pool_stats 取不到成员
    # → 涨停数记 0、封板率与龙头记 null → breadth 因子的涨停分位从 100 掉到 10，
    # 光伏少算 3.75 分、名次从第 1 掉到第 2。全程不报错，只在报告正文里继续写着「11 家涨停」。
    #
    # members 只有 .get(code) 这一种用法（不遍历），多加载几个板块的代价只是报价快照大一点：
    # 反正这些成分股本来就在 kline.sqlite 里，多出来的请求是 0。
    members: dict[str, list[str]] = {}
    _extra_p = ROOT / "pipeline" / "cache" / f"extra-{args.as_of}.json"
    _extra_rows = (json.loads(_extra_p.read_text(encoding="utf-8")).get("rows") or {}
                   if _extra_p.exists() else {})
    for f in sorted((ROOT / "pipeline" / "cache").glob("codes-*.json")):
        code = f.stem.split("-", 1)[1]
        if code.startswith("INDEX"):
            continue
        members[code] = json.loads(f.read_text(encoding="utf-8"))

    # 龙头 5 日涨幅需要个股 K 线与当日成交额；K 线库已在 run 阶段建好，这里只补一次报价
    from pipeline import http, kline, quotes  # noqa: E402

    store = kline.Store(ROOT / "pipeline" / "cache" / "kline.sqlite")
    # 成分表现在是全 128 个板块（v1.9 的广度分位要用），但**报价与 K 线只对候选取**：
    # 128 个板块的成员去重后 5,655 只，按全体补齐会一次发 3,600 个报价请求。
    _idx_p = ROOT / "pipeline" / "cache" / f"codes-INDEX-{args.as_of}.json"
    _cand_boards = (set(json.loads(_idx_p.read_text(encoding="utf-8")))
                    if _idx_p.exists() else {g["code"] for g in run["gates"]})
    all_members = list(dict.fromkeys(str(c).zfill(6)
                                     for b, v in members.items() if b in _cand_boards for c in v))
    # 报价快照落盘：龙头判定要按当日成交额排序，没有成交额就选不出龙头；
    # 但每改一行文案都重拉 485 只（9 次请求）既慢又碰到 WAF。同日快照一次即够，
    # 盘后价格不会变，命中缓存时不发任何请求。
    qdir = ROOT / "pipeline" / "cache"
    snap, snap_date = quotes.load(qdir, args.as_of)
    if snap and snap_date == args.as_of:
        # 命中也要补齐：快照可能是上一轮只覆盖 485 只时留下的，而 members 现在有 1600 只。
        # 缺报价的股票在 kline.breadth 里会被直接跳过（same_day 分支要求有 price），
        # 广度就只在「恰好进了快照」的那部分成分股上计算，比例会有偏。
        _miss = [c for c in all_members if c not in snap]
        if len(_miss) > 20:
            snap.update(quotes.fetch(http.make_client(workers=4, max_rps=4, min_span=0), _miss))
            quotes.save(qdir, args.as_of, snap)
            print(f"  报价快照命中缓存并补齐：{len(snap)} 只（{len(_miss)} 只补拉）")
        else:
            print(f"  报价快照命中缓存：{len(snap)} 只（0 请求）")
    else:
        if snap:
            print(f"  ⚠ 缓存快照是 {snap_date} 的，与基准日 {args.as_of} 不同源，重拉（不覆盖旧文件）")
        snap = quotes.fetch(http.make_client(workers=4, max_rps=4, min_span=0), all_members)
        wrote, qd = quotes.save(qdir, args.as_of, snap)
        print(f"  报价快照已落盘：{len(snap)} 只 -> quotes-{args.as_of}.json" if wrote
              else f"  ⚠ 快照未落盘：报价交易日 {qd} 与 as_of {args.as_of} 不一致，仅本轮内存使用")

    def leader_chg5(bk: str) -> float | None:
        """板块内当日成交额最大的成分股，其 5 日涨幅。"""
        codes = [str(c).zfill(6) for c in members.get(bk, [])]
        best, amt = None, -1.0
        for c in codes:
            a = (snap.get(c) or {}).get("amount_yi") or 0
            if a > amt:
                best, amt = c, a
        if not best:
            return None
        bars = store.bars(best, args.as_of, 6)
        # 库里有缺口时「6 根」跨的自然日不是 6 个交易日，5 日涨幅会被放大成 8~10 日涨幅。
        # 首根对不上当天就直接给 None，宁可缺这个字段也不要给个错数。
        if len(bars) < 6 or bars[0][0] != args.as_of:
            return None
        return round(bars[0][1] / bars[-1][1] - 1, 4)

    def pool_stats(bk: str) -> dict:
        codes = [str(c).zfill(6) for c in members.get(bk, [])]
        zt = [zt_by_code[c] for c in codes if c in zt_by_code]
        zb = [zb_by_code[c] for c in codes if c in zb_by_code]
        prev = [prev_by_code[c] for c in codes if c in prev_by_code]
        # 开板家数 = 涨停股中盘中开过板的（zbc > 0），v1.6 glossary 的板块口径
        open_n = sum(1 for x in zt if (x.get("open_times") or 0) > 0)
        # prev_limit_up 为空有两种可能：①没传 --prev（本轮没取上期池）②取到了但该板块上期无涨停。
        # 前者必须写 null（0 与「上期零家涨停」含义完全不同），否则 divergence 的
        # 「连板回落 ≥2 级」会用一个假的 0 去比，把没判据的板块判成「没回落」。
        prev_fetched = bool((lim or {}).get("prev_limit_up"))
        return {
            "limit_up_count": len(zt),
            "limit_up_names": [x["name"] for x in zt],
            "max_streak": max((x.get("streak") or 1) for x in zt) if zt else 0,
            "max_streak_prev": (max((x.get("streak") or 1) for x in prev) if prev else 0)
                                if prev_fetched else None,
            "open_count": open_n,
            "broken_count": len(zb),
            # 板块口径封板率 = 1 − 开板家数 ÷ 涨停家数（v1.6 glossary 原文定义）
            "seal_rate": round(1 - open_n / len(zt), 4) if zt else None,
            "leader_chg_5d": leader_chg5(bk),
        }

    # ---- 逐板块组装 ----
    # pool_stats 要对全部 8 个候选算，因为 breadth 的横截面百分位需要更宽的样本；
    # 只用「≥2 条闸门」的两个板块做分母，会让新高分位在 50/100 之间硬跳。
    gated = []
    for g in run["gates"]:
        f = rows.get(g["code"])
        if not f:
            continue
        gated.append({**f, "gate": g, **pool_stats(g["code"])})
    # 分位样本只认 run 的候选：extra 是「按需补算的近失板块」，让它进样本会让分数
    # 随「本轮补算了几个板块」漂移（实测同一天跑与不跑 extra，光伏 breadth 分位 87.5→60）。
    n_base = len(gated)
    for code, e in _extra_rows.items():
        if any(g["code"] == code for g in gated):
            continue
        f = rows.get(code)
        if not f:
            continue
        _p1 = f["days_top10_20"] >= 6 and f["consecutive_top10"] >= 2
        _p2 = (None if (e.get("valid") or 0) < 10 or e.get("degraded")
               else ((e.get("up_ratio") or 0) >= 0.55 and (e.get("new_high_ratio") or 0) >= 0.08))
        _p3 = (f["share_chg_5"] or 0) >= 0.005 and (f["share_pct_250"] or 0) >= 0.60
        gated.append({**f, "gate": {
            "code": code, "name": e.get("name") or f["name"],
            "p1": _p1, "p2": _p2, "p3": _p3,
            "gates": int(_p1) + int(bool(_p2)) + int(_p3),
            "breadth_up_ratio": e.get("up_ratio"), "new_high_ratio": e.get("new_high_ratio"),
            "valid": e.get("valid"),
        }, **pool_stats(code)})
    cands = [g for g in gated if g["gate"]["gates"] >= 2]

    # 横截面样本（分项各自用可得样本）
    all_rows = list(rows.values())
    S_rs = [r["rs_20"] for r in all_rows]
    S_dt = [r["days_top10_20"] for r in all_rows]
    S_cs = [r["consecutive_top10"] for r in all_rows]
    S_ud = [r["up_days_60"] for r in all_rows]
    S_sh = [r["share"] for r in all_rows]
    S_d5 = [r["share_chg_5"] for r in all_rows]
    S_fl = [r["flow5"] for r in all_rows]
    S_up = [c["gate"]["breadth_up_ratio"] for c in gated[:n_base]]
    S_nh = [c["gate"]["new_high_ratio"] for c in gated[:n_base]]
    S_zt = [c["limit_up_count"] for c in gated[:n_base]]
    # v1.9：广度的三个分项改成在**当天全部板块**上排（boardbreadth），不再用候选样本。
    # 旧口径的毛病是双重的：①候选只有 8~11 个，分母每档 9~12 个百分点；②候选全是强票，
    # 彼此比较会把大多数压到低分位——11-05 出版上涨占比 89.3% 被排到 18.2 分位；
    # ③分母还随「今天几个板块过闸门」漂移，同一个板块的分数会因别人涨跌而变。
    # 现在分母固定（当天 123~128 个板块），涨/强势/涨停占比全部由快照本地算，零额外请求。
    bb = boardbreadth.load(args.as_of)
    _uni = {k: v for k, v in bb["boards"].items() if v.get("ranked")}
    B_up = [v["up_ratio"] for v in _uni.values()]
    B_st = [v["strong_ratio"] for v in _uni.values()]
    B_zt = [v["limit_up_ratio"] for v in _uni.values()]
    S_g20 = [r["chg_20d"] for r in all_rows]

    out = []
    for c in gated:
        base20 = fac["base"]["chg_20d"]
        rs = (1 + c["chg_20d"]) / (1 + base20)
        crowding = 0.5 * (c["share_pct_250"] or 0) + 0.5 * pct_in(S_g20, c["chg_20d"]) / 100

        n_rs = pct_in(S_rs, c["rs_20"])
        n_pe = round((pct_in(S_dt, c["days_top10_20"]) + pct_in(S_cs, c["consecutive_top10"])
                      + pct_in(S_ud, c["up_days_60"])) / 3, 2)
        n_vo = round(pct_in(S_sh, c["share"]) * 0.6 + pct_in(S_d5, c["share_chg_5"]) * 0.4, 2)
        # 三项各占 0.40 / 0.35 / 0.25；新高退出计分（保留为 P2 闸门——突破是资格，不是程度）。
        # 板块在当天广度表里缺席（成分太少/停牌）时退回候选样本口径，不让它变成 0 分。
        _u = _uni.get(c["code"])
        if _u:
            n_br = round(pct_in(B_up, _u["up_ratio"]) * 0.40
                         + pct_in(B_st, _u["strong_ratio"]) * 0.35
                         + pct_in(B_zt, _u["limit_up_ratio"]) * 0.25, 2)
        else:
            n_br = round(pct_in(S_up, c["gate"]["breadth_up_ratio"]) * 0.4
                         + pct_in(S_nh, c["gate"]["new_high_ratio"]) * 0.35
                         + pct_in(S_zt, c["limit_up_count"]) * 0.25, 2)
        n_ff = pct_in(S_fl, c["flow5"])
        # 未评 = None，不是 0。0 分的含义是「有 0 条可验证证据」，与「本轮没登记」必须区分，
        # 否则缺评的板块会被读者当成「无叙事」，也会在边界裁决里被当成最低分参与比较。
        n_na = narrative.score_of(entries, c["code"])
        norm = {"rs": n_rs, "persistence": n_pe, "volume": n_vo, "breadth": n_br,
                "fundflow": n_ff, "narrative": n_na}
        contrib = {k: round(v * WEIGHTS[k] / TOTAL_W, 2) for k, v in norm.items() if k in WEIGHTS}

        # 五阶段判据
        gate = c["gate"]
        d5, d20 = c["share_chg_5"] or 0, c["share_chg_20"] or 0
        crit = {
            "fade": [
                ("份额 Δ20 < −0.5pct", d20 < -0.005, f"{d20 * 100:+.2f}pct"),
                ("龙头 5 日跌幅 > 8%", (c["leader_chg_5d"] or 0) < -0.08,
                 f"{(c['leader_chg_5d'] or 0) * 100:+.2f}%"),
                ("上涨占比 < 45%", gate["breadth_up_ratio"] < 0.45, f"{gate['breadth_up_ratio'] * 100:.1f}%"),
            ],
            "divergence": [
                ("5 日涨幅 < 20 日涨幅/4", (c["chg_5d"] or 0) < (c["chg_20d"] or 0) / 4,
                 f"{(c['chg_5d'] or 0) * 100:+.2f}% vs {(c['chg_20d'] or 0) / 4 * 100:+.2f}%"),
                ("份额分位 > 0.90", (c["share_pct_250"] or 0) > 0.90, f"{c['share_pct_250']}"),
                # 板块自身前后对比：prev − cur ≥ 2。和全市场最高连板比是错的，
                # 首板板块会被误判成「回落」，白酒上一轮就因此被错判成 divergence。
                # prev 是 5 个交易日前的连板高度（limitpool --prev 取 10-23），不是「前一日」。
                ("连板回落 ≥ 2 级",
                 c["max_streak_prev"] is not None and c["max_streak_prev"] - c["max_streak"] >= 2,
                 f"5 个交易日前 {'无数据' if c['max_streak_prev'] is None else str(c['max_streak_prev']) + ' 级'}"
                 f" → 当日 {c['max_streak']} 级"),
            ],
            "acceleration": [
                ("20 日涨幅 > 25%", (c["chg_20d"] or 0) > 0.25, f"{(c['chg_20d'] or 0) * 100:+.2f}%"),
                ("拥挤度 > 0.85", crowding > 0.85, f"{crowding:.4f}"),
                ("封板率 > 75%", (c["seal_rate"] or 0) > 0.75,
                 f"{c['seal_rate'] if c['seal_rate'] is not None else '无涨停'}"),
            ],
            "expansion": [
                ("份额分位 0.60~0.85", 0.60 <= (c["share_pct_250"] or 0) <= 0.85, f"{c['share_pct_250']}"),
                ("涨停 ≥ 5 家", c["limit_up_count"] >= 5, f"{c['limit_up_count']} 家"),
                ("连板 3~4 级", 3 <= c["max_streak"] <= 4, f"{c['max_streak']} 级"),
                ("上涨占比 ≥ 60%", gate["breadth_up_ratio"] >= 0.60, f"{gate['breadth_up_ratio'] * 100:.1f}%"),
            ],
            # v1.7 新增。语义是「已过扩张窗口、仍在延续」：分位超过 expansion 的
            # 0.60~0.85 上界，说明资金深度参与；但涨幅没到 acceleration 的 25%、
            # 涨停也没成潮，说明尚未过热。这一档在 v1.6 里无家可归。
            "trend": [
                ("份额分位 ≥ 0.85", (c["share_pct_250"] or 0) >= 0.85, f"{c['share_pct_250']}"),
                ("20 日涨幅 ≥ 8%", (c["chg_20d"] or 0) >= 0.08, f"{(c['chg_20d'] or 0) * 100:+.2f}%"),
                ("上涨占比 ≥ 70%", gate["breadth_up_ratio"] >= 0.70, f"{gate['breadth_up_ratio'] * 100:.1f}%"),
            ],
            "ignition": [
                ("份额 Δ5 ≥ +0.5pct", d5 >= 0.005, f"{d5 * 100:+.2f}pct"),
                ("前 10 天数 ≤ 8", c["days_top10_20"] <= 8, f"{c['days_top10_20']} 天"),
                ("涨停 2~5 家", 2 <= c["limit_up_count"] <= 5, f"{c['limit_up_count']} 家"),
            ],
        }
        # 阶段判定只对过了 ≥2 条闸门的候选做。闸门在前、阶段在后是 v1.6 的因果顺序：
        # 汽车零部件 P1 0/20、P2 上涨 7.6%，却因为「前 10 天数 ≤ 8」（它从没进过前 10）
        # 和「份额 Δ5 +0.58pct」被判成 ignition——不给闸门不足的板块判阶段，就不会出这种荒诞结果。
        hits = {k: [x for x in v if x[1]] for k, v in crit.items()}
        stage = None
        if c["gate"]["gates"] >= 2:
            # trend 排在 expansion 之后：expansion 的判据更硬（分位窗口 + 涨停 + 连板 + 广度，4 条），
            # 放到 trend 前面才不会把「发酵扩散」误吃成「主升持续」（游戏Ⅱ 分位 0.7372、
            # 20 日 +14.93%、上涨 91.7% 会同时命中 trend 的 2 条）。
            for s in ("fade", "divergence", "acceleration", "expansion", "trend", "ignition"):
                if len(hits[s]) >= 2:
                    stage = s
                    break

        # 惩罚
        pen, reasons = 0, []
        if (c["share_pct_250"] or 0) > 0.95 and c["max_streak"] >= 5:
            pen = max(pen, 12)
            reasons.append("R1")
        if (c["share_pct_250"] or 0) > 0.90 and crowding > 0.90:
            pen = max(pen, 6)
            reasons.append("R2")
        if (c["chg_60d"] or 0) > 0.60 and (c["flow5"] or 0) < 0:
            pen = max(pen, 8)
            reasons.append("R3")

        total = round(sum(contrib.values()) - pen, 2)
        out.append({
            "code": c["code"], "name": c["name"], "stage": stage,
            "gates": c["gate"]["gates"],
            # 进榜条件：≥2 条闸门 AND 阶段可判定（§3 第 6 条）
            "listed": c["gate"]["gates"] >= 2 and stage is not None,
            "rs": round(rs, 4), "crowding": round(crowding, 4),
            "norm": norm, "contrib": contrib, "penalty": pen, "penalty_rules": reasons,
            "score": total,
            "pool": {k: c[k] for k in ("limit_up_count", "limit_up_names", "max_streak",
                                       "max_streak_prev", "open_count", "broken_count",
                                       "seal_rate", "leader_chg_5d")},
            "crit": {k: [(n, ok, val) for n, ok, val in v] for k, v in crit.items()},
        })

    # 主键分数、次键叙事分。次键只在分数完全相同时起作用（|Δ|<1 的边界裁决由
    # build_v16 的 narrative.pick_top 做，那里能看见第 n 与 n+1 名这一对，score 这边看不见）。
    out.sort(key=lambda x: (-x["score"],
                            -(x["norm"]["narrative"] if x["norm"]["narrative"] is not None else -1)))

    print("=" * 70)
    print("阶段判定（按 fade→divergence→acceleration→expansion→trend→ignition 顺序）")
    print("=" * 70)
    for o in out:
        print(f"\n  {o['name']}（{o['code']}）")
        for s in ("fade", "divergence", "acceleration", "expansion", "trend", "ignition"):
            hi = sum(1 for _, ok, _ in o["crit"][s] if ok)
            mark = " <== 命中" if o["stage"] == s else ""
            print(f"    {s:<13} {hi}/{len(o['crit'][s])}{mark}")
            for n, ok, val in o["crit"][s]:
                print(f"        {'✓' if ok else '·'} {n:<24} {val}")
        print(f"    -> stage = {o['stage']}" if o["stage"]
              else f"    -> {'闸门不足（' + str(o['gates']) + ' 条），不做阶段判定' if o['gates'] < 2 else '阶段不可判定（进 emerging）'}")

    print("\n" + "=" * 70)
    print("六因子打分")
    print("=" * 70)
    for o in out:
        tag = "进榜" if o["listed"] else f"{o['gates']} 条闸门，进萌芽"
        print(f"\n  {o['name']}  score {o['score']}  penalty {o['penalty']} {o['penalty_rules']}  [{tag}]")
        print(f"    {'因子':<12}{'norm':>9}{'w':>5}{'贡献':>8}")
        for k, w in WEIGHTS.items():
            print(f"    {k:<12}{o['norm'][k]:>9.2f}{w / TOTAL_W * 100:>5.1f}{o['contrib'][k]:>8.2f}")
        _nv = o["norm"]["narrative"]
        _nv_txt = f"{_nv:>9.2f}" if _nv is not None else "        —"
        print(f"    {'narrative':<12}{_nv_txt}{0:>5}{0:>8.2f}   ← 权重 0，仅边界裁决")
        print(f"    {'小计':<12}{'':>9}{'':>5}{sum(o['contrib'].values()):>8.2f}")

    # 叙事覆盖：候选池是「过 ≥2 条闸门」的板块，缺评必须点名而不是静默归零。
    pool = [o["code"] for o in out if o["gates"] >= 2]
    cov = narrative.coverage(entries, pool)
    print("\n" + "=" * 70)
    print(f"叙事分台账（候选 {cov['total']} 个 / 已评 {cov['evaluated']} 个）")
    print("=" * 70)
    for o in out:
        if o["code"] not in pool:
            continue
        e = entries.get(o["code"]) or {}
        print(f"  {o['name']:<12}{narrative.explain(e)}")
    if cov["missing"]:
        names = [o["name"] for o in out if o["code"] in cov["missing"]]
        print(f"  ⚠ 未评：{'、'.join(names)}——报告里会写成 null，不计 0 分、不参与边界裁决")
    if cov["legacy"]:
        print(f"  ⚠ 裸数字条目（无证据台账）：{'、'.join(cov['legacy'])}")

    dest = ROOT / "pipeline" / "cache" / f"score-{args.as_of}.json"
    dest.write_text(json.dumps({
        "as_of": args.as_of, "weights": WEIGHTS, "market": lim["market"],
        "cross_section": {"boards": len(all_rows), "p2_boards": len(cands),
                          "breadth_universe": len(_uni), "breadth_ranked": bb.get("ranked")},
        "narrative": {"entries": entries, "coverage": cov,
                      "tie_threshold": narrative.TIE_THRESHOLD,
                      "strong_threshold": narrative.STRONG_NARRATIVE},
        "rows": out,
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\n  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

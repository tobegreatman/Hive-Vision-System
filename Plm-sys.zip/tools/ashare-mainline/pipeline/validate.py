"""发布前校验：把手工核对清单变成一条命令。

    python -m pipeline.validate --as-of 2026-11-09

检查四类问题：

1. **文件与日期**：score/factors/run/limit/boardbreadth/aml 是否齐全，`as_of` 是否同一天。
2. **数字自洽**：`score = 贡献之和 - 惩罚`；`listed` 必须有 stage；stage 非空必须 ≥2 条闸门；
   P0 诊断字段是否齐全。
3. **报告契约**：schema、主线条数、`data_quality`、`rotation.emerging` 是否覆盖
   「1 条闸门」与「闸门够但阶段不可判定」两类板块。
4. **内容卫生**：正文/结构化字段里是否残留 TODO/TBD/待补/占位符。

退出码 1 表示有 error，0 表示只有 warning 或全部通过。daily 在组装后、发布前调用它，
失败会停在发布之前，避免把一份自洽性有问题的报告推到 /mainline。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import cacheio, day, panel  # noqa: E402

C = ROOT / "pipeline" / "cache"
PLACEHOLDER = re.compile(r"TODO|TBD|FIXME|待补|占位")
MAINLINE_KEYS = ("id", "rank", "name", "stage", "score", "score_breakdown",
                 "penalty", "drivers", "narrative", "invalidation", "watch")


def _load(name: str, as_of: str, errors: list[str]) -> dict | None:
    p = C / f"{name}-{as_of}.json"
    if not p.exists():
        errors.append(f"缺少 {p.name}")
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        errors.append(f"{p.name} 读取失败：{e}")
        return None


def _as_of(d: dict) -> str | None:
    return d.get("as_of") or (d.get("_meta") or {}).get("as_of")


def _walk_strings(obj, path: str = ""):
    if isinstance(obj, str):
        yield path, obj
    elif isinstance(obj, list):
        for i, x in enumerate(obj):
            yield from _walk_strings(x, f"{path}[{i}]")
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk_strings(v, f"{path}.{k}" if path else str(k))


def validate(as_of: str) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    checks: dict = {}

    score = _load("score", as_of, errors)
    factors = _load("factors", as_of, errors)
    run = _load("run", as_of, errors)
    limit = _load("limit", as_of, errors)
    bb = _load("boardbreadth", as_of, errors)
    extra = None
    extra_p = C / f"extra-{as_of}.json"
    if extra_p.exists():
        try:
            extra = json.loads(extra_p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            errors.append(f"{extra_p.name} 读取失败：{e}")
    else:
        warnings.append("缺少 extra-<as_of>.json：近失板块 P2 覆盖可能不全")
    report = None
    aml_p = ROOT / f"aml-{as_of.replace('-', '')}-v16.json"
    if not aml_p.exists():
        errors.append(f"缺少 {aml_p.name}")
    else:
        try:
            report = json.loads(aml_p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            errors.append(f"{aml_p.name} 读取失败：{e}")

    # 1. 日期一致性
    for name, d in (("score", score), ("factors", factors), ("run", run),
                    ("limit", limit), ("boardbreadth", bb), ("extra", extra)):
        if d is not None:
            got = _as_of(d)
            if got != as_of:
                errors.append(f"{name}: as_of={got} != {as_of}")
            if not d.get("_meta"):
                warnings.append(f"{name}: 旧缓存无 _meta（建议重跑一次写入契约）")
    if report is not None:
        got = (report.get("meta") or {}).get("as_of")
        if got != as_of:
            errors.append(f"aml: meta.as_of={got} != {as_of}")

    # 1b. 板块清单（生存偏差）：缺失只告警——它是辅助口径，不阻断发布；
    # 但当日板块数必须与 run/factors 的横截面一致，否则说明快照与面板不同源。
    uni_p = C / f"universe-{as_of}.json"
    if not uni_p.exists():
        warnings.append("缺少 universe-<as_of>.json：板块清单生存偏差未量化")
    else:
        try:
            uni = json.loads(uni_p.read_text(encoding="utf-8"))
            checks["universe_boards"] = (uni.get("current") or {}).get("count")
            checks["universe_removed"] = (uni.get("drift") or {}).get("removed_union_count")
            if _as_of(uni) != as_of:
                errors.append(f"universe: as_of={_as_of(uni)} != {as_of}")
            live = (run or {}).get("boards_live")
            if live and checks["universe_boards"] != live:
                warnings.append(f"universe.current={checks['universe_boards']} != "
                                f"run.boards_live={live}，清单快照与面板不同源")
        except (OSError, ValueError) as e:
            errors.append(f"{uni_p.name} 读取失败：{e}")

    # 2. 数字自洽
    rows = (score or {}).get("rows") or []
    checks["score_rows"] = len(rows)
    if not rows:
        errors.append("score.rows 为空")
    for r in rows:
        calc = round(sum((r.get("contrib") or {}).values()) - (r.get("penalty") or 0), 2)
        if abs(calc - (r.get("score") or 0)) > 0.011:
            errors.append(f"{r.get('name')}: score={r.get('score')} != 贡献和-惩罚={calc}")
        if r.get("listed") and not r.get("stage"):
            errors.append(f"{r.get('name')}: listed=true 但 stage=null")
        if r.get("stage") and (r.get("gates") or 0) < 2:
            errors.append(f"{r.get('name')}: stage={r.get('stage')} 但 gates<2")
        if not r.get("stage_evidence"):
            errors.append(f"{r.get('name')}: 缺 stage_evidence")
        if not r.get("stage") and not r.get("stage_pending_reason"):
            errors.append(f"{r.get('name')}: stage=null 且无 stage_pending_reason")

    # 3. 数据覆盖
    fac_rows = (factors or {}).get("rows") or {}
    checks["factor_boards"] = len(fac_rows)
    if len(fac_rows) < 100:
        errors.append(f"factors.rows={len(fac_rows)} < 100，横截面不完整")
    bb_boards = (bb or {}).get("boards") or {}
    checks["breadth_boards"] = len(bb_boards)
    if len(bb_boards) < 100:
        errors.append(f"boardbreadth.boards={len(bb_boards)} < 100")
    gates = (run or {}).get("gates") or []
    checks["run_gates"] = len(gates)
    if not gates:
        errors.append("run.gates 为空")
    else:
        p2_known = sum(1 for g in gates if g.get("p2") is not None)
        checks["p2_known_ratio"] = round(p2_known / len(gates), 4)
        if p2_known / len(gates) < 0.5:
            warnings.append(f"run.gates 中 P2 已算比例仅 {p2_known}/{len(gates)}")
        # P3 的「250 日分位」在样本不足时按实际样本算，必须披露；样本 <120 日不应过闸门。
        p3_gates = [g for g in gates if g.get("p3")]
        thin = [g for g in p3_gates
                if g.get("share_samples") is not None
                and g["share_samples"] < panel.SHARE_MIN_SAMPLES]
        if thin:
            errors.append(f"{len(thin)} 个板块 P3 通过但分位样本 <{panel.SHARE_MIN_SAMPLES} 日："
                          + "、".join(x.get("name") or x.get("code") for x in thin[:6]))
        short = [g for g in p3_gates
                 if g.get("share_samples") is not None
                 and panel.SHARE_MIN_SAMPLES <= g["share_samples"] < panel.SHARE_WINDOW]
        checks["p3_short_window"] = len(short)
        if short:
            warnings.append(f"{len(short)} 个板块 P3 分位窗口 <{panel.SHARE_WINDOW} 日"
                            f"（按实际样本计，已降级）："
                            + "、".join(x.get("name") or x.get("code") for x in short[:6]))
    leaders = sum(1 for r in rows if (r.get("pool") or {}).get("leader_chg_5d") is not None)
    checks["leader_ratio"] = round(leaders / len(rows), 4) if rows else None
    if rows and leaders / len(rows) < 0.5:
        warnings.append(f"龙头 5 日涨幅覆盖仅 {leaders}/{len(rows)}")

    # regime 一致性：run 定闸门、score 定阶段，两处必须同档；阈值三件套缺一不可，
    # 否则报告里的「阈值」和实际判定会各说各话。
    rr = (run or {}).get("regime") or {}
    sr = (score or {}).get("regime") or {}
    if not sr:
        warnings.append("score 缺 regime（P1 改造前缓存，阈值可能仍是固定值）")
    else:
        checks["regime"] = sr.get("regime")
        if rr and rr.get("regime") != sr.get("regime"):
            errors.append(f"regime 不一致：run={rr.get('regime')} score={sr.get('regime')}")
        _th = sr.get("thresholds") or {}
        miss_th = [k for k in ("p2_up", "p2_new_high", "p3_share_chg_5") if k not in _th]
        if miss_th:
            errors.append(f"score.thresholds 缺 {'、'.join(miss_th)}")
    rs_blend = sum(1 for r in fac_rows.values() if r.get("rs_blend") is not None)
    checks["rs_blend_ratio"] = round(rs_blend / len(fac_rows), 4) if fac_rows else None
    if fac_rows and rs_blend / len(fac_rows) < 0.9:
        warnings.append(f"factors 中 rs_blend 覆盖仅 {rs_blend}/{len(fac_rows)}")

    # 4. 报告契约
    if report:
        try:
            import jsonschema
            schema = json.loads((ROOT / "schema" / "ashare-mainline.schema.json")
                                .read_text(encoding="utf-8"))
            jsonschema.Draft7Validator(schema).validate(report)
            checks["schema"] = "ok"
        except ImportError:
            warnings.append("未安装 jsonschema，跳过 schema 校验")
        except Exception as e:  # noqa: BLE001 - 只要求把错误汇总出来
            errors.append(f"schema: {str(e)[:300]}")

        mainlines = report.get("mainlines") or []
        checks["mainlines"] = len(mainlines)
        if not mainlines:
            errors.append("mainlines 为空")
        sc_by = {r.get("code"): r for r in rows}
        for m in mainlines:
            miss = [k for k in MAINLINE_KEYS if k not in m]
            if miss:
                errors.append(f"{m.get('name')}: 缺字段 {'、'.join(miss)}")
            if not m.get("stage"):
                errors.append(f"{m.get('name')}: mainline.stage=null")
            src = sc_by.get((m.get("sector_codes") or [None])[0])
            if src and abs((src.get("score") or 0) - (m.get("score") or 0)) > 0.011:
                errors.append(f"{m.get('name')}: 报告分 {m.get('score')} != score 缓存 {src.get('score')}")

        dq = report.get("data_quality") or {}
        checks["data_quality_status"] = dq.get("status")
        if not dq.get("sources"):
            errors.append("data_quality.sources 为空")
        if not dq.get("notes"):
            warnings.append("data_quality.notes 为空")
        if dq.get("coverage") is None:
            warnings.append("data_quality.coverage 缺失")

        emerging = (report.get("rotation") or {}).get("emerging") or []
        checks["emerging"] = len(emerging)
        em_names = {e.get("name") for e in emerging}
        main_names = {m.get("name") for m in mainlines}
        for r in rows:
            name = r.get("name")
            if r.get("gates") == 1 and name not in em_names and name not in main_names:
                warnings.append(f"{name}: 1 条闸门但未进 emerging")
            if (r.get("gates") or 0) >= 2 and not r.get("stage") \
                    and name not in em_names and name not in main_names:
                errors.append(f"{name}: 闸门≥2 且 stage=null，但未进 emerging")

        for path, text in _walk_strings(report):
            if PLACEHOLDER.search(text):
                errors.append(f"报告残留占位符 {path}: {text[:60]}")

    # 5. 成品页
    page = ROOT / f"report-{as_of}.html"
    if not page.exists():
        warnings.append(f"缺少 {page.name}（validate 在 embed_report 之前跑时为正常）")
    else:
        html = page.read_text(encoding="utf-8", errors="replace")
        checks["report_kb"] = round(len(html.encode("utf-8")) / 1024)
        if "const EMBEDDED" not in html:
            errors.append("成品页缺 EMBEDDED 块")
        if f"aml-report-{as_of}" not in html:
            errors.append("成品页 STORAGE_KEY 不是当期日期")
        if len(html.encode("utf-8")) < 100 * 1024:
            warnings.append("成品页小于 100KB，可能未完整嵌入")

    return {"as_of": as_of, "ok": not errors, "errors": errors,
            "warnings": warnings, "checks": checks}


def main() -> int:
    ap = argparse.ArgumentParser(description="主线报告发布前校验")
    day.add_as_of(ap)
    args = ap.parse_args()
    as_of = day.resolve(args.as_of)
    out = validate(as_of)
    cacheio.write_json(C / f"validate-{as_of}.json", out)

    status = "ok" if out["ok"] else "FAIL"
    print(f"发布前校验 {as_of}：{status}（{len(out['errors'])} errors / {len(out['warnings'])} warnings）")
    for e in out["errors"]:
        print(f"  [error] {e}")
    for w in out["warnings"]:
        print(f"  [warn] {w}")
    print(f"  checks: {json.dumps(out['checks'], ensure_ascii=False)}")
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

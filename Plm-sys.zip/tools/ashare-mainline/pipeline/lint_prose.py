"""正文数字校验：抓「板块名 + 分数」「N 因子」这类换榜后最容易残留的过期文案。

背景：11-10 的 `rotation.narrative` 里留着上一期的「影视院线 78.83、游戏Ⅱ 77.03 都停在一条闸门」。
schema 校验不看内容，`None` / 占位符检查也不看数字，这类错误能一路发到页面上。
本模块只做三件可机械判定的事：

1. 板块名后面紧跟的两位小数，若该板块当日有分数，必须等于它的分数（排除百分比 / 金额 / 元等单位）；
2. 「N 因子」的 N 必须等于当日权重表的因子个数（`score.WEIGHTS` 是 5 个，`narrative` 权重为 0 不计入）；
3. 出现在「分」前面的两位小数，必须是当日某个板块的分数。

宁可漏报，不可误报：只报能当场验算的冲突，不做模糊语义判断。

用法：
    python -m pipeline.lint_prose --as-of 2026-11-10
    python -m pipeline.lint_prose --as-of 2026-11-10 --json aml-20261110-v16.json
"""
from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(BASE, "pipeline", "cache")

NUM = re.compile(r"(?<![\d.])(\d{2}\.\d{2})(?![\d])")
# 数字后面跟这些单位，说明它不是「分数」
UNIT_PREFIX = ("%", "pct", "亿", "万", "元", "倍", "家", "只", "条", "天", "日", "个", "级")


def _walk_strings(node, path=""):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from _walk_strings(v, f"{path}.{k}" if path else k)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from _walk_strings(v, f"{path}[{i}]")
    elif isinstance(node, str):
        yield path, node


def _is_unit(tail: str) -> bool:
    t = tail.lstrip()
    return any(t.startswith(u) for u in UNIT_PREFIX)


def _recent_trading_days(as_of: str, n: int = 6, cache_dir: str = CACHE) -> list[str]:
    """取 as_of 及之前最近的 n 个交易日；库不存在时返回空列表（跳过日历校验）。"""
    db = os.path.join(cache_dir, "kline.sqlite")
    if not os.path.exists(db):
        return []
    import sqlite3
    con = sqlite3.connect(db)
    try:
        return [r[0] for r in con.execute(
            "select distinct d from kline where d <= ? order by d desc limit ?", (as_of, n))]
    finally:
        con.close()


def lint(report: dict, cache_dir: str = CACHE) -> tuple[list[str], dict]:
    as_of = report["meta"]["as_of"]
    with io.open(os.path.join(cache_dir, f"score-{as_of}.json"), encoding="utf-8") as f:
        scores = {r["name"]: round(r["score"], 2) for r in json.load(f)["rows"]}
    with io.open(os.path.join(cache_dir, f"factors-{as_of}.json"), encoding="utf-8") as f:
        board_names = sorted({v["name"] for v in json.load(f)["rows"].values()},
                             key=len, reverse=True)
    from pipeline.score import WEIGHTS  # 延迟导入：score 会读缓存，放函数里避免启动即 IO

    score_values = set(scores.values())
    problems: list[str] = []
    stats = {"strings": 0, "board_hits": 0, "factor_claims": 0,
             "timeline": len((report.get("rotation") or {}).get("timeline") or [])}

    for path, text in _walk_strings(report):
        stats["strings"] += 1
        for name in board_names:
            if name not in text:
                continue
            for m in re.finditer(re.escape(name), text):
                tail = text[m.end():m.end() + 16]
                nm = NUM.search(tail)
                if not nm or _is_unit(tail[nm.end():]):
                    continue
                # 形如「游戏Ⅱ）~ +14.18（数字媒体）」的分数变动区间：数字属于相邻的另一个板块，
                # 不是这个板块的分数，跳过。判据是数字前面出现右括号或正负号/波浪号。
                before = tail[:nm.start()]
                if "）" in before or re.search(r"[+\-−~到约]\s*$", before):
                    continue
                # 显式写明「上一期 / 上期 / 前值」的分数是历史对照，不是当期断言。
                # 换榜后与上一期比名次、比分数是正文里最正常的一类表述，不能一律按残留处理。
                if re.search(r"(上一期|上期|前值|此前|当时)[^，。；]{0,6}$", before):
                    continue
                expect = scores.get(name)
                if expect is None:
                    continue
                stats["board_hits"] += 1
                got = round(float(nm.group(1)), 2)
                if got != expect:
                    problems.append(
                        f"[分数不符] {path}：{name} 后面写 {got}，当日实际 {expect}")

        for m in re.finditer(r"([一二三四五六七八九十]|\d+)\s*因子", text):
            # 「其余四因子」「其他三因子」是相对表述（breadth 用 123 板块、其余四个用 128），
            # 不是「共 N 个因子」的断言，跳过，否则会误报。
            if re.search(r"(其余|其他|剩下|另外|除此之外)[^，。；]{0,4}$", text[:m.start()]):
                continue
            stats["factor_claims"] += 1
            cn = m.group(1)
            n = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8}.get(
                cn, int(cn) if cn.isdigit() else 0)
            if n != len(WEIGHTS):
                problems.append(
                    f"[因子数不符] {path}：「{m.group(0)}」写成 {n}，权重表实际 {len(WEIGHTS)} 个"
                    f"（{'、'.join(WEIGHTS)}）")

        for m in re.finditer(r"(\d{2}\.\d{2})\s*分", text):
            got = round(float(m.group(1)), 2)
            # 「+15.66 分」「−5.04 分」是本期与上一期的差值，不是某个板块的分数
            if text[max(0, m.start() - 1):m.start()] in "+-−":
                continue
            if got not in score_values:
                problems.append(f"[孤立分数] {path}：{got} 分 不在当日任何板块的分数里")

        # 规则 4：timeline 的日期必须落在最近 6 个交易日里
        # 复制上一期的 timeline 时，字符串里的板块名+分数可能都对得上，只有日期是旧的。
    recent = _recent_trading_days(as_of, 6, cache_dir)
    if recent:
        for i, ev in enumerate((report.get("rotation") or {}).get("timeline") or []):
            d = ev.get("date")
            if d and d not in recent:
                problems.append(
                    f"[日期越界] rotation.timeline[{i}]：{d} 不在最近 6 个交易日"
                    f"（{recent[0]} ~ {recent[-1]}）")

    return problems, stats


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="正文数字校验：板块名+分数、N 因子、孤立分数")
    ap.add_argument("--as-of", required=True)
    ap.add_argument("--json", help="默认 aml-<YYYYMMDD>-v16.json")
    args = ap.parse_args(argv)

    sys.path.insert(0, BASE)
    path = args.json or os.path.join(BASE, f"aml-{args.as_of.replace('-', '')}-v16.json")
    with io.open(path, encoding="utf-8") as f:
        report = json.load(f)

    problems, stats = lint(report)
    print(f"扫描 {stats['strings']} 段文本、{stats['board_hits']} 处「板块名+数字」、"
          f"{stats['factor_claims']} 处「N 因子」、timeline {stats.get('timeline', 0)} 条")
    if not problems:
        print("正文数字校验：通过（无过期分数、无孤立分数、因子数一致、timeline 日期在窗口内）")
        return 0
    print(f"发现 {len(problems)} 处：")
    for p in problems:
        print("  " + p)
    return 1


if __name__ == "__main__":
    sys.exit(main())

"""板块面板：涨跌幅 / 资金流 / 成交额（真值优先）/ 份额分位。

成交额有两个来源，优先真值：

1. **主口径**：`boardkline` 从 push2his 的板块日线直接取成交额（每板块 1 次请求）。
   2026-11-05 实测与「成员股成交额加总」逐位一致（光伏 561.1 亿、半导体 2984.2 亿）。
2. **兜底**：`RPT_INDUSTRY_FUNDFLOW` 只给净额与占比，用「净额 ÷ 占比」在五个分档
   里取中位数反推。正常日 0.00%，但净流入趋近 0 时误差放大——1442 个板块日实测
   中位 0.08% / P90 2.89% / P99 15.07% / 最大 19.2%。

每一行带 `amount_src`（kline / flow），面板汇总两边的计数。份额、Δ5/Δ20、
volume 因子与 P3 闸门（阈值 0.5pct）都建在这个量上，口径必须可追溯。
"""
from __future__ import annotations

import statistics

from . import boardkline
from .http import Client

BASE = "https://datacenter-web.eastmoney.com/api/data/v1/get"
COLS = (
    "BOARD_CODE,BOARD_NAME,TRADE_DATE,CHANGE_RATE,NET_INFLOW,NET_INFLOW_RATIO,"
    "SUPERDEAL_NET,SUPERDEAL_NET_RATIO,BIGDEAL_NET,BIGDEAL_NET_RATIO,"
    "MIDDEAL_NET,MIDDEAL_NET_RATIO,SMALLDEAL_NET,SMALLDEAL_NET_RATIO"
)


def _url(flt: str, page: int = 1, size: int = 500, sort: str = "TRADE_DATE") -> str:
    return (
        f"{BASE}?reportName=RPT_INDUSTRY_FUNDFLOW&columns={COLS}"
        f"&pageNumber={page}&pageSize={size}&sortColumns={sort}&sortTypes=-1"
        f"&filter={flt}"
    )


def amount_from_flow(row: dict) -> float | None:
    """用各档净额 ÷ 占比反推成交额，取中位数（单位：元）。"""
    pairs = [
        (row.get("NET_INFLOW"), row.get("NET_INFLOW_RATIO")),
        (row.get("SUPERDEAL_NET"), row.get("SUPERDEAL_NET_RATIO")),
        (row.get("BIGDEAL_NET"), row.get("BIGDEAL_NET_RATIO")),
        (row.get("MIDDEAL_NET"), row.get("MIDDEAL_NET_RATIO")),
        (row.get("SMALLDEAL_NET"), row.get("SMALLDEAL_NET_RATIO")),
    ]
    vals = []
    for net, ratio in pairs:
        if net is None or ratio is None:
            continue
        try:
            net = float(net)
            ratio = float(ratio)
        except (TypeError, ValueError):
            continue
        if abs(ratio) < 0.05 or net == 0:
            continue
        vals.append(net / (ratio / 100.0))
    if not vals:
        return None
    return statistics.median(vals)


def board_list(client: Client, as_of: str) -> list[dict]:
    """某个交易日有资金流数据的全部板块（一次请求）。"""
    flt = f"(TRADE_DATE%3D%27{as_of}%27)"
    j = client.get_json(_url(flt, size=500, sort="BOARD_CODE"))
    rows = ((j.get("result") or {}).get("data")) or []
    out = []
    for r in rows:
        code = r.get("BOARD_CODE")
        if not code:
            continue
        out.append({
            "code": code,
            "name": r.get("BOARD_NAME"),
            "pct": r.get("CHANGE_RATE"),
            "amount": amount_from_flow(r),
            "net": r.get("NET_INFLOW"),
        })
    return out


def board_history(client: Client, code: str, since: str) -> list[dict] | None:
    """单板块日线（涨跌幅 + 资金流 + 反推成交额），按日期降序。"""
    flt = f"(BOARD_CODE%3D%22{code}%22)(TRADE_DATE%3E%3D%27{since}%27)"
    j = client.get_json(_url(flt, size=500))
    rows = ((j.get("result") or {}).get("data")) or []
    if not rows:
        return None
    out = []
    for r in rows:
        d = str(r.get("TRADE_DATE", ""))[:10]
        if not d:
            continue
        out.append({
            "d": d,
            "pct": r.get("CHANGE_RATE"),
            "amount": amount_from_flow(r),
            "net": r.get("NET_INFLOW"),
        })
    out.sort(key=lambda x: x["d"], reverse=True)
    return out


def build(client: Client, as_of: str, since: str, *, verbose: bool = True) -> dict:
    """拉全样本面板，返回 {boards, by_date, market_amount}。"""
    listed = board_list(client, as_of)
    if verbose:
        print(f"  当日板块 {len(listed)} 个，开始拉历史…")

    codes = [b["code"] for b in listed]
    histories = client.map(lambda c: board_history(client, c, since), codes)
    # 真实成交额：每板块 1 次 push2his（host 限速 2 rps，128 个板块约 64 秒）。
    # 与资金流历史并行拉取，二者按日期对齐；真值缺失时才退回反推。
    klines = client.map(lambda c: boardkline.fetch(client, c), codes)
    # 上游的 TRADE_DATE 过滤只有下限，历史接口没有上限：用 --as-of 回溯历史日时，
    # 每个板块都会带回 as_of 之后的行。必须先按 as_of 截断，否则
    #   ① 「最后一行 == as_of」的现役判定会把所有板块判成停更（直接 RuntimeError）；
    #   ② factors 取 shares[-1] / compound(hist, n) 会读到 as_of 之后的行情（前视偏差）。
    # 当日运行（as_of = 最新交易日）时这一步不改变任何数据。
    histories = [[r for r in h if r["d"] <= as_of] if h else h for h in histories]

    boards, dropped = [], []
    n_kline = n_flow = 0
    for meta, hist, kl in zip(listed, histories, klines):
        if not hist:
            dropped.append(meta["code"])
            continue
        # 按日期对齐真值；kline 也带 as_of 之后的行，同样要截断（与 hist 同因）
        kl = {d: v for d, v in (kl or {}).items() if d <= as_of}
        rows = []
        for r in hist:
            true_amt = (kl.get(r["d"]) or {}).get("amount")
            if true_amt:
                rows.append({**r, "amount": true_amt, "amount_src": "kline",
                             "close": kl[r["d"]].get("close")})
                n_kline += 1
            else:
                rows.append({**r, "amount_src": "flow",
                             "close": (kl.get(r["d"]) or {}).get("close")})
                n_flow += 1
        boards.append({**meta, "hist": rows})

    if not boards:
        raise RuntimeError("面板为空：所有板块历史都拉不到")

    # 停更的判据是「最后一行不在目标日」，不是「行数最短」。
    # 东财 2026-02-13 调整行业分类后，白酒Ⅱ 这类板块的历史只有 169 天，
    # 但它在 10-30 仍有数据，属于现役；食品饮料、煤炭等才是真的不再更新。
    live, stale = [], []
    for b in boards:
        last = b["hist"][0]["d"] if b["hist"] else ""
        (live if last == as_of else stale).append(b)
    if not live:
        raise RuntimeError(f"没有板块在 {as_of} 有数据，检查交易日是否正确")

    spans = sorted(len(b["hist"]) for b in live)
    full_span = spans[-1]
    common_span = spans[max(0, int(len(spans) * 0.1))]
    if verbose:
        print(f"  现役 {len(live)} 个（最长 {full_span} 日 / 共同 {common_span} 日），"
              f"停更 {len(stale)} 个，拉空 {len(dropped)} 个")
        if stale:
            print("  停更：" + "、".join(b["name"] for b in stale[:14]) + ("…" if len(stale) > 14 else ""))
        nk, nf = n_kline, n_flow
        tot = nk + nf
        print(f"  成交额口径：真值 {nk}/{tot} ({nk / tot * 100:.1f}%)，反推兜底 {nf}")
        short = [b["name"] for b in live if len(b["hist"]) <= common_span][:6]
        if short and common_span < full_span:
            print(f"  历史偏短（分类调整前无数据）：{'、'.join(short)}")

    by_date: dict[str, dict[str, dict]] = {}
    history: dict[str, list[tuple[str, float]]] = {}
    for b in live:
        for row in b["hist"]:
            by_date.setdefault(row["d"], {})[b["code"]] = row
        history[b["code"]] = [(r["d"], r["pct"]) for r in reversed(b["hist"]) if r["pct"] is not None]

    market = {}
    for d, m in by_date.items():
        total = sum(v["amount"] for v in m.values() if v.get("amount"))
        market[d] = total or None

    return {
        "as_of": as_of,
        "since": since,
        "span": common_span,
        "span_full": full_span,
        "boards": [{k: v for k, v in b.items() if k != "hist"} | {"bars": len(b["hist"])} for b in live],
        "by_date": by_date,
        "history": history,
        "market_amount": market,
        "amount_src": {"kline": n_kline, "flow": n_flow},
        "dropped": dropped,
        "stale": [b["name"] for b in stale],
    }


def rolling_return(panel: dict, n: int = 20) -> dict[str, dict[str, float]]:
    """每个板块在每个交易日的前 n 日累计涨幅。

    P1 的「进前 10 的天数」是按 **滚动 n 日累计涨幅** 的横截面排名算的，
    不是按当日涨跌幅。当日排名波动太大，白酒 2026-10-28 单日 −2.33% 排全样本末位，
    按当日算不可能「连续 11 天进前 10」。
    """
    out: dict[str, dict[str, float]] = {}
    for code, series in panel.get("history", {}).items():
        asc = series
        if len(asc) < n:
            continue
        acc: dict[str, float] = {}
        for i in range(n - 1, len(asc)):
            prod = 1.0
            for j in range(i - n + 1, i + 1):
                prod *= 1.0 + asc[j][1] / 100.0
            acc[asc[i][0]] = prod - 1.0
        out[code] = acc
    return out


def top_days(panel: dict, code: str, n: int = 20, top: int = 10) -> dict:
    """近 n 个交易日里，该板块滚动 n 日涨幅进入全样本前 top 的天数与连续天数。"""
    roll = panel.get("_roll") or rolling_return(panel)
    panel["_roll"] = roll
    dates = sorted(panel["by_date"], reverse=True)[:n]
    hits = streak = 0
    broken = False
    for d in dates:
        board = {c: acc[d] for c, acc in roll.items() if d in acc}
        if not board:
            continue
        ranked = sorted(board.items(), key=lambda x: x[1], reverse=True)
        in_top = code in {c for c, _ in ranked[:top]}
        if in_top:
            hits += 1
            if not broken:
                streak += 1
        else:
            broken = True
    return {"days_top10_20": hits, "consecutive_top10": streak}


def share_series(panel: dict, code: str, market_scale: float = 1.0) -> list[tuple[str, float]]:
    """单板块的成交额份额序列（分母为当日全市场，按 market_scale 校准）。"""
    out = []
    for d, m in panel["by_date"].items():
        total = panel["market_amount"].get(d)
        row = m.get(code)
        if not total or not row or not row.get("amount"):
            continue
        out.append((d, row["amount"] / (total * market_scale)))
    out.sort()
    return out


SHARE_WINDOW = 250
# 分位窗口最多 250 日，不足 250 日按实际样本算并降级披露；但少于半年（120 日）的
# 样本谈不上「年度高位」，P3 不采用。run / factors / score / daily 共用这一处下限。
SHARE_MIN_SAMPLES = 120


def p3_pass(share_chg_5, share_pct_250, samples, min_chg: float) -> bool:
    """P3 闸门唯一实现：份额 Δ5 + 分位，并检查分位样本长度。

    samples 为 None（旧缓存没有该字段）时不施加下限，保证历史期数可复算；
    新缓存一定带 samples。0.60 分位阈值固定，属于跨 regime 不变的结构量。
    """
    if samples is not None and samples < SHARE_MIN_SAMPLES:
        return False
    return (share_chg_5 or 0) >= min_chg and (share_pct_250 or 0) >= 0.60


def share_stats(panel: dict, code: str, window: int = SHARE_WINDOW) -> dict:
    """份额现值 / 5 日与 20 日变化 / 250 日分位。**唯一实现**。

    这个量被三处用到：run 的 P3 闸门、factors 的横截面因子、build_v16 的文案。
    原先是 run.p3_metrics 与 factors 各写一遍，两边都自认为对——本轮改窗口口径时
    正是靠「只改一处、另一处不动」才暴露出分叉（run 判 0.5839 不过闸门、factors 判
    0.6160 过闸门，同一只板块在同一天同时是「候选」和「非候选」）。所以收敛到这里。

    window 固定为 250：字段名、闸门文案、glossary 都是「250 日分位」，用「全部可得
    交易日」会让同一个份额值随着历史变长而落到不同分位，跨日不可比。样本不足 250 日
    的板块（本期 173~249 日）按实际样本算，调用方读 samples 自行披露。
    """
    series = share_series(panel, code)
    shares = [v for _, v in series]
    if not shares:
        return {"share": None, "share_chg_5": None, "share_chg_20": None,
                "share_pct_250": None, "samples": 0}
    cur = shares[-1]
    win = shares[-window:] if len(shares) > window else shares
    return {
        "share": round(cur, 6),
        "share_chg_5": round(cur - shares[-6], 6) if len(shares) >= 6 else None,
        "share_chg_20": round(cur - shares[-21], 6) if len(shares) >= 21 else None,
        "share_pct_250": round(sum(1 for x in win if x <= cur) / len(win), 4),
        "samples": len(shares),
    }

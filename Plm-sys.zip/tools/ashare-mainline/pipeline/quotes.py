"""腾讯批量报价。

qt.gtimg.cn 支持一次查 60~120 只（实测 120 只 0.24s）。这是替代「逐只拉 K 线」的关键：
232 只成分股从 232 次请求压到 4 次。

字段索引（2026-11-01 实测校准，左闭右开按 '~' 切分）：
    1 名称  2 代码  3 现价  4 昨收  5 今开  6 成交量(手)
    30 时间戳 YYYYMMDDHHMMSS  31 涨跌额  32 涨跌%
    33 最高  34 最低  36 成交量(手)  37 成交额(万元)
    38 换手率  39 PE(TTM)  44 总市值(亿)  45 流通市值(亿)
    46 PB  47 涨停价  48 跌停价  49 量比
"""
from __future__ import annotations

import json
from pathlib import Path

from .http import Client

BATCH = 60
F = {
    "name": 1, "code": 2, "price": 3, "prev_close": 4, "open": 5,
    "time": 30, "chg": 31, "chg_pct": 32, "high": 33, "low": 34,
    "vol": 36, "amount_wan": 37, "turnover": 38, "pe": 39,
    "mktcap_yi": 44, "float_cap_yi": 45, "pb": 46,
    "limit_up": 47, "limit_down": 48, "vol_ratio": 49,
}


def to_symbol(code: str) -> str:
    if code.startswith("6"):
        return "sh" + code
    if code[0] in "03":
        return "sz" + code
    return "bj" + code


def _num(s: str) -> float | None:
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def parse(body: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for seg in body.split(";"):
        seg = seg.strip()
        if not seg.startswith("v_") or '"' not in seg:
            continue
        payload = seg.split('"')[1]
        f = payload.split("~")
        if len(f) < 50:
            continue
        code = f[F["code"]]
        if len(code) != 6:
            continue
        price = _num(f[F["price"]])
        if price is None:
            continue
        out[code] = {
            "code": code,
            "name": f[F["name"]].replace(" ", ""),
            "price": price,
            "prev_close": _num(f[F["prev_close"]]),
            "chg": _num(f[F["chg"]]),
            "chg_pct": (_num(f[F["chg_pct"]]) or 0.0) / 100.0,
            "high": _num(f[F["high"]]),
            "low": _num(f[F["low"]]),
            "amount_yi": round((_num(f[F["amount_wan"]]) or 0.0) / 1e4, 4),
            "turnover": _num(f[F["turnover"]]),
            "pe": _num(f[F["pe"]]),
            "mktcap_yi": _num(f[F["mktcap_yi"]]),
            "pb": _num(f[F["pb"]]),
            "limit_up": _num(f[F["limit_up"]]),
            "limit_down": _num(f[F["limit_down"]]),
            "vol_ratio": _num(f[F["vol_ratio"]]),
            "ts": f[F["time"]],
            "suspended": price <= 0,
        }
    return out


def fetch(client: Client, codes: list[str]) -> dict[str, dict]:
    """按 60 只一批拉全量报价，返回 {6 位代码: 报价}。"""
    syms = [to_symbol(c) for c in codes]
    batches = [syms[i:i + BATCH] for i in range(0, len(syms), BATCH)]

    def one(group: list[str]) -> dict[str, dict]:
        url = "https://qt.gtimg.cn/q=" + ",".join(group)
        return parse(client.get(url, encoding="gbk", retries=2))

    merged: dict[str, dict] = {}
    for part in client.map(one, batches):
        if part:
            merged.update(part)
    return merged


def trade_date(quotes: dict[str, dict]) -> str | None:
    """从报价时间戳里取交易日 YYYY-MM-DD。"""
    for q in quotes.values():
        ts = q.get("ts") or ""
        if len(ts) >= 8:
            return f"{ts[:4]}-{ts[4:6]}-{ts[6:8]}"
    return None


def load(cache_dir: str | Path, as_of: str) -> tuple[dict, str | None]:
    """读 quotes-<as_of>.json，返回 (快照, 快照本身的交易日)。

    文件名里的 as_of 是**这份快照供哪一天的分析使用**，不是快照自身的交易日。
    两者本应相等，但回溯历史日时上游只给「最新」报价（跑 --as-of 2026-10-30 拿到的
    是 11-05 的成交额），历史版本会照样写成 quotes-2026-10-30.json。后果不是数字难看，
    而是静默选错票：score.leader_chg5 与 build_v16 的龙头梯队都按 amount_yi 排序，
    用 11-05 的成交额去选 10-30 的龙头，选出来的可能压根不在当天的领涨名单里。

    现在由 save() 守写入端，文件名与内容不会再分叉；读取端仍返回快照交易日，
    让调用方能判断这份快照是不是本日的（返回 None 表示文件不存在）。
    """
    p = Path(cache_dir) / f"quotes-{as_of}.json"
    if not p.exists():
        return {}, None
    snap = json.loads(p.read_text(encoding="utf-8"))
    return snap, trade_date(snap)


def save(cache_dir: str | Path, as_of: str, snap: dict) -> tuple[bool, str | None]:
    """落盘快照，返回 (是否写入, 快照交易日)。

    **只写快照交易日 == as_of 的情况。** 回溯时报价是「抓取那一刻的最新」，
    与基准日不同源；写进 quotes-<as_of>.json 会让文件名撒谎，而下游只按文件名取用、
    无从察觉。宁可让当日缓存缺失（回溯时 breadth 走库内复权价、append 直接跳过），
    也不要制造一个看起来像「10-30 快照」的 11-05 文件。
    """
    td = trade_date(snap)
    if td and td != as_of:
        return False, td
    Path(cache_dir, f"quotes-{as_of}.json").write_text(
        json.dumps(snap, ensure_ascii=False), encoding="utf-8")
    return True, td

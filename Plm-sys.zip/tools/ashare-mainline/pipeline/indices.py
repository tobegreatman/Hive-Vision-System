"""宽基指数取数：快照 1 次 + 每指数 1 次日 K。

    python -m pipeline.indices --as-of 2026-10-30

为什么要单独成模块：指数的 1/5/20/60 日收益此前是**硬编码**在 factors.py（IDX_REF）
和 build_report.py（idx 元组）里的常量，来自某一轮人工核对。常量一旦写死，
下一轮无论行情怎么走它都不会变，`rs` 因子的分母就成了假的。

取数成本：8 个指数 = 1 次批量快照 + 8 次日 K，共 9 次请求。
日 K 主源腾讯（web.ifzq.gtimg.cn），被 WAF 拦时自动切东财 push2his；
两源都要求最后一根 K 线日期必须等于 as_of，否则视为陈旧序列、不参与 5/20/60 日计算
（2026-11-06 腾讯日 K 再次被 501，靠这条与东财回退才没有把空值写进当日缓存）。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import day, http  # noqa: E402

CACHE = ROOT / "pipeline" / "cache"

# 报告里要展示的 6 个 + rs 基准（中证全指）。顺序即报告 indices 数组顺序。
INDEX_LIST = [
    ("000001.SH", "上证指数", "sh000001"),
    ("399001.SZ", "深证成指", "sz399001"),
    ("399006.SZ", "创业板指", "sz399006"),
    ("000688.SH", "科创50", "sh000688"),
    ("000300.SH", "沪深300", "sh000300"),
    ("000905.SH", "中证500", "sh000905"),
    ("000985.CSI", "中证全指", "sh000985"),
    ("000922.CSI", "中证红利", "sh000922"),
]

KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param={sym},day,,,{n},qfq"
# 东财备用源：1=上交所/中证指数，0=深交所。f53 为收盘价。
EM_KLINE_URL = ("https://push2his.eastmoney.com/api/qt/stock/kline/get?secid={secid}"
                "&fields1=f1,f2,f3&fields2=f51,f52,f53,f54,f55,f56&klt=101&fqt=1&lmt={n}&end=20500101")
EM_SECID = {
    "000001.SH": "1.000001", "399001.SZ": "0.399001", "399006.SZ": "0.399006",
    "000688.SH": "1.000688", "000300.SH": "1.000300", "000905.SH": "1.000905",
    "000985.CSI": "1.000985", "000922.CSI": "1.000922",
}


def _f(x) -> float | None:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def snapshot(client: http.Client) -> dict[str, dict]:
    """一次批量快照：现价、昨收、涨跌幅、成交额（万元）。"""
    syms = ",".join(sym for _, _, sym in INDEX_LIST)
    body = client.get(f"https://qt.gtimg.cn/q={syms}", encoding="gbk", retries=2)
    out: dict[str, dict] = {}
    for seg in body.split(";"):
        seg = seg.strip()
        if not seg.startswith("v_") or '"' not in seg:
            continue
        f = seg.split('"')[1].split("~")
        if len(f) < 50:
            continue
        sym = seg[2:].split("=")[0]
        out[sym] = {
            "price": _f(f[3]),
            "prev_close": _f(f[4]),
            "chg_pct": round((_f(f[32]) or 0.0) / 100.0, 4),
            "amount_yi": round((_f(f[37]) or 0.0) / 1e4, 2),
            "ts": f[30],
        }
    return out


def closes(client: http.Client, sym: str, n: int = 65) -> list[tuple[str, float]]:
    """日 K 收盘序列，升序。复权字段可能叫 qfqday 也可能叫 day（指数无复权）。"""
    j = client.get_json(KLINE_URL.format(sym=sym, n=n), retries=2)
    d = (j.get("data") or {}).get(sym) or {}
    rows = d.get("qfqday") or d.get("day") or []
    out = []
    for r in rows:
        if len(r) >= 3:
            c = _f(r[2])
            if c:
                out.append((r[0], c))
    out.sort()
    return out


def closes_em(client: http.Client, code: str, n: int = 65) -> list[tuple[str, float]]:
    """东财备用日 K，升序。klines 每行 `日期,开,收,高,低,量,...`，第 2 项（下标 2）是收盘。"""
    secid = EM_SECID.get(code)
    if not secid:
        return []
    j = client.get_json(EM_KLINE_URL.format(secid=secid, n=n), retries=1)
    rows = ((j.get("data") or {}).get("klines") or [])
    out = []
    for r in rows:
        parts = r.split(",") if isinstance(r, str) else r
        if len(parts) >= 3:
            c = _f(parts[2])
            if c:
                out.append((parts[0], c))
    out.sort()
    return out


def ret(series: list[tuple[str, float]], n: int) -> float | None:
    """最近 n 个交易日的复合收益；不足 n+1 根返回 None。"""
    if len(series) < n + 1:
        return None
    return round(series[-1][1] / series[-(n + 1)][1] - 1, 4)


def build(client: http.Client, as_of: str) -> dict:
    snap = snapshot(client)
    rows, errors = [], []
    for code, name, sym in INDEX_LIST:
        s = snap.get(sym) or {}
        ser: list[tuple[str, float]] = []
        src = None
        # 主源腾讯、备源东财。任一源返回的序列都必须有一根 as_of 当日的 K 线：
        # 停牌、源延迟或返回上一交易日时，末根日期会小于 as_of，此时把它当「今天」去算
        # 5/20/60 日，等于用昨天的收盘冒充今天，而且全程不报错。宁可当作缺失。
        for source, fetch in (("tencent", lambda: closes(client, sym)),
                              ("eastmoney", lambda: closes_em(client, code))):
            try:
                cand = fetch()
            except Exception as e:  # noqa: BLE001
                errors.append(f"{name} 日K({source})失败：{type(e).__name__}")
                continue
            if not cand:
                errors.append(f"{name} 日K({source})为空")
                continue
            if cand[-1][0] != as_of:
                errors.append(f"{name} 日K({source})末根 {cand[-1][0]} ≠ {as_of}，视为陈旧")
                continue
            ser, src = cand, source
            break
        if not ser:
            errors.append(f"{name} 无可用日K")
        rows.append({
            "code": code, "name": name, "symbol": sym,
            "trade_date": ser[-1][0] if ser else None,
            "close": s.get("price") if s.get("price") else (ser[-1][1] if ser else None),
            "chg_1d": s.get("chg_pct"),
            "chg_5d": ret(ser, 5), "chg_20d": ret(ser, 20), "chg_60d": ret(ser, 60),
            "turnover_yi": s.get("amount_yi"),
            "bars": len(ser), "kline_source": src,
        })
    return {"as_of": as_of, "snapshot_ts": next((v.get("ts") for v in snap.values()), None),
            "indices": rows, "errors": errors}


def load(as_of: str) -> dict | None:
    p = CACHE / f"indices-{as_of}.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return None


def refuse_overwrite(d: dict, prev: dict | None) -> tuple[bool, str]:
    """本轮结果是否该拒绝覆盖磁盘上的旧文件。返回 (拒绝?, 原因)。

    判据只有一个：**中证全指**（000985）的 20 日涨幅。它是 factors 的基准，
    rs = (1+板块 20 日) ÷ (1+基准 20 日)；缺了会让 factors 回落到 FALLBACK_IDX_REF
    （10-30 的常量，20 日 −14.44%，当日真实值 −6.26%），128 个板块的 rs 与全部分数一起偏。

    其它 7 个指数缺了只是表格难看，不值得为它拒绝一份可用的数据；中证全指缺了不行。
    """
    base = next((r for r in d.get("indices", [])
                 if str(r.get("code", "")).startswith("000985")), None)
    if base and base.get("chg_20d") is not None:
        return False, ""
    prev_base = next((r for r in (prev or {}).get("indices", [])
                      if str(r.get("code", "")).startswith("000985")), None)
    if prev_base and prev_base.get("chg_20d") is not None:
        return True, (f"中证全指 20 日涨幅取不到，磁盘上已有 "
                      f"{prev_base['chg_20d'] * 100:+.2f}%")
    return False, ""


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--rps", type=float, default=3.0)
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)

    # 8 个请求不值得起并发；2 workers 让快照与日 K 能小范围重叠，仍受全局 2 rps 约束。
    cli = http.make_client(workers=2, max_rps=min(args.rps, 2.0), min_span=0,
                           jitter=(0.25, 0.55))
    try:
        d = build(cli, args.as_of)
    except http.EndpointBlocked as e:
        print(f"  指数接口被拒，保留上一轮留存值：{e}")
        return 3

    # 写入端守卫：中证全指是 factors 的基准（rs = (1+板块 20 日) ÷ (1+基准 20 日)），
    # 它取不到时 factors 会回落到 FALLBACK_IDX_REF —— 那是 10-30 的常量，20 日 −14.44%，
    # 而当日真实值是 −6.26%。基准一错，128 个板块的 rs 与全部分数会一起偏，
    # 且 daily 仍然返回 0（看起来跑成功了）。
    #
    # 这个降级是静默的：build() 对每只指数都 try/except 兜住，EndpointBlocked 只在 errors
    # 里留一行，main 看不到异常就会拿「收盘价有、涨幅全 null」的结果覆盖上一轮的好数据。
    # 2026-11-05 连续第三次重跑时实测触发（腾讯日 K 被 WAF 拦），所以在这里拦住。
    refuse, why = refuse_overwrite(d, load(args.as_of))
    if refuse:
        print(f"  ⚠ {why}，拒绝覆盖（{len(d['errors'])} 个错误）")
        for e in d["errors"][:4]:
            print(f"    {e}")
        return 3
    base_row = next((r for r in d["indices"] if str(r["code"]).startswith("000985")), None)
    if base_row is None or base_row["chg_20d"] is None:
        print("  ⚠ 中证全指 20 日涨幅取不到，且无历史留存值——下游 factors 将回落常量基准")

    dest = CACHE / f"indices-{args.as_of}.json"
    dest.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"  {'指数':<10}{'收盘':>10}{'1日':>9}{'5日':>9}{'20日':>9}{'60日':>9}{'成交额亿':>10}  日K")
    for r in d["indices"]:
        def p(v):
            return "null" if v is None else f"{v * 100:+.2f}%"
        src = {"tencent": "TX", "eastmoney": "EM"}.get(r.get("kline_source") or "", "-")
        print(f"  {r['name']:<10}{(r['close'] or 0):>10.2f}{p(r['chg_1d']):>9}{p(r['chg_5d']):>9}"
              f"{p(r['chg_20d']):>9}{p(r['chg_60d']):>9}{(r['turnover_yi'] or 0):>10.1f}"
              f"{r['bars']:>5} {src}")
    if d["errors"]:
        print("  ⚠", "；".join(d["errors"]))
    print(f"  快照时间戳 {d['snapshot_ts']} | 请求 {cli.stats.ok} 次 / 失败 {cli.stats.failed}")
    print(f"  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

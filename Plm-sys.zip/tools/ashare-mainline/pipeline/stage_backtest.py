"""P0 阶段诊断回测。

    python -m pipeline.stage_backtest --as-of 2026-11-09

只回答两个问题，不改线上判定：

1. **全量判据**：在已有 score 缓存上，按「当日有无涨停」分组，比较 stage 覆盖率、
   闸门 ≥2 但 stage 为空的比例，以及六阶段最高命中数的分布。
   这一组样本只有最近 7 个交易日，属于描述性证据，不作统计结论。

2. **面板可测判据**：用 panel 的 175 日板块日线，复现不依赖广度/涨停/封板的判据
   （份额、Δ5/Δ20、5/20 日涨幅、拥挤度、前 10 天数），按「命中 ≥2 项」判阶段，
   再看未来 5/20 日超额收益与 20 日最大回撤。
   历史广度/涨停/封板/龙头没有落盘，所以 fade 与 expansion 在这一层不可判定，
   只能验证 divergence / acceleration / trend / ignition 四个阶段是否有区分度。

结论只作 P0 基线：不是 2~3 年验证，也不是上线依据。
"""
from __future__ import annotations

import argparse
import json
import pickle
import statistics
import sys
from collections import Counter
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import day  # noqa: E402

CACHE = ROOT / "pipeline" / "cache"
STAGES = ("fade", "divergence", "acceleration", "expansion", "trend", "ignition")
STAGE_REQUIRED = 2
FORWARD = (5, 20)


def _rank(values: list[float], v: float | None) -> float | None:
    vals = [x for x in values if x is not None]
    if v is None or not vals:
        return None
    return round((sum(1 for x in vals if x < v) + 1) / len(vals) * 100, 2)


def _mean(vals: list[float]) -> float | None:
    return round(statistics.fmean(vals), 4) if vals else None


def _median(vals: list[float]) -> float | None:
    return round(statistics.median(vals), 4) if vals else None


def _stats(records: list[dict]) -> dict:
    """前向收益汇总。excess 为相对当日全板块等权平均的超额。"""
    out = {"n": len(records)}
    for h in FORWARD:
        vals = [r[f"excess{h}"] for r in records if r.get(f"excess{h}") is not None]
        out[f"excess{h}_mean"] = _mean(vals)
        out[f"excess{h}_median"] = _median(vals)
        out[f"excess{h}_win"] = round(sum(1 for x in vals if x > 0) / len(vals), 4) if vals else None
    dd = [r["mdd20"] for r in records if r.get("mdd20") is not None]
    out["mdd20_mean"] = _mean(dd)
    out["mdd20_median"] = _median(dd)
    return out


def _latest_panel(as_of: str | None) -> tuple[dict, Path]:
    files = sorted(CACHE.glob("panel-*.pkl"))
    if not files:
        raise SystemExit("没有 panel-*.pkl")
    p = CACHE / f"panel-{as_of}.pkl" if as_of else files[-1]
    if not p.exists():
        raise SystemExit(f"找不到 {p.name}")
    return pickle.loads(p.read_bytes()), p


def _full_rule() -> dict:
    """全量判据：按当日有无涨停分组，比较 stage 可判定性。"""
    groups = {
        "no_limit_up": {"n": 0, "gates2": 0, "assigned": 0, "stage_none_2g": 0,
                        "max_hits": Counter(), "gates2_max_hits": Counter(),
                        "stages": Counter(), "stage_none_2g_names": []},
        "has_limit_up": {"n": 0, "gates2": 0, "assigned": 0, "stage_none_2g": 0,
                         "max_hits": Counter(), "gates2_max_hits": Counter(),
                         "stages": Counter(), "stage_none_2g_names": []},
    }
    by_date = []
    dates = []
    for f in sorted(CACHE.glob("score-*.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        day_key = d.get("as_of") or f.stem.split("-", 1)[1]
        dates.append(day_key)
        snap = {"date": day_key, "no_limit_up": {"n": 0, "gates2": 0, "assigned": 0, "stage_none_2g": 0},
                "has_limit_up": {"n": 0, "gates2": 0, "assigned": 0, "stage_none_2g": 0}}
        for r in d.get("rows") or []:
            pool = r.get("pool") or {}
            key = "no_limit_up" if (pool.get("limit_up_count") or 0) == 0 else "has_limit_up"
            g = groups[key]
            s = snap[key]
            g["n"] += 1
            s["n"] += 1
            gates = r.get("gates") or 0
            if gates >= 2:
                g["gates2"] += 1
                s["gates2"] += 1
            stage = r.get("stage")
            if stage:
                g["assigned"] += 1
                g["stages"][stage] += 1
                s["assigned"] += 1
            elif gates >= 2:
                g["stage_none_2g"] += 1
                g["stage_none_2g_names"].append(f"{day_key}:{r.get('name')}")
                s["stage_none_2g"] += 1
            crit = r.get("crit") or {}
            max_hits = r.get("stage_max_hits")
            if max_hits is None and crit:
                max_hits = max(sum(1 for item in v if item[1]) for v in crit.values())
            g["max_hits"][str(max_hits or 0)] += 1
            if gates >= 2:
                g["gates2_max_hits"][str(max_hits or 0)] += 1
        by_date.append(snap)

    for g in groups.values():
        g["stage_coverage"] = round(g["assigned"] / g["n"], 4) if g["n"] else None
        g["stage_coverage_of_gates2"] = round(g["assigned"] / g["gates2"], 4) if g["gates2"] else None
        g["stage_none_2g_rate"] = round(g["stage_none_2g"] / g["gates2"], 4) if g["gates2"] else None
        g["max_hits"] = dict(sorted(g["max_hits"].items()))
        g["gates2_max_hits"] = dict(sorted(g["gates2_max_hits"].items()))
        g["stages"] = dict(g["stages"].most_common())
    return {
        "dates": dates,
        "groups": groups,
        "by_date": by_date,
        "note": "全量判据样本仅最近 7 个交易日，且跨 v1.6~v1.9 广度口径，只作描述性对照；不据此下统计结论。",
    }


def _panel_series(p: dict) -> tuple[list[str], dict[str, list[dict]]]:
    dates = sorted(p["by_date"])
    series: dict[str, list[dict]] = {}
    for b in p["boards"]:
        code = b["code"]
        rows = []
        for d in dates:
            r = p["by_date"][d].get(code)
            if not r:
                continue
            close, amount = r.get("close"), r.get("amount")
            if close is None or amount is None:
                continue
            rows.append({"d": d, "close": float(close), "amount": float(amount), "net": r.get("net")})
        if rows:
            series[code] = rows
    return dates, series


def _panel_backtest(p: dict) -> dict:
    dates, series = _panel_series(p)
    didx = {d: i for i, d in enumerate(dates)}

    # 每个板块按全局交易日对齐，避免用「第 i-5 行」代替「5 个交易日前」。
    by_d: dict[str, dict[str, dict]] = {}
    for code, rows in series.items():
        rows.sort(key=lambda x: x["d"])
        by_d[code] = {r["d"]: r for r in rows}
        shares = []
        for r in rows:
            gi = didx[r["d"]]
            total = p["market_amount"].get(r["d"])
            r["share"] = r["amount"] / total if total else None
            for n, key in ((5, "chg5"), (20, "chg20"), (60, "chg60")):
                prev = by_d[code].get(dates[gi - n]) if gi >= n else None
                r[key] = r["close"] / prev["close"] - 1 if prev and prev.get("close") else None
            r["roll20"] = r["chg20"]
            if r["share"] is not None:
                shares.append((r["d"], r["share"]))
            # 份额统计只用该板块自己已有的份额序列；样本不足 60 日不给分位。
            cur = r["share"]
            if cur is not None and len(shares) >= 60:
                win = [x for _, x in shares[-250:]]
                r["share_pct"] = round(sum(1 for x in win if x <= cur) / len(win), 4)
            else:
                r["share_pct"] = None
            prev5 = by_d[code].get(dates[gi - 5]) if gi >= 5 else None
            prev20 = by_d[code].get(dates[gi - 20]) if gi >= 20 else None
            r["d5"] = round(cur - prev5["share"], 6) if cur is not None and prev5 and prev5.get("share") is not None else None
            r["d20"] = round(cur - prev20["share"], 6) if cur is not None and prev20 and prev20.get("share") is not None else None
            window = [by_d[code].get(dates[j]) for j in range(max(0, gi - 4), gi + 1)]
            if len(window) == 5 and all(x and x.get("net") is not None and x.get("amount") for x in window):
                r["flow5"] = round(sum(x["net"] for x in window) / sum(x["amount"] for x in window), 5)
            else:
                r["flow5"] = None

    # 横截面：20 日涨幅分位、滚 20 日涨幅前 10、拥挤度。
    top10: dict[str, set[str]] = {}
    for d in dates:
        vals = {c: row["chg20"] for c, row in ((c, by_d[c].get(d)) for c in by_d)
                if row and row.get("chg20") is not None}
        ranked = sorted(vals.items(), key=lambda kv: kv[1], reverse=True)
        top10[d] = {c for c, _ in ranked[:10]}
        for c, v in vals.items():
            by_d[c][d]["chg20_rank"] = _rank(list(vals.values()), v)
    for c, rows in by_d.items():
        for r in rows.values():
            if r.get("share_pct") is None or r.get("chg20_rank") is None:
                r["crowding"] = None
            else:
                r["crowding"] = round(0.5 * r["share_pct"] + 0.5 * r["chg20_rank"] / 100, 4)
        for r in rows.values():
            gi = didx[r["d"]]
            hits = streak = 0
            broken = False
            for j in range(max(0, gi - 19), gi + 1):
                if c in top10.get(dates[j], set()):
                    hits += 1
                    if not broken:
                        streak += 1
                else:
                    broken = True
            r["days_top10_20"] = hits
            r["consecutive_top10"] = streak

    # 面板能复现的判据；缺失项不参与命中，也不参与分母。
    def panel_criteria(r: dict) -> dict[str, list[tuple[str, bool, bool]]]:
        return {
            "fade": [
                ("份额 Δ20 < −0.5pct", r["d20"] is not None and r["d20"] < -0.005, r["d20"] is not None),
                ("龙头 5 日跌幅 > 8%", False, False),
                ("上涨占比 < 45%", False, False),
            ],
            "divergence": [
                ("5 日涨幅 < 20 日涨幅/4",
                 r["chg5"] is not None and r["chg20"] is not None and r["chg5"] < r["chg20"] / 4,
                 r["chg5"] is not None and r["chg20"] is not None),
                ("份额分位 > 0.90", r["share_pct"] is not None and r["share_pct"] > 0.90,
                 r["share_pct"] is not None),
                ("连板回落 ≥ 2 级", False, False),
            ],
            "acceleration": [
                ("20 日涨幅 > 25%", r["chg20"] is not None and r["chg20"] > 0.25, r["chg20"] is not None),
                ("拥挤度 > 0.85", r["crowding"] is not None and r["crowding"] > 0.85, r["crowding"] is not None),
                ("封板率 > 75%", False, False),
            ],
            "expansion": [
                ("份额分位 0.60~0.85", r["share_pct"] is not None and 0.60 <= r["share_pct"] <= 0.85,
                 r["share_pct"] is not None),
                ("涨停 ≥ 5 家", False, False),
                ("连板 3~4 级", False, False),
                ("上涨占比 ≥ 60%", False, False),
            ],
            "trend": [
                ("份额分位 ≥ 0.85", r["share_pct"] is not None and r["share_pct"] >= 0.85,
                 r["share_pct"] is not None),
                ("20 日涨幅 ≥ 8%", r["chg20"] is not None and r["chg20"] >= 0.08, r["chg20"] is not None),
                ("上涨占比 ≥ 70%", False, False),
            ],
            "ignition": [
                ("份额 Δ5 ≥ +0.5pct", r["d5"] is not None and r["d5"] >= 0.005, r["d5"] is not None),
                ("前 10 天数 ≤ 8", r["days_top10_20"] <= 8, True),
                ("涨停 2~5 家", False, False),
            ],
        }

    records = []
    for c, rows in by_d.items():
        for r in rows.values():
            gi = didx[r["d"]]
            fwd = {}
            for h in FORWARD:
                j = gi + h
                nxt = (by_d[c].get(dates[j]) or {}).get("close") if j < len(dates) else None
                fwd[h] = nxt / r["close"] - 1 if nxt is not None else None
            mdd = None
            closes = [(by_d[c].get(dates[j]) or {}).get("close") for j in range(gi + 1, min(gi + 21, len(dates)))]
            if closes and all(x is not None for x in closes):
                mdd = round(min(x / r["close"] - 1 for x in closes), 4)
            ev = panel_criteria(r)
            hits = {s: sum(1 for _, ok, ok_app in v if ok and ok_app) for s, v in ev.items()}
            applicable = {s: sum(1 for _, _, ok_app in v if ok_app) for s, v in ev.items()}
            max_hits = max(hits.values())
            assigned = None
            for s in STAGES:
                if hits[s] >= STAGE_REQUIRED:
                    assigned = s
                    break
            records.append({
                "code": c, "date": r["d"], "stage": assigned, "max_hits": max_hits,
                "hits": hits, "applicable": applicable,
                "fwd5": fwd[5], "fwd20": fwd[20], "mdd20": mdd,
            })

    # 每日基准：当日全板块等权前向收益。
    bench = {}
    for h in FORWARD:
        for d in dates:
            vals = [r[f"fwd{h}"] for r in records if r["date"] == d and r.get(f"fwd{h}") is not None]
            bench[(d, h)] = _mean(vals)
    for r in records:
        for h in FORWARD:
            b = bench.get((r["date"], h))
            r[f"excess{h}"] = round(r[f"fwd{h}"] - b, 4) if r.get(f"fwd{h}") is not None and b is not None else None

    eval_records = [r for r in records if r.get("excess20") is not None]
    assigned_records = [r for r in eval_records if r["stage"]]
    by_stage = {}
    for s in STAGES:
        recs = [r for r in assigned_records if r["stage"] == s]
        if recs:
            by_stage[s] = _stats(recs) | {"insufficient_sample": len(recs) < 30}
    by_hits = {}
    for n in range(0, 4):
        recs = [r for r in eval_records if r["max_hits"] == n]
        if recs:
            by_hits[str(n)] = _stats(recs)

    return {
        "window": {
            "start": min(r["date"] for r in eval_records) if eval_records else None,
            "end": max(r["date"] for r in eval_records) if eval_records else None,
            "days": len({r["date"] for r in eval_records}),
            "boards": len({r["code"] for r in eval_records}),
            "board_days": len(eval_records),
        },
        "coverage": {
            "assigned": len(assigned_records),
            "board_days": len(eval_records),
            "rate": round(len(assigned_records) / len(eval_records), 4) if eval_records else None,
        },
        "stage_counts": dict(Counter(r["stage"] or "none" for r in eval_records).most_common()),
        "baseline": _stats(eval_records),
        "by_stage": by_stage,
        "by_max_hits": by_hits,
        "limitations": [
            "历史广度/涨停/封板/龙头未落盘：fade、expansion 在本层不可判定，只验证 divergence/acceleration/trend/ignition。",
            "panel-only 的 trend 只含份额分位 + 20 日涨幅，不含广度；它的负超额说明这两条不足以单独定义 trend，不等于完整 trend 阶段无效。",
            "by_max_hits 不区分方向：2 项命中可能来自 divergence，也可能来自 trend，不能把命中数直接当强弱排序。",
            "未做涨停倾向分型；机构型与情绪型的覆盖率差异只能看全量判据的 7 日描述。",
            "前向收益为板块收盘价相对当日全板块等权平均，未扣交易成本；20 日回撤为区间最小收盘回撤。",
            "panel 可测窗口 256 日，但历史广度/涨停覆盖不足，不是 2~3 年完整验证；结果只作 P0 基线。",
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--mode", choices=("all", "full", "panel"), default="all")
    args = ap.parse_args()
    as_of = day.resolve(args.as_of)
    panel, panel_path = _latest_panel(args.as_of)

    out = {"as_of": as_of, "panel_file": panel_path.name, "stage_model_version": "p0"}
    if args.mode in ("all", "full"):
        out["full_rule"] = _full_rule()
    if args.mode in ("all", "panel"):
        out["panel_only"] = _panel_backtest(panel)

    dest = CACHE / f"stage-backtest-{as_of}.json"
    dest.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

    print("=" * 72)
    print(f"P0 阶段诊断回测 {as_of}")
    print("=" * 72)
    if "full_rule" in out:
        for key, label in (("no_limit_up", "无涨停"), ("has_limit_up", "有涨停")):
            g = out["full_rule"]["groups"][key]
            print(f"  全量判据 {label:<4} n={g['n']:<4} 闸门≥2={g['gates2']:<3} "
                  f"stage覆盖={g['stage_coverage']} 闸门≥2后stage覆盖={g['stage_coverage_of_gates2']} "
                  f"闸门≥2但stage空={g['stage_none_2g']} 最高命中={g['max_hits']}")
            print(f"    闸门≥2的最高命中={g['gates2_max_hits']} stage空={g['stage_none_2g_names']}")
    if "panel_only" in out:
        p = out["panel_only"]
        print(f"  面板可测判据 {p['window']['start']}~{p['window']['end']} "
              f"{p['window']['days']} 日 / {p['window']['board_days']} 板块日，"
              f"stage 覆盖={p['coverage']['rate']}")
        for s, v in p["by_stage"].items():
            print(f"    {s:<12} n={v['n']:<4} 超额5={v['excess5_mean']} 超额20={v['excess20_mean']} "
                  f"胜率20={v['excess20_win']} 回撤20={v['mdd20_mean']}"
                  f"{' [样本不足]' if v['insufficient_sample'] else ''}")
    print(f"  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""缓存契约：原子写、规则版本、输入指纹。

为什么需要这一层：

1. 2026-11-09 做阶段回测时，同一批 `score-*.json` 里混着 v1.6~v1.9 的口径，
   文件本身没有规则版本，只能靠时间猜。下游拿到旧缓存时不会报错，只会悄悄算错。
2. 旧实现用 `write_text`/`write_bytes` 直接覆盖，进程中断会留下半截 JSON 或 pkl；
   第二天读到的是"文件存在但内容不完整"，报错位置离真正原因很远。
3. `as_of` 只写在文件内容里，下游读取时没有统一校验；复制/改名/跨日重跑都可能错配。

约定：

- 只给 **dict 型缓存** 加 `_meta`；list 型缓存（`codes-*.json`）保持原形，
  避免消费端 `for code in data` 时多出一项。
- `_meta` 缺失视为旧缓存：默认告警并继续，便于回看历史；新写入必须带 `_meta`。
- `as_of` 不一致直接抛 `CacheMismatch`；`rule_version` 不一致由调用方用
  `expect_rule` 决定是否阻断。规则版本是"可追溯"，不是每次改代码都全量失效。
"""
from __future__ import annotations

import json
import os
import pickle
import time
from pathlib import Path
from typing import Any

META = "_meta"

# 各环节的规则版本。改动了对应环节的判据/口径时手动 bump，
# 这样回测能按版本筛样本，下游也能在发现版本不符时给出明确提示。
PANEL_RULE = "panel-v1"
RUN_RULE = "run-v2"            # P1：闸门阈值随 regime 变，run 落 regime 与当期阈值
FACTORS_RULE = "factors-v2"    # P1：rs 改为 20/60/跑赢天数三周期合成
BREADTH_RULE = "boardbreadth-v1"
EXTRA_RULE = "extra-v1"
REGIME_RULE = "regime-v1"
UNIVERSE_RULE = "universe-v1"  # P2：板块清单快照 + 生存偏差锚点
SCORE_RULE = "score-p1-v1"     # P1：rs 合成 + regime 阈值
SHADOW_RULE = "p1-draft-2026-11-10"


class CacheMismatch(RuntimeError):
    """缓存与当前请求/规则不匹配。"""


def fingerprint(path: Path) -> dict:
    st = path.stat()
    return {"name": path.name, "bytes": st.st_size, "mtime": int(st.st_mtime)}


def make_meta(as_of: str, rule_version: str, inputs: dict[str, Path] | None = None,
              **extra: Any) -> dict:
    """生成统一的缓存元信息。inputs 只记录存在的文件，避免把缺失当成指纹。"""
    return {
        "as_of": as_of,
        "rule_version": rule_version,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "inputs": {k: fingerprint(p) for k, p in (inputs or {}).items() if p.exists()},
        **extra,
    }


def check_meta(obj: dict, label: str, *, as_of: str | None = None,
               expect_rule: str | None = None, allow_legacy: bool = True) -> list[str]:
    """校验缓存元信息。

    - 无 `_meta`：旧缓存，默认返回告警；`allow_legacy=False` 时抛错。
    - `as_of` 不一致：直接抛错，这是跨日错配，不能继续。
    - `expect_rule` 不一致：直接抛错，说明上游是用另一套规则算的。
    """
    meta = (obj or {}).get(META) or {}
    if not meta:
        if allow_legacy:
            return [f"{label}: 旧缓存无 {META}，按 legacy 继续"]
        raise CacheMismatch(f"{label}: 缺少 {META}")
    if as_of and meta.get("as_of") != as_of:
        raise CacheMismatch(f"{label}: as_of={meta.get('as_of')} != {as_of}")
    if expect_rule and meta.get("rule_version") != expect_rule:
        raise CacheMismatch(
            f"{label}: rule_version={meta.get('rule_version')} != {expect_rule}，请重跑上游"
        )
    return []


def warn(warnings: list[str]) -> None:
    for w in warnings:
        print(f"  [cache] {w}")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp.{os.getpid()}")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def write_bytes(path: Path, data: bytes) -> None:
    _atomic_write(path, data)


def write_text(path: Path, text: str) -> None:
    _atomic_write(path, text.encode("utf-8"))


def write_json(path: Path, obj: Any, *, indent: int = 1) -> None:
    _atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=indent).encode("utf-8"))


def write_pickle(path: Path, obj: Any) -> None:
    _atomic_write(path, pickle.dumps(obj))


def read_json(path: Path, label: str | None = None, *, as_of: str | None = None,
              expect_rule: str | None = None, allow_legacy: bool = True) -> tuple[Any, list[str]]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    warnings = check_meta(obj, label or path.name, as_of=as_of,
                          expect_rule=expect_rule, allow_legacy=allow_legacy)
    return obj, warnings


def read_pickle(path: Path, label: str | None = None, *, as_of: str | None = None,
                expect_rule: str | None = None,
                allow_legacy: bool = True) -> tuple[Any, list[str]]:
    obj = pickle.loads(path.read_bytes())
    warnings = check_meta(obj, label or path.name, as_of=as_of,
                          expect_rule=expect_rule, allow_legacy=allow_legacy)
    return obj, warnings

"""每日阶段影子快照（只读，不改主榜、不回写 score/report）。

    python -m pipeline.stage_shadow --as-of 2026-11-09

产出 archive/stage-shadow/<as_of>.json，给后续前向验证用：

- 全 128 个板块的当日指标（份额、涨幅、拥挤、广度、涨停数、资金流等）；
- 当前阶段的诊断明细（仅 score 池，保留 stage_evidence / stage_candidates）；
- 一套 P1 草案影子规则 stage_shadow（核心 + 辅助，缺失判据用替代项），
  只写快照，不进报告、不改 stage；
- 日线级 microstructure 字段，后续可按 20 日窗口计算涨停倾向，做 regime 分型。

默认只归档当日，不回填历史。`--bootstrap-existing` 可选地把已经落盘的
point-in-time score/factors/boardbreadth 缓存补成种子快照，但会标记 bootstrap=true，
评估时不应把它们当成前向验证样本。
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import day, panel, regime  # noqa: E402

CACHE = ROOT / "pipeline" / "cache"
ARCHIVE = ROOT / "archive" / "stage-shadow"
STAGES = ("fade", "divergence", "acceleration", "expansion", "trend", "ignition")
STAGE_REQUIRED = 2
SHADOW_VERSION = "p1-draft-2026-11-10b"


def _load(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _rank(values: list[float], v: float | None) -> float | None:
    vals = [x for x in values if x is not None]
    if v is None or not vals:
        return None
    return round((sum(1 for x in vals if x < v) + 1) / len(vals) * 100, 2)


def _lt(v, threshold: float) -> bool:
    return v is not None and v < threshold


def _ge(v, threshold: float) -> bool:
    return v is not None and v >= threshold


def _crit(key: str, label: str, passed: bool, value=None, *, applicable: bool = True,
          structural_zero: bool = False, substitute: bool = False) -> dict:
    return {
        "key": key, "label": label, "value": value,
        "passed": bool(passed), "applicable": bool(applicable),
        "structural_zero": bool(structural_zero), "substitute": bool(substitute),
    }


def _stage(criteria: list[dict]) -> dict:
    hits = sum(1 for c in criteria if c["passed"])
    return {
        "hits": hits,
        "applicable": sum(1 for c in criteria if c["applicable"]),
        "required": STAGE_REQUIRED,
        "assigned": hits >= STAGE_REQUIRED,
        "criteria": criteria,
    }


def _shadow_evidence(m: dict, b: dict, pool: dict, crowding: float | None,
                     th: dict) -> dict[str, dict]:
    """P1 草案：完整保留线上判据，只在「结构性零」处补一条替代判据。

    这样做的原因是可验证性：影子必须能复现线上已经判出的阶段（否则验证的是另一套规则），
    再在此之上观察替代判据是否带来增量。因此 regime 相关的绝对阈值（份额 Δ20、龙头跌幅、
    上涨占比、20 日涨幅、涨停家数）必须与 score 读同一份 `th`，不能锁死在 neutral 一档。
    替代项只在无涨停/连板结构时出现，且单独标记，评估时可以随时剔除，回退到纯线上口径。

    紧贴阈值不加替代：acceleration/ignition/trend/fade 各有 ≥2 条不依赖涨停的判据，
    无涨停板块本来就够 2 条，强行补替代项只会制造假阳性。
    """
    up = b.get("up_ratio")
    flow = m.get("flow5")
    leader = pool.get("leader_chg_5d")
    seal = pool.get("seal_rate")
    streak = pool.get("max_streak")
    prev_streak = pool.get("max_streak_prev")
    lu = b.get("limit_up")
    if lu is None:
        lu = pool.get("limit_up_count")
    chg5, chg20 = m.get("chg_5d"), m.get("chg_20d")
    d5, d20 = m.get("share_chg_5"), m.get("share_chg_20")
    share_pct, days10 = m.get("share_pct_250"), m.get("days_top10_20")
    no_lu = lu is not None and lu == 0

    ev: dict[str, dict] = {}

    fade = [
        _crit("share_chg_20", f"份额 Δ20 < {th['fade_share_chg_20'] * 100:+.1f}pct",
              _lt(d20, th["fade_share_chg_20"]), d20),
        _crit("leader_chg_5d", f"龙头 5 日跌幅 > {abs(th['fade_leader_chg_5d']) * 100:.0f}%",
              _lt(leader, th["fade_leader_chg_5d"]), leader,
              applicable=leader is not None),
        _crit("breadth_up_ratio", f"上涨占比 < {th['fade_up'] * 100:.0f}%",
              _lt(up, th["fade_up"]), up, applicable=up is not None),
    ]
    if leader is None:
        fade.append(_crit("flow5_neg", "资金净流出（龙头缺失替代）", _lt(flow, 0), flow,
                          applicable=flow is not None, substitute=True))
    ev["fade"] = _stage(fade)

    div = [
        _crit("chg_5d_vs_20d4", "5 日涨幅 < 20 日涨幅/4",
              chg5 is not None and chg20 is not None and chg5 < chg20 / 4,
              [chg5, chg20], applicable=chg5 is not None and chg20 is not None),
        _crit("share_pct_250", "份额分位 > 0.90", share_pct is not None and share_pct > 0.90,
              share_pct, applicable=share_pct is not None),
        _crit("streak_drop", "连板回落 ≥ 2 级",
              prev_streak is not None and prev_streak - (streak or 0) >= 2,
              [prev_streak, streak], applicable=prev_streak is not None,
              structural_zero=no_lu),
    ]
    if no_lu or prev_streak is None:
        div.append(_crit("flow_out_momentum_fade", "资金流出且 5 日动量不足 20 日一半（无连板替代）",
                         _lt(flow, 0) and chg5 is not None and chg20 is not None and chg5 < chg20 / 2,
                         [flow, chg5, chg20],
                         applicable=flow is not None and chg5 is not None and chg20 is not None,
                         substitute=True))
    ev["divergence"] = _stage(div)

    ev["acceleration"] = _stage([
        _crit("chg_20d", f"20 日涨幅 > {th['accel_chg_20'] * 100:.0f}%",
              chg20 is not None and chg20 > th["accel_chg_20"], chg20,
              applicable=chg20 is not None),
        _crit("crowding", "拥挤度 > 0.85", crowding is not None and crowding > 0.85, crowding,
              applicable=crowding is not None),
        _crit("seal_rate", "封板率 > 75%", seal is not None and seal > 0.75, seal,
              applicable=seal is not None, structural_zero=no_lu),
    ])

    exp = [
        _crit("share_pct_250", "份额分位 0.60~0.85",
              share_pct is not None and 0.60 <= share_pct <= 0.85, share_pct,
              applicable=share_pct is not None),
        _crit("limit_up_count_5", f"涨停 ≥ {th['expansion_limit_up']} 家",
              lu is not None and lu >= th["expansion_limit_up"], lu,
              applicable=lu is not None, structural_zero=no_lu),
        _crit("max_streak_3_4", "连板 3~4 级", streak is not None and 3 <= streak <= 4, streak,
              applicable=streak is not None, structural_zero=no_lu),
        _crit("breadth_up_ratio", f"上涨占比 ≥ {th['expansion_up'] * 100:.0f}%",
              _ge(up, th["expansion_up"]), up, applicable=up is not None),
    ]
    if no_lu:
        exp.append(_crit("flow_in_breadth", f"资金净流入且广度 ≥ {th['expansion_up'] * 100:.0f}%（无涨停替代）",
                         _gt0(flow) and _ge(up, th["expansion_up"]), [flow, up],
                         applicable=flow is not None and up is not None, substitute=True))
    ev["expansion"] = _stage(exp)

    ev["trend"] = _stage([
        _crit("share_pct_250", "份额分位 ≥ 0.85",
              share_pct is not None and share_pct >= 0.85, share_pct, applicable=share_pct is not None),
        _crit("chg_20d", f"20 日涨幅 ≥ {th['trend_chg_20'] * 100:.0f}%",
              _ge(chg20, th["trend_chg_20"]), chg20, applicable=chg20 is not None),
        _crit("breadth_up_ratio", f"上涨占比 ≥ {th['trend_up'] * 100:.0f}%",
              _ge(up, th["trend_up"]), up, applicable=up is not None),
    ])

    ev["ignition"] = _stage([
        _crit("share_chg_5", f"份额 Δ5 ≥ +{th['ignition_share_chg_5'] * 100:.1f}pct",
              _ge(d5, th["ignition_share_chg_5"]), d5, applicable=d5 is not None),
        _crit("days_top10_20", "前 10 天数 ≤ 8", days10 is not None and days10 <= 8, days10,
              applicable=days10 is not None),
        _crit("limit_up_count_2_5", "涨停 2~5 家", lu is not None and 2 <= lu <= 5, lu,
              applicable=lu is not None, structural_zero=no_lu),
    ])
    return ev


def _gt0(v) -> bool:
    return v is not None and v > 0


def _current_compact(row: dict | None) -> dict | None:
    if not row:
        return None
    cands = row.get("stage_candidates") or {}
    return {
        "stage": row.get("stage"),
        "gates": row.get("gates"),
        "score": row.get("score"),
        "listed": row.get("listed"),
        "max_hits": row.get("stage_max_hits"),
        "pending": row.get("stage_pending_reason"),
        "candidates": {
            s: {k: c.get(k) for k in ("hits", "applicable", "effective", "structural_zero", "distance")}
            for s, c in cands.items()
        },
    }


def build_snapshot(as_of: str, source: str = "daily", bootstrap: bool = False) -> Path:
    score = _load(CACHE / f"score-{as_of}.json") or {}
    factors = _load(CACHE / f"factors-{as_of}.json")
    breadth = _load(CACHE / f"boardbreadth-{as_of}.json") or {}
    run = _load(CACHE / f"run-{as_of}.json") or {}
    limit = _load(CACHE / f"limit-{as_of}.json") or {}
    if not factors:
        raise SystemExit(f"缺少 factors-{as_of}.json，无法生成影子快照")
    for name, obj in (("score", score), ("factors", factors), ("boardbreadth", breadth),
                      ("run", run), ("limit", limit)):
        if obj and obj.get("as_of") and obj["as_of"] != as_of:
            raise SystemExit(f"{name} 缓存日期 {obj['as_of']} 与 as_of {as_of} 不一致")

    factor_rows = factors.get("rows") or {}
    score_map = {r["code"]: r for r in (score.get("rows") or []) if r.get("code")}
    breadth_boards = breadth.get("boards") or {}
    run_gates = {g["code"]: g for g in (run.get("gates") or []) if g.get("code")}
    # 闸门与阶段判据都复刻当期 regime 阈值（run 缓存优先）：闸门不一致会把
    # 「闸门内覆盖率」系统性拉偏；阶段判据锁死在 neutral 则无法复现线上阶段。
    th = run.get("thresholds") or (run.get("regime") or {}).get("thresholds") or dict(regime.THRESHOLDS["neutral"])
    chg20_vals = [r.get("chg_20d") for r in factor_rows.values() if r.get("chg_20d") is not None]
    limit_market = limit.get("market") or {}

    boards = []
    for code, m in sorted(factor_rows.items()):
        b = breadth_boards.get(code) or {}
        g = run_gates.get(code) or {}
        sc = score_map.get(code)
        pool = (sc or {}).get("pool") or {}
        share_pct, chg20 = m.get("share_pct_250"), m.get("chg_20d")
        crowd = None
        if share_pct is not None and chg20 is not None:
            rank = _rank(chg20_vals, chg20)
            if rank is not None:
                crowd = round(0.5 * share_pct + 0.5 * rank / 100, 4)

        lu = b.get("limit_up")
        if lu is None:
            lu = pool.get("limit_up_count")
        members = b.get("members")
        gate_p1 = (m.get("days_top10_20") or 0) >= 6 and (m.get("consecutive_top10") or 0) >= 2
        gate_p3 = panel.p3_pass(m.get("share_chg_5"), m.get("share_pct_250"),
                                m.get("share_samples"), th["p3_share_chg_5"])
        gate_p2 = g.get("p2") if g else None
        # P2 只有 run 的闸门候选才算了；其余板块用 P1+P3 作**下界**，
        # 不把「P2 未知」当成「P2 未通过」。
        if sc:
            gates_known = sc.get("gates")
        elif gate_p2 is not None:
            gates_known = int(gate_p1) + int(bool(gate_p2)) + int(gate_p3)
        else:
            gates_known = int(gate_p1) + int(gate_p3)

        ev = _shadow_evidence(m, b, pool, crowd, th)
        shadow_stage = next((s for s in STAGES if ev[s]["assigned"]), None)
        # 极高位拥挤但广度不确认：不硬塞六阶段之一，单独记 crowded_pending。
        # 数字媒体 11-09 就是这一类（份额分位 0.99、上涨占比 40%、5 日涨幅仍在扩张）。
        shadow_pending = (shadow_stage is None and (gates_known or 0) >= 2
                          and crowd is not None and crowd >= 0.90 and _lt(b.get("up_ratio"), 0.55))
        shadow_state = shadow_stage or ("crowded_pending" if shadow_pending else None)
        shadow_gated = shadow_state if (gates_known or 0) >= 2 else None
        boards.append({
            "code": code,
            "name": m.get("name") or (sc or {}).get("name") or code,
            "metrics": {
                k: m.get(k) for k in (
                    "chg_1d", "chg_5d", "chg_20d", "chg_60d", "up_days_60",
                    "days_top10_20", "consecutive_top10", "share", "share_chg_5",
                    "share_chg_20", "share_pct_250", "flow5", "rs_5", "rs_20", "rs_60",
                )
            } | {"crowding": crowd},
            "micro": {
                "limit_up_count": lu,
                "members": members,
                "valid": b.get("valid"),
                "up_ratio": b.get("up_ratio"),
                "strong_ratio": b.get("strong_ratio"),
                "limit_up_ratio": b.get("limit_up_ratio"),
                "limit_up_member_ratio": (round(lu / members, 5) if lu is not None and members else None),
                "day_type": "no_limit_up" if (lu or 0) == 0 else "has_limit_up",
            },
            "gate_flags": {"p1": gate_p1, "p2": gate_p2, "p3": gate_p3, "gates_known": gates_known},
            "current": _current_compact(sc),
            "shadow": {
                "stage": shadow_stage,
                "state": shadow_state,
                "stage_gated": shadow_gated,
                "rule_version": SHADOW_VERSION,
                "evidence": ev,
            },
        })

    diagnostics = {
        code: {
            "stage": r.get("stage"),
            "gates": r.get("gates"),
            "max_hits": r.get("stage_max_hits"),
            "pending": r.get("stage_pending_reason"),
            "evidence": r.get("stage_evidence"),
            "candidates": r.get("stage_candidates"),
        }
        for code, r in score_map.items() if (r.get("gates") or 0) >= 2
    }
    n = len(boards)
    gated = [x for x in boards if (x["gate_flags"].get("gates_known") or 0) >= 2]
    # current 只存在于 score 池（闸门候选）里，拿它跟全 128 个板块比会把
    # 「没评估」误当成「评了但为 null」。这里分开报：池内对比 + 影子的全样本覆盖。
    pool = [x for x in boards if x["current"] is not None]
    current_n = sum(1 for x in pool if x["current"].get("stage"))
    shadow_in_pool = sum(1 for x in pool if x["shadow"]["state"])
    shadow_gated_n = sum(1 for x in gated if x["shadow"]["stage_gated"])
    shadow_n = sum(1 for x in boards if x["shadow"]["state"])
    summary = {
        "boards": n,
        "score_pool": len(pool),
        "gated_known": len(gated),
        "current_stage_counts": dict(Counter(x["current"]["stage"] or "none" for x in pool).most_common()),
        "shadow_stage_counts": dict(Counter(x["shadow"]["state"] or "none" for x in boards).most_common()),
        "shadow_gated_stage_counts": dict(Counter(x["shadow"]["stage_gated"] or "none" for x in gated).most_common()),
        "day_type_counts": dict(Counter(x["micro"]["day_type"] for x in boards)),
        "coverage": {
            "current_in_pool": round(current_n / len(pool), 4) if pool else None,
            "shadow_in_pool": round(shadow_in_pool / len(pool), 4) if pool else None,
            "shadow_all": round(shadow_n / n, 4) if n else None,
            "shadow_gated": round(shadow_gated_n / len(gated), 4) if gated else None,
            "current_in_gated": round(
                sum(1 for x in gated if (x["current"] or {}).get("stage")) / len(gated), 4
            ) if gated else None,
        },
    }
    snap = {
        "schema_version": "stage-shadow-v1",
        "as_of": as_of,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source": source,
        "bootstrap": bootstrap,
        "shadow_rule_version": SHADOW_VERSION,
        "inputs": {
            "score": score.get("as_of"),
            "factors": factors.get("as_of"),
            "boardbreadth": breadth.get("as_of"),
            "run": run.get("as_of"),
            "limit": limit.get("as_of"),
        },
        "market": {
            "amount_yi": run.get("market_amount_yi"),
            "limit_up": limit_market.get("limit_up"),
            "broken": limit_market.get("broken"),
            "limit_down": limit_market.get("limit_down"),
            "seal_rate": limit_market.get("seal_rate"),
            "max_streak": limit_market.get("max_streak"),
            "breadth_universe": breadth.get("universe"),
            "breadth_ranked": breadth.get("ranked"),
            "members_total": breadth.get("members_total"),
        },
        "summary": summary,
        "boards": boards,
        "current_diagnostics": diagnostics,
        "notes": [
            "只读快照，不参与报告与主榜；stage_shadow 是 P1 草案，不是线上阶段。",
            "默认只归档当日，不回填历史；--bootstrap-existing 的 bootstrap=true 样本不应当作前向验证。",
            "regime 分型需要至少 10 个已归档交易日；此前按 unknown 处理。",
            "当日无涨停的板块涨停判据为结构性零，影子规则用广度/资金流/龙头替代，仍需前向验证。",
        ],
    }
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    dest = ARCHIVE / f"{as_of}.json"
    dest.write_text(json.dumps(snap, ensure_ascii=False, indent=1), encoding="utf-8")
    return dest


def _bootstrap_existing(force: bool) -> int:
    dates = []
    for p in sorted(CACHE.glob("score-*.json")):
        d = _load(p) or {}
        if d.get("as_of"):
            dates.append(d["as_of"])
    done = 0
    for date in sorted(set(dates)):
        if not (CACHE / f"factors-{date}.json").exists():
            print(f"  跳过 {date}：无 factors 缓存")
            continue
        dest = ARCHIVE / f"{date}.json"
        if dest.exists() and not force:
            print(f"  跳过 {date}：快照已存在（--force 覆盖）")
            continue
        p = build_snapshot(date, source="existing-cache", bootstrap=True)
        print(f"  {p.relative_to(ROOT)}")
        done += 1
    return done


def main() -> int:
    ap = argparse.ArgumentParser(description="每日阶段影子快照（只读）")
    day.add_as_of(ap)
    ap.add_argument("--bootstrap-existing", action="store_true",
                    help="把已有 point-in-time score/factors/boardbreadth 缓存补成种子快照（默认关闭）")
    ap.add_argument("--force", action="store_true", help="bootstrap 时覆盖已有快照")
    args = ap.parse_args()

    if args.bootstrap_existing:
        n = _bootstrap_existing(args.force)
        print(f"bootstrap 完成：{n} 个")
        return 0

    as_of = day.resolve(args.as_of)
    dest = build_snapshot(as_of)
    snap = json.loads(dest.read_text(encoding="utf-8"))
    s = snap["summary"]
    print(f"阶段影子快照 {as_of}")
    print(f"  板块 {s['boards']} | score 池 {s['score_pool']} | 已知闸门 {s['gated_known']} | 当日类型 {s['day_type_counts']}")
    print(f"  阶段覆盖：当前池内 {s['coverage']['current_in_pool']} / 影子池内 {s['coverage']['shadow_in_pool']}"
          f" / 影子闸门内 {s['coverage']['shadow_gated']} / 影子全样本 {s['coverage']['shadow_all']}")
    print(f"  影子阶段分布（闸门内）：{s['shadow_gated_stage_counts']}")
    print(f"  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""补算「仅通过 1 条闸门」板块的 P2（供 rotation.emerging 使用）。

    python -m pipeline.extra --as-of 2026-11-02 --boards 数字媒体,电视广播Ⅱ,医疗美容,医疗服务

run.py 只为 P1/P3 已通过的板块拉成分与 K 线；P2 未算的板块不能算作「未通过」，
要进 rotation.emerging 就必须把 P2 真算出来。本模块只补这一块，输出
cache/extra-<as_of>.json：每个板块的 up_ratio / new_high_ratio / valid / degraded。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import cacheio, day, http, kline, quotes  # noqa: E402

CACHE = ROOT / "pipeline" / "cache"
CONST_URL = ("https://datacenter-web.eastmoney.com/api/data/v1/get?"
             "reportName=RPT_BOARD_CONSTITUENT&columns=BOARD_CODE_BK,SECURITY_CODE"
             "&pageNumber=1&pageSize=500&filter=(BOARD_CODE_BK%3D%22{code}%22)")


def main() -> int:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--fresh", action="store_true", help="丢弃已有结果，只保留本次板块")
    ap.add_argument("--boards", required=True, help="逗号分隔的板块名称")
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)

    fac_p = CACHE / f"factors-{args.as_of}.json"
    fac, warns = cacheio.read_json(fac_p, "factors", as_of=args.as_of,
                                   expect_rule=cacheio.FACTORS_RULE)
    cacheio.warn(warns)
    ix = {v["name"]: v["code"] for v in fac["rows"].values()}
    names = [n.strip() for n in args.boards.split(",") if n.strip()]
    missing = [n for n in names if n not in ix]
    if missing:
        raise SystemExit(f"面板里没有：{missing}")
    pairs = [(ix[n], n) for n in names]

    cli = http.make_client(workers=3, max_rps=3.0, min_span=0)
    cons: dict[str, list[str]] = {}
    for code, _ in pairs:
        j = cli.get_json(CONST_URL.format(code=code))
        rows = ((j.get("result") or {}).get("data")) or []
        cons[code] = [str(r["SECURITY_CODE"]).zfill(6) for r in rows if r.get("SECURITY_CODE")]
        cacheio.write_text(CACHE / f"codes-{code}.json",
                           json.dumps(cons[code], ensure_ascii=False))
    # codes-INDEX.json 是 score/组装的成分股白名单（run 只写本轮候选）。extra 抓了新的
    # 板块却不登记，下游 members 就取不到它们的成分股，涨停数、龙头、拥挤惩罚一律归零，
    # 算出来的分数是错的。这里合并写回，不覆盖 run 已经写好的部分。
    _idx = CACHE / f"codes-INDEX-{args.as_of}.json"
    _old = list(json.loads(_idx.read_text(encoding="utf-8"))) if _idx.exists() else []
    cacheio.write_text(_idx, json.dumps(sorted(set(_old) | set(cons)), ensure_ascii=False))

    codes = list(dict.fromkeys(c for v in cons.values() for c in v))
    snap, _snap_date = quotes.load(CACHE, args.as_of)
    need = [c for c in codes if c not in snap]
    if need:
        snap.update(quotes.fetch(cli, need))
        _wrote, _qd = quotes.save(CACHE, args.as_of, snap)
        if not _wrote:
            print(f"  ⚠ 快照未落盘：报价交易日 {_qd} 与 as_of {args.as_of} 不一致")

    dest = CACHE / f"extra-{args.as_of}.json"
    pkl = CACHE / f"panel-{args.as_of}.pkl"
    p, warns = cacheio.read_pickle(pkl, "panel", as_of=args.as_of,
                                   expect_rule=cacheio.PANEL_RULE)
    cacheio.warn(warns)
    cal = sorted(p["by_date"])
    store = kline.Store(CACHE / "kline.sqlite")
    try:
        r = kline.ensure_history(cli, store, codes, args.as_of, need=45, calendar=cal)
        print(f"  K 线补历史：{r}")
    except http.EndpointBlocked as e:
        print(f"  ⚠ 建库接口不可用，用库内数据继续：{e}")
    w = kline.append_from_quotes(store, {c: snap[c] for c in codes if c in snap}, args.as_of)
    # 与 run.py 保持一致：回溯历史日时报价是「最新快照」，日期不符必须写明白，
    # 否则日志里只有「入库 0 行」，看不出是保护生效还是真没数据。
    if w.get("skipped"):
        print(f"  ⚠ 报价未入库：{w['skipped']}")
    else:
        print(f"  当日报价入库 {w.get('written')} 行")

    # 增量写：只补新板块时不能把上一批结果冲掉，否则 rotation.emerging 会悄悄变样。
    # 需要整体重算时用 --fresh。
    out = {"as_of": args.as_of, "rows": {}}
    if dest.exists() and not args.fresh:
        prev = json.loads(dest.read_text(encoding="utf-8"))
        out["rows"].update(prev.get("rows") or {})
        print(f"  沿用已有 {len(prev.get('rows') or {})} 个板块结果，本次覆盖同名项")
    for code, name in pairs:
        b = kline.breadth(store, cons[code], args.as_of, snap, calendar=cal,
                          quote_date=quotes.trade_date(snap))
        out["rows"][code] = {"name": name, **{k: b.get(k) for k in
                            ("up_ratio", "new_high_ratio", "valid", "degraded",
                             "hole_count", "stale")}}
        print(f"  {name:<10} 上涨 {(b.get('up_ratio') or 0) * 100:5.1f}% "
              f"新高 {(b.get('new_high_ratio') or 0) * 100:5.1f}% 有效 {b.get('valid')} "
              f"退化 {bool(b.get('degraded'))}")
    store.close()
    out[cacheio.META] = cacheio.make_meta(args.as_of, cacheio.EXTRA_RULE,
                                          {"factors": fac_p, "panel": pkl},
                                          rows=len(out["rows"]))
    cacheio.write_json(dest, out)
    print(f"  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

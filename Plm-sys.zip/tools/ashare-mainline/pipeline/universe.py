"""板块清单生存偏差：前瞻快照 + 历史锚点量化。

问题：`panel.build` 只对「当日仍在更新」的板块拉历史，`by_date / history / market_amount`
因此只含今天的赢家。若某板块在半年前存在、后来被并入别的板块（或停止更新），
它在半年后的历史横截面里完全消失——当时的分位被系统性高估，而报告与回测都看不出来。

做法（不补 260 日历史面板）：

1. **前瞻记录**：每个交易日把当日板块清单落盘（`current`），后续任意一天都可回看；
2. **锚点量化**：取 20 / 60 / 120 / 250 个交易日前的锚点日各发 1 次
   `RPT_INDUSTRY_FUNDFLOW`（`panel.board_list` 支持任意历史日），对比
   「当时有、现在无」的板块数与名称；
3. 结果写进 `data_quality.notes`，读者知道当期横截面漏掉了多少只、最大一档占多少。

口径：

- 两侧都调 `panel.board_list`（同一接口、同一 `TRADE_DATE` 语义），不在本地拼集合；
- 锚点日取自面板交易日历，不自己算自然日；
- 只量化、不改历史份额与分位算法。补历史面板会把「当时不存在」按 null 记入，
  改变 `market_amount` 分母、整体位移历史分位，那应是一次独立的版本变更。

    python -m pipeline.universe --as-of 2026-11-09
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import cacheio, day, http, panel  # noqa: E402

CACHE = ROOT / "pipeline" / "cache"
LAGS = (20, 60, 120, 250)


def _set(rows: list[dict]) -> dict[str, str]:
    return {r["code"]: (r.get("name") or r["code"]) for r in rows if r.get("code")}


def capture(client: http.Client, as_of: str, calendar: list[str], *,
            verbose: bool = True) -> dict:
    """拉当日清单与四个锚点，落 `cache/universe-<as_of>.json` 并返回。"""
    cur = _set(panel.board_list(client, as_of))
    if not cur:
        raise RuntimeError(f"{as_of} 当日板块清单为空，无法建立快照")
    idx = calendar.index(as_of) if as_of in calendar else len(calendar) - 1
    anchors = []
    for lag in LAGS:
        if idx - lag < 0:
            anchors.append({"lag": lag, "date": None, "status": "skipped",
                            "reason": f"面板仅 {idx + 1} 个交易日，不足 {lag} 日"})
            continue
        d = calendar[idx - lag]
        try:
            old = _set(panel.board_list(client, d))
        except Exception as e:  # noqa: BLE001 - 单个锚点失败不影响其余锚点
            anchors.append({"lag": lag, "date": d, "status": "error",
                            "reason": str(e)[:200]})
            if verbose:
                print(f"  ⚠ {lag} 日前（{d}）清单拉取失败：{e}")
            continue
        if not old:
            # 空清单不能当成「当时没有板块」：那会把 128 个现役全算成新增、把漂移写成 0。
            anchors.append({"lag": lag, "date": d, "status": "empty",
                            "reason": "接口返回 0 个板块，锚点作废"})
            if verbose:
                print(f"  ⚠ {lag} 日前（{d}）清单为空，锚点作废")
            continue
        removed = [{"code": c, "name": old[c]} for c in sorted(set(old) - set(cur))]
        added = [{"code": c, "name": cur[c]} for c in sorted(set(cur) - set(old))]
        anchors.append({"lag": lag, "date": d, "status": "ok", "boards": len(old),
                        "removed": {"count": len(removed), "boards": removed},
                        "added": {"count": len(added), "boards": added}})
        if verbose:
            print(f"  {lag:>3} 日前（{d}）：{len(old)} 个板块，消失 {len(removed)}、"
                  f"新增 {len(added)}")

    removed_union: dict[str, str] = {}
    for a in anchors:
        for b in (a.get("removed") or {}).get("boards", []):
            removed_union.setdefault(b["code"], b["name"])
    ok = [a for a in anchors if a["status"] == "ok"]
    worst = max(ok, key=lambda a: a["removed"]["count"]) if ok else None
    drift = {
        "anchors_ok": len(ok),
        "max_removed": worst["removed"]["count"] if worst else 0,
        "max_removed_lag": worst["lag"] if worst else None,
        "removed_union_count": len(removed_union),
        "removed_union": [{"code": c, "name": n} for c, n in sorted(removed_union.items())],
        "removed_ratio_max": (round(worst["removed"]["count"] / worst["boards"], 4)
                              if worst and worst["boards"] else None),
    }
    out = {
        cacheio.META: cacheio.make_meta(as_of, cacheio.UNIVERSE_RULE,
                                        inputs={"panel": CACHE / f"panel-{as_of}.pkl"},
                                        current=len(cur), anchors_ok=len(ok)),
        "as_of": as_of,
        "method": ("当日板块清单快照 + 20/60/120/250 交易日前锚点对比；"
                   "只量化「当时有、现在无」的板块数，不补历史面板、不改份额与分位算法"),
        "current": {"count": len(cur),
                    "boards": [{"code": c, "name": n} for c, n in sorted(cur.items())]},
        "anchors": anchors,
        "drift": drift,
    }
    cacheio.write_json(CACHE / f"universe-{as_of}.json", out)
    return out


def load(as_of: str) -> dict | None:
    p = CACHE / f"universe-{as_of}.json"
    if not p.exists():
        return None
    try:
        obj, warns = cacheio.read_json(p, "universe", as_of=as_of,
                                       expect_rule=cacheio.UNIVERSE_RULE)
    except (OSError, ValueError, cacheio.CacheMismatch) as e:
        print(f"  [cache] universe-{as_of}.json 读取失败：{e}")
        return None
    cacheio.warn(warns)
    return obj


def note(u: dict | None) -> str:
    """data_quality.notes 用的一句话：漂移了多少、最大一档占多少。"""
    if not u:
        return ("板块清单生存偏差：本期未落 universe 快照（run 未跑或清单接口失败），"
                "历史横截面含多少已消失板块无法量化；下期起补记")
    cur = (u.get("current") or {}).get("count")
    ok = [a for a in (u.get("anchors") or []) if a.get("status") == "ok"]
    if not ok:
        return (f"板块清单生存偏差：当日 {cur} 个板块；交易日历不足或锚点接口失败，"
                f"本期未能量化历史消失板块")
    parts = "、".join(f"{a['lag']} 日前（{a['date']}）消失 {a['removed']['count']} 只"
                     for a in ok)
    d = u.get("drift") or {}
    names = [b["name"] for b in (d.get("removed_union") or [])]
    name_txt = ("（" + "、".join(names[:8]) + ("…" if len(names) > 8 else "") + "）"
                if names else "")
    pct = d.get("removed_ratio_max")
    return (f"板块清单生存偏差（universe 前瞻快照 + 锚点量化）：当日 {cur} 个板块；"
            f"{parts}；合计消失 {d.get('removed_union_count', 0)} 只{name_txt}"
            + (f"，最多一档占当时板块数的 {pct * 100:.1f}%" if pct is not None else "")
            + "。历史 by_date / 分位只含当期仍在更新的板块，消失板块未补入，"
              "跨期比较与回测需按此偏差打折")


def main() -> int:
    ap = argparse.ArgumentParser(description="板块清单快照与生存偏差锚点")
    day.add_as_of(ap)
    args = ap.parse_args()
    as_of = day.resolve(args.as_of)
    pkl = CACHE / f"panel-{as_of}.pkl"
    if not pkl.exists():
        print(f"[FATAL] 缺少 {pkl.name}：交易日历取自面板，先跑 pipeline.run --as-of {as_of}")
        return 2
    p, warns = cacheio.read_pickle(pkl, "panel", as_of=as_of,
                                   expect_rule=cacheio.PANEL_RULE)
    cacheio.warn(warns)
    cli = http.make_client()
    print(f"板块清单快照 · {as_of}")
    u = capture(cli, as_of, sorted(p["by_date"]))
    print("  " + note(u))
    print(f"  -> pipeline/cache/universe-{as_of}.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

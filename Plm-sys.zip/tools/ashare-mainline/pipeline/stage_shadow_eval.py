"""阶段影子前向评估（只读归档 + panel 前向收益）。

    python -m pipeline.stage_shadow_eval                 # 评估全部日常归档
    python -m pipeline.stage_shadow_eval --as-of 2026-11-09
    python -m pipeline.stage_shadow_eval --include-bootstrap

它回答三个问题：

1. **覆盖率**：过了 ≥2 条闸门的板块里，当前规则和影子规则各能标出多少；
   按「当日有涨停 / 无涨停」拆开，无涨停组就是机构型板块的代理。
2. **前向表现**：标签出现后 5/20 日相对全板块等权的超额、20 日胜率、20 日最大回撤。
   11-09 这类最新快照没有未来数据，只出覆盖率与一致性，前向样本记 0。
3. **规则一致性**：影子必须复现当前已判出的阶段（current_only 应为 0）；
   影子多出来的标签按「补位」计数，作为 P1 增量的候选证据。

regime（投机 / 机构 / 混合）用归档里的涨停家数滚动 20 日分位判断；
归档不足 10 天时一律记 unknown，不用 1~2 天的样本硬分型。

阈值扰动下的标签稳定性（±10~20%）需要 30 个以上归档日才有统计意义，
本版先把原始证据与阈值一起落盘，稳定性检查留到样本足够后再做。

输出 archive/stage-shadow/summary-<最新归档日>.json。只读，不改报告与主榜。
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pipeline import day  # noqa: E402
from pipeline.stage_shadow import ARCHIVE, CACHE, STAGES  # noqa: E402

HORIZONS = (5, 20)
RISK_ON = ("acceleration", "expansion", "trend")
RISK_OFF = ("fade", "divergence", "crowded_pending")
REGIME_WINDOW = 20
REGIME_MIN_DAYS = 10


def _load(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _mean(xs: list[float]) -> float | None:
    return round(sum(xs) / len(xs), 4) if xs else None


def _snapshots(as_of: str | None, include_bootstrap: bool) -> list[dict]:
    rows = []
    for p in sorted(ARCHIVE.glob("20*.json")):
        snap = _load(p)
        if not snap or not snap.get("as_of"):
            continue
        if not include_bootstrap and snap.get("bootstrap"):
            continue
        if as_of and snap["as_of"] > as_of:
            continue
        rows.append(snap)
    return rows


def _load_panel() -> dict:
    files = sorted(CACHE.glob("panel-*.pkl"))
    if not files:
        raise SystemExit("缺少 panel-*.pkl，无法计算前向收益")
    with files[-1].open("rb") as f:
        return pickle.load(f)


def _forward(panel: dict, date: str, code: str, h: int) -> float | None:
    by_date = panel.get("by_date") or {}
    dates = sorted(by_date)
    if date not in by_date:
        return None
    i = dates.index(date)
    if i + h >= len(dates):
        return None
    c0 = (by_date[date].get(code) or {}).get("close")
    c1 = (by_date[dates[i + h]].get(code) or {}).get("close")
    if not c0 or not c1:
        return None
    return c1 / c0 - 1


def _mdd(panel: dict, date: str, code: str, h: int = 20) -> float | None:
    by_date = panel.get("by_date") or {}
    dates = sorted(by_date)
    if date not in by_date:
        return None
    i = dates.index(date)
    c0 = (by_date[date].get(code) or {}).get("close")
    if not c0:
        return None
    worst = 0.0
    seen = 0
    for j in range(i + 1, min(i + h + 1, len(dates))):
        c = (by_date[dates[j]].get(code) or {}).get("close")
        if c:
            worst = min(worst, c / c0 - 1)
            seen += 1
    return round(worst, 4) if seen else None


def _regime(limit_counts: list[int]) -> str:
    """投机 / 机构 / 混合。样本不足时 unknown，不用小样本硬分。"""
    if len(limit_counts) < REGIME_MIN_DAYS:
        return "unknown"
    vals = sorted(limit_counts)
    lo = vals[int(len(vals) / 3)]
    hi = vals[int(len(vals) * 2 / 3)]
    avg = sum(vals) / len(vals)
    if hi == lo:
        return "mixed" if avg > 0 else "institutional"
    if avg <= lo:
        return "institutional"
    if avg >= hi:
        return "speculative"
    return "mixed"


def _bump(bucket: dict, source: str, label: str, ex: dict[int, float | None],
          mdd20: float | None) -> None:
    row = bucket[source][label]
    row["n"] += 1
    for h in HORIZONS:
        v = ex.get(h)
        if v is not None:
            row[f"ex{h}"].append(v)
    if mdd20 is not None:
        row["mdd20"].append(mdd20)


def _finish(bucket: dict) -> dict:
    out = {}
    for source, labels in bucket.items():
        out[source] = {}
        for label, row in labels.items():
            out[source][label] = {
                "n": row["n"],
                "ex5": _mean(row["ex5"]),
                "ex20": _mean(row["ex20"]),
                "win20": (round(sum(1 for x in row["ex20"] if x > 0) / len(row["ex20"]), 4)
                          if row["ex20"] else None),
                "mdd20": _mean(row["mdd20"]),
            }
    return out


def evaluate(as_of: str | None, include_bootstrap: bool) -> dict:
    snaps = _snapshots(as_of, include_bootstrap)
    if not snaps:
        raise SystemExit("archive/stage-shadow 下没有可用快照；先跑 pipeline.stage_shadow")

    panel = _load_panel()
    by_date = panel.get("by_date") or {}
    dates = sorted(by_date)
    # 面板日 → 全板块等权收益，作为超额基准。
    mkt = {}
    for d in by_date:
        i = dates.index(d)
        for h in HORIZONS:
            if i + h >= len(dates):
                continue
            rets = []
            for code, row in by_date[d].items():
                nxt = (by_date[dates[i + h]].get(code) or {}).get("close")
                if row.get("close") and nxt:
                    rets.append(nxt / row["close"] - 1)
            mkt[(d, h)] = _mean(rets)

    days = []
    bucket = {"current": defaultdict(lambda: {"n": 0, "ex5": [], "ex20": [], "mdd20": []}),
              "shadow": defaultdict(lambda: {"n": 0, "ex5": [], "ex20": [], "mdd20": []})}
    coverage = {
        "gated": 0, "gated_no_lu": 0, "gated_has_lu": 0,
        "current": 0, "shadow": 0, "shadow_stage_only": 0,
        "current_no_lu": 0, "shadow_no_lu": 0,
        "current_has_lu": 0, "shadow_has_lu": 0,
    }
    agree = {"both": 0, "same": 0, "shadow_fill": 0, "current_only": 0,
             "both_different": 0, "neither": 0}
    limit_hist: list[int] = []

    for snap in snaps:
        d = snap["as_of"]
        lu = (snap.get("market") or {}).get("limit_up")
        if isinstance(lu, int):
            limit_hist.append(lu)
        regime = _regime(limit_hist[-REGIME_WINDOW:])
        day_row = {"as_of": d, "regime": regime, "limit_up": lu, "gated": 0,
                   "current_labeled": 0, "shadow_labeled": 0}
        for b in snap.get("boards") or []:
            gates = (b.get("gate_flags") or {}).get("gates_known") or 0
            if gates < 2:
                continue
            current = ((b.get("current") or {}).get("stage"))
            shadow = ((b.get("shadow") or {}).get("state"))
            shadow_stage = ((b.get("shadow") or {}).get("stage"))
            day_type = (b.get("micro") or {}).get("day_type")
            coverage["gated"] += 1
            day_row["gated"] += 1
            key = "gated_no_lu" if day_type == "no_limit_up" else "gated_has_lu"
            coverage[key] += 1
            if current:
                coverage["current"] += 1
                day_row["current_labeled"] += 1
            if shadow:
                coverage["shadow"] += 1
                day_row["shadow_labeled"] += 1
            if shadow_stage:
                coverage["shadow_stage_only"] += 1
            if day_type == "no_limit_up":
                coverage["current_no_lu"] += int(bool(current))
                coverage["shadow_no_lu"] += int(bool(shadow))
            else:
                coverage["current_has_lu"] += int(bool(current))
                coverage["shadow_has_lu"] += int(bool(shadow))

            if current and shadow:
                agree["both"] += 1
                if current == shadow:
                    agree["same"] += 1
                else:
                    agree["both_different"] += 1
            elif current and not shadow:
                agree["current_only"] += 1
            elif shadow and not current:
                agree["shadow_fill"] += 1
            else:
                agree["neither"] += 1

            code = b.get("code")
            ex = {}
            for h in HORIZONS:
                r = _forward(panel, d, code, h)
                base = mkt.get((d, h))
                ex[h] = (r - base) if r is not None and base is not None else None
            mdd20 = _mdd(panel, d, code)
            if current:
                _bump(bucket, "current", current, ex, mdd20)
            if shadow:
                _bump(bucket, "shadow", shadow, ex, mdd20)
        days.append(day_row)

    forward_n = sum(1 for row in bucket["current"].values() if row["ex5"] or row["ex20"])
    sep = {}
    for source in ("current", "shadow"):
        on = [row["ex20"] for label, row in bucket[source].items() if label in RISK_ON]
        off = [row["ex20"] for label, row in bucket[source].items() if label in RISK_OFF]
        on_flat = [x for xs in on for x in xs]
        off_flat = [x for xs in off for x in xs]
        sep[source] = {
            "risk_on_n": len(on_flat),
            "risk_on_ex20": _mean(on_flat),
            "risk_off_n": len(off_flat),
            "risk_off_ex20": _mean(off_flat),
            "spread_ex20": (round(_mean(on_flat) - _mean(off_flat), 4)
                            if on_flat and off_flat else None),
        }

    summary = {
        "schema_version": "stage-shadow-eval-v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "as_of": days[-1]["as_of"] if days else None,
        "days": len(days),
        "forward_ready_days": sum(1 for d in days if mkt.get((d["as_of"], 5)) is not None),
        "forward_samples": forward_n,
        "coverage": {
            **coverage,
            "current_rate": round(coverage["current"] / coverage["gated"], 4) if coverage["gated"] else None,
            "shadow_rate": round(coverage["shadow"] / coverage["gated"], 4) if coverage["gated"] else None,
            "current_rate_no_lu": (round(coverage["current_no_lu"] / coverage["gated_no_lu"], 4)
                                   if coverage["gated_no_lu"] else None),
            "shadow_rate_no_lu": (round(coverage["shadow_no_lu"] / coverage["gated_no_lu"], 4)
                                  if coverage["gated_no_lu"] else None),
            "current_rate_has_lu": (round(coverage["current_has_lu"] / coverage["gated_has_lu"], 4)
                                    if coverage["gated_has_lu"] else None),
            "shadow_rate_has_lu": (round(coverage["shadow_has_lu"] / coverage["gated_has_lu"], 4)
                                   if coverage["gated_has_lu"] else None),
        },
        "agreement": agree,
        "forward": _finish(bucket),
        "risk_separation": sep,
        "regimes": dict(Counter(d["regime"] for d in days).most_common()),
        "days_detail": days,
        "notes": [
            "forward_samples=0 表示归档日还没有未来 5/20 日数据，属于正常现象。",
            "覆盖率只统计 gates_known≥2 的板块；无涨停组是机构型板块的代理样本。",
            "shadow 含 crowded_pending；shadow_stage_only 是只算六阶段的口径。",
            "regime 用归档涨停家数滚动 20 日三分位；不足 10 天记 unknown。",
            "影子规则与线上规则同阈值，只在结构性零处补替代判据，current_only 应为 0。",
        ],
    }
    return summary


def main() -> int:
    ap = argparse.ArgumentParser(description="阶段影子前向评估（只读）")
    day.add_as_of(ap)
    ap.add_argument("--include-bootstrap", action="store_true",
                    help="把 bootstrap=true 的种子快照也纳入（默认排除，避免伪前向样本）")
    args = ap.parse_args()

    as_of = args.as_of if args.as_of not in (None, "", "auto") else None
    summary = evaluate(as_of, args.include_bootstrap)
    dest = ARCHIVE / f"summary-{summary['as_of']}.json"
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")

    c = summary["coverage"]
    a = summary["agreement"]
    print(f"阶段影子评估 {summary['as_of']}（归档 {summary['days']} 天，前向样本 {summary['forward_samples']}）")
    print(f"  闸门内 {c['gated']}（无涨停 {c['gated_no_lu']} / 有涨停 {c['gated_has_lu']}）")
    print(f"  当前覆盖 {c['current_rate']}，无涨停组 {c['current_rate_no_lu']}")
    print(f"  影子覆盖 {c['shadow_rate']}，无涨停组 {c['shadow_rate_no_lu']}（含 crowded_pending）")
    print(f"  一致性 相同 {a['same']} / 不同 {a['both_different']} / 影子补位 {a['shadow_fill']}"
          f" / 影子漏判 {a['current_only']}")
    sep = summary["risk_separation"]
    print(f"  风险分层 20d 价差：当前 {sep['current']['spread_ex20']}，影子 {sep['shadow']['spread_ex20']}")
    print(f"  -> {dest.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

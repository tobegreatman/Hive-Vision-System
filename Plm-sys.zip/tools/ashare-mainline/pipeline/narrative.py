"""叙事分的唯一实现：证据条数 × 来源等级 → 分数，外加它在流水线里唯一的用途。

    python -m pipeline.narrative --as-of 2026-11-05

v1.8 相对 v1.7 的三处改动（v1.7 已把叙事分移出总分）：

1. **分数不再手填。** v1.7 的台账是 `{"BK1277": 78}` 这种裸数字，78 既不是 75+5 也不是
   80−2，无法用 §6 的档位复算。现在每条只登记 (evidence, source)，分数由 derive() 推导，
   台账里若另写了 score 就必须与推导值相等，否则直接报错——手填的中间档没有地方藏。
2. **未评 != 0 分。** 0 的含义是「有 0 条可验证证据」，与「本轮没给它评分」完全不同。
   未评一律写 null 并进 coverage.missing，由 build_v16 在 data_quality 里点名，不再静默归零。
3. **用途收敛为两条，都不改分数。**
   a) TOP_N 切口 |Δscore| < TIE_THRESHOLD 时，叙事高者优先（pick_top）；
   b) emerging 里「叙事 ≥ 85 但只差一条闸门」单独打标（strong_but_gated），
      让半导体这种 P1 0/20 天、分数排第 12 的板块不至于被埋在萌芽列表末尾。

为什么权重仍然是 0：叙事分是人工判定的，一旦进入算术总分，排序就取决于「谁被评得细」，
而不是「谁的资金与价格更强」。它只能用来裁决分数本来就分不出高下的那一小段边界，
以及给读者一个「这条线的产业证据够不够硬」的横截面坐标。

分档（提示词 §6 原文）：

    基础分：0 条 → 0 / 1 条 → 40 / 2 条 → 60 / 3 条 → 75 / ≥4 条 → 85
    来源加分（只取最高一条）：官方原文 +15 / 公司公告 +10 / 主流媒体 +5 /
                              卖方研报 0 / 自有数据复算 0 / 社媒传闻 −10
    normalized = min(100, max(0, 基础分 + 来源加分))
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

TEMPLATE = ROOT / "pipeline" / "templates" / "narrative.json"

# 基础分：证据条数 → 分。≥4 条不再加分（85 是「证据充分」的天花板）。
BASE = {0: 0, 1: 40, 2: 60, 3: 75, 4: 85}
MAX_EVIDENCE = 4

# 来源等级 → 加分。表外的等级一律拒绝，避免「随手写个 source 就多 5 分」。
# data = 自有行情/资金流复算：可验证，但不是外部叙事，按 §6 归入「无额外加成」档。
SRC_BONUS = {
    "official": 15,       # 政府/监管/交易所原文
    "announcement": 10,   # 上市公司公告、财报
    "media": 5,           # 主流财经媒体
    "report": 0,          # 卖方研报
    "data": 0,            # 自有数据复算（行情、资金流、涨停池）
    "rumor": -10,         # 社媒传闻
}
SRC_LABEL = {
    "official": "官方原文", "announcement": "公司公告", "media": "主流媒体",
    "report": "卖方研报", "data": "自有数据", "rumor": "社媒传闻",
}

# TOP_N 边界裁决阈值：分差小于 1 分时，分数本身已经不可区分（样本噪声、四舍五入、
# 取数日内的微小差异都能翻转它），此时才让叙事分说话。
TIE_THRESHOLD = 1.0
# 「叙事强」的门槛：≥4 条证据 + 公告及以上来源才够 85，即「证据充分且有一手来源」。
STRONG_NARRATIVE = 85


class NarrativeError(ValueError):
    """台账不自洽（分数与档位对不上、来源等级不认识、证据条数为负）。"""


def derive(evidence: int | None, source: str | None) -> int | None:
    """(证据条数, 最高来源等级) → 叙事分。任一缺失返回 None（= 未评，不是 0 分）。"""
    if evidence is None or source is None:
        return None
    ev = int(evidence)
    if ev < 0:
        raise NarrativeError(f"证据条数不能为负：{evidence}")
    if source not in SRC_BONUS:
        raise NarrativeError(f"未知来源等级 {source!r}，可选：{'/'.join(SRC_BONUS)}")
    base = BASE[min(ev, MAX_EVIDENCE)]
    return max(0, min(100, base + SRC_BONUS[source]))


def explain(entry: dict) -> str:
    """把一条台账翻译成人能读的一句话，供报告与自测复用。"""
    if not entry or entry.get("score") is None:
        return "未评（本轮未登记可验证证据）"
    ev, src = entry.get("evidence"), entry.get("source")
    if ev is None or src is None:
        # 历史裸数字：保留可读性，但明确标出来，免得被当成正常条目
        return f"{entry['score']:.0f}（v1.8 之前的裸数字，无证据台账）"
    base = BASE[min(int(ev), MAX_EVIDENCE)]
    bonus = SRC_BONUS[src]
    sign = f"{bonus:+d}" if bonus else "0"
    return f"{ev} 条可验证证据（{base}）+ {SRC_LABEL.get(src, src)}（{sign}）= {entry['score']:.0f}"


def parse_entry(code: str, raw) -> dict:
    """把台账里的一条（裸数字或结构化对象）归一成统一结构，并校验自洽。"""
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        # 历史格式：只有分数。保留但标记 legacy，derive 无从校验。
        return {"score": float(raw), "evidence": None, "source": None,
                "note": "", "legacy": True}
    if not isinstance(raw, dict):
        raise NarrativeError(f"{code} 的台账条目既不是数字也不是对象：{raw!r}")
    ev, src = raw.get("evidence"), raw.get("source")
    got = derive(ev, src)
    declared = raw.get("score")
    if declared is not None and got is not None and abs(float(declared) - got) > 1e-9:
        raise NarrativeError(
            f"{code} 的分数 {declared} 与档位推导值 {got} 不符"
            f"（{ev} 条证据 + {SRC_LABEL.get(src, src)}）。"
            f"要改分数就改 evidence/source，不要直接写数字。")
    val = float(got if got is not None else (declared or 0))
    return {
        # 档位产物天然是整数。保留 95.5 这种历史小数，但别把 80 输出成 80.0——
        # 报告里「叙事 80.0」和「叙事 80」读者会以为是两种精度。
        "score": int(val) if val.is_integer() else val,
        "evidence": None if ev is None else int(ev),
        "source": src,
        "note": str(raw.get("note") or ""),
        "legacy": got is None,
    }


def load(as_of: str, path: Path | None = None) -> dict[str, dict]:
    """读某一天的叙事台账。返回 {板块代码: {score, evidence, source, note, legacy}}。"""
    p = path or TEMPLATE
    if not p.exists():
        return {}
    all_days = json.loads(p.read_text(encoding="utf-8"))
    block = all_days.get(as_of) or {}
    out: dict[str, dict] = {}
    for k, v in block.items():
        if k.startswith("_"):
            continue
        out[k] = parse_entry(k, v)
    return out


def score_of(entries: dict[str, dict], code: str) -> float | None:
    e = entries.get(code)
    return None if not e else e.get("score")


def coverage(entries: dict[str, dict], codes: list[str]) -> dict:
    """候选池的叙事覆盖：哪些评了、哪些没评。缺评不是 0 分，必须在报告里说清楚。"""
    have = [c for c in codes if score_of(entries, c) is not None]
    miss = [c for c in codes if score_of(entries, c) is None]
    legacy = [c for c in codes if (entries.get(c) or {}).get("legacy")]
    return {"total": len(codes), "evaluated": len(have), "missing": miss,
            "legacy": legacy, "complete": not miss}


def strong_but_gated(entries: dict[str, dict], code: str, gates: int | None) -> bool:
    """叙事够硬、却差一条闸门进不了主线——emerging 里值得单独点名的组合。"""
    s = score_of(entries, code)
    return s is not None and s >= STRONG_NARRATIVE and gates is not None and gates < 2


def pick_top(rows: list[dict], n: int, entries: dict[str, dict],
             threshold: float = TIE_THRESHOLD) -> tuple[list[dict], list[dict], dict | None]:
    """按分数降序取前 n 条；切口处 |Δscore| < threshold 时，由叙事分裁决。

    只动**边界那一对**，不做链式交换：分数仍是主排序键，叙事分只在它失效的
    1 分之内起作用。若边界内叙事相同或有一方未评，维持分数顺序并如实记录原因。

    返回 (top, dropped, info)。info 为 None 表示候选数不足，没有边界可裁。
    """
    ordered = sorted(rows, key=lambda r: -r["score"])
    if n <= 0 or len(ordered) <= n:
        return ordered[:max(n, 0)], ordered[max(n, 0):], None

    a, b = ordered[n - 1], ordered[n]          # a = 当前第 n 名，b = 第一个落榜的
    delta = round(a["score"] - b["score"], 4)
    na, nb = score_of(entries, a["code"]), score_of(entries, b["code"])

    def brief(x, narr):
        return {"code": x["code"], "name": x["name"], "score": x["score"],
                "narrative": narr}

    info = {
        "threshold": threshold, "boundary": n, "delta": delta, "applied": False,
        "kept": brief(a, na), "dropped": brief(b, nb),
    }
    if delta >= threshold:
        info["reason"] = f"第 {n}/{n + 1} 名分差 {delta:.2f} ≥ {threshold:g}，分数已能区分，不裁决"
        return ordered[:n], ordered[n:], info
    if na is None or nb is None:
        missing = a["name"] if na is None else b["name"]
        info["reason"] = f"分差 {delta:.2f} < {threshold:g}，但{missing}未评叙事分，维持分数顺序"
        return ordered[:n], ordered[n:], info
    if nb <= na:
        info["reason"] = (f"分差 {delta:.2f} < {threshold:g}，叙事 {nb:.0f} ≤ {na:.0f}，"
                          f"维持分数顺序")
        return ordered[:n], ordered[n:], info

    ordered[n - 1], ordered[n] = b, a
    info["applied"] = True
    info["kept"], info["dropped"] = brief(b, nb), brief(a, na)
    info["reason"] = (f"第 {n}/{n + 1} 名分差 {delta:.2f} < {threshold:g}，"
                      f"叙事 {nb:.0f} > {na:.0f}，由叙事分取得第 {n} 席")
    return ordered[:n], ordered[n:], info


def main() -> int:
    ap = argparse.ArgumentParser(description="检查某一天的叙事分台账")
    ap.add_argument("--as-of", required=True)
    args = ap.parse_args()

    entries = load(args.as_of)
    if not entries:
        print(f"  {args.as_of} 没有叙事台账")
        return 1
    print(f"{args.as_of}：{len(entries)} 条")
    for code, e in sorted(entries.items(), key=lambda kv: -(kv[1]["score"] or 0)):
        flag = "  [legacy]" if e["legacy"] else ""
        print(f"  {code}  {e['score']:>5.0f}  {explain(e)}{flag}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

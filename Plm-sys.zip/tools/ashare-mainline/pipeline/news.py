"""东财资讯检索：按关键词取最近 N 天新闻，输出 日期/媒体/标题/摘要/链接。

支持两种入参：
- **板块名**（见 `pipeline/news_keywords.json`）→ 自动展开为该板块的关键词组，
  解决「关键词选偏就窗口内无」的问题；
- **原始关键词** → 按原样检索，保持向后兼容。

用法：
    python -m pipeline.news 2026-11-09 影视院线 数字媒体     # 板块名自动展开
    python -m pipeline.news 2026-11-09 电影票房              # 原始关键词
    python -m pipeline.news --list-boards                    # 查看映射覆盖
    python -m pipeline.news --suggest 影视                    # 模糊匹配板块名
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys
import urllib.parse
import urllib.request

BASE = "https://search-api-web.eastmoney.com/search/jsonp"
HERE = os.path.dirname(os.path.abspath(__file__))
MAP_PATH = os.path.join(HERE, "news_keywords.json")


def _load_map() -> dict[str, list[str]]:
    if not os.path.exists(MAP_PATH):
        return {}
    with io.open(MAP_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: v for k, v in raw.items() if not k.startswith("_") and isinstance(v, list)}


def fetch(keyword: str, size: int = 20) -> list[dict]:
    param = {
        "uid": "", "keyword": keyword, "type": ["cmsArticleWebOld"],
        "client": "web", "clientType": "web", "clientVersion": "curr",
        "param": {"cmsArticleWebOld": {
            "searchScope": "default", "sort": "time",
            "pageIndex": 1, "pageSize": size,
            "preTag": "", "postTag": ""}},
    }
    url = f"{BASE}?cb=cb&param={urllib.parse.quote(json.dumps(param, ensure_ascii=False))}"
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Referer": "https://so.eastmoney.com/"})
    body = urllib.request.urlopen(req, timeout=25).read().decode("utf-8", "ignore")
    body = body[body.index("(") + 1:body.rindex(")")]
    j = json.loads(body)
    return ((j.get("result") or {}).get("cmsArticleWebOld")) or []


def _print_rows(rows: list[dict], since: str, limit: int) -> list[dict]:
    """按时间倒序打印，返回窗口内命中的记录（按标题去重）。"""
    hit, seen = [], set()
    for r in rows:
        d = (r.get("date") or "")[:10]
        if not d or d < since:
            continue
        key = (r.get("title") or "").strip()
        if key in seen:
            continue
        seen.add(key)
        hit.append(r)
    for r in hit[:limit]:
        d = (r.get("date") or "")[:10]
        txt = (r.get("content") or "").replace("\n", " ")
        print(f"  [{d}] {r.get('mediaName')} | {r.get('title')}")
        print(f"          {txt[:150]}")
        if r.get("url"):
            print(f"          {r['url']}")
    if len(hit) > limit:
        print(f"  …… 另 {len(hit) - limit} 条未显示")
    return hit


def _run_group(title: str, keywords: list[str], since: str, limit: int,
               stats: list[tuple[str, int, int]]) -> None:
    print("=" * 78)
    print(f"{title}｜关键词 {len(keywords)} 个：{' / '.join(keywords)}")
    total, ok_kw = 0, 0
    for kw in keywords:
        print(f"-- [{kw}]")
        try:
            rows = fetch(kw, 30)
        except Exception as e:  # noqa: BLE001
            print("  ERR", type(e).__name__, e)
            continue
        hit = _print_rows(rows, since, limit)
        if hit:
            ok_kw += 1
            total += len(hit)
        else:
            print("  （窗口内无）")
    name = title.split("｜")[0].strip().removeprefix("板块：").removeprefix("关键词：")
    print(f">>> {name} 命中 {total} 条（去重后），{ok_kw}/{len(keywords)} 个关键词有结果")
    print()
    stats.append((name, total, ok_kw))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="东财资讯检索（板块名自动展开关键词）")
    ap.add_argument("since", nargs="?", help="起始日期 YYYY-MM-DD（含）")
    ap.add_argument("tokens", nargs="*", help="板块名或原始关键词")
    ap.add_argument("--max", type=int, default=4,
                    help="每个关键词最多展示的条数（默认 4；单关键词深挖时可给 12）")
    ap.add_argument("--list-boards", action="store_true", help="列出关键词映射覆盖的板块")
    ap.add_argument("--suggest", metavar="KW", help="模糊匹配板块名")
    args = ap.parse_args(argv)

    mapping = _load_map()

    if args.list_boards:
        print(f"映射表 {MAP_PATH}\n共 {len(mapping)} 个板块：\n")
        for name, kws in sorted(mapping.items()):
            print(f"  {name:<10} {' / '.join(kws)}")
        return 0

    if args.suggest:
        hits = [n for n in mapping if args.suggest in n]
        print(f"匹配「{args.suggest}」：{('、'.join(hits)) if hits else '无'}")
        return 0 if hits else 1

    if not args.since or not args.tokens:
        ap.print_help()
        return 2

    since = args.since
    print(f"# 东财资讯检索  起始 {since}  共 {len(args.tokens)} 个入参\n")

    stats: list[tuple[str, int, int]] = []
    for token in args.tokens:
        if token in mapping:
            _run_group(f"板块：{token}", mapping[token], since, args.max, stats)
            continue
        if token.startswith("@") and token[1:] in mapping:
            _run_group(f"板块：{token[1:]}", mapping[token[1:]], since, args.max, stats)
            continue
        if token.startswith("@"):
            print(f"[unmapped] @{token[1:]} 不在映射表里，回退为原始关键词\n")
            token = token[1:]
        _run_group(f"关键词：{token}", [token], since, max(args.max, 8), stats)

    if len(stats) > 1:
        print("=" * 78)
        print("=== 汇总（命中 0 条的建议换关键词或放宽窗口）===")
        for name, total, ok_kw in stats:
            flag = "  ← 窗口内无" if total == 0 else ""
            print(f"  {name:<16} 命中 {total:>3} 条   有结果关键词 {ok_kw}{flag}")
        bad = [n for n, t, _ in stats if t == 0]
        if bad:
            print(f"\n  0 命中：{'、'.join(bad)}——先换行业词/产品词，不要直接放弃该板块")
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""叙事权重的影子评分验证（只读，不改榜单、不回写任何缓存）。

    python -m pipeline.shadow_narrative --weight 10 --horizons 1,5

回答一个问题：把叙事分按 w% 计入总分后，排名与「之后 h 个交易日收益」的关系，
比现在的 0 权重更好还是更差。

    shadow = score × (1 − w) + narrative × w        # 缺失时取 score（中性）
    naive  = score × (1 − w) + narrative × w        # 缺失时取 0（暴露覆盖偏差）

为什么缺失要中性：叙事分只为候选板块手写，未评不是 0 分。缺失记 0 会系统性压低
那些「没被评」的板块，而谁被评又由闸门决定——等于用结果解释结果。naive 口径
放在结果里，是为了让这个偏差可量化，而不是留一句口头提醒。

样本边界必须如实说明：叙事台账从 2026-10-30 才有，score 缓存只有 6 天，
其中 11-06 是空榜日（0 个候选）。本脚本给出的是**方向性检查**，不是显著性检验；
随着每日运行积累，重跑同一条命令即可更新。
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

CACHE = ROOT / "pipeline" / "cache"


def _rank(xs: list[float]) -> list[float]:
    """平均秩（并列取均值）。"""
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    out = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1
        for k in range(i, j + 1):
            out[order[k]] = avg
        i = j + 1
    return out


def spearman(xs: list[float], ys: list[float]) -> float | None:
    """秩相关。样本 < 3 时没有意义，直接返回 None。"""
    if len(xs) < 3 or len(xs) != len(ys):
        return None
    rx, ry = _rank(xs), _rank(ys)
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    dx = sum((a - mx) ** 2 for a in rx) ** 0.5
    dy = sum((b - my) ** 2 for b in ry) ** 0.5
    return None if dx == 0 or dy == 0 else num / (dx * dy)


def forward_return(panel: dict, code: str, date: str, h: int) -> float | None:
    """从 date 之后第 1 根 K 线起，往后 h 个交易日的复合收益。样本不足返回 None。"""
    hist = (panel.get("history") or {}).get(code) or []
    idx = next((i for i, (d, _) in enumerate(hist) if d == date), None)
    if idx is None or len(hist) - idx - 1 < h:
        return None
    prod = 1.0
    for _, pct in hist[idx + 1: idx + 1 + h]:
        prod *= 1.0 + pct / 100.0
    return prod - 1.0


def latest_panel() -> tuple[dict, str]:
    files = sorted(CACHE.glob("panel-*.pkl"))
    if not files:
        raise SystemExit("没有 panel-*.pkl，无法计算前瞻收益")
    p = files[-1]
    return pickle.loads(p.read_bytes()), p.stem.split("-", 1)[1]


def load_score_days() -> list[dict]:
    out = []
    for p in sorted(CACHE.glob("score-*.json")):
        d = json.loads(p.read_text(encoding="utf-8"))
        out.append({"date": d.get("as_of") or p.stem.split("-", 1)[1], "rows": d.get("rows") or []})
    return out


def build_obs(rows: list[dict], panel: dict, date: str, w: float, h: int) -> list[dict]:
    """某一天、某个期限下可评估的候选板块观测。"""
    obs = []
    for r in rows:
        if (r.get("gates") or 0) < 2 or r.get("score") is None:
            continue
        fr = forward_return(panel, r["code"], date, h)
        if fr is None:
            continue
        n = (r.get("norm") or {}).get("narrative")
        base = float(r["score"])
        obs.append({
            "code": r["code"], "name": r["name"], "base": base, "narr": n,
            "shadow": round(base * (1 - w) + (n if n is not None else base) * w, 4),
            "naive": round(base * (1 - w) + (n if n is not None else 0.0) * w, 4),
            "fwd": fr,
        })
    return obs


def mean(xs: list[float | None]) -> float | None:
    vals = [x for x in xs if x is not None]
    return sum(vals) / len(vals) if vals else None


def top_avg(obs: list[dict], key: str, k: int) -> float | None:
    if not obs:
        return None
    picked = sorted(obs, key=lambda o: -o[key])[:k]
    return sum(o["fwd"] for o in picked) / len(picked)


def main() -> int:
    ap = argparse.ArgumentParser(description="叙事权重的影子评分验证")
    ap.add_argument("--weight", type=float, default=10.0, help="叙事权重（%），默认 10")
    ap.add_argument("--horizons", default="1,5", help="前瞻交易日数，逗号分隔，默认 1,5")
    ap.add_argument("--top", type=int, default=3, help="TOP-N 平均收益的 N，默认 3")
    args = ap.parse_args()

    w = args.weight / 100.0
    horizons = [int(x) for x in args.horizons.split(",") if x.strip()]
    panel, panel_date = latest_panel()
    days = load_score_days()

    print(f"影子评分：叙事权重 {args.weight:g}%（缺失按中性处理）| 前瞻源 panel-{panel_date}")
    print("候选口径：当日通过 ≥2 条闸门的板块；空榜日无可评估观测\n")

    for h in horizons:
        print(f"{'=' * 72}\n前瞻 {h} 个交易日\n{'=' * 72}")
        print(f"  {'日期':<12}{'n':>3}{'IC基':>8}{'IC影':>8}{'IC零':>8}"
              f"{'TOP1基':>9}{'TOP1影':>9}{f'TOP{args.top}基':>9}{f'TOP{args.top}影':>9}")
        pooled = []
        for day in days:
            obs = build_obs(day["rows"], panel, day["date"], w, h)
            if not obs:
                continue
            ic_b = spearman([o["base"] for o in obs], [o["fwd"] for o in obs])
            ic_s = spearman([o["shadow"] for o in obs], [o["fwd"] for o in obs])
            ic_n = spearman([o["naive"] for o in obs], [o["fwd"] for o in obs])
            pooled.append({"date": day["date"], "obs": obs, "ic_b": ic_b, "ic_s": ic_s, "ic_n": ic_n})
            p = lambda v: "  n/a" if v is None else f"{v * 100:+.2f}%"  # noqa: E731
            icf = lambda v: "   n/a" if v is None else f"{v:+.3f}"  # noqa: E731
            print(f"  {day['date']:<12}{len(obs):>3}{icf(ic_b):>8}{icf(ic_s):>8}{icf(ic_n):>8}"
                  f"{p(top_avg(obs, 'base', 1)):>9}{p(top_avg(obs, 'shadow', 1)):>9}"
                  f"{p(top_avg(obs, 'base', args.top)):>9}{p(top_avg(obs, 'shadow', args.top)):>9}")

        if not pooled:
            print("  没有同时具备候选与前瞻收益的日期（样本尚未积累）\n")
            continue

        mb, ms, mn = mean([x["ic_b"] for x in pooled]), mean([x["ic_s"] for x in pooled]), mean([x["ic_n"] for x in pooled])
        better = sum(1 for x in pooled if x["ic_b"] is not None and x["ic_s"] is not None
                     and x["ic_s"] > x["ic_b"])
        valid = sum(1 for x in pooled if x["ic_b"] is not None and x["ic_s"] is not None)
        fmt = lambda v: "n/a" if v is None else f"{v:+.3f}"  # noqa: E731
        print(f"\n  汇总：{len(pooled)} 天可用 | 平均 IC 基 {fmt(mb)} / 影 {fmt(ms)} / 零 {fmt(mn)}"
              f" | 影子优于基准 {better}/{valid} 天")
        # 排名变动：只在叙事缺失比例高时才有意义，顺手列出来
        for x in pooled:
            changed = sum(1 for a, b in zip(
                sorted(x["obs"], key=lambda o: -o["base"]),
                sorted(x["obs"], key=lambda o: -o["shadow"])) if a["code"] != b["code"])
            miss = sum(1 for o in x["obs"] if o["narr"] is None)
            print(f"    {x['date']}：序位变动 {changed}/{len(x['obs'])}，叙事缺失 {miss}")
        print()

    print("提示：样本 < 30 天时只能看方向，不能看显著性；重跑同一命令即可随日积累。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

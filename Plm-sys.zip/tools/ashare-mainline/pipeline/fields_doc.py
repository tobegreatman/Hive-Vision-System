"""字段枚举文档：以 schema 为唯一真源，自动生成枚举表并同步到 prompt / SKILL。

背景：枚举值此前只在 schema 里，prompt 手抄了一份（还漏了 `trend`），SKILL 完全没写。
手抄必然漂移，所以这里改成「schema → 生成表 → 注入文档标记块」，并用 `--check`
在流水线里做同步校验。

用法：
    python -m pipeline.fields_doc            # 打印当前枚举表
    python -m pipeline.fields_doc --check    # 校验 prompt / SKILL 是否与 schema 同步（不同步退出码 1）
    python -m pipeline.fields_doc --write    # 把生成结果写回两个文档的标记块
"""
from __future__ import annotations

import argparse
import io
import json
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHEMA = os.path.join(BASE, "schema", "ashare-mainline.schema.json")
PROMPT = os.path.join(BASE, "prompt", "ashare-mainline-prompt.md")
SKILLS = ("ashare-mainline-analysis", "SKILL.md")


def _skill_docs() -> list[str]:
    """技能目录可能有三份（项目 .workbuddy / 项目 .trae / 用户级），全部同步，别只改一份。

    SKILL.md 自己写明「同一份目录可直接用于 Trae 与 WorkBuddy」，所以这里不能写死
    `.workbuddy`：换到 Trae 环境或改成用户级安装时，写死会静默跳过、枚举表悄悄过期。
    环境变量 ASHARE_MAINLINE_SKILL 可显式指定单个路径。
    """
    repo = os.path.abspath(os.path.join(BASE, "..", ".."))
    home = os.path.expanduser("~")
    out: list[str] = []
    env = os.environ.get("ASHARE_MAINLINE_SKILL")
    if env:
        out.append(os.path.abspath(env))
    for root in (repo, home):
        for skills_dir in (".workbuddy/skills", ".trae/skills", ".trae-cn/skills"):
            out.append(os.path.join(root, skills_dir, *SKILLS))
    return [p for i, p in enumerate(out) if p and os.path.exists(p)]


def _source_skill() -> str | None:
    """项目内的 .workbuddy 副本是真源；其余（.trae / 用户级）是镜像，应逐字节相同。"""
    repo = os.path.abspath(os.path.join(BASE, "..", ".."))
    src = os.path.join(repo, ".workbuddy", "skills", *SKILLS)
    docs = _skill_docs()
    return src if src in docs else (docs[0] if docs else None)


def _targets() -> list[str]:
    """只同步带标记块的文档；镜像整份复制，不走标记块。"""
    return [PROMPT] + [p for p in _skill_docs() if BEGIN in io.open(p, encoding="utf-8").read()]


def _mirrors() -> list[str]:
    src = _source_skill()
    return [p for p in _skill_docs() if src and p != src]

BEGIN = "<!-- ENUMS:BEGIN 由 python -m pipeline.fields_doc --write 生成，勿手改 -->"
END = "<!-- ENUMS:END -->"

# 表格顺序（人工排定，便于阅读）；schema 里新增而这里没列的会自动追加到末尾
ORDER = [
    "meta.data_mode",
    "market_regime.phase",
    "market_regime.leverage.scope",
    "market_regime.leverage.trend",
    "verdict.stance",
    "mainlines[].stage",
    "mainlines[].theme_type",
    "mainlines[].drivers[].type",
    "mainlines[].leaders[].role",
    "mainlines[].score_breakdown[].key",
    "rotation.timeline[].impact",
    "risks[].level",
    "data_quality.status",
    "data_quality.sources[].reliability",
    "data_quality.coverage_detail[].state",
]

# 补充说明。键必须与 schema 路径一致；缺省则说明列留空
NOTES = {
    "meta.data_mode": "`live` 为盘后实测，`delayed` 为延时源，`demo` 仅用于模板",
    "market_regime.phase": "由广度、量能、两融三者共同判定，不由单一指标决定",
    "market_regime.leverage.scope": "口径一次性选定，同一期不得混算沪深北与单市",
    "market_regime.leverage.trend": "由 `chg_20d` 机械映射：≤ −3% → deleveraging，≥ +3% → releveraging，其间为 stable",
    "verdict.stance": "仓位档位：offensive 七成以上、balanced 五到六成、defensive 三成以下",
    "mainlines[].stage": "六阶段。**`stage` 不允许 null**：判据不足的板块写 null 时改用 `rotation.emerging`，不得进 `mainlines`",
    "mainlines[].theme_type": "行业型 / 概念型 / 风格型。描述主线**本身**的类别，与 `drivers[].type` 的驱动来源不是一回事",
    "mainlines[].drivers[].type": "驱动来源。资金流用 `liquidity`，公司事件用 `event`，**不要自造 `fundflow` / `company` / `risk`**",
    "mainlines[].leaders[].role": "leader 为板块龙头，core 为核心跟风，follower 为扩散标的",
    "mainlines[].score_breakdown[].key": "六因子键名，须与权重表一一对应",
    "rotation.timeline[].impact": "对主线的影响方向，不是涨跌方向",
    "risks[].level": "high 需给出对冲动作，medium 需给出观察条件，low 仅提示",
    "data_quality.status": "partial 需在 `notes` 写明缺什么、缺多久",
    "data_quality.sources[].reliability": "与 `data_quality.notes` 的取数交叉校验说明保持一致",
    "data_quality.coverage_detail[].state": "full 为全量取到，degraded 为代理指标，missing 为未取到",
}


def _walk(node, path=""):
    """产出 (path, enum_values) 对，数组用 `[]` 后缀。"""
    if isinstance(node, dict):
        if isinstance(node.get("enum"), list):
            # JSON 的 null 在 Python 里是 None，展示时还原成 `null`
            yield path, ["null" if x is None else str(x) for x in node["enum"]]
        for key, val in node.items():
            if key in ("enum", "description", "title", "examples"):
                continue
            if key == "properties" and isinstance(val, dict):
                for name, sub in val.items():
                    yield from _walk(sub, f"{path}.{name}" if path else name)
            elif key == "items":
                yield from _walk(val, f"{path}[]" if path else "[]")
            elif key in ("definitions", "$defs") and isinstance(val, dict):
                for name, sub in val.items():
                    yield from _walk(sub, name)
    elif isinstance(node, list):
        for item in node:
            yield from _walk(item, path)


def collect(path: str = SCHEMA) -> list[tuple[str, list[str]]]:
    with io.open(path, "r", encoding="utf-8") as f:
        schema = json.load(f)
    found = dict(_walk(schema))
    ranked = sorted(found.items(), key=lambda kv: (
        ORDER.index(kv[0]) if kv[0] in ORDER else len(ORDER), kv[0]))
    return ranked


def render_rows(rows: list[tuple[str, list[str]]]) -> list[str]:
    out = ["| 字段 | 允许值 | 说明 |", "|---|---|---|"]
    for path, values in rows:
        cells = " / ".join(f"`{v}`" for v in values)
        out.append(f"| `{path}` | {cells} | {NOTES.get(path, '')} |")
    return out


def block(rows: list[tuple[str, list[str]]] | None = None) -> str:
    rows = rows if rows is not None else collect()
    return "\n".join([BEGIN, ""] + render_rows(rows) + ["", END])


def _replace_block(text: str, new_block: str, where: str) -> str:
    if BEGIN not in text or END not in text:
        raise SystemExit(
            f"{where} 缺少标记块：请先插入\n  {BEGIN}\n  {END}\n再运行 --write")
    head, rest = text.split(BEGIN, 1)
    _, tail = rest.split(END, 1)
    return head + new_block + tail


def check(verbose: bool = True) -> bool:
    rows = collect()
    expect = block(rows)
    ok = True
    for path in _targets():
        if not os.path.exists(path):
            if verbose:
                print(f"[skip] 不存在：{path}")
            continue
        text = io.open(path, "r", encoding="utf-8").read()
        if BEGIN not in text or END not in text:
            if verbose:
                print(f"[miss] {os.path.basename(path)} 无枚举标记块")
            ok = False
            continue
        current = BEGIN + text.split(BEGIN, 1)[1].split(END, 1)[0] + END
        if current.strip() != expect.strip():
            ok = False
            if verbose:
                print(f"[drift] {path}")
                cur_paths = {ln.split("|")[1].strip().strip("`")
                             for ln in current.split("\n") if ln.startswith("| `")}
                new_paths = {p for p, _ in rows}
                for p in sorted(new_paths - cur_paths):
                    print(f"        文档缺字段：{p}")
                for p in sorted(cur_paths - new_paths):
                    print(f"        文档多字段：{p}（schema 已无）")
                if cur_paths == new_paths:
                    print("        字段集合一致但取值不同，直接 --write 覆盖")
        elif verbose:
            print(f"[ok] {os.path.basename(path)} 枚举同步")

    src = _source_skill()
    for m in _mirrors():
        if src and io.open(m, encoding="utf-8").read() != io.open(src, encoding="utf-8").read():
            ok = False
            if verbose:
                rel = os.path.relpath(m, os.path.abspath(os.path.join(BASE, "..", "..")))
                print(f"[drift] 镜像未同步：{rel}（跑 --mirror 用 {os.path.basename(src)} 覆盖）")
        elif verbose:
            print(f"[ok] 镜像一致：{os.path.relpath(m, os.path.abspath(os.path.join(BASE, '..', '..')))}")
    return ok


def write() -> None:
    new_block = block()
    for path in _targets():
        if not os.path.exists(path):
            print(f"[skip] 不存在：{path}")
            continue
        text = io.open(path, "r", encoding="utf-8").read()
        io.open(path, "w", encoding="utf-8", newline="\n").write(
            _replace_block(text, new_block, path))
        print(f"[write] {path}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="从 schema 生成字段枚举表并同步文档")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--check", action="store_true", help="校验文档是否与 schema 同步")
    g.add_argument("--write", action="store_true", help="写回 prompt 与 SKILL 的标记块")
    g.add_argument("--mirror", action="store_true",
                   help="把项目 .workbuddy 的 SKILL.md 整份复制到 .trae / 用户级副本")
    args = ap.parse_args(argv)

    if args.write:
        write()
        return 0
    if args.mirror:
        src = _source_skill()
        if not src:
            raise SystemExit("找不到技能源文件（.workbuddy/skills/ashare-mainline-analysis/SKILL.md）")
        body = io.open(src, encoding="utf-8").read()
        for m in _mirrors():
            io.open(m, "w", encoding="utf-8", newline="\n").write(body)
            print(f"[mirror] {m}")
        return 0
    if args.check:
        return 0 if check() else 1
    rows = collect()
    print(f"schema 共 {len(rows)} 组枚举：\n")
    print("\n".join(render_rows(rows)))
    return 0


if __name__ == "__main__":
    sys.exit(main())

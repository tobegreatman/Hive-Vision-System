"""板块级广度：把「上涨占比 / 强势股占比 / 涨停占比」算到**全部板块**上。

背景（v1.9）：breadth 因子的横截面分位原先只在「进了闸门的候选」里排（11-05 是 9 个）。
9 个候选全是强票，彼此比较会把大多数压到低分位——出版上涨占比 89.3% 却排 18.2 分位；
而且这个分母随「今天有几个板块过闸门」漂移，同一个板块的分数会因为别人涨跌而变。
现在三个分项全部在同一天的全部板块上算，分母固定、无选择偏差。

口径：
  - 有效样本 = 有报价且 price>0、昨收>0 的成分股（停牌不计入分子分母）；
  - 上涨占比 = 现价 > 昨收 的家数 ÷ 有效家数（用价格比，不用 changepercent 的两位小数）；
  - 强势股占比 = 涨幅 ≥ 5% 的家数 ÷ 有效家数；
  - 涨停占比 = 涨停池里属于该板块的家数 ÷ 有效家数（用占比而不是家数，避免大板块占便宜）。

数据来源全部是本地/已落盘的东西，**零额外请求**：
  - 全 A 快照 quotes-all-<as_of>.json（breadth 模块每天已经在拉；缺了才现拉一次）
  - 成分表 codes-<board>.json（一次性回填，存在即复用）
  - 涨停池 limit-<as_of>.json

    python -m pipeline.boardbreadth --as-of 2026-11-05
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pipeline import day

CACHE = Path(__file__).resolve().parent / "cache"


def _snapshot(as_of: str) -> list[dict]:
    p = CACHE / f"quotes-all-{as_of}.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    from pipeline import breadth as market  # noqa: PLC0415

    rows = market.fetch_all()
    p.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    return rows


def _members() -> dict[str, list[str]]:
    out = {}
    for f in CACHE.glob("codes-BK*.json"):
        out[f.stem.split("-", 1)[1]] = [str(x).zfill(6) for x in
                                        json.loads(f.read_text(encoding="utf-8"))]
    return out


def build(as_of: str) -> dict:
    rows = _snapshot(as_of)
    quote = {str(r.get("code")).zfill(6): r for r in rows}
    lim_p = CACHE / f"limit-{as_of}.json"
    lim = json.loads(lim_p.read_text(encoding="utf-8")) if lim_p.exists() else {}
    zt = {str(r["code"]).zfill(6) for r in lim.get("limit_up", [])}

    boards: dict[str, dict] = {}
    for code, mem in _members().items():
        valid = up = strong = zt_n = 0
        for m in mem:
            r = quote.get(m)
            if not r:
                continue
            try:
                px, pre = float(r["trade"]), float(r["settlement"])
            except (KeyError, TypeError, ValueError):
                continue
            if px <= 0 or pre <= 0:
                continue
            valid += 1
            chg = px / pre - 1
            if px > pre:
                up += 1
            if chg >= 0.05:
                strong += 1
            if m in zt:
                zt_n += 1
        if not valid:                       # 一只都取不到报价：不进表
            continue
        boards[code] = {
            "members": len(mem), "valid": valid, "up": up, "strong": strong, "limit_up": zt_n,
            # valid<5 的板块照常给值（可能是候选，要能查到），但不进分位样本：
            # 3 只成分的板块会让「1 只涨停 = 33%」把整条分位线拉歪。
            "ranked": valid >= 5,
            "up_ratio": round(up / valid, 4),
            "strong_ratio": round(strong / valid, 4),
            "limit_up_ratio": round(zt_n / valid, 4),
        }

    out = {
        "as_of": as_of,
        "universe": len(boards),
        "ranked": sum(1 for v in boards.values() if v["ranked"]),
        "members_total": sum(v["members"] for v in boards.values()),
        "boards": boards,
        "note": ("上涨/强势按全 A 快照（新浪 node=hs_a）与成分表本地计算；涨停取自当日涨停池；"
                 "分母为该板块有报价的成分股数，停牌不计"),
    }
    (CACHE / f"boardbreadth-{as_of}.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def load(as_of: str, *, rebuild: bool = False) -> dict:
    p = CACHE / f"boardbreadth-{as_of}.json"
    if p.exists() and not rebuild:
        return json.loads(p.read_text(encoding="utf-8"))
    return build(as_of)


def main() -> None:
    ap = argparse.ArgumentParser()
    day.add_as_of(ap)
    ap.add_argument("--rebuild", action="store_true")
    args = ap.parse_args()
    args.as_of = day.resolve(args.as_of)
    d = load(args.as_of, rebuild=args.rebuild)
    b = d["boards"]
    print(f"  {args.as_of}：{d['universe']} 个板块，成分 {d['members_total']} 只（去重后按板块计）")
    top = sorted(b.items(), key=lambda kv: -kv[1]["up_ratio"])[:5]
    for code, v in top:
        print(f"    {code} up {v['up_ratio']:.1%} strong {v['strong_ratio']:.1%} zt {v['limit_up_ratio']:.1%}")
    print(f"  -> boardbreadth-{args.as_of}.json")


if __name__ == "__main__":
    main()

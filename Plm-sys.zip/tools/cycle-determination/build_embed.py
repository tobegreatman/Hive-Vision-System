"""把经济周期定位 JSON 注入 dashboard.html，产出 /cycle 页面。

用法（在仓库根目录或本目录执行均可）：
    python tools/cycle-determination/build_embed.py
    python tools/cycle-determination/build_embed.py --data tools/cycle-determination/samples/10-20.json
    python tools/cycle-determination/build_embed.py --no-dist

默认读取 samples/11-01.json，写入 public/cycle/index.html；若仓库存在 dist/，
同时覆盖 dist/cycle/index.html，避免本地构建产物继续显示旧一期。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
DEFAULT_TEMPLATE = HERE / "dashboard.html"
DEFAULT_DATA = HERE / "samples" / "11-01.json"
DEFAULT_OUT = REPO / "public" / "cycle" / "index.html"

CYCLE_KEYS = ("kichin", "juglar", "kuznets", "kondratieff")
CYCLE_LABELS = {"kichin": "基钦", "juglar": "朱格拉", "kuznets": "库兹涅茨", "kondratieff": "康波"}
DEMO_DATA_RE = re.compile(
    r'(<script type="application/json" id="demo-data">)(.*?)(</script>)',
    re.S,
)


def fail(message: str) -> None:
    print(f"[build_embed] 校验失败：{message}", file=sys.stderr)
    raise SystemExit(1)


def validate(data: object) -> None:
    """按《周期定位提示词》的输出契约做硬校验，避免把半成品发到页面。"""
    if not isinstance(data, dict):
        fail("顶层必须是 JSON 对象")
    cycles = data.get("cycles")
    if not isinstance(cycles, dict):
        fail("缺少 cycles 字段")
    for key in CYCLE_KEYS:
        cycle = cycles.get(key)
        label = CYCLE_LABELS[key]
        if not isinstance(cycle, dict):
            fail(f"缺少 cycles.{key}（{label}周期）")
        phase = cycle.get("phase")
        if not isinstance(phase, (int, float)) or not 0 <= phase <= 1:
            fail(f"{label}周期 phase 必须是 0-1 小数")
        evidence = cycle.get("evidence")
        if not isinstance(evidence, list) or len(evidence) < 3:
            fail(f"{label}周期 evidence 至少 3 条")

    industries = data.get("industries")
    if not isinstance(industries, list) or len(industries) != 24:
        fail(f"industries 必须恰好 24 项，当前 {len(industries) if isinstance(industries, list) else 0} 项")

    top3 = data.get("top3")
    if not isinstance(top3, list) or len(top3) != 3:
        fail("top3 必须恰好 3 项")

    watchlist = data.get("watchlist")
    if not isinstance(watchlist, list) or len(watchlist) != 5:
        fail("watchlist 必须恰好 5 项")

    if not isinstance(data.get("nesting"), dict):
        fail("缺少 nesting 字段")
    if not data.get("as_of"):
        fail("缺少 as_of 字段")


def render(template: str, data: dict) -> str:
    if not DEMO_DATA_RE.search(template):
        fail('模板中找不到 <script type="application/json" id="demo-data"> 区块')
    # `</` 转义成 `<\/`，避免 JSON 字符串提前闭合 script 标签
    payload = json.dumps(data, ensure_ascii=False, indent=2).replace("</", "<\\/")
    return DEMO_DATA_RE.sub(lambda m: m.group(1) + "\n" + payload + "\n" + m.group(3), template, count=1)


def main() -> None:
    parser = argparse.ArgumentParser(description="注入经济周期定位数据并生成 /cycle 页面")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA, help="周期定位 JSON")
    parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE, help="dashboard 模板")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="页面输出路径")
    parser.add_argument("--no-dist", action="store_true", help="只写 public/，不覆盖 dist/")
    args = parser.parse_args()

    data_path = args.data if args.data.is_absolute() else (REPO / args.data)
    template_path = args.template if args.template.is_absolute() else (REPO / args.template)
    out_path = args.out if args.out.is_absolute() else (REPO / args.out)

    data = json.loads(data_path.read_text(encoding="utf-8"))
    validate(data)
    template = template_path.read_text(encoding="utf-8")
    html = render(template, data)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    print(f"[build_embed] 已写入 {out_path}（数据 {data_path.name}，revision {data.get('meta', {}).get('revision', '—')}）")

    dist_out = REPO / "dist" / "cycle" / "index.html"
    if not args.no_dist and (REPO / "dist").is_dir():
        dist_out.parent.mkdir(parents=True, exist_ok=True)
        dist_out.write_text(html, encoding="utf-8")
        print(f"[build_embed] 已同步 {dist_out}")


if __name__ == "__main__":
    main()

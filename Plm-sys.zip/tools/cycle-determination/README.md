# 经济周期定位 · 提示词 + 数据 + 页面

把 `Cycle-Determination` 的「提示词 → 结构化 JSON → 可视化报告页」完整移植到本项目，
页面入口为 `/cycle`（分析工作台「经济周期」），实际渲染 `public/cycle/index.html`。

## 资产

```
tools/cycle-determination/
├── dashboard.html                    # 报告页模板（内联 Vue 运行时，离线可用）
├── DESIGN.md                         # 页面设计规范（Stripe 风格令牌与组件）
├── prompt/周期定位提示词.md           # 总提示词 + 分周期深挖 + 嵌套研判
├── samples/10-20.json                # 历史基线数据
├── samples/11-01.json                # 当前内置数据（schema 2.1）
├── reports/周期定位报告-2026-11.md    # 配套 Markdown 报告样例
└── build_embed.py                    # 把 JSON 注入模板，生成 public/cycle/index.html
```

- 页面入口 `src/pages/cycle/CyclePage.vue`（iframe）
- 页面产物 `public/cycle/index.html`，构建后同步到 `dist/cycle/index.html`
- 工作台入口 `src/widgets/feature-deck/FeatureDeck.vue`（04 · 经济周期）

## 更新一期定位

1. 从 `prompt/周期定位提示词.md` 复制【一、总提示词】，填入报告时点与地区，交给具备取数能力的 Agent。
2. 取回报告末尾的 `json` 代码块，保存为 `reports/cycle-YYYY-MM.json`。
3. 注入并发布：

```powershell
python tools/cycle-determination/build_embed.py --data tools/cycle-determination/reports/cycle-YYYY-MM.json
```

`build_embed.py` 会按输出契约做硬校验（四周期 phase、每周期证据 ≥3、24 行业、TOP3×3、
跟踪清单×5、nesting），校验不通过直接退出，不会把半成品发到页面。仓库存在 `dist/` 时会
同时覆盖 `dist/cycle/index.html`；只写 public 时加 `--no-dist`。

4. 打开 `http://localhost:8080/cycle` 确认期数、周期卡片、波形叠加、行业分层与 TOP3 均已刷新。

## 数据契约（schema 2.1）

页面只认 `cycles / industries / top3 / nesting` 这组核心字段，`meta` 用于数据质量体检：

- `cycles.{kichin,juglar,kuznets,kondratieff}`：`stage / direction / confidence / phase / evidence / trigger`
- `industries`：恰好 24 项，`inventory / capacity / demand / summary / key_var / action`
- `top3`：恰好 3 项，`rank / name / action / layers / logic / evidence / key_var / risk`
- `nesting`：`state / description / analogy / assets.{equity,bond,commodity,cash,gold}`
- `watchlist`：恰好 5 项；`meta.pending_data / missing_data / weak_evidence` 记录缺口
- `phase` 与 `stage` 的区间映射固定，详见提示词「字段约束」

页面也支持在浏览器内「导入数据」临时预览（写入 localStorage），但正式发布以
`build_embed.py` 注入的内置数据为准；内置数据 revision 更高时会自动丢弃旧草稿。

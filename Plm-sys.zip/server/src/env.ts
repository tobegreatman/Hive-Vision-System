const DEFAULT_CORS_ORIGINS = [
  'http://localhost:8080',
  'http://127.0.0.1:8080',
  'http://localhost:4173',
  'http://127.0.0.1:4173',
]

function parsePort(raw: string | undefined, fallback: number): number {
  const port = Number.parseInt(raw ?? '', 10)
  return Number.isInteger(port) && port > 0 && port < 65536 ? port : fallback
}

function parsePositiveInt(raw: string | undefined, fallback: number): number {
  const value = Number.parseInt(raw ?? '', 10)
  return Number.isInteger(value) && value > 0 ? value : fallback
}

export const serverEnv = {
  port: parsePort(process.env.PORT, 3600),
  host: process.env.HOST ?? '127.0.0.1',
  runtime: `node-${process.versions.node}`,
  corsOrigins: (process.env.CORS_ORIGINS?.split(',')
    .map((value) => value.trim())
    .filter(Boolean) ?? DEFAULT_CORS_ORIGINS) as string[],
  /**
   * 写接口令牌。留空时只在回环地址放行匿名写入（本地开发）；
   * 一旦 `HOST` 指向 0.0.0.0 或对外域名，写接口会直接 503，直到配置令牌。
   */
  writeToken: process.env.WRITE_TOKEN?.trim() ?? '',

  /**
   * 盘面数据模式：
   *   live（默认）→ 服务端抓真实行情，失败才退回内置快照并如实标注 demo
   *   demo        → 强制内置快照，用于完全离线的教学演示
   */
  marketMode: process.env.MARKET_DATA_MODE?.trim() === 'demo' ? 'demo' : 'live',
  /**
   * 盘中快照有效期。一轮全量抓取是 60 页（约 0.5–1.5s），
   * 因此这个值同时是「上游请求频率」的上限：20s ≈ 180 请求/分钟，
   * 再多就该考虑换正式行情授权了。非盘中会自动放宽到分钟级。
   */
  quoteTtlMs: parsePositiveInt(process.env.MARKET_QUOTE_TTL_MS, 20_000),
  /**
   * 每个板块进蜂巢的格子数（按成交额降序取前 N）。
   * 5900 个六边形贴图会把显存与帧率一起拖垮，真实家数另由 `count` 承载。
   */
  samplePerBoard: parsePositiveInt(process.env.MARKET_SAMPLE_PER_BOARD, 60),
  /**
   * 上游请求速率上限（个/秒，令牌桶匀速）。不影响平均负载，只削瞬时脉冲：
   * 20s 一轮 60 页，平均都是 180 次/分钟；不限速时是「0.5s 内打 60 个」，
   * 限速 12 后摊成 5s，风控形状完全不一样。调大以换取更快首帧，调小更保守。
   */
  upstreamQps: parsePositiveInt(process.env.MARKET_UPSTREAM_QPS, 12),
  /** 令牌桶突发容量：空闲后最多能立刻打出多少个（默认 QPS 的一半）。 */
  upstreamBurst: parsePositiveInt(process.env.MARKET_UPSTREAM_BURST, 6),
  /** 熔断基础冷却：连续失败或收到 429/503 后，闭闸这么久不再碰上游。 */
  breakerCooldownMs: parsePositiveInt(process.env.MARKET_BREAKER_COOLDOWN_MS, 60_000),
} as const


import type { ApiError } from '@platform/contracts'
import { Hono } from 'hono'
import { bodyLimit } from 'hono/body-limit'
import { compress } from 'hono/compress'
import { cors } from 'hono/cors'
import { HTTPException } from 'hono/http-exception'
import { logger } from 'hono/logger'
import { secureHeaders } from 'hono/secure-headers'

import { serverEnv } from './env.js'
import { rateLimit } from './middleware/rate-limit.js'
import { writeGuard } from './middleware/write-guard.js'
import { healthRoutes } from './routes/health.js'
import { feedRoutes, intradayRoutes } from './routes/industry.js'
import { marketRoutes } from './routes/market.js'

export const app = new Hono()

/** 写请求体上限：现有最大载荷是新增自选（十余个短字段），8KB 足够且能挡住灌包。 */
const MAX_WRITE_BODY_BYTES = 8 * 1024
const WRITE_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE'])

app.use('*', logger())
/** 给所有响应补上 nosniff / frame-options 一类基线头，避免下游直接透传时缺失。 */
app.use('*', secureHeaders())
/** 行业资金流要透传 496 行原始行情，gzip 能把几百 KB 压到几十 KB。 */
app.use('*', compress())

app.use(
  '*',
  cors({
    // 不回退到「第一个白名单」：那会返回一个与请求方不匹配的值，语义误导且难排查。
    // 返回空串表示不设置该响应头，浏览器自然拒绝跨源。
    origin: (origin) => (origin && serverEnv.corsOrigins.includes(origin) ? origin : ''),
    allowMethods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'X-Write-Token'],
    maxAge: 86400,
  }),
)

/** 写请求体上限：挡掉「一个请求灌几百 MB」这类最低成本的 DoS。 */
const writeBodyLimit = bodyLimit({
  maxSize: MAX_WRITE_BODY_BYTES,
  onError: (c) => {
    const body: ApiError = {
      error: { code: 'payload_too_large', message: '请求体超过 8KB 上限' },
    }
    return c.json(body, 413)
  },
})

app.use('*', async (c, next) => {
  if (!WRITE_METHODS.has(c.req.method)) {
    await next()
    return
  }
  return writeBodyLimit(c, next)
})
app.use('*', writeGuard(serverEnv.writeToken, serverEnv.host))

// 读写分档限流：读路径被前端 20s 轮询，给宽一点；写路径收紧
app.use('*', rateLimit({ windowMs: 60_000, max: 240 }))
app.use(
  '*',
  rateLimit({
    windowMs: 60_000,
    max: 30,
    methods: ['POST', 'PUT', 'PATCH', 'DELETE'],
    // 写请求共用一个桶：按路径分桶的话，换个 id 就是一条新配额
    scope: 'write',
    message: '写操作过于频繁，请稍后再试',
  }),
)
// 取数代理要做 5 次上游分页，比纯内存读贵得多
app.use('/api/feed', rateLimit({ windowMs: 60_000, max: 60, scope: 'feed' }))

app.route('/api/health', healthRoutes)
app.route('/api/market', marketRoutes)
app.route('/api/feed', feedRoutes)
app.route('/api/intraday', intradayRoutes)

app.notFound((c) => {
  const body: ApiError = { error: { code: 'not_found', message: '路由不存在' } }
  return c.json(body, 404)
})

app.onError((error, c) => {
  // 覆盖 onError 会吃掉 Hono 的默认分支：HTTPException（401/413/429 等）必须自己还原，
  // 否则一律降级成 500，状态码就此失真。
  if (error instanceof HTTPException) return error.getResponse()

  console.error('[api] unhandled error:', error)
  const body: ApiError = { error: { code: 'internal_error', message: '服务端内部错误' } }
  return c.json(body, 500)
})

export type AppType = typeof app

import type { MarketKlinePeriod } from '@platform/contracts'

import {
  boardOfCode,
  type KlineBar,
  type WatchedIndexQuote,
  type WatchedIndexTrend,
} from './quote.service.js'

/**
 * 腾讯行情兜底通道。
 *
 * 东财 push2 / push2his 经常对同一出口 IP 直接掐连接（WAF），
 * 自选池如果只绑一个源，用户看到的就是「个股行情暂不可用」。
 * 这里只覆盖自定义板块需要的最小集合：
 * - 批量实时快照 `qt.gtimg.cn`
 * - 日 / 周 / 月 K 线 `web.ifzq.gtimg.cn`
 * - 当日分时 `web.ifzq.gtimg.cn/appstock/app/minute/query`
 *
 * 注意：腾讯只认 sh / sz / bj 前缀，东财 secid 需要先转换。
 */

const QUOTE_ENDPOINT = 'https://qt.gtimg.cn/q='
const KLINE_ENDPOINT = 'https://web.ifzq.gtimg.cn/appstock/app/fqkline/get'
const MINUTE_ENDPOINT = 'https://web.ifzq.gtimg.cn/appstock/app/minute/query'
const TIMEOUT_MS = 8_000
const HEADERS = { Referer: 'https://gu.qq.com/' }

/** 09:30–11:30 + 13:00–15:00，午休折叠。 */
const MORNING_OPEN = 9 * 60 + 30
const MORNING_CLOSE = 11 * 60 + 30
const AFTERNOON_OPEN = 13 * 60
const AFTERNOON_CLOSE = 15 * 60
const SESSION_MINUTES = 240

function tencentSymbol(secid: string): string | null {
  const [marketRaw = '', code = ''] = secid.split('.')
  if (!/^\d{6}$/.test(code)) return null

  const prefix = boardOfCode(code) === 'bse' ? 'bj' : marketRaw === '1' ? 'sh' : 'sz'
  return `${prefix}${code}`
}

function toNumber(value: string | undefined): number | null {
  if (value === undefined || value.trim() === '') return null
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : null
}

function round2(value: number): number {
  return Number(value.toFixed(2))
}

/** 东财口径的 secid → 腾讯代码表；无效的直接丢弃。 */
function pairsOf(secids: readonly string[]): { secid: string; symbol: string }[] {
  return secids.flatMap((secid) => {
    const symbol = tencentSymbol(secid)
    return symbol ? [{ secid, symbol }] : []
  })
}

/**
 * 批量实时快照。返回结构与东财 `WatchedIndexQuote` 完全同构，
 * 上层不用关心当前命中的是哪个源。
 */
export async function fetchTencentQuotes(secids: readonly string[]): Promise<WatchedIndexQuote[]> {
  const pairs = pairsOf(secids)
  if (pairs.length === 0) return []

  const response = await fetch(`${QUOTE_ENDPOINT}${pairs.map((pair) => pair.symbol).join(',')}`, {
    headers: HEADERS,
    signal: AbortSignal.timeout(TIMEOUT_MS),
  })
  if (!response.ok) throw new Error(`腾讯行情不可用（${response.status}）`)

  // 腾讯返回 GBK 编码的 `v_sh600519="..."`，按行拆开后逐只映射回 secid
  const text = new TextDecoder('gbk').decode(await response.arrayBuffer())
  const bySymbol = new Map<string, WatchedIndexQuote>()
  const secidBySymbol = new Map(pairs.map((pair) => [pair.symbol, pair.secid]))

  for (const line of text.split('\n')) {
    const match = /^v_(\w+)="([^"]*)"/.exec(line.trim())
    if (!match) continue
    const symbol = match[1] ?? ''
    const fields = (match[2] ?? '').split('~')
    if (fields.length < 38) continue

    const code = fields[2] ?? ''
    const price = toNumber(fields[3])
    const preClose = toNumber(fields[4])
    if (!code || price === null || price <= 0) continue

    const change = toNumber(fields[31]) ?? (preClose ? price - preClose : 0)
    const changePct =
      toNumber(fields[32]) ?? (preClose && preClose > 0 ? (change / preClose) * 100 : 0)
    const secid = secidBySymbol.get(symbol)
    if (!secid) continue

    bySymbol.set(symbol, {
      secid,
      code,
      market: Number.parseInt(secid.split('.')[0] ?? '0', 10) || 0,
      name: (fields[1] ?? code).trim(),
      price,
      change: round2(change),
      changePct: round2(changePct),
      preClose: round2(preClose ?? price),
      high: toNumber(fields[33]) ?? price,
      low: toNumber(fields[34]) ?? price,
      // 腾讯成交额字段单位是万元，统一折算成「亿元」与东财口径一致
      turnover: round2((toNumber(fields[37]) ?? 0) / 1e4),
    })
  }

  return [...bySymbol.values()]
}

/** 分钟下标：09:30 为 0，11:30 为 120，13:00 为 120，15:00 为 240。 */
function minuteOffset(hhmm: string): number {
  if (!/^\d{4}$/.test(hhmm)) return -1
  const total = Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(2, 4))

  if (total >= MORNING_OPEN && total <= MORNING_CLOSE) return total - MORNING_OPEN
  if (total >= AFTERNOON_OPEN && total <= AFTERNOON_CLOSE) {
    return 120 + (total - AFTERNOON_OPEN)
  }
  return -1
}

/** 当日分时：返回与东财 trends2 相同的稀疏点列（下标即第几分钟）。 */
export async function fetchTencentTrend(secid: string): Promise<WatchedIndexTrend | null> {
  const symbol = tencentSymbol(secid)
  if (!symbol) return null

  const response = await fetch(`${MINUTE_ENDPOINT}?code=${symbol}`, {
    headers: HEADERS,
    signal: AbortSignal.timeout(TIMEOUT_MS),
  })
  if (!response.ok) throw new Error(`腾讯分时不可用（${response.status}）`)

  const payload = (await response.json().catch(() => null)) as {
    data?: Record<
      string,
      {
        data?: { data?: unknown }
        qt?: Record<string, unknown>
      }
    >
  } | null

  const block = payload?.data?.[symbol]
  const rawRows = block?.data?.data
  if (!Array.isArray(rawRows) || rawRows.length === 0) return null

  const points: number[] = new Array<number>(SESSION_MINUTES + 1).fill(0)
  for (const raw of rawRows) {
    if (typeof raw !== 'string') continue
    const [time = '', priceRaw = ''] = raw.split(' ')
    const offset = minuteOffset(time)
    const price = toNumber(priceRaw)
    if (offset < 0 || price === null || price <= 0) continue
    points[offset] = price
  }

  const qt = block?.qt?.[symbol]
  const preClose = Array.isArray(qt) ? toNumber(String(qt[4] ?? '')) : null

  if (!points.some((point) => point > 0)) return null
  return { points, preClose, axisMinutes: SESSION_MINUTES }
}

/** 日 / 周 / 月 K 线（前复权）。 */
export async function fetchTencentKline(
  secid: string,
  period: MarketKlinePeriod,
  limit: number,
): Promise<KlineBar[]> {
  const symbol = tencentSymbol(secid)
  if (!symbol) return []

  const unit = period === 'day' ? 'day' : period === 'week' ? 'week' : 'month'
  const url = `${KLINE_ENDPOINT}?param=${symbol},${unit},,,${limit},qfq`
  const response = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(TIMEOUT_MS) })
  if (!response.ok) throw new Error(`腾讯 K 线不可用（${response.status}）`)

  const payload = (await response.json().catch(() => null)) as {
    data?: Record<string, Record<string, unknown>>
  } | null
  const block = payload?.data?.[symbol]
  // 前复权的 key 是 qfqday / qfqweek / qfqmonth；个别标的会退回不带前缀的原始 key
  const rawRows = block?.[`qfq${unit}`] ?? block?.[unit]
  if (!Array.isArray(rawRows)) return []

  const bars: KlineBar[] = []
  for (const raw of rawRows) {
    if (!Array.isArray(raw)) continue
    const [atRaw, openRaw, closeRaw, highRaw, lowRaw, volumeRaw] = raw as unknown[]
    const at = String(atRaw ?? '')
    const open = toNumber(String(openRaw ?? ''))
    const close = toNumber(String(closeRaw ?? ''))
    const high = toNumber(String(highRaw ?? ''))
    const low = toNumber(String(lowRaw ?? ''))
    if (!/^\d{4}-\d{2}-\d{2}$/.test(at)) continue
    if (open === null || close === null || high === null || low === null) continue
    if (open <= 0 || close <= 0 || high <= 0 || low <= 0) continue

    const previous = bars[bars.length - 1]
    const changePct =
      previous && previous.close > 0 ? ((close - previous.close) / previous.close) * 100 : 0

    bars.push({
      at,
      open,
      close,
      high,
      low,
      volume: Math.max(0, toNumber(String(volumeRaw ?? '')) ?? 0),
      // 腾讯不直接给成交额，盘口也不展示，留 0 比编一个近似值诚实
      amount: 0,
      changePct: round2(changePct),
    })
  }

  return bars
}

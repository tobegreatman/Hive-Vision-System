import { describe, expect, it } from 'vitest'

import {
  backoffDelay,
  parseRetryAfter,
  UpstreamBreakerOpenError,
  UpstreamLimiter,
} from './upstream-limiter.js'

/**
 * 跟随真实时间的时钟：`advance()` 在此之上再叠加偏移。
 * 令牌桶的补充依赖时间推进，用完全静止的假时钟会让队列永远等不到令牌。
 */
function liveClock() {
  let drift = 0
  return {
    now: () => Date.now() + drift,
    advance(ms: number) {
      drift += ms
    },
  }
}

describe('backoffDelay', () => {
  it('按 2 的幂增长，且被上限截断', () => {
    expect(backoffDelay(0, 400, 2_000, () => 1)).toBe(400)
    expect(backoffDelay(1, 400, 2_000, () => 1)).toBe(800)
    expect(backoffDelay(2, 400, 2_000, () => 1)).toBe(1_600)
    // 800 × 2 = 1600，1600 × 2 = 3200 已被 cap 截到 2000
    expect(backoffDelay(3, 400, 2_000, () => 1)).toBe(2_000)
    expect(backoffDelay(9, 400, 2_000, () => 1)).toBe(2_000)
  })

  it('full jitter：低随机数下退避变短，但不会为负', () => {
    expect(backoffDelay(2, 400, 2_000, () => 0)).toBe(0)
    expect(backoffDelay(2, 400, 2_000, () => 0.5)).toBe(800)
  })
})

describe('parseRetryAfter', () => {
  const now = Date.parse('2026-11-05T07:00:00Z')

  it('支持秒数写法', () => {
    expect(parseRetryAfter('3', now)).toBe(3_000)
    expect(parseRetryAfter('0.5', now)).toBe(500)
    expect(parseRetryAfter(' 12 ', now)).toBe(12_000)
  })

  it('支持 HTTP 日期写法', () => {
    expect(parseRetryAfter('Thu, 05 Nov 2026 07:00:30 GMT', now)).toBe(30_000)
    // 已经过去的日期不该得到负等待
    expect(parseRetryAfter('Thu, 05 Nov 2026 06:59:00 GMT', now)).toBe(0)
  })

  it('缺失或无法解析时返回 null', () => {
    expect(parseRetryAfter(null, now)).toBeNull()
    expect(parseRetryAfter('', now)).toBeNull()
    expect(parseRetryAfter('soon', now)).toBeNull()
  })
})

describe('UpstreamLimiter 令牌桶', () => {
  it('突发容量内的请求立即放行', async () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({ now: clock.now, burst: 4, ratePerSec: 10 })

    const started = Date.now()
    await Promise.all([
      limiter.acquire(),
      limiter.acquire(),
      limiter.acquire(),
      limiter.acquire(),
    ])
    // 4 个令牌都在桶里，不该有任何等待
    expect(Date.now() - started).toBeLessThan(50)
  })

  it('超出突发容量后按速率排队，而不是一次性打出去', async () => {
    const clock = liveClock()
    // 20 req/s → 每个令牌 50ms
    const limiter = new UpstreamLimiter({ now: clock.now, burst: 1, ratePerSec: 20 })

    const started = Date.now()
    await limiter.acquire() // 用掉初始令牌
    await limiter.acquire()
    await limiter.acquire()

    // 后两个各等约 50ms，总计至少 ~90ms（留给定时器精度一点余量）
    const elapsed = Date.now() - started
    expect(elapsed).toBeGreaterThanOrEqual(90)
    expect(elapsed).toBeLessThan(400)
  })

  it('reset 会放行排队中的调用者，不留悬挂的 Promise', async () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({ now: clock.now, burst: 1, ratePerSec: 1 })

    await limiter.acquire()
    const pending = limiter.acquire()
    limiter.reset()

    await expect(pending).resolves.toBeUndefined()
  })
})

describe('UpstreamLimiter 熔断', () => {
  it('连续失败达到阈值就闭闸，冷却期内直接拒绝', () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({
      now: clock.now,
      burst: 10,
      ratePerSec: 100,
      failureThreshold: 3,
      cooldownMs: 1_000,
    })

    limiter.reportFailure()
    limiter.reportFailure()
    expect(limiter.state()).toBe('closed')

    limiter.reportFailure()
    expect(limiter.state()).toBe('open')
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(1_000, -2)
  })

  it('收到 429 立即闭闸，不等失败阈值累计', () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({
      now: clock.now,
      burst: 10,
      ratePerSec: 100,
      failureThreshold: 6,
      cooldownMs: 1_000,
    })

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.state()).toBe('open')
    expect(limiter.stats().lastThrottleAt).not.toBeNull()
  })

  it('Retry-After 优先于基础冷却，但受上限约束', () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({
      now: clock.now,
      burst: 10,
      ratePerSec: 100,
      cooldownMs: 1_000,
      maxCooldownMs: 5_000,
    })

    limiter.reportFailure({ rateLimited: true, retryAfterMs: 3_000 })
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(3_000, -2)

    // 上游说等一小时，也不能把行情冻结一小时
    limiter.reportFailure({ rateLimited: true, retryAfterMs: 3_600_000 })
    expect(limiter.cooldownRemainingMs()).toBeLessThanOrEqual(5_000)
  })

  it('连续触发冷却按 2 的幂放大', () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({
      now: clock.now,
      burst: 10,
      ratePerSec: 100,
      cooldownMs: 1_000,
      maxCooldownMs: 60_000,
    })

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(1_000, -2)

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(2_000, -2)

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(4_000, -2)
  })

  it('冷却结束后进入半开：只放一个探针，其余拒绝', async () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({ now: clock.now, burst: 10, ratePerSec: 100, cooldownMs: 1_000 })

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.state()).toBe('open')

    clock.advance(1_001)
    expect(limiter.state()).toBe('half-open')

    // 探针放行
    await expect(limiter.acquire()).resolves.toBeUndefined()
    // 探针还没回报结果，第二个请求必须被挡住
    await expect(limiter.acquire()).rejects.toBeInstanceOf(UpstreamBreakerOpenError)
  })

  it('探针成功即彻底恢复', async () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({ now: clock.now, burst: 10, ratePerSec: 100, cooldownMs: 1_000 })

    limiter.reportFailure({ rateLimited: true })
    clock.advance(1_001)
    await limiter.acquire()
    limiter.reportSuccess()

    expect(limiter.state()).toBe('closed')
    expect(limiter.stats().consecutiveFailures).toBe(0)
    await expect(limiter.acquire()).resolves.toBeUndefined()
  })

  it('探针失败会重新闭闸，并继续放大冷却', () => {
    const clock = liveClock()
    const limiter = new UpstreamLimiter({
      now: clock.now,
      burst: 10,
      ratePerSec: 100,
      cooldownMs: 1_000,
      maxCooldownMs: 60_000,
    })

    limiter.reportFailure({ rateLimited: true })
    clock.advance(1_001)
    expect(limiter.state()).toBe('half-open')

    limiter.reportFailure({ rateLimited: true })
    expect(limiter.state()).toBe('open')
    expect(limiter.cooldownRemainingMs()).toBeCloseTo(2_000, -2)
  })
})

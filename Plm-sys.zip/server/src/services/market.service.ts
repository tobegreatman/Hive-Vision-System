import { createHash } from 'node:crypto'

import type {
  CreateMarketNodeCommand,
  MarketBoard,
  MarketBoardSummary,
  MarketBreadth,
  MarketExchange,
  MarketIndex,
  MarketKind,
  MarketNode,
  MarketOverview,
  MarketSession,
  QuoteStatus,
  UpdateMarketNodePayload,
} from '@platform/contracts'
import { BOARD_LABEL, BOARD_ORDER, MARKET_PROVIDER, PRICE_LIMIT_PCT, limitStatusOf, trendOf } from '@platform/contracts'

import { serverEnv } from '../env.js'
import { indexWatchService } from './index-watch.service.js'
import { quoteService, type QuoteRow, type QuoteSnapshot } from './quote.service.js'

interface VisitRecord {
  visits: number
  lastVisitedAt: string | null
}

interface SeedNode {
  symbol: string
  exchange: MarketExchange
  name: string
  kind: MarketKind
  board: MarketBoard
  price: number
  changePct: number
  amplitude: number
  turnoverRate: number
  volumeRatio: number
  turnover: number
  marketCap: number
  mainNetInflow: number
  heat: number
  tags: string[]
}

export interface MarketServiceOptions {
  /** live = 抓真实行情；demo = 强制内置快照 */
  mode?: 'live' | 'demo'
  /** 每个板块进蜂巢的格子数 */
  samplePerBoard?: number
  /** 盘中快照有效期（毫秒） */
  quoteTtlMs?: number
}

/**
 * 盘面样本：13 只个股 + 3 条指数。**仅在两种情况下出现**——
 * 强制 `MARKET_DATA_MODE=demo`，或行情源完全不可用时的冷启动兜底。
 * 一旦拿到真实快照就会被整体替换，`/api/health` 的 `dataMode` 如实区分两者。
 */
const SEEDS: SeedNode[] = [
  {
    symbol: '000001',
    exchange: 'SH',
    name: '上证指数',
    kind: 'index',
    board: 'index',
    price: 3312.45,
    changePct: 0.62,
    amplitude: 0.94,
    turnoverRate: 0.9,
    volumeRatio: 1.05,
    turnover: 4210,
    marketCap: 552000,
    mainNetInflow: 86.4,
    heat: 0.86,
    tags: ['大盘', '沪市'],
  },
  {
    symbol: '399001',
    exchange: 'SZ',
    name: '深证成指',
    kind: 'index',
    board: 'index',
    price: 10548.32,
    changePct: 0.94,
    amplitude: 1.32,
    turnoverRate: 1.1,
    volumeRatio: 1.12,
    turnover: 5860,
    marketCap: 312000,
    mainNetInflow: 42.8,
    heat: 0.82,
    tags: ['大盘', '深市'],
  },
  {
    symbol: '399006',
    exchange: 'SZ',
    name: '创业板指',
    kind: 'index',
    board: 'index',
    price: 2176.88,
    changePct: -0.35,
    amplitude: 1.86,
    turnoverRate: 1.3,
    volumeRatio: 0.96,
    turnover: 2870,
    marketCap: 121000,
    mainNetInflow: -18.6,
    heat: 0.78,
    tags: ['成长', '创业板'],
  },
  {
    symbol: '600519',
    exchange: 'SH',
    name: '贵州茅台',
    kind: 'stock',
    board: 'main',
    price: 1586.0,
    changePct: 1.24,
    amplitude: 1.86,
    turnoverRate: 0.28,
    volumeRatio: 1.14,
    turnover: 38.6,
    marketCap: 19920,
    mainNetInflow: 6.2,
    heat: 0.92,
    tags: ['白酒', '权重'],
  },
  {
    symbol: '300750',
    exchange: 'SZ',
    name: '宁德时代',
    kind: 'stock',
    board: 'gem',
    price: 268.4,
    changePct: 2.86,
    amplitude: 3.42,
    turnoverRate: 0.92,
    volumeRatio: 1.36,
    turnover: 62.4,
    marketCap: 11810,
    mainNetInflow: 9.8,
    heat: 0.95,
    tags: ['锂电', '新能源'],
  },
  {
    symbol: '601318',
    exchange: 'SH',
    name: '中国平安',
    kind: 'stock',
    board: 'main',
    price: 58.72,
    changePct: -0.68,
    amplitude: 1.24,
    turnoverRate: 0.36,
    volumeRatio: 0.88,
    turnover: 41.2,
    marketCap: 10690,
    mainNetInflow: -4.1,
    heat: 0.7,
    tags: ['保险', '权重'],
  },
  {
    symbol: '000858',
    exchange: 'SZ',
    name: '五粮液',
    kind: 'stock',
    board: 'main',
    price: 142.3,
    changePct: 0.86,
    amplitude: 1.52,
    turnoverRate: 0.41,
    volumeRatio: 1.02,
    turnover: 31.5,
    marketCap: 5520,
    mainNetInflow: 2.4,
    heat: 0.6,
    tags: ['白酒'],
  },
  {
    symbol: '002594',
    exchange: 'SZ',
    name: '比亚迪',
    kind: 'stock',
    board: 'main',
    price: 312.8,
    changePct: 3.42,
    amplitude: 4.16,
    turnoverRate: 1.08,
    volumeRatio: 1.44,
    turnover: 78.9,
    marketCap: 9110,
    mainNetInflow: 12.6,
    heat: 0.88,
    tags: ['汽车', '新能源'],
  },
  {
    symbol: '688981',
    exchange: 'SH',
    name: '中芯国际',
    kind: 'stock',
    board: 'star',
    price: 96.35,
    changePct: 4.68,
    amplitude: 6.02,
    turnoverRate: 2.14,
    volumeRatio: 1.62,
    turnover: 55.3,
    marketCap: 7660,
    mainNetInflow: 7.4,
    heat: 0.82,
    tags: ['半导体', '科创板'],
  },
  {
    symbol: '300059',
    exchange: 'SZ',
    name: '东方财富',
    kind: 'stock',
    board: 'gem',
    price: 22.48,
    changePct: 5.12,
    amplitude: 6.88,
    turnoverRate: 3.62,
    volumeRatio: 1.88,
    turnover: 96.8,
    marketCap: 3550,
    mainNetInflow: 15.2,
    heat: 0.93,
    tags: ['券商', '互联网金融'],
  },
  {
    symbol: '600030',
    exchange: 'SH',
    name: '中信证券',
    kind: 'stock',
    board: 'main',
    price: 28.16,
    changePct: 2.05,
    amplitude: 3.14,
    turnoverRate: 1.26,
    volumeRatio: 1.22,
    turnover: 68.4,
    marketCap: 4170,
    mainNetInflow: 5.6,
    heat: 0.75,
    tags: ['券商'],
  },
  {
    symbol: '300124',
    exchange: 'SZ',
    name: '汇川技术',
    kind: 'stock',
    board: 'gem',
    price: 61.2,
    changePct: -1.42,
    amplitude: 2.68,
    turnoverRate: 0.74,
    volumeRatio: 0.92,
    turnover: 22.7,
    marketCap: 1640,
    mainNetInflow: -2.8,
    heat: 0.5,
    tags: ['工控', '机器人'],
  },
  {
    symbol: '601012',
    exchange: 'SH',
    name: '隆基绿能',
    kind: 'stock',
    board: 'main',
    price: 17.85,
    changePct: -2.36,
    amplitude: 3.28,
    turnoverRate: 1.14,
    volumeRatio: 1.06,
    turnover: 18.9,
    marketCap: 1350,
    mainNetInflow: -3.6,
    heat: 0.45,
    tags: ['光伏'],
  },
  {
    symbol: '002415',
    exchange: 'SZ',
    name: '海康威视',
    kind: 'stock',
    board: 'main',
    price: 30.42,
    changePct: 0.32,
    amplitude: 1.18,
    turnoverRate: 0.44,
    volumeRatio: 0.94,
    turnover: 19.8,
    marketCap: 2810,
    mainNetInflow: 1.1,
    heat: 0.55,
    tags: ['安防'],
  },
  {
    symbol: '601127',
    exchange: 'SH',
    name: '赛力斯',
    kind: 'stock',
    board: 'main',
    price: 128.6,
    changePct: 10,
    amplitude: 11.42,
    turnoverRate: 4.86,
    volumeRatio: 2.34,
    turnover: 54.2,
    marketCap: 2160,
    mainNetInflow: 8.9,
    heat: 0.8,
    tags: ['汽车', '华为链'],
  },
  {
    symbol: '002460',
    exchange: 'SZ',
    name: '赣锋锂业',
    kind: 'stock',
    board: 'main',
    price: 32.18,
    changePct: -10,
    amplitude: 9.68,
    turnoverRate: 5.24,
    volumeRatio: 2.18,
    turnover: 27.4,
    marketCap: 640,
    mainNetInflow: -6.4,
    heat: 0.65,
    tags: ['锂矿'],
  },
  {
    symbol: '835185',
    exchange: 'BJ',
    name: '贝特瑞',
    kind: 'stock',
    board: 'bse',
    price: 41.2,
    changePct: 30,
    amplitude: 18.64,
    turnoverRate: 3.18,
    volumeRatio: 2.06,
    turnover: 8.4,
    marketCap: 292,
    mainNetInflow: 1.7,
    heat: 0.58,
    tags: ['锂电材料', '北交所'],
  },
]

const SHANGHAI_INDEX = '000001'
const SHENZHEN_INDEX = '399001'
/** 自选指数进入蜂巢的刷新节奏：与指数快照 TTL 对齐，不必每个请求都拉一次。 */
const INDEX_SYNC_TTL_MS = 15_000

function isoNow(): string {
  return new Date().toISOString()
}

function round2(value: number): number {
  return Number(value.toFixed(2))
}

/**
 * 标的 id 由「交易所 + 代码」确定性派生（UUIDv5 布局）。
 *
 * 之前每次启动 `randomUUID()` 一发，id 每次都不一样，`?node=<id>` 这种分享链接
 * 过一夜就全失效。真实行情每 20s 整体换一帧，id 必须是身份而不是实例。
 */
export function stableNodeId(exchange: MarketExchange, symbol: string): string {
  const digest = createHash('sha1').update(`platform-sys:market:${exchange}:${symbol}`).digest()
  const bytes = Buffer.from(digest.subarray(0, 16))
  bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x50 // version 5
  bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80 // RFC 4122 variant
  const hex = bytes.toString('hex')
  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20, 32),
  ].join('-')
}

/**
 * 关注度：真实行情里没有「热度」这个字段，用成交额在板块内的相对位置
 * 叠加离涨跌停的距离合成——盘面上最活跃、最极端的格子自然最亮。
 */
function deriveHeat(row: QuoteRow, rank: number, total: number): number {
  const depth = total <= 1 ? 1 : 1 - rank / (total - 1)
  const limit = PRICE_LIMIT_PCT[row.board]
  const swing = Number.isFinite(limit)
    ? Math.min(Math.abs(row.changePct) / limit, 1)
    : Math.min(Math.abs(row.changePct) / 5, 1)
  return round2(Math.min(Math.max(0.3 + depth * 0.4 + swing * 0.3, 0), 1))
}

/**
 * 时区格式化器只建一次：`Intl.DateTimeFormat` 的构造代价远高于格式化本身，
 * 而 `/api/health` 与 `/api/market/overview` 每次请求都要算盘前/盘中/收盘。
 */
const BEIJING_FORMATTER = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Shanghai',
  hour12: false,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  weekday: 'short',
})

function beijingClock(now: Date): { minutes: number; weekday: string; tradeDate: string } {
  const parts = BEIJING_FORMATTER.formatToParts(now)

  const pick = (type: string): string => parts.find((part) => part.type === type)?.value ?? ''
  const hour = Number(pick('hour')) % 24
  const minute = Number(pick('minute'))

  return {
    minutes: hour * 60 + minute,
    weekday: pick('weekday'),
    tradeDate: `${pick('year')}-${pick('month')}-${pick('day')}`,
  }
}

export function currentSession(now: Date = new Date()): MarketSession {
  const { minutes, weekday } = beijingClock(now)
  if (weekday === 'Sat' || weekday === 'Sun') return 'holiday'
  if (minutes < 9 * 60 + 15) return 'pre-open'
  if (minutes < 9 * 60 + 30) return 'auction'
  if (minutes < 11 * 60 + 30) return 'open'
  if (minutes < 13 * 60) return 'lunch-break'
  if (minutes < 15 * 60) return 'open'
  return 'closed'
}

export function currentTradeDate(now: Date = new Date()): string {
  return beijingClock(now).tradeDate
}

function sortByTurnoverDesc(nodes: MarketNode[]): MarketNode[] {
  return [...nodes].sort((a, b) => b.turnover - a.turnover)
}

/**
 * 盘面仓储。
 *
 * 数据来源只有一条：`quote.service` 的全市场快照。业务规则（涨跌停、排名、板块家数、
 * 广度）一律服务端算完再下发，前端只渲染——这样「涨跌停」只有一份实现，
 * 不会出现前端徽标说涨停、后端说有 0.3% 空间的分裂。
 *
 * 手工自选（POST /nodes）以 symbol 为键单独保存：真实快照里没有的标的
 * （停牌、退市、代码录错）也要留在盘面上，不能让用户加进去就消失。
 */
export class MarketService {
  private readonly mode: 'live' | 'demo'
  private readonly samplePerBoard: number
  private readonly quoteTtlMs: number

  private readonly nodes = new Map<string, MarketNode>()
  private readonly bySymbol = new Map<string, MarketNode>()
  private readonly visits = new Map<string, VisitRecord>()
  private readonly heatOverrides = new Map<string, number>()
  /** 手工自选：symbol → 节点，快照里查不到时才用它兜底 */
  private readonly watchlist = new Map<string, MarketNode>()
  /** 首次出现时间：刷新不应该改写标的的「出生时间」 */
  private readonly firstSeen = new Map<string, string>()

  private snapshot: QuoteSnapshot | null = null
  private lastSyncAttempt = 0
  private lastWarnAt = 0
  private syncInflight: Promise<void> | null = null

  /** 自选指数转换来的节点：蜂巢「指数」板块的唯一数据源，跟随 index-watch 增删。 */
  private indexNodes: MarketNode[] = []
  /** 是否已成功从 index-watch 取过一帧；false 时退回快照自带的三大指数。 */
  private indexNodesReady = false
  private lastIndexSyncAt = 0
  private indexSyncInflight: Promise<void> | null = null

  /**
   * 数据版本号：每次重建节点 +1，读路径用它判断聚合/排序缓存是否还能复用。
   * 盘面读多写少，之前每次请求都复制数组再排序，纯属白做。
   */
  private revision = 0
  private listCache: { revision: number; value: MarketNode[] } | null = null
  private turnoverCache: { revision: number; value: MarketNode[] } | null = null
  private boardsCache: { revision: number; value: MarketBoardSummary[] } | null = null

  constructor(options: MarketServiceOptions = {}) {
    this.mode = options.mode ?? serverEnv.marketMode
    this.samplePerBoard = Math.max(1, options.samplePerBoard ?? serverEnv.samplePerBoard)
    this.quoteTtlMs = Math.max(2_000, options.quoteTtlMs ?? serverEnv.quoteTtlMs)

    // 冷启动先摆一帧内置快照：真实行情 0.5s 就到，但白屏比旧数据难看
    this.replaceNodes(
      SEEDS.map((seed) => ({
        id: stableNodeId(seed.exchange, seed.symbol),
        ...seed,
        createdAt: isoNow(),
        updatedAt: isoNow(),
      })),
    )
  }

  /** 真实数据是否已就位。health 用它区分 live / demo，不做任何美化。 */
  dataMode(): 'live' | 'demo' {
    return this.snapshot ? 'live' : 'demo'
  }

  quoteStatus(): QuoteStatus | null {
    if (this.mode === 'demo' || !this.snapshot) return null
    return {
      provider: MARKET_PROVIDER.id,
      label: MARKET_PROVIDER.label,
      asOf: new Date(this.snapshot.at).toISOString(),
      ageMs: Math.max(0, Date.now() - this.snapshot.at),
      latencyMs: this.snapshot.latencyMs,
      pages: this.snapshot.pages,
      failedPages: this.snapshot.failedPages,
      universe: this.snapshot.universe,
      degraded: this.snapshot.degraded,
      // 上游闸门状态：被限流时能在 /api/health 里直接看见冷却剩余时间
      limiter: quoteService.limiterStats(),
    }
  }

  /** 盘中 20s，午间/盘前 60s，收盘后 5min —— 收盘后每 20s 扫 60 页是纯浪费。 */
  private ttlMs(): number {
    const session = currentSession()
    if (session === 'open' || session === 'auction') return this.quoteTtlMs
    if (session === 'closed' || session === 'holiday') return Math.max(this.quoteTtlMs, 300_000)
    return Math.max(this.quoteTtlMs, 60_000)
  }

  /**
   * 保证手上有一帧够新的快照。路由在读之前 await 一次，失败不抛——
   * 盘面可以旧，但不能整页 502。
   *
   * 有旧帧时走 stale-while-revalidate：立刻返回旧数据，刷新在后台跑完。
   * 限速之后一轮扫描约 5s，如果每个请求都同步等这一轮，接口就会被拖到 5s 延迟；
   * 只有「一帧都没有」的冷启动才值得让用户等。
   */
  async ready(force = false): Promise<void> {
    if (this.mode === 'demo') return

    // 自选指数与全市场快照各走各的缓存：这里只触发、不等待，避免分时请求拖慢盘面
    this.primeWatchIndices()

    const ttl = this.ttlMs()
    if (!force && this.snapshot && Date.now() - this.snapshot.at < ttl) return

    // 熔断打开时上游已明确拒绝：这一段没必要排队等，直接用旧帧
    if (!force && quoteService.limiterStats().breaker === 'open') return

    const hasFrame = this.snapshot !== null

    if (this.syncInflight) {
      // 后台已经在刷新了：有旧帧就别跟着等
      if (hasFrame && !force) return
      return this.syncInflight
    }

    // 上游整体不可用时的退避：没有一帧数据时不要每个请求都去扫 60 页
    if (!force && !hasFrame && Date.now() - this.lastSyncAttempt < 15_000) return

    this.lastSyncAttempt = Date.now()
    this.syncInflight = this.sync().finally(() => {
      this.syncInflight = null
    })

    if (hasFrame && !force) return
    return this.syncInflight
  }

  private async sync(): Promise<void> {
    try {
      const snapshot = await quoteService.snapshot(this.ttlMs())
      this.applySnapshot(snapshot)
    } catch (error) {
      // 熔断期间每个前端轮询都会失败一次，日志按分钟节流，免得刷屏掩盖真正的问题
      const now = Date.now()
      if (now - this.lastWarnAt < 60_000) return
      this.lastWarnAt = now
      console.warn(
        '[market] 行情源不可用，继续使用上一帧：',
        error instanceof Error ? error.message : String(error),
      )
    }
  }

  /** 用一份快照重建整个盘面：指数 → 各板块成交额前列 → 手工自选。 */
  private applySnapshot(snapshot: QuoteSnapshot): void {
    this.snapshot = snapshot
    this.rebuildNodes()
  }

  /**
   * 重建节点表。指数节点优先用自选指数（全球指数 / 板块指数都能进来），
   * 只有 index-watch 还没返回过一帧时才退回快照自带的三大指数。
   */
  private rebuildNodes(): void {
    const snapshot = this.snapshot
    const nodes: MarketNode[] = []
    const seen = new Set<string>()

    if (this.indexNodesReady) {
      for (const node of this.indexNodes) {
        nodes.push(node)
        seen.add(node.symbol)
      }
    } else if (snapshot) {
      for (const row of snapshot.indices) {
        nodes.push(this.nodeFromRow(row, 'index', snapshot, 0, 1))
        seen.add(row.symbol)
      }
    }

    if (snapshot) {
      for (const board of BOARD_ORDER) {
        if (board === 'index') continue
        const rows = snapshot.rows.filter((row) => row.board === board).slice(0, this.samplePerBoard)
        rows.forEach((row, index) => {
          // 手工加过的标的上游也在：保留「自选」标签
          nodes.push(this.nodeFromRow(row, 'stock', snapshot, index, rows.length, this.watchlist.has(row.symbol)))
          seen.add(row.symbol)
        })
      }

      // 自选里的票如果不在板块前列（甚至不在上游），也得留在盘面上
      for (const [symbol, fallback] of this.watchlist) {
        if (seen.has(symbol)) continue
        const row = snapshot.rowBySymbol.get(symbol)
        nodes.push(row ? this.nodeFromRow(row, 'stock', snapshot, 0, 1, true) : fallback)
        seen.add(symbol)
      }
    } else {
      for (const fallback of this.watchlist.values()) nodes.push(fallback)
    }

    this.replaceNodes(nodes)
  }

  /** 后台把自选指数刷进盘面；15s 内不重复拉取，失败则继续用上一帧。 */
  private primeWatchIndices(): void {
    if (Date.now() - this.lastIndexSyncAt < INDEX_SYNC_TTL_MS) return
    if (this.indexSyncInflight) return
    void this.loadWatchIndices()
  }

  /** 供指数增删接口调用：跳过节流，立刻让蜂巢指数板块与 2D 指数栏对齐。 */
  async refreshIndices(): Promise<void> {
    if (this.mode === 'demo') return
    await this.loadWatchIndices()
  }

  private async loadWatchIndices(): Promise<void> {
    if (this.indexSyncInflight) return this.indexSyncInflight

    const promise = indexWatchService
      .list()
      .then((items) => {
        this.indexNodes = items.map((item) => this.indexNodeFromItem(item))
        this.indexNodesReady = true
        this.lastIndexSyncAt = Date.now()
        // 冷启动时快照还没到：等 applySnapshot 统一铺个股，别先清空种子盘面
        if (this.snapshot) this.rebuildNodes()
      })
      .catch(() => {
        // 指数源挂了就继续用上一帧；一帧都没有时退回快照自带的三大指数
      })
      .finally(() => {
        this.indexSyncInflight = null
      })

    this.indexSyncInflight = promise
    return promise
  }

  /**
   * 自选指数 → 蜂巢节点。
   * 沪深指数沿用原来的 SH / SZ（分享链接与代码后缀不变），
   * 全球指数与板块指数没有沪深归属，统一记作 GL。
   */
  private indexNodeFromItem(item: MarketIndex): MarketNode {
    const now = isoNow()
    const marketFlag = item.secid.split('.')[0]
    const exchange: MarketExchange =
      (marketFlag === '0' || marketFlag === '1') && /^\d{6}$/.test(item.code)
        ? marketFlag === '1'
          ? 'SH'
          : 'SZ'
        : 'GL'
    const amplitude =
      item.preClose > 0 && item.high > 0 && item.low > 0
        ? round2(Math.min(Math.max(((item.high - item.low) / item.preClose) * 100, 0), 500))
        : round2(Math.min(Math.abs(item.changePct) * 1.8, 20))

    return {
      id: stableNodeId(exchange, exchange === 'GL' ? item.secid : item.code),
      symbol: item.code,
      exchange,
      name: item.name.slice(0, 16) || item.code,
      kind: 'index',
      board: 'index',
      price: item.price,
      changePct: item.changePct,
      amplitude,
      turnoverRate: 0,
      volumeRatio: 0,
      turnover: item.turnover,
      marketCap: 0,
      mainNetInflow: 0,
      heat: round2(Math.min(0.45 + Math.min(Math.abs(item.changePct) / 5, 1) * 0.45, 1)),
      tags: ['指数'],
      secid: item.secid,
      spark: item.spark,
      // 轴长由服务端按 secid 判定：`90.BKxxxx` 板块会被归到 GL，不能只看 exchange
      sparkAxis: item.sparkAxis,
      createdAt: this.firstSeen.get(item.code) ?? now,
      updatedAt: now,
    }
  }

  private nodeFromRow(
    row: QuoteRow,
    kind: MarketKind,
    snapshot: QuoteSnapshot,
    rank: number,
    total: number,
    watch = false,
  ): MarketNode {
    const now = new Date(snapshot.at).toISOString()
    const tags: string[] = []
    if (watch) tags.push('自选')
    tags.push(row.industry || BOARD_LABEL[row.board])

    return {
      id: stableNodeId(row.exchange, row.symbol),
      symbol: row.symbol,
      exchange: row.exchange,
      name: row.name,
      kind,
      board: row.board,
      price: row.price,
      changePct: row.changePct,
      amplitude: row.amplitude,
      turnoverRate: round2(row.turnoverRate),
      volumeRatio: round2(row.volumeRatio),
      turnover: round2(row.turnover),
      marketCap: round2(row.marketCap),
      mainNetInflow: round2(row.mainNetInflow),
      heat: this.heatOverrides.get(row.symbol) ?? deriveHeat(row, rank, total),
      tags: tags.slice(0, 6).map((tag) => tag.slice(0, 12)),
      createdAt: this.firstSeen.get(row.symbol) ?? now,
      updatedAt: now,
    }
  }

  private replaceNodes(nodes: MarketNode[]): void {
    this.nodes.clear()
    this.bySymbol.clear()
    for (const node of nodes) {
      this.nodes.set(node.id, node)
      this.bySymbol.set(node.symbol, node)
      if (!this.firstSeen.has(node.symbol)) this.firstSeen.set(node.symbol, node.createdAt)
    }
    this.touch()
  }

  /** 任何改动都必须走这里，否则缓存会看到旧帧。 */
  private touch(): void {
    this.revision += 1
  }

  /** 盘面顺序：指数在前，其余按成交额降序，保证 3D 与列表读序一致。 */
  list(): MarketNode[] {
    if (this.listCache?.revision === this.revision) return this.listCache.value

    const all = [...this.nodes.values()]
    const indices = all.filter((node) => node.kind === 'index')
    const stocks = sortByTurnoverDesc(all.filter((node) => node.kind === 'stock'))
    const value = [...indices, ...stocks]

    this.listCache = { revision: this.revision, value }
    return value
  }

  /** 全样本按成交额降序；演示模式下的排名与"上一只/下一只"共用这份顺序。 */
  private turnoverOrder(): MarketNode[] {
    if (this.turnoverCache?.revision === this.revision) return this.turnoverCache.value

    const value = sortByTurnoverDesc([...this.nodes.values()])
    this.turnoverCache = { revision: this.revision, value }
    return value
  }

  find(id: string): MarketNode | undefined {
    return this.nodes.get(id)
  }

  overview(): MarketOverview {
    const snapshot = this.snapshot
    const indices = this.list().filter((node) => node.kind === 'index')

    if (snapshot) {
      // 两市成交额固定取沪、深综指口径：自选列表里删掉指数也不该让全市场成交额归零
      const shanghai = snapshot.indices.find((row) => row.symbol === SHANGHAI_INDEX)
      const shenzhen = snapshot.indices.find((row) => row.symbol === SHENZHEN_INDEX)

      return {
        indices,
        // 广度来自全市场 5927 只的逐行统计，不是蜂巢样本
        breadth: snapshot.breadth,
        // 避免创业板指重复计入
        turnover: round2((shanghai?.turnover ?? 0) + (shenzhen?.turnover ?? 0)),
        mainNetInflow: snapshot.mainNetInflow,
        session: currentSession(),
        tradeDate: currentTradeDate(),
        asOf: new Date(snapshot.at).toISOString(),
      }
    }

    // 演示快照：一次遍历算完所有口径
    let up = 0
    let down = 0
    let flat = 0
    let limitUp = 0
    let limitDown = 0
    let netInflow = 0
    let shanghai: MarketNode | undefined
    let shenzhen: MarketNode | undefined

    for (const node of this.nodes.values()) {
      netInflow += node.mainNetInflow
      if (node.symbol === SHANGHAI_INDEX) shanghai = node
      else if (node.symbol === SHENZHEN_INDEX) shenzhen = node

      if (node.kind === 'index') continue

      const trend = trendOf(node.changePct)
      if (trend === 'up') up += 1
      else if (trend === 'down') down += 1
      else flat += 1

      const limit = limitStatusOf(node)
      if (limit === 'limit-up') limitUp += 1
      else if (limit === 'limit-down') limitDown += 1
    }

    const breadth: MarketBreadth = { up, down, flat, limitUp, limitDown }

    return {
      indices,
      breadth,
      turnover: round2((shanghai?.turnover ?? 0) + (shenzhen?.turnover ?? 0)),
      mainNetInflow: round2(netInflow),
      session: currentSession(),
      tradeDate: currentTradeDate(),
      asOf: isoNow(),
    }
  }

  create(command: CreateMarketNodeCommand): MarketNode {
    // 幂等：上游已经在盘面上的标的直接返回，不再造一个同代码的重复格子
    const existing = this.bySymbol.get(command.symbol)
    if (existing) return existing

    const now = isoNow()
    const kind: MarketKind = command.board === 'index' ? 'index' : 'stock'

    const fallback: MarketNode = {
      id: stableNodeId(command.exchange, command.symbol),
      symbol: command.symbol,
      exchange: command.exchange,
      name: command.name,
      kind,
      board: command.board,
      price: command.price,
      changePct: command.changePct,
      amplitude: round2(Math.min(Math.abs(command.changePct) * 1.8, 20)),
      turnoverRate: 0,
      volumeRatio: 0,
      turnover: command.turnover,
      marketCap: round2(command.price * 10),
      mainNetInflow: 0,
      heat: command.heat,
      tags: ['自选'],
      createdAt: now,
      updatedAt: now,
    }

    this.watchlist.set(command.symbol, fallback)

    if (this.snapshot) {
      // 上游有这只票就用真实行情覆盖手填的价格，并让它在盘面上出现
      this.applySnapshot(this.snapshot)
    } else {
      this.nodes.set(fallback.id, fallback)
      this.bySymbol.set(fallback.symbol, fallback)
      if (!this.firstSeen.has(fallback.symbol)) this.firstSeen.set(fallback.symbol, now)
      this.touch()
    }

    return this.bySymbol.get(command.symbol) ?? fallback
  }

  update(id: string, patch: UpdateMarketNodePayload): MarketNode | undefined {
    const current = this.nodes.get(id)
    if (!current) return undefined

    const heat = patch.heat ?? current.heat
    // 用户改过的关注度要能扛过下一次行情刷新，因此按 symbol 记住
    if (patch.heat !== undefined) this.heatOverrides.set(current.symbol, heat)

    const next: MarketNode = { ...current, heat, updatedAt: isoNow() }
    this.nodes.set(id, next)
    this.touch()
    return next
  }

  /** 记录一次检视，返回自增后的计数。计数按 symbol 累计，刷新不会清零。 */
  inspect(id: string): { visits: number; lastVisitedAt: string | null } | undefined {
    const node = this.nodes.get(id)
    if (!node) return undefined
    const record = this.visits.get(node.symbol) ?? { visits: 0, lastVisitedAt: null }
    const next: VisitRecord = { visits: record.visits + 1, lastVisitedAt: isoNow() }
    this.visits.set(node.symbol, next)
    return next
  }

  /**
   * 板块聚合：蜂巢导航第一层的单元。
   *
   * `count` 是板块真实家数（全市场口径），`sampleCount` 是真正铺进蜂巢的格子数——
   * 两者必须分开，否则「沪深主板 3488 只」会变成「3488 个六边形」。
   */
  boards(): MarketBoardSummary[] {
    if (this.boardsCache?.revision === this.revision) return this.boardsCache.value

    const sampleCounts = new Map<MarketBoard, number>()
    for (const node of this.nodes.values()) {
      if (node.kind !== 'stock') continue
      sampleCounts.set(node.board, (sampleCounts.get(node.board) ?? 0) + 1)
    }

    const snapshot = this.snapshot

    const value = BOARD_ORDER.map((board) => {
      const stats = snapshot?.boardStats.get(board)
      if (snapshot && stats) {
        return {
          board,
          label: BOARD_LABEL[board],
          count: stats.universe,
          sampleCount: sampleCounts.get(board) ?? 0,
          up: stats.up,
          down: stats.down,
          limitCount: stats.limitUp + stats.limitDown,
          turnover: round2(stats.turnover),
          mainNetInflow: round2(stats.mainNetInflow),
          avgChangePct: stats.universe === 0 ? 0 : round2(stats.changeSum / stats.universe),
          leader: stats.leader
            ? (this.bySymbol.get(stats.leader.symbol) ??
              this.nodeFromRow(stats.leader, 'stock', snapshot, 0, 1))
            : null,
        } satisfies MarketBoardSummary
      }

      // 演示 / 兜底：按内存节点聚合
      const members = [...this.nodes.values()].filter((node) => node.board === board)
      let up = 0
      let down = 0
      let limitCount = 0
      let turnover = 0
      let netInflow = 0
      let changeSum = 0
      let leader: MarketNode | null = null

      for (const node of members) {
        const trend = trendOf(node.changePct)
        if (trend === 'up') up += 1
        else if (trend === 'down') down += 1

        if (limitStatusOf(node) !== 'normal') limitCount += 1
        turnover += node.turnover
        netInflow += node.mainNetInflow
        changeSum += node.changePct
        if (!leader || node.changePct > leader.changePct) leader = node
      }

      return {
        board,
        label: BOARD_LABEL[board],
        count: members.length,
        sampleCount: members.length,
        up,
        down,
        limitCount,
        turnover: round2(turnover),
        mainNetInflow: round2(netInflow),
        avgChangePct: members.length === 0 ? 0 : round2(changeSum / members.length),
        leader,
      } satisfies MarketBoardSummary
    })

    this.boardsCache = { revision: this.revision, value }
    return value
  }

  /** 成交额排名（全市场真实口径），1 表示成交额最大。 */
  rankOf(id: string): number {
    const node = this.nodes.get(id)
    if (!node) return this.list().length + 1

    const exact = this.snapshot?.rankBySymbol.get(node.symbol)
    if (exact) return exact

    const ordered = this.turnoverOrder()
    const index = ordered.findIndex((item) => item.id === id)
    return index < 0 ? ordered.length + 1 : index + 1
  }

  peerCountOf(node: MarketNode): number {
    const stats = this.snapshot?.boardStats.get(node.board)
    if (stats && node.kind === 'stock') return Math.max(0, stats.universe - 1)

    let count = 0
    for (const candidate of this.nodes.values()) {
      if (candidate.id !== node.id && candidate.board === node.board) count += 1
    }
    return count
  }
}

export const marketService = new MarketService()

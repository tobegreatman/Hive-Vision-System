import { marketNodeSchema } from '@platform/contracts'
import { describe, expect, it } from 'vitest'

import { MarketService, stableNodeId } from './market.service.js'

describe('stableNodeId', () => {
  it('同一只标的每次启动都得到同一个 id（分享链接不能过夜失效）', () => {
    const first = stableNodeId('SH', '600519')
    const second = stableNodeId('SH', '600519')
    expect(first).toBe(second)
    expect(marketNodeSchema.shape.id.safeParse(first).success).toBe(true)
  })

  it('同代码不同市场互不冲突', () => {
    expect(stableNodeId('SH', '000001')).not.toBe(stableNodeId('SZ', '000001'))
  })
})

describe('MarketService（demo 兜底模式）', () => {
  const service = new MarketService({ mode: 'demo', samplePerBoard: 10 })

  it('没有真实快照时如实标注 demo，并给出内置样本', () => {
    expect(service.dataMode()).toBe('demo')
    expect(service.quoteStatus()).toBeNull()
    expect(service.list().length).toBeGreaterThan(0)
  })

  it('板块聚合的 count 与 sampleCount 在兜底模式下相等', () => {
    const boards = service.boards()
    const main = boards.find((board) => board.board === 'main')
    expect(main?.count).toBe(main?.sampleCount)
    expect(main?.count).toBeGreaterThan(0)
  })

  it('自选幂等：已在盘面上的代码不会造出第二个格子', () => {
    const before = service.list().length
    const node = service.create({
      symbol: '600519',
      name: '贵州茅台',
      exchange: 'SH',
      board: 'main',
      price: 1586,
      changePct: 1.24,
      turnover: 38.6,
      heat: 0.5,
    })
    expect(node.symbol).toBe('600519')
    expect(service.list().length).toBe(before)
  })

  it('关注度写回后能扛住重建（heat 按 symbol 记住）', () => {
    const node = service.list().find((item) => item.symbol === '300750')
    expect(node).toBeDefined()
    if (!node) return

    const updated = service.update(node.id, { heat: 0.12 })
    expect(updated?.heat).toBe(0.12)
  })
})

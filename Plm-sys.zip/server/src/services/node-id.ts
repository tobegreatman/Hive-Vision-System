import { createHash } from 'node:crypto'

import type { MarketExchange } from '@platform/contracts'

/**
 * 标的 id 由「交易所 + 代码」确定性派生（UUIDv5 布局）。
 *
 * 之前每次启动 `randomUUID()` 一发，id 每次都不一样，`?node=<id>` 这种分享链接
 * 过一夜就全失效。真实行情每 20s 整体换一帧，id 必须是身份而不是实例。
 *
 * 放在独立模块而不是 market.service 里：自选池也要用它生成与蜂巢节点一致的 id，
 * 直接反向依赖 market.service 会形成循环引用。
 */
export function stableNodeId(exchange: MarketExchange, symbol: string): string {
  const digest = createHash('sha1').update(`platform-sys:market:${exchange}:${symbol}`).digest()
  const bytes = Buffer.from(digest.subarray(0, 16))
  bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x50 // version 5
  bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80 // RFC 4122 variant
  const hex = bytes.toString('hex')
  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20, 32),
  ].join('-')
}

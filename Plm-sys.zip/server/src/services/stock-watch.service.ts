import type {
  MarketExchange,
  MarketKlineBar,
  MarketKlinePeriod,
  MarketStock,
  MarketStockCandidate,
  MarketStockQuote,
} from '@platform/contracts'

import { stableNodeId } from './node-id.js'
import {
  boardOfCode,
  fetchStockKline,
  fetchWatchedIndexQuotes,
  fetchWatchedIndexTrend,
  sessionMinutesOf,
  type KlineBar,
  type WatchedIndexQuote,
  type WatchedIndexTrend,
} from './quote.service.js'
import { fetchSearchRows, type SearchRow } from './quote-search.js'
import { fetchTencentKline, fetchTencentQuotes, fetchTencentTrend } from './tencent-quote.js'

/**
 * 自定义板块（板块导航里的「自定义」）。
 *
 * 与自选指数同一套思路：只维护一份 secid 白名单，行情走 quote.service 的统一上游通道。
 * - 快照：`ulist.np` 一次批量取回（A 股任意 secid 都行）
 * - 分时：`trends2` 每只一次，缓存 60s
 * - K 线：`kline/get` 按粒度取，日线 60s、周 / 月线 5min
 *
 * 列表存内存，与自选指数 / 手工自选保持一致：服务重启后自选池清空。
 */

/** 上限既保护上游额度，也避免左侧面板无限拉长。 */
const MAX_WATCHED = 20
const QUOTE_TTL_MS = 15_000
const TREND_TTL_MS = 60_000
const SEARCH_TTL_MS = 5 * 60_000
const KLINE_TTL_MS: Record<MarketKlinePeriod, number> = {
  // 盘中最后一根日线还在动，缓存太久会看到一根「凝固」的柱子
  day: 60_000,
  week: 5 * 60_000,
  month: 5 * 60_000,
}
const SECID_PATTERN = /^\d{1,3}\.[A-Za-z0-9]{1,16}$/

/**
 * klt：101 日 / 102 周 / 103 月。
 * 图表一屏只显示约 60 根，其余靠左右拖拽查看，所以这里保留完整历史。
 */
const KLINE_REQUEST: Record<MarketKlinePeriod, { klt: string; limit: number }> = {
  day: { klt: '101', limit: 250 },
  week: { klt: '102', limit: 220 },
  month: { klt: '103', limit: 240 },
}

export type StockWatchErrorCode = 'limit' | 'not_found' | 'upstream'

export class StockWatchError extends Error {
  constructor(
    readonly code: StockWatchErrorCode,
    message: string,
  ) {
    super(message)
    this.name = 'StockWatchError'
  }
}

function round2(value: number): number {
  return Number(value.toFixed(2))
}

/** secid 的市场号只区分沪 / 深，北交所也走 0；交易所归属按代码段判定。 */
function exchangeOf(code: string, market: number): MarketExchange {
  if (boardOfCode(code) === 'bse') return 'BJ'
  return market === 1 ? 'SH' : 'SZ'
}

function toItem(
  quote: WatchedIndexQuote,
  trend: WatchedIndexTrend | null,
  asOf = new Date().toISOString(),
): MarketStock {
  return {
    ...quote,
    quoteStatus: 'live',
    nodeId: stableNodeId(exchangeOf(quote.code, quote.market), quote.code),
    spark: trend?.points ?? [],
    sparkAxis: trend?.axisMinutes ?? null,
    asOf,
  }
}

function toCandidate(raw: SearchRow): MarketStockCandidate | null {
  const secid = String(raw.QuoteID ?? '').trim()
  const code = String(raw.Code ?? '').trim()
  const name = String(raw.Name ?? '').trim()
  const market = Number(raw.MktNum)
  const typeLabel = String(raw.SecurityTypeName ?? '').trim()

  if (!SECID_PATTERN.test(secid) || !/^\d{6}$/.test(code) || !name || !Number.isInteger(market)) {
    return null
  }
  // 上游 suggest 会混进基金 / 债券 / 港股 / 美股，这里只要沪深北 A 股
  if (!/(沪|深|京)A$/.test(typeLabel)) return null

  return {
    secid,
    code,
    market,
    name: name.slice(0, 24),
    typeLabel: typeLabel.slice(0, 12),
  }
}

export class StockWatchService {
  private readonly secids: string[] = []
  /** 搜索选择时带上的名称：实时快照缺失时用它兜底，避免列表只剩一串代码。 */
  private readonly names = new Map<string, string>()

  private quotesCache: { at: number; key: string; value: WatchedIndexQuote[] } | null = null
  private quotesInflight: { key: string; promise: Promise<WatchedIndexQuote[]> } | null = null

  private readonly trendCache = new Map<string, { at: number; value: WatchedIndexTrend }>()
  private readonly trendInflight = new Map<string, Promise<WatchedIndexTrend>>()

  private readonly searchCache = new Map<string, { at: number; value: MarketStockCandidate[] }>()
  private readonly klineCache = new Map<string, { at: number; value: MarketKlineBar[] }>()
  private readonly klineInflight = new Map<string, Promise<MarketKlineBar[]>>()

  secidList(): string[] {
    return [...this.secids]
  }

  async list(): Promise<MarketStock[]> {
    const secids = [...this.secids]
    if (secids.length === 0) return []

    let quotes: WatchedIndexQuote[] = []
    try {
      quotes = await this.ensureQuotes(secids)
    } catch {
      // 实时快照源挂了不代表自选池不可用：下面逐只走日线兜底
    }

    const quoteBySecid = new Map(quotes.map((quote) => [quote.secid, quote]))
    const asOf = new Date().toISOString()

    return Promise.all(
      secids.map(async (secid) => {
        const quote = quoteBySecid.get(secid)
        if (!quote) {
          // 停牌 / 实时源不可用：用最近一根日线收盘兜底，先让自选池可见
          const fallback = await this.safeFallbackQuote(secid)
          return this.pendingItem(secid, this.names.get(secid) ?? '', fallback)
        }

        let trend: WatchedIndexTrend | null = null
        try {
          trend = await this.ensureTrend(secid)
        } catch {
          // 分时挂了不影响主列表：前端会画一条空基线
        }
        return toItem(quote, trend, asOf)
      }),
    )
  }

  async add(input: { secid: string; name?: string }): Promise<MarketStock> {
    if (!SECID_PATTERN.test(input.secid)) {
      throw new StockWatchError('not_found', '证券代码格式应为「市场.代码」，如 1.600519')
    }

    if (this.secids.includes(input.secid)) {
      if (input.name) this.names.set(input.secid, input.name)
      const existing = (await this.list()).find((item) => item.secid === input.secid)
      if (existing) return existing
    }

    if (this.secids.length >= MAX_WATCHED) {
      throw new StockWatchError('limit', `最多同时添加 ${MAX_WATCHED} 只个股，请先移除一只`)
    }

    const { quote, reachable } = await this.liveQuote(input.secid)

    if (!quote && reachable) {
      throw new StockWatchError('not_found', '行情源没有这只个股的报价')
    }
    if (quote && !/^\d{6}$/.test(quote.code)) {
      throw new StockWatchError('not_found', '行情源没有这只个股的报价')
    }
    if (quote && input.name && quote.name === quote.code) quote.name = input.name

    this.secids.push(input.secid)
    if (input.name) this.names.set(input.secid, input.name)
    this.quotesCache = null
    this.trendCache.delete(input.secid)
    this.clearKline(input.secid)

    // 实时源不可用：用最近日线收盘组一份「待行情」快照，添加不再报错
    if (!quote) {
      const fallback = await this.safeFallbackQuote(input.secid)
      return this.pendingItem(input.secid, input.name ?? '', fallback)
    }

    let trend: WatchedIndexTrend | null = null
    try {
      trend = await this.ensureTrend(input.secid, true)
    } catch {
      // 分时首次失败不阻塞添加，下一轮 list 会再试
    }

    return toItem(quote, trend)
  }

  remove(secid: string): boolean {
    const index = this.secids.indexOf(secid)
    if (index < 0) return false

    this.secids.splice(index, 1)
    this.names.delete(secid)
    this.quotesCache = null
    this.trendCache.delete(secid)
    this.trendInflight.delete(secid)
    this.clearKline(secid)
    return true
  }

  /**
   * 单只个股报价：给「加入自选盘面」用。
   * 用户只选股票，现价 / 涨跌幅由这里补齐；实时源不可用时退回最近日线收盘并标记 delayed。
   */
  async lookup(secid: string): Promise<MarketStockQuote | null> {
    if (!SECID_PATTERN.test(secid)) {
      throw new StockWatchError('not_found', '证券代码格式应为「市场.代码」')
    }

    const { quote } = await this.liveQuote(secid)
    if (quote && quote.price > 0) {
      return {
        secid: quote.secid,
        code: quote.code,
        name: quote.name || quote.code,
        price: quote.price,
        changePct: quote.changePct,
        preClose: quote.preClose,
        quoteStatus: 'live',
      }
    }

    const fallback = await this.safeFallbackQuote(secid)
    if (!fallback || fallback.price <= 0) return null

    return {
      secid: fallback.secid,
      code: fallback.code,
      name: this.names.get(secid) || fallback.name,
      price: fallback.price,
      changePct: fallback.changePct,
      preClose: fallback.preClose,
      quoteStatus: 'delayed',
    }
  }

  /** 日线最后两根收盘拼出一份「延时快照」：实时源不可用时的兜底。 */
  private async fallbackQuote(secid: string): Promise<WatchedIndexQuote | null> {
    const bars = await this.kline(secid, 'day')
    if (bars.length === 0) return null

    const last = bars[bars.length - 1]!
    const previousClose = bars.length > 1 ? bars[bars.length - 2]!.close : last.open
    const change = last.close - previousClose
    const [marketRaw = '0', code = secid] = secid.split('.')

    return {
      secid,
      code,
      market: Number.parseInt(marketRaw, 10) || 0,
      name: code,
      price: last.close,
      change: round2(change),
      changePct: previousClose > 0 ? round2((change / previousClose) * 100) : 0,
      preClose: round2(previousClose),
      high: last.high,
      low: last.low,
      turnover: round2(last.amount / 1e8),
    }
  }

  private async safeFallbackQuote(secid: string): Promise<WatchedIndexQuote | null> {
    try {
      return await this.fallbackQuote(secid)
    } catch {
      return null
    }
  }

  /** 待行情条目：价格可能为 0（日线也拿不到），前端显示「待行情」。 */
  private pendingItem(
    secid: string,
    name: string,
    fallback: WatchedIndexQuote | null,
  ): MarketStock {
    const [marketRaw = '0', code = secid] = secid.split('.')
    const market = Number.parseInt(marketRaw, 10) || 0
    const base: WatchedIndexQuote = fallback ?? {
      secid,
      code,
      market,
      name: code,
      price: 0,
      change: 0,
      changePct: 0,
      preClose: 0,
      high: 0,
      low: 0,
      turnover: 0,
    }

    return {
      ...base,
      name: (name.trim() || base.name || code).slice(0, 24),
      quoteStatus: 'pending',
      nodeId: stableNodeId(exchangeOf(code, base.market), code),
      spark: [],
      sparkAxis: sessionMinutesOf(secid),
      asOf: new Date().toISOString(),
    }
  }

  /** 搜索沪深北 A 股；指数 / 板块 / 基金等其它类型一律过滤。 */
  async search(query: string): Promise<MarketStockCandidate[]> {
    const keyword = query.trim()
    if (!keyword) return []

    const cached = this.searchCache.get(keyword)
    if (cached && Date.now() - cached.at < SEARCH_TTL_MS) return cached.value

    let rows: SearchRow[]
    try {
      rows = await fetchSearchRows(keyword)
    } catch (error) {
      throw new StockWatchError(
        'upstream',
        error instanceof Error ? error.message : '个股搜索暂不可用',
      )
    }

    const seen = new Set<string>()
    const value: MarketStockCandidate[] = []
    for (const row of rows) {
      const candidate = toCandidate(row)
      if (!candidate || seen.has(candidate.secid)) continue
      seen.add(candidate.secid)
      value.push(candidate)
      if (value.length >= 12) break
    }

    this.searchCache.set(keyword, { at: Date.now(), value })
    return value
  }

  /** 日 / 周 / 月 K 线；分时走快照里的 `spark`，不在这里重复请求。 */
  async kline(secid: string, period: MarketKlinePeriod): Promise<MarketKlineBar[]> {
    if (!SECID_PATTERN.test(secid)) {
      throw new StockWatchError('not_found', '证券代码格式应为「市场.代码」')
    }

    const cacheKey = `${secid}:${period}`
    const cached = this.klineCache.get(cacheKey)
    if (cached && Date.now() - cached.at < KLINE_TTL_MS[period]) return cached.value

    const inflight = this.klineInflight.get(cacheKey)
    if (inflight) return inflight

    const config = KLINE_REQUEST[period]
    const promise = (async () => {
      let bars: KlineBar[] = []
      try {
        bars = await fetchStockKline(secid, config.klt, config.limit)
      } catch {
        // 东财被 WAF / 熔断拦截时不放弃，下面走腾讯兜底
      }

      if (bars.length === 0) {
        // 东财不可用时改走腾讯，粒度原样透传（day / week / month）
        try {
          bars = await fetchTencentKline(secid, period, config.limit)
        } catch {
          // 两个源都不可用：返回空数组，由前端提示「暂无 K 线」
        }
      }

      this.klineCache.set(cacheKey, { at: Date.now(), value: bars })
      return bars
    })().finally(() => {
      if (this.klineInflight.get(cacheKey) === promise) this.klineInflight.delete(cacheKey)
    })

    this.klineInflight.set(cacheKey, promise)
    return promise
  }

  private clearKline(secid: string): void {
    for (const period of Object.keys(KLINE_REQUEST) as MarketKlinePeriod[]) {
      const key = `${secid}:${period}`
      this.klineCache.delete(key)
      this.klineInflight.delete(key)
    }
  }

  private async ensureQuotes(secids: string[]): Promise<WatchedIndexQuote[]> {
    const key = secids.join(',')

    if (
      this.quotesCache &&
      this.quotesCache.key === key &&
      Date.now() - this.quotesCache.at < QUOTE_TTL_MS
    ) {
      return this.quotesCache.value
    }
    if (this.quotesInflight?.key === key) return this.quotesInflight.promise

    const promise = (async () => {
      let rows: WatchedIndexQuote[] = []
      try {
        rows = await fetchWatchedIndexQuotes(secids)
      } catch {
        // 东财批量快照失败：整批切腾讯
        rows = []
      }

      const missing = secids.filter((secid) => !rows.some((row) => row.secid === secid))
      if (missing.length > 0) {
        try {
          rows.push(...(await fetchTencentQuotes(missing)))
        } catch {
          // 两个源都失败：上层用日线收盘兜底
        }
      }

      this.quotesCache = { at: Date.now(), key, value: rows }
      return rows
    })().finally(() => {
      if (this.quotesInflight?.promise === promise) this.quotesInflight = null
    })

    this.quotesInflight = { key, promise }
    return promise
  }

  /** 添加时的实时报价：东财优先，失败 / 缺行整只切腾讯；两者都不可用才算“不可达”。 */
  private async liveQuote(
    secid: string,
  ): Promise<{ quote: WatchedIndexQuote | null; reachable: boolean }> {
    let reachable = false

    try {
      const rows = await fetchWatchedIndexQuotes([secid])
      reachable = true
      const row = rows.find((item) => item.secid === secid)
      if (row) return { quote: row, reachable }
    } catch {
      // 继续试腾讯
    }

    try {
      const rows = await fetchTencentQuotes([secid])
      reachable = true
      return { quote: rows.find((item) => item.secid === secid) ?? null, reachable }
    } catch {
      return { quote: null, reachable }
    }
  }

  private async ensureTrend(secid: string, force = false): Promise<WatchedIndexTrend> {
    const cached = this.trendCache.get(secid)
    if (!force && cached && Date.now() - cached.at < TREND_TTL_MS) return cached.value

    const inflight = this.trendInflight.get(secid)
    if (inflight) return inflight

    const promise = (async () => {
      let eastmoney: WatchedIndexTrend | null = null
      try {
        eastmoney = await fetchWatchedIndexTrend(secid)
        if (eastmoney.points.some((point) => point > 0)) return eastmoney
      } catch {
        // 继续试腾讯
      }

      const fallback = await fetchTencentTrend(secid).catch(() => null)
      return fallback ?? eastmoney ?? { points: [], preClose: null, axisMinutes: 240 }
    })()
      .then((value) => {
        this.trendCache.set(secid, { at: Date.now(), value })
        return value
      })
      .finally(() => {
        if (this.trendInflight.get(secid) === promise) this.trendInflight.delete(secid)
      })

    this.trendInflight.set(secid, promise)
    return promise
  }
}

export const stockWatchService = new StockWatchService()

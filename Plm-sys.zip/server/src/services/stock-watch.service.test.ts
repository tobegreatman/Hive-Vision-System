import { describe, expect, it } from 'vitest'

import { parseKline } from './quote.service.js'

describe('parseKline', () => {
  it('按 fields2 顺序解析出日线，并丢弃缺价 / 停牌的脏行', () => {
    const payload = {
      data: {
        klines: [
          '2026-11-10,10.00,10.50,10.80,9.90,12000,12500000,9.0,5.00,0.50,1.20',
          '2026-11-11,10.50,10.20,10.60,10.10,9000,9200000,-4.8,-2.86,-0.30,0.90',
          '2026-11-12,-,-,-,-,-,-,-,-,-,-',
        ],
      },
    }

    const bars = parseKline(payload)
    expect(bars).toHaveLength(2)
    expect(bars[0]).toEqual({
      at: '2026-11-10',
      open: 10,
      close: 10.5,
      high: 10.8,
      low: 9.9,
      volume: 12000,
      amount: 12500000,
      changePct: 5,
    })
    expect(bars[1]?.at).toBe('2026-11-11')
    expect(bars[1]?.changePct).toBe(-2.86)
  })

  it('上游返回空对象时给空数组，不抛异常', () => {
    expect(parseKline({ data: { klines: [] } })).toEqual([])
    expect(parseKline({})).toEqual([])
    expect(parseKline(null)).toEqual([])
  })
})

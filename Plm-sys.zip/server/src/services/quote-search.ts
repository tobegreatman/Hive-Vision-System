import { MARKET_PROVIDER } from '@platform/contracts'

/**
 * 东财 suggest 搜索的公共传输层。
 *
 * 指数 / 板块与个股走的是同一个上游接口，只是过滤条件不同：
 * 这里只负责「按关键词取回原始行」，类型筛选与缓存各服务自己维护，
 * 避免把「指数」与「个股」的业务口径混在一个函数里。
 */

const SEARCH_TIMEOUT_MS = 6_000
const SEARCH_COUNT = 20

export interface SearchRow {
  QuoteID?: unknown
  Code?: unknown
  Name?: unknown
  MktNum?: unknown
  SecurityTypeName?: unknown
}

export async function fetchSearchRows(keyword: string): Promise<SearchRow[]> {
  const params = new URLSearchParams({
    input: keyword,
    type: '14',
    token: MARKET_PROVIDER.searchToken,
    count: String(SEARCH_COUNT),
  })
  const url = `https://${MARKET_PROVIDER.searchHost}${MARKET_PROVIDER.searchPath}?${params.toString()}`

  let response: Response
  try {
    response = await fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
        Referer: MARKET_PROVIDER.referer,
      },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    })
  } catch (error) {
    throw new Error(`证券搜索暂不可用：${error instanceof Error ? error.message : String(error)}`)
  }
  if (!response.ok) throw new Error(`证券搜索暂不可用（${response.status}）`)

  const payload = (await response.json().catch(() => null)) as {
    QuotationCodeTable?: { Data?: unknown }
  } | null
  const rawRows = payload?.QuotationCodeTable?.Data
  return Array.isArray(rawRows) ? (rawRows as SearchRow[]) : []
}

/**
 * 上游请求闸：令牌桶（削峰） + 熔断（止撞墙） + 指数退避（带抖动）。
 *
 * 为什么需要它：一次全量扫描是 60 页。如果只靠 `Promise.all` 限并发，
 * 实测 5 路并发能在 0.5s 内把 60 个请求全部打出——平均每分钟 180 次没问题，
 * 但**瞬时 120 req/s 的脉冲**恰好是风控最敏感的形状。令牌桶把同样是 60 个请求
 * 摊平到 5 秒（默认 12 req/s），平均负载一点没少，瞬时压力降一个数量级。
 *
 * 熔断解决另一个问题：被限流后如果每 20 秒（TTL）又去全量扫一轮，
 * 就是持续撞墙，还可能把「限流」升级成「封 IP」。连续失败或收到 429/503
 * 之后，这里会直接闭闸一段时间，期间所有请求立刻失败并由上层用旧帧兜底。
 */

import { serverEnv } from '../env.js'

export type BreakerState = 'closed' | 'open' | 'half-open'

export interface LimiterOptions {
  /** 稳态放行速率（个/秒） */
  ratePerSec?: number
  /** 突发容量：空闲后最多能立刻打出多少个 */
  burst?: number
  /** 连续失败多少次开闸 */
  failureThreshold?: number
  /** 熔断基础冷却时长，连续触发按 2 的幂放大 */
  cooldownMs?: number
  /** 冷却上限，避免一次惩罚就把行情冻结半小时 */
  maxCooldownMs?: number
  /** 注入时钟，便于测试 */
  now?: () => number
}

/** 熔断打开时抛出：调用方应立刻放弃重试，而不是换域名再撞一次。 */
export class UpstreamBreakerOpenError extends Error {
  constructor(readonly retryAfterMs: number) {
    super(`upstream circuit open, ${Math.max(0, Math.round(retryAfterMs))}ms left`)
    this.name = 'UpstreamBreakerOpenError'
  }
}

/** 半开状态下探针请求的存活上限：调用方漏了 report 也不至于把闸门永久锁死。 */
const PROBE_TIMEOUT_MS = 10_000
/** 冷却最多放大到基础值的 2^4 = 16 倍 */
const MAX_BACKOFF_EXPONENT = 4

/**
 * full jitter 退避：`random() × min(cap, base × 2^attempt)`。
 *
 * 不用「固定间隔」是因为一批页往往同时失败，固定间隔会让它们在同一个瞬间
 * 齐刷刷重来，等于把限流节奏复制一遍。抖动把它们打散。
 */
export function backoffDelay(
  attempt: number,
  baseMs: number,
  capMs: number,
  random: () => number = Math.random,
): number {
  const ceiling = Math.min(capMs, baseMs * 2 ** Math.max(0, attempt))
  return Math.round(random() * ceiling)
}

/**
 * 解析 `Retry-After`（上游两种写法都支持：秒数 / HTTP 日期）。
 * 上游明确告诉你多久之后再来，照着做是最省事的合规姿势。
 */
export function parseRetryAfter(header: string | null, now = Date.now()): number | null {
  if (!header) return null
  const raw = header.trim()
  if (!raw) return null

  // 纯数字（含小数）按秒处理
  if (/^\d+(\.\d+)?$/.test(raw)) return Math.round(Number(raw) * 1000)

  const at = Date.parse(raw)
  if (!Number.isNaN(at)) return Math.max(0, at - now)
  return null
}

export class UpstreamLimiter {
  private readonly ratePerSec: number
  private readonly burst: number
  private readonly failureThreshold: number
  private readonly cooldownMs: number
  private readonly maxCooldownMs: number
  private readonly now: () => number

  private tokens: number
  private lastRefill: number
  private readonly waiters: Array<() => void> = []
  private timer: ReturnType<typeof setTimeout> | null = null

  private failures = 0
  private openedCount = 0
  private cooldownUntil = 0
  private probeInFlight = false
  private probeAt = 0
  private lastThrottleAt = 0

  constructor(options: LimiterOptions = {}) {
    this.ratePerSec = Math.max(0.5, options.ratePerSec ?? 12)
    this.burst = Math.max(1, Math.floor(options.burst ?? 6))
    this.failureThreshold = Math.max(1, options.failureThreshold ?? 6)
    this.cooldownMs = Math.max(1_000, options.cooldownMs ?? 60_000)
    this.maxCooldownMs = Math.max(this.cooldownMs, options.maxCooldownMs ?? 300_000)
    this.now = options.now ?? Date.now

    this.tokens = this.burst
    this.lastRefill = this.now()
  }

  state(): BreakerState {
    if (this.cooldownUntil === 0) return 'closed'
    return this.now() < this.cooldownUntil ? 'open' : 'half-open'
  }

  cooldownRemainingMs(): number {
    return Math.max(0, this.cooldownUntil - this.now())
  }

  /**
   * 取一个请求许可：先过熔断，再排队等令牌。
   * 熔断打开时立刻抛 `UpstreamBreakerOpenError`，调用方不该重试。
   */
  async acquire(): Promise<void> {
    this.assertAvailable()
    await this.takeToken()
  }

  /** 上游给了正常响应：清零失败计数、关闭熔断。 */
  reportSuccess(): void {
    this.failures = 0
    this.openedCount = 0
    this.cooldownUntil = 0
    this.probeInFlight = false
  }

  /**
   * 上游失败。`rateLimited` 为真（429 / 503 / 403 / 带 Retry-After）时
   * 不再等失败阈值累计——上游都已经明说「慢点」，再撞两次毫无意义。
   */
  reportFailure(options: { rateLimited?: boolean; retryAfterMs?: number } = {}): void {
    this.probeInFlight = false
    this.failures += 1

    const hint = options.retryAfterMs ?? 0
    if (options.rateLimited || hint > 0) {
      this.lastThrottleAt = this.now()
      this.openCooldown(hint)
      return
    }

    if (this.failures >= this.failureThreshold) this.openCooldown(0)
  }

  /** 健康检查与调试用的快照。 */
  stats(): {
    ratePerSec: number
    burst: number
    breaker: BreakerState
    cooldownRemainingMs: number
    consecutiveFailures: number
    lastThrottleAt: string | null
  } {
    return {
      ratePerSec: this.ratePerSec,
      burst: this.burst,
      breaker: this.state(),
      cooldownRemainingMs: Math.round(this.cooldownRemainingMs()),
      consecutiveFailures: this.failures,
      lastThrottleAt: this.lastThrottleAt > 0 ? new Date(this.lastThrottleAt).toISOString() : null,
    }
  }

  /** 仅用于测试：清空令牌、队列与熔断状态。 */
  reset(): void {
    if (this.timer) {
      clearTimeout(this.timer)
      this.timer = null
    }
    // 排队的调用者不能永久悬挂，直接放行（宁可多一个请求也不要死锁）
    while (this.waiters.length) this.waiters.shift()?.()
    this.tokens = this.burst
    this.lastRefill = this.now()
    this.failures = 0
    this.openedCount = 0
    this.cooldownUntil = 0
    this.probeInFlight = false
    this.probeAt = 0
    this.lastThrottleAt = 0
  }

  private assertAvailable(): void {
    const state = this.state()

    if (state === 'open') {
      throw new UpstreamBreakerOpenError(this.cooldownRemainingMs())
    }

    if (state === 'half-open') {
      // 冷却刚过，只放一个探针出去；它成功就彻底恢复，失败则重新闭闸
      if (this.probeInFlight && this.now() - this.probeAt < PROBE_TIMEOUT_MS) {
        throw new UpstreamBreakerOpenError(1_000)
      }
      this.probeInFlight = true
      this.probeAt = this.now()
    }
  }

  private openCooldown(hintMs: number): void {
    this.openedCount += 1
    const backoff = this.cooldownMs * 2 ** Math.min(this.openedCount - 1, MAX_BACKOFF_EXPONENT)
    // 上游给的 Retry-After 优先，但同样受上限约束
    const cooldown = Math.min(this.maxCooldownMs, Math.max(hintMs, backoff))
    this.cooldownUntil = this.now() + cooldown
  }

  private refill(): void {
    const now = this.now()
    const elapsed = now - this.lastRefill
    if (elapsed <= 0) return
    this.tokens = Math.min(this.burst, this.tokens + (elapsed / 1_000) * this.ratePerSec)
    this.lastRefill = now
  }

  private takeToken(): Promise<void> {
    this.refill()
    if (this.tokens >= 1) {
      this.tokens -= 1
      return Promise.resolve()
    }
    return new Promise<void>((resolve) => {
      this.waiters.push(resolve)
      this.pump()
    })
  }

  /**
   * 单一定时器驱动队列：每轮把现有令牌发给队首，然后按「还差几个令牌」算出
   * 下一次唤醒时间。用一个 timer 而不是每个请求各起一个，避免 60 个页面
   * 醒来后同时抢同一个令牌的惊群。
   */
  private pump(): void {
    if (this.timer) return

    this.refill()
    while (this.waiters.length > 0 && this.tokens >= 1) {
      this.tokens -= 1
      this.waiters.shift()?.()
    }
    if (this.waiters.length === 0) return

    const deficit = 1 - this.tokens
    const delay = Math.max(1, Math.ceil((deficit / this.ratePerSec) * 1_000))
    this.timer = setTimeout(() => {
      this.timer = null
      this.pump()
    }, delay)
    // 别因为一个待发的请求把进程钉在事件循环里
    this.timer.unref?.()
  }
}

/**
 * 全局单例：整轮扫描（含指数请求）共用同一个桶，
 * 否则「每页各建一个 limiter」等于没有限速。
 */
export const upstreamLimiter = new UpstreamLimiter({
  ratePerSec: serverEnv.upstreamQps,
  burst: serverEnv.upstreamBurst,
  cooldownMs: serverEnv.breakerCooldownMs,
})

/**
 * 历史 K 线（push2his）单独一个桶。
 *
 * 实时快照所在的 push2 被 WAF 掐断时，如果共用同一个熔断器，
 * 用户连个股 K 线都打不开——而这两类接口在域名层面本来就是分开的。
 */
export const klineLimiter = new UpstreamLimiter({
  ratePerSec: serverEnv.upstreamQps,
  burst: serverEnv.upstreamBurst,
  cooldownMs: serverEnv.breakerCooldownMs,
})

import {
  INDUSTRY_FEED_FIELDS,
  INDUSTRY_PROVIDER,
  type IndustryFeedRows,
  type IndustryPeriod,
} from '@platform/contracts'

/**
 * 行业资金流取数代理。
 *
 * 浏览器不再直连上游（JSONP = 允许第三方在本页执行任意脚本），改为同源 `/api/feed`。
 * 这里只做「抓取 + 缓存 + 原样透传原始行」，字段解码与聚合仍由前端的
 * `decodeRow` / `build()` 负责，保持业务规则只有一份实现。
 */

/** 抓取结果缓存时长：略短于前端缓存（60s），保证用户强制刷新时能拿到新数据。 */
const CACHE_TTL_MS = 55_000
const PAGE_TIMEOUT_MS = 6_000
/** 页间隔：上游对连续分页有 IP 级限流，串行 + 小间隔比并发更稳。 */
const PAGE_GAP_MS = 80
/** 兜底页数上限，避免上游 total 异常时无限翻页。 */
const MAX_PAGES = 8

interface RawBundle {
  at: number
  rows: unknown[]
  total: number
  pages: number
  latencyMs: number
  failedPages: number
}

let cache: RawBundle | null = null
let inflight: Promise<RawBundle> | null = null
/** 镜像域游标：失败后换下一个域，避免一直撞同一台坏主机。 */
let hostCursor = 0

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

function pickHost(offset: number): string {
  const hosts = INDUSTRY_PROVIDER.hosts
  const index = (hostCursor + offset) % hosts.length
  return hosts[index] ?? hosts[0] ?? 'push2.eastmoney.com'
}

function buildUrl(host: string, page: number): string {
  const params = new URLSearchParams({
    pn: String(page),
    pz: String(INDUSTRY_PROVIDER.pageSize),
    po: '0',
    np: '1',
    fltt: '2',
    invt: '2',
    fid: 'f12',
    fs: INDUSTRY_PROVIDER.universeFs,
    fields: INDUSTRY_FEED_FIELDS,
    _: String(Date.now()),
  })
  return `https://${host}${INDUSTRY_PROVIDER.path}?${params.toString()}`
}

/** 上游 diff 可能是数组，也可能是以序号为键的对象。 */
function extractRows(payload: unknown): { rows: unknown[]; total: number } {
  const data = (payload as { data?: { diff?: unknown; total?: number } } | null)?.data
  const diff = data?.diff
  let rows: unknown[] = []
  if (Array.isArray(diff)) rows = diff
  else if (diff && typeof diff === 'object') rows = Object.values(diff as Record<string, unknown>)
  return { rows, total: Number(data?.total ?? 0) }
}

async function requestPage(page: number): Promise<{ rows: unknown[]; total: number }> {
  let lastError: unknown = new Error('upstream unreachable')

  for (let attempt = 0; attempt < INDUSTRY_PROVIDER.hosts.length; attempt += 1) {
    const host = pickHost(attempt)
    try {
      const response = await fetch(buildUrl(host, page), {
        headers: {
          Accept: 'application/json, text/plain, */*',
          Referer: INDUSTRY_PROVIDER.referer,
          'User-Agent': 'Mozilla/5.0 (compatible; platform-sys/0.1)',
        },
        signal: AbortSignal.timeout(PAGE_TIMEOUT_MS),
      })
      if (!response.ok) {
        lastError = new Error(`upstream ${response.status}`)
        continue
      }
      const payload: unknown = await response.json()
      hostCursor = (hostCursor + attempt) % INDUSTRY_PROVIDER.hosts.length
      return extractRows(payload)
    } catch (error) {
      lastError = error
    }
  }

  throw lastError
}

/**
 * 抓全量板块列表。
 *
 * 首页失败直接抛错（交给路由层回 502）；后续页失败只累计 `failedPages`，
 * 用已有样本继续，`degraded` 会如实上报——宁可在审计面板里显示「少了一页」，
 * 也不要整页空白。
 */
async function collect(): Promise<RawBundle> {
  const startedAt = Date.now()
  const first = await requestPage(1)
  const total = first.total || INDUSTRY_PROVIDER.expected
  const pages = Math.min(MAX_PAGES, Math.max(1, Math.ceil(total / INDUSTRY_PROVIDER.pageSize)))

  let rows = first.rows
  let failedPages = 0

  for (let page = 2; page <= pages; page += 1) {
    await sleep(PAGE_GAP_MS)
    try {
      rows = rows.concat((await requestPage(page)).rows)
    } catch {
      failedPages += 1
    }
  }

  return { at: Date.now(), rows, total, pages, latencyMs: Date.now() - startedAt, failedPages }
}

/** 并发请求共享同一次抓取，避免冷启动时被多个页签打穿上游。 */
function refresh(): Promise<RawBundle> {
  if (inflight) return inflight

  inflight = collect()
    .then((bundle) => {
      cache = bundle
      return bundle
    })
    .catch((error: unknown) => {
      // 抓取失败但手里有过期数据：宁可发旧帧并标注 degraded，也不要整页报错
      if (cache) return { ...cache, failedPages: cache.pages, latencyMs: Date.now() - cache.at }
      throw error
    })
    .finally(() => {
      inflight = null
    })

  return inflight
}

async function bundle(): Promise<RawBundle> {
  if (cache && Date.now() - cache.at < CACHE_TTL_MS) return cache
  return refresh()
}

export const industryService = {
  /** 组装 `/api/feed` 响应。`period` 只影响前端聚合口径，raw 行是同一份。 */
  async feed(period: IndustryPeriod): Promise<IndustryFeedRows> {
    const data = await bundle()
    return {
      schema: 'industry-flow/rows-v1',
      period,
      asOf: new Date(data.at).toISOString(),
      total: data.total,
      pages: data.pages,
      latencyMs: data.latencyMs,
      degraded: data.failedPages > 0 || data.rows.length < data.total,
      records: data.rows,
    }
  },
}

export type { RawBundle }

import { Hono } from 'hono'
import { describe, expect, it } from 'vitest'

import { rateLimit } from './rate-limit.js'
import { writeGuard } from './write-guard.js'

/**
 * 写接口守卫是这次加固里唯一「判错就等于没防」的部件，
 * 三种分支（放行 / 401 / 503）必须锁死。
 */
function appWith(token: string, host: string): Hono {
  const app = new Hono()
  app.use('*', writeGuard(token, host))
  app.get('/r', (c) => c.json({ ok: true }))
  app.post('/w', (c) => c.json({ ok: true }, 201))
  app.patch('/w', (c) => c.json({ ok: true }))
  return app
}

describe('writeGuard', () => {
  it('allows anonymous writes on loopback when no token is configured', async () => {
    const app = appWith('', '127.0.0.1')

    const response = await app.request('/w', { method: 'POST' })

    expect(response.status).toBe(201)
  })

  it('refuses anonymous writes when bound to a non-loopback host', async () => {
    const app = appWith('', '0.0.0.0')

    const response = await app.request('/w', { method: 'POST' })

    expect(response.status).toBe(503)
    await expect(response.json()).resolves.toMatchObject({
      error: { code: 'write_disabled' },
    })
  })

  it('rejects writes without the token once one is configured', async () => {
    const app = appWith('s3cret', '127.0.0.1')

    const response = await app.request('/w', { method: 'POST' })

    expect(response.status).toBe(401)
  })

  it('rejects a wrong token, including one that is a prefix of the real value', async () => {
    const app = appWith('s3cret', '127.0.0.1')

    const wrong = await app.request('/w', {
      method: 'POST',
      headers: { 'X-Write-Token': 's3cre' },
    })
    const right = await app.request('/w', {
      method: 'POST',
      headers: { 'X-Write-Token': 's3cret' },
    })

    expect(wrong.status).toBe(401)
    expect(right.status).toBe(201)
  })

  it('accepts the token as a bearer credential too', async () => {
    const app = appWith('s3cret', '0.0.0.0')

    const response = await app.request('/w', {
      method: 'PATCH',
      headers: { Authorization: 'Bearer s3cret' },
    })

    expect(response.status).toBe(200)
  })

  it('leaves reads untouched even when a token is required', async () => {
    const app = appWith('s3cret', '0.0.0.0')

    const response = await app.request('/r')

    expect(response.status).toBe(200)
  })
})

describe('rateLimit', () => {
  function limitedApp(max: number, scope?: string): Hono {
    const app = new Hono()
    app.use('*', rateLimit({ windowMs: 60_000, max, scope }))
    app.post('/a', (c) => c.json({ ok: true }))
    app.post('/b', (c) => c.json({ ok: true }))
    return app
  }

  it('returns 429 with Retry-After once the window budget is spent', async () => {
    const app = limitedApp(2)

    await app.request('/a', { method: 'POST' })
    await app.request('/a', { method: 'POST' })
    const blocked = await app.request('/a', { method: 'POST' })

    expect(blocked.status).toBe(429)
    expect(Number(blocked.headers.get('Retry-After'))).toBeGreaterThan(0)
  })

  it('shares one budget across paths when a scope is given', async () => {
    const app = limitedApp(2, 'write')

    await app.request('/a', { method: 'POST' })
    await app.request('/b', { method: 'POST' })
    // 换了路径，但仍然超预算：这正是「换 id 绕过限流」的防线
    const blocked = await app.request('/a', { method: 'POST' })

    expect(blocked.status).toBe(429)
  })

  it('keeps per-path budgets when no scope is given', async () => {
    const app = limitedApp(1)

    await app.request('/a', { method: 'POST' })
    const otherPath = await app.request('/b', { method: 'POST' })

    expect(otherPath.status).toBe(200)
  })
})

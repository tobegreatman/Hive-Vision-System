import { timingSafeEqual } from 'node:crypto'

import type { Context, MiddlewareHandler } from 'hono'

/**
 * 写接口守卫。
 *
 * 现状：`/api/market/nodes` 的 POST / PATCH 会直接改内存仓储，且没有任何身份。
 * 默认只绑 127.0.0.1 时问题不大，但只要 `HOST` 或 `CORS_ORIGINS` 被放开，
 * 就是一个公网可写的接口。策略：
 *
 *   - 配了 `WRITE_TOKEN`：所有写请求必须带 `X-Write-Token`（或 Bearer）；
 *   - 没配但绑在回环地址：放行，保留本地开发体验；
 *   - 没配且绑在非回环地址：直接 503，宁可写不了也不裸奔。
 */
const WRITE_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE'])

function isLoopback(host: string): boolean {
  return host === '127.0.0.1' || host === 'localhost' || host === '::1'
}

function safeEqual(presented: string, expected: string): boolean {
  const a = Buffer.from(presented)
  const b = Buffer.from(expected)
  // 长度不同直接判否，避免 timingSafeEqual 抛错；长度本身不是秘密
  if (a.length !== b.length) return false
  return timingSafeEqual(a, b)
}

function presentedToken(c: Context): string {
  const header = c.req.header('x-write-token')
  if (header) return header.trim()
  const authorization = c.req.header('authorization') ?? ''
  return authorization.toLowerCase().startsWith('bearer ') ? authorization.slice(7).trim() : ''
}

export function writeGuard(token: string, host: string): MiddlewareHandler {
  return async (c, next) => {
    if (!WRITE_METHODS.has(c.req.method)) {
      await next()
      return
    }

    if (!token) {
      if (isLoopback(host)) {
        await next()
        return
      }
      return c.json(
        {
          error: {
            code: 'write_disabled',
            message: '写接口未配置 WRITE_TOKEN，已拒绝匿名写入',
          },
        },
        503,
      )
    }

    if (!safeEqual(presentedToken(c), token)) {
      return c.json(
        { error: { code: 'unauthorized', message: '写接口需要有效的 X-Write-Token' } },
        401,
      )
    }

    await next()
  }
}

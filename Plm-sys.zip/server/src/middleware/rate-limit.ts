import { getConnInfo } from '@hono/node-server/conninfo'
import type { Context, MiddlewareHandler } from 'hono'

/**
 * 极简滑动窗口限流。
 *
 * 项目没有反向代理做接入层防护，而写接口会直接改内存仓储，
 * 必须在进程内兜一层——否则一个脚本就能把 `MarketService` 的 Map 撑爆。
 * 计数键 = 来源 IP + 作用域：
 *   - 读请求默认按路径分桶，接口之间不互相挤占；
 *   - 写请求必须共用一个作用域，否则换个 id 就是一条新桶，限流形同虚设。
 */
export interface RateLimitOptions {
  /** 窗口长度（毫秒） */
  windowMs: number
  /** 窗口内允许的请求数 */
  max: number
  /** 只统计这些方法；缺省统计全部 */
  methods?: readonly string[]
  /** 计数作用域；缺省用请求路径。写接口务必传固定值。 */
  scope?: string
  message?: string
}

interface Bucket {
  count: number
  resetAt: number
}

function clientIp(c: Context): string {
  try {
    return getConnInfo(c).remote.address ?? 'unknown'
  } catch {
    // 拿不到连接信息（非 node-server 适配器 / 单元测试的 app.request）时退化到共享桶
    return 'unknown'
  }
}

export function rateLimit(options: RateLimitOptions): MiddlewareHandler {
  const buckets = new Map<string, Bucket>()

  // 定期回收过期桶：来源 IP 数量不可控，不清理会变成另一个内存泄漏
  const sweeper = setInterval(
    () => {
      const now = Date.now()
      for (const [key, bucket] of buckets) {
        if (bucket.resetAt <= now) buckets.delete(key)
      }
    },
    Math.max(options.windowMs, 60_000),
  )
  sweeper.unref()

  return async (c, next) => {
    if (options.methods && !options.methods.includes(c.req.method)) {
      await next()
      return
    }

    const key = `${clientIp(c)}:${options.scope ?? c.req.path}`
    const now = Date.now()
    const bucket = buckets.get(key)

    if (!bucket || bucket.resetAt <= now) {
      buckets.set(key, { count: 1, resetAt: now + options.windowMs })
      await next()
      return
    }

    bucket.count += 1
    if (bucket.count > options.max) {
      c.header('Retry-After', String(Math.max(1, Math.ceil((bucket.resetAt - now) / 1000))))
      return c.json(
        {
          error: { code: 'rate_limited', message: options.message ?? '请求过于频繁，请稍后再试' },
        },
        429,
      )
    }

    await next()
  }
}

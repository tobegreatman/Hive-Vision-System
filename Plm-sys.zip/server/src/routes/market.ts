import type {
  ListMarketBoardsResponse,
  ListMarketIndicesResponse,
  ListMarketNodesResponse,
  ListMarketStocksResponse,
  MarketIndexResponse,
  MarketKlineResponse,
  MarketNodeDetailResponse,
  MarketNodeResponse,
  MarketOverviewResponse,
  MarketStockQuoteResponse,
  MarketStockResponse,
  RemoveMarketIndexResponse,
  RemoveMarketStockResponse,
  SearchMarketIndicesResponse,
  SearchMarketStocksResponse,
} from '@platform/contracts'
import {
  addMarketIndexInputSchema,
  addMarketStockInputSchema,
  limitStatusOf,
  marketKlinePeriodSchema,
} from '@platform/contracts'
import { Hono } from 'hono'

import { createMarketNodeInputSchema, updateMarketNodeInputSchema } from '../schemas/index.js'
import { badRequest, notFound, parseBody } from '../schemas/validate.js'
import { IndexWatchError, indexWatchService } from '../services/index-watch.service.js'
import { marketService } from '../services/market.service.js'
import { StockWatchError, stockWatchService } from '../services/stock-watch.service.js'

/** 路由层只做「解析 → 调用 service → 序列化」，不承载业务规则。 */
export const marketRoutes = new Hono()

/**
 * 每个读接口先把行情刷成新鲜的：`ready()` 内部按交易时段做 TTL 与并发去重，
 * 最坏情况（上游挂了）也只是返回上一帧，不会让页面 502。
 */
marketRoutes.get('/overview', async (c) => {
  await marketService.ready()
  const body: MarketOverviewResponse = { overview: marketService.overview() }
  return c.json(body)
})

/** 蜂巢第一层：板块聚合。 */
marketRoutes.get('/boards', async (c) => {
  await marketService.ready()
  const body: ListMarketBoardsResponse = {
    items: marketService.boards(),
    asOf: new Date().toISOString(),
  }
  return c.json(body)
})

marketRoutes.get('/nodes', async (c) => {
  await marketService.ready()
  const items = marketService.list()
  const body: ListMarketNodesResponse = { items, total: items.length }
  return c.json(body)
})

marketRoutes.post('/nodes', async (c) => {
  const parsed = await parseBody(c, createMarketNodeInputSchema)
  if (!parsed.success) return parsed.response

  const node = marketService.create(parsed.data)
  const body: MarketNodeResponse = { node }
  return c.json(body, 201)
})

marketRoutes.get('/nodes/:id', (c) => {
  const node = marketService.find(c.req.param('id'))
  if (!node) return notFound(c, '标的不存在')

  const body: MarketNodeResponse = { node }
  return c.json(body)
})

marketRoutes.get('/nodes/:id/detail', (c) => {
  const id = c.req.param('id')
  const node = marketService.find(id)
  if (!node) return notFound(c, '标的不存在')

  /**
   * 说明：这是唯一一个会写内存的读接口——`visits` 是「被检视次数」的统计埋点
   * （与页面浏览量同性质），因此它不是幂等 GET。既然刻意不幂等，
   * 就必须显式禁掉缓存，否则中间层会把计数当成可缓存资源，返回陈旧值。
   */
  c.header('Cache-Control', 'no-store')

  const visit = marketService.inspect(id)
  const body: MarketNodeDetailResponse = {
    node,
    detail: {
      rank: marketService.rankOf(id),
      peerCount: marketService.peerCountOf(node),
      limitStatus: limitStatusOf(node),
      visits: visit?.visits ?? 0,
      lastVisitedAt: visit?.lastVisitedAt ?? null,
    },
  }
  return c.json(body)
})

marketRoutes.patch('/nodes/:id', async (c) => {
  const parsed = await parseBody(c, updateMarketNodeInputSchema)
  if (!parsed.success) return parsed.response

  const node = marketService.update(c.req.param('id'), parsed.data)
  if (!node) return notFound(c, '标的不存在')

  const body: MarketNodeResponse = { node }
  return c.json(body)
})

/* ------------------------------------------------------------------ *
 * 自选指数：板块导航「大盘指数」区域的动态增删与微型分时
 * ------------------------------------------------------------------ */

marketRoutes.get('/indices', async (c) => {
  try {
    const body: ListMarketIndicesResponse = {
      items: await indexWatchService.list(),
      asOf: new Date().toISOString(),
    }
    return c.json(body)
  } catch (error) {
    console.error('[api] 自选指数取数失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '指数行情暂不可用，请稍后重试' } },
      502,
    )
  }
})

/** 搜索指数 / 板块：只返回上游标记为「指数」「板块」的结果。 */
marketRoutes.get('/indices/search', async (c) => {
  const query = (c.req.query('q') ?? '').trim()
  if (query.length === 0 || query.length > 24) {
    return badRequest(c, 'validation_error', '搜索关键词长度需在 1–24 个字符之间')
  }

  try {
    const body: SearchMarketIndicesResponse = { items: await indexWatchService.search(query) }
    return c.json(body)
  } catch (error) {
    console.error('[api] 指数搜索失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '指数搜索暂不可用，请稍后重试' } },
      502,
    )
  }
})

marketRoutes.post('/indices', async (c) => {
  const parsed = await parseBody(c, addMarketIndexInputSchema)
  if (!parsed.success) return parsed.response

  try {
    const item = await indexWatchService.add(parsed.data)
    // 立刻把新指数铺进蜂巢「指数」板块，不等下一轮 10s 轮询
    await marketService.refreshIndices()
    const body: MarketIndexResponse = { item }
    return c.json(body, 201)
  } catch (error) {
    if (error instanceof IndexWatchError) {
      if (error.code === 'limit') {
        return c.json({ error: { code: 'index_limit', message: error.message } }, 409)
      }
      if (error.code === 'not_found') return notFound(c, error.message)
      return c.json({ error: { code: 'upstream_unavailable', message: error.message } }, 502)
    }
    console.error('[api] 添加指数失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '指数行情暂不可用，请稍后重试' } },
      502,
    )
  }
})

marketRoutes.delete('/indices/:secid', async (c) => {
  const removed = indexWatchService.remove(c.req.param('secid'))
  if (removed) await marketService.refreshIndices()

  const body: RemoveMarketIndexResponse = { removed }
  return c.json(body)
})

/* ------------------------------------------------------------------ *
 * 自定义板块：个股自选池 + 日 / 周 / 年 K 线
 * ------------------------------------------------------------------ */

marketRoutes.get('/stocks', async (c) => {
  try {
    const body: ListMarketStocksResponse = {
      items: await stockWatchService.list(),
      asOf: new Date().toISOString(),
    }
    return c.json(body)
  } catch (error) {
    console.error('[api] 自定义板块取数失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '个股行情暂不可用，请稍后重试' } },
      502,
    )
  }
})

/** 搜索个股：只返回沪深北 A 股。 */
marketRoutes.get('/stocks/search', async (c) => {
  const query = (c.req.query('q') ?? '').trim()
  if (query.length === 0 || query.length > 24) {
    return badRequest(c, 'validation_error', '搜索关键词长度需在 1–24 个字符之间')
  }

  try {
    const body: SearchMarketStocksResponse = { items: await stockWatchService.search(query) }
    return c.json(body)
  } catch (error) {
    console.error('[api] 个股搜索失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '个股搜索暂不可用，请稍后重试' } },
      502,
    )
  }
})

/** 单只个股报价：加入自选盘面前由服务端补齐名称 / 现价 / 涨跌幅，避免手填。 */
marketRoutes.get('/stocks/:secid/quote', async (c) => {
  const secid = c.req.param('secid')
  try {
    const item = await stockWatchService.lookup(secid)
    if (!item) return notFound(c, '行情源没有这只个股的报价')

    c.header('Cache-Control', 'no-store')
    const body: MarketStockQuoteResponse = { item }
    return c.json(body)
  } catch (error) {
    if (error instanceof StockWatchError) {
      if (error.code === 'not_found') return notFound(c, error.message)
      return c.json({ error: { code: 'upstream_unavailable', message: error.message } }, 502)
    }
    console.error('[api] 个股报价取数失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '个股行情暂不可用，请稍后重试' } },
      502,
    )
  }
})

marketRoutes.post('/stocks', async (c) => {
  const parsed = await parseBody(c, addMarketStockInputSchema)
  if (!parsed.success) return parsed.response

  try {
    const item = await stockWatchService.add(parsed.data)
    // 立刻把新个股铺进蜂巢「自定义」板块，不等下一轮 10s 轮询
    await marketService.refreshCustomStocks()
    const body: MarketStockResponse = { item }
    return c.json(body, 201)
  } catch (error) {
    if (error instanceof StockWatchError) {
      if (error.code === 'limit') {
        return c.json({ error: { code: 'stock_limit', message: error.message } }, 409)
      }
      if (error.code === 'not_found') return notFound(c, error.message)
      return c.json({ error: { code: 'upstream_unavailable', message: error.message } }, 502)
    }
    console.error('[api] 添加个股失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: '个股行情暂不可用，请稍后重试' } },
      502,
    )
  }
})

marketRoutes.delete('/stocks/:secid', async (c) => {
  const removed = stockWatchService.remove(c.req.param('secid'))
  if (removed) await marketService.refreshCustomStocks()

  const body: RemoveMarketStockResponse = { removed }
  return c.json(body)
})

/** 历史 K 线：日 / 周 / 月。分时随自选池快照下发，不在这里。 */
marketRoutes.get('/stocks/:secid/kline', async (c) => {
  const period = marketKlinePeriodSchema.safeParse(c.req.query('period') ?? 'day')
  if (!period.success) return badRequest(c, 'validation_error', 'K 线粒度需为 day / week / month')

  const secid = c.req.param('secid')
  try {
    const bars = await stockWatchService.kline(secid, period.data)
    // K 线只有收盘后才定型，盘中最后一根每 60s 变一次：给短缓存而不是 no-store
    c.header('Cache-Control', 'public, max-age=30')
    const body: MarketKlineResponse = {
      secid,
      period: period.data,
      bars,
      asOf: new Date().toISOString(),
    }
    return c.json(body)
  } catch (error) {
    if (error instanceof StockWatchError) {
      if (error.code === 'not_found') return notFound(c, error.message)
      return c.json({ error: { code: 'upstream_unavailable', message: error.message } }, 502)
    }
    console.error('[api] 个股 K 线取数失败:', error)
    return c.json(
      { error: { code: 'upstream_unavailable', message: 'K 线暂不可用，请稍后重试' } },
      502,
    )
  }
})

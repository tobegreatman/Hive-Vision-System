import type { IndustryIntraday, IndustryPeriod } from '@platform/contracts'
import {
  INDUSTRY_PROVIDER,
  industryFeedRowsSchema,
  industryIntradaySchema,
  industryPeriodSchema,
} from '@platform/contracts'
import type { Context } from 'hono'
import { Hono } from 'hono'

import { badRequest } from '../schemas/validate.js'
import { industryService } from '../services/industry.service.js'

/**
 * 行业资金流的数据代理。
 *
 * 存在的理由：`/api/feed` 缺失时前端会退到 JSONP 直连第三方，
 * 那等于让数据源在页面上下文里执行任意脚本。所有上游访问都必须收口到这两个端点。
 */

const INTRADAY_TIMEOUT_MS = 6_000

function upstreamError(c: Context, message: string): Response {
  return c.json({ error: { code: 'upstream_unavailable', message } }, 502)
}

export const feedRoutes = new Hono()

feedRoutes.get('/', async (c) => {
  const parsed = industryPeriodSchema.safeParse(c.req.query('period') ?? 'd1')
  if (!parsed.success) {
    return badRequest(c, 'validation_error', '不支持的周期参数', { allowed: ['d1', 'd5', 'd10'] })
  }

  try {
    const body = await industryService.feed(parsed.data as IndustryPeriod)
    // 出厂前按共享契约自校验：字段一旦漂移，这里先炸，而不是等前端渲染空白
    return c.json(industryFeedRowsSchema.parse(body))
  } catch (error) {
    console.error('[api] feed 取数失败:', error)
    return upstreamError(c, '数据源暂不可用，请稍后重试')
  }
})

export const intradayRoutes = new Hono()

/** 板块分钟级资金流：原样透传上游时间序列，仅做字段解码与数值校验。 */
intradayRoutes.get('/', async (c) => {
  const code = c.req.query('code') ?? ''
  if (!/^\d{6}$/.test(code)) {
    return badRequest(c, 'validation_error', '证券代码必须是 6 位数字')
  }

  const host = INDUSTRY_PROVIDER.hosts[0] ?? 'push2.eastmoney.com'
  const url =
    `https://${host}/api/qt/stock/fflow/kline/get?lmt=0&klt=1&secid=90.${code}` +
    '&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'

  try {
    const response = await fetch(url, {
      headers: {
        Accept: 'application/json, text/plain, */*',
        Referer: INDUSTRY_PROVIDER.referer,
      },
      signal: AbortSignal.timeout(INTRADAY_TIMEOUT_MS),
    })
    if (!response.ok) return upstreamError(c, `数据源返回 ${response.status}`)

    const payload = (await response.json()) as { data?: { klines?: unknown } }
    const klines = Array.isArray(payload.data?.klines) ? payload.data.klines : []

    const body: IndustryIntraday = {
      code,
      points: klines.flatMap((line) => {
        if (typeof line !== 'string') return []
        const [t, main, sm, md, lg, xl] = line.split(',')
        if (!t) return []
        const n = (value: string | undefined): number | null => {
          const parsed = Number(value)
          return Number.isFinite(parsed) ? parsed : null
        }
        return [{ t, main: n(main), sm: n(sm), md: n(md), lg: n(lg), xl: n(xl) }]
      }),
    }
    return c.json(industryIntradaySchema.parse(body))
  } catch (error) {
    console.error('[api] intraday 取数失败:', error)
    return upstreamError(c, '分钟资金流暂不可用')
  }
})

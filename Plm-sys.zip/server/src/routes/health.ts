import type { HealthResponse } from '@platform/contracts'
import { Hono } from 'hono'

import { serverEnv } from '../env.js'
import { currentSession, currentTradeDate, marketService } from '../services/market.service.js'

const startedAt = Date.now()

export const healthRoutes = new Hono()

healthRoutes.get('/', async (c) => {
  // 健康检查兼作行情预热：前端每 20s 轮询一次，正好替盘面维持热缓存
  await marketService.ready()

  const now = new Date()
  const body: HealthResponse = {
    status: 'ok',
    runtime: serverEnv.runtime,
    uptimeMs: Date.now() - startedAt,
    timestamp: now.toISOString(),
    session: currentSession(now),
    tradeDate: currentTradeDate(now),
    dataMode: marketService.dataMode(),
    quote: marketService.quoteStatus(),
  }
  return c.json(body)
})

/**
 * 卡片类型（type）—— 6 种笔记形态。
 * 数据源：个人投资认知知识库建设方案 · 附录 A.1
 *
 * 从各方提议的 8–12 类收敛到 6 类；类型越少，填写越不会卡住。
 * 每种类型对应一个 Three.js 几何体形状，用于 3D 场景区分。
 */

export const CARD_TYPES = {
  concept: {
    id: 'concept',
    name: '概念',
    en: 'Concept',
    desc: '可定义的知识单元（含现象、偏差、指标）',
    test: '「它是什么」',
    color: '#d9a441',
    geometry: 'sphere',
    radius: 1.0,
  },
  claim: {
    id: 'claim',
    name: '观点',
    en: 'Claim',
    desc: '可被反驳的命题 + 我的判断',
    test: '「只能被同意/反对」',
    color: '#f472b6',
    geometry: 'octahedron',
    radius: 1.1,
  },
  case: {
    id: 'case',
    name: '案例',
    en: 'Case',
    desc: '事件与可复用教训',
    test: '「发生过什么」',
    color: '#fb923c',
    geometry: 'box',
    radius: 0.95,
  },
  model: {
    id: 'model',
    name: '模型',
    en: 'Model',
    desc: '可执行的规则（触发条件 → 动作）',
    test: '「能被执行」',
    color: '#a78bfa',
    geometry: 'icosahedron',
    radius: 1.15,
  },
  decision: {
    id: 'decision',
    name: '决策',
    en: 'Decision',
    desc: '决策当时 + 事后归因，同卡两段',
    test: '「我做了什么」',
    color: '#f87171',
    geometry: 'tetrahedron',
    radius: 1.1,
  },
  index: {
    id: 'index',
    name: '索引',
    en: 'Index',
    desc: '外部材料的只读索引 + MOC',
    test: '「指向别处」',
    color: '#94a3b8',
    geometry: 'sphere',
    radius: 0.55,
  },
};

export const CARD_TYPE_LIST = Object.values(CARD_TYPES);

/**
 * 体系常量：关系词、归因四格、decay 三档、北极星指标、五条判断。
 * 数据源：个人投资认知知识库建设方案 · 第七 / 九 / 十二节 + 附录 A
 */

/** 六个关系词，方向统一「从我出发」 */
export const RELATIONS = [
  { id: '前提', color: '#38bdf8', hint: '我以 X 为前提，学我之前要先懂 X' },
  { id: '从属', color: '#a78bfa', hint: '我属于 X 的下位' },
  { id: '印证', color: '#34d399', hint: '我印证了 X（案例支持概念）' },
  { id: '反驳', color: '#fb7185', hint: '我反驳了 X（我是 X 的反例）' },
  { id: '对立', color: '#f59e0b', hint: '我与 X 互斥' },
  { id: '易混', color: '#e879f9', hint: '我与 X 易混（必须双向写）' },
];

export const RELATION_COLOR = Object.fromEntries(
  RELATIONS.map((r) => [r.id, r.color])
);

/** 归因四格：判断对错 × 结果好坏 */
export const ATTRIBUTION = [
  { id: '判断对-结果对', tag: '能力', action: '可复用', color: '#34d399' },
  { id: '判断对-结果错', tag: '运气差', action: '不修改流程（最易被误改）', color: '#fbbf24' },
  { id: '判断错-结果对', tag: '运气好', action: '危险信号，连续出现即流程有缺陷', color: '#fb7185' },
  { id: '判断错-结果错', tag: '能力问题', action: '必须改流程', color: '#ef4444' },
];

/** decay 三档：半衰期，不是复核周期 */
export const DECAY = [
  { id: 'A', name: '原理', half: '10 年', expires: '+10 年', desc: '复利、机会成本、损失厌恶的定义' },
  { id: 'B', name: '框架', half: '3 年', expires: '+3 年', desc: 'DCF、仓位管理、决策清单' },
  { id: 'C', name: '观点与数据', half: '1 年', expires: '+1 年', desc: '行业格局、估值中枢、带数字的快照' },
];

export const DECAY_COLOR = { A: '#34d399', B: '#fbbf24', C: '#fb7185' };

/** 北极星指标：决策相关、难以伪造 */
export const NORTH_STAR = [
  { name: '决策前查库次数', healthy: '≥3 次/周', why: '唯一无法伪造的同向指标——要造假必须真去查' },
  { name: 'MOC 复用度', healthy: '持续增长', why: '衡量知识是否跨场景可用，而非堆积' },
];

/** 五条判断（结论先行） */
export const CONCLUSIONS = [
  { t: '九域是依赖链', d: '认知与行为在底层，操作与风控在操作层。按学科平铺，三个月后必然退化为资料堆。' },
  { t: '价值在决策时被调用', d: '验收标准是每周决策前查库的次数，不是笔记条数。' },
  { t: '检索先做结构后做语义', d: '命名、别名、双链、MOC 是 P0，向量检索是 P2。先装 AI 插件是常见错误顺序。' },
  { t: '最大风险是回音室', d: '库把你过去的判断变成高权重证据，召回的全是当年看多的笔记——你把它当第三方验证，其实只是镜子。' },
  { t: '保鲜比建设更重要', d: '一个能被持续执行的简单规则，胜过一个设计精美但会被关掉的复杂机制。' },
];

/** 前端字段表（frontmatter），人只判断三个 */
export const FIELDS = [
  { key: 'type', who: '模板', value: 'concept / claim / case / model / decision / index', note: '卡片形态' },
  { key: 'domain', who: '人判断①', value: '9 值', note: '唯一决定 layer', core: true },
  { key: 'decay', who: '人判断②', value: 'A / B / C', note: '半衰期', core: true },
  { key: 'source', who: '人判断③', value: '书:… / 文:… / 亲历:…', note: '写不出就不建卡', core: true },
  { key: 'status', who: '默认', value: '速记 / 苗 / 长 / 熟 / 已废', note: '「熟」为合格线' },
  { key: 'expires', who: '机器', value: 'A+10y / B+3y / C+1y', note: '「下一次该看它」' },
  { key: 'sensitivity', who: '默认 L2', value: 'L1 / L2（无 L3）', note: 'L3 在交易库' },
  { key: 'confidence', who: '默认中', value: '高 / 中 / 低', note: '证据有多硬' },
  { key: 'conviction', who: '选填', value: '1–5', note: '敢押多少' },
  { key: 'created', who: '自动', value: '{{date}}', note: '不用 file.ctime' },
];

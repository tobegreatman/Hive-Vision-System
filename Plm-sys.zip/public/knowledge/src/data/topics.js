/**
 * 概念卡的主题分类（topic）——领域内的第二层结构。
 *
 * 层级：领域 → 卡片类型 → 主题 → 卡片。
 * 只覆盖 concept 类型：概念数量最多，平铺会变成一堵清单墙；
 * 模型 / 案例 / 决策 / 索引通常只有几条，保持平铺即可。
 *
 * 主题按「先方法、再结构、后周期与定价」的顺序排列，
 * 与每个领域的核心问题对齐，而不是按字母或链接数排序。
 */

export const CARD_TOPICS = {
  cognition: [
    {
      name: '思维工具',
      hint: '怎么想',
      ids: ['c_capability', 'c_prob', 'c_falsify', 'c_first', 'c_second', 'c_baserate', 'c_reflexivity'],
    },
    {
      name: '判断偏差',
      hint: '怎么错',
      ids: ['c_confirm', 'c_anchor', 'c_survivor', 'c_narrative', 'c_availability', 'c_overconf'],
    },
    {
      name: '决策与情绪',
      hint: '怎么被情绪带走',
      ids: ['c_sunk', 'c_mental', 'c_loss', 'c_disposition', 'c_herd'],
    },
  ],
  systems: [
    {
      name: '系统机制',
      hint: '为什么会失控',
      ids: ['c_feedback', 'c_delay', 'c_nonlinear', 'c_stockflow', 'c_tipping', 'c_constraint'],
    },
    {
      name: '结构与演化',
      hint: '为什么形态不同',
      ids: ['c_scale', 'c_pathdep', 'c_network', 'c_powerlaw', 'c_antifragile', 'c_emergence'],
    },
  ],
  economics: [
    {
      name: '基础原理',
      hint: '价格与选择',
      ids: ['c_compound', 'c_opportunity', 'c_supply', 'c_marginal', 'c_discount'],
    },
    {
      name: '货币与信用',
      hint: '钱从哪里来',
      ids: ['c_credit', 'c_inflation', 'c_fx', 'c_monetary', 'c_liquidity'],
    },
    {
      name: '周期与政策',
      hint: '现在在哪个位置',
      ids: ['c_cycle', 'c_fiscal', 'c_creditcycle', 'c_debtcycle', 'c_inventory'],
    },
  ],
  finance: [
    {
      name: '报表与现金',
      hint: '钱是否真赚到',
      ids: ['c_statements', 'c_cashflow', 'c_fcf', 'c_workingcap'],
    },
    {
      name: '盈利与资产',
      hint: '资产是否在变重',
      ids: ['c_margin_turn', 'c_capex', 'c_debt', 'c_goodwill'],
    },
    {
      name: '估值',
      hint: '价格隐含了什么',
      ids: ['c_terminal', 'c_implied', 'c_cycle_val'],
    },
  ],
  industry: [
    {
      name: '生意本质',
      hint: '靠什么赚钱',
      ids: ['c_bizmodel', 'c_revenue', 'c_valuechain', 'c_lifecycle'],
    },
    {
      name: '竞争格局',
      hint: '凭什么守住',
      ids: ['c_concentration', 'c_pricing', 'c_switching'],
    },
    {
      name: '组织与资本',
      hint: '谁在做、怎么分',
      ids: ['c_governance', 'c_incentive', 'c_ma'],
    },
  ],
  market: [
    {
      name: '价值与价格',
      hint: '值多少',
      ids: ['c_margin', 'c_intrinsic', 'c_reversion', 'c_moat', 'c_valuation', 'c_emh'],
    },
    {
      name: '市场结构',
      hint: '谁在交易',
      ids: ['c_assets', 'c_index', 'c_participants', 'c_a_share'],
    },
    {
      name: '工具与资产',
      hint: '还能买什么',
      ids: ['c_convertible', 'c_options', 'c_gold', 'c_realestate'],
    },
  ],
  operations: [
    {
      name: '仓位与风险',
      hint: '押多少',
      ids: ['c_concentration_risk', 'c_drawdown', 'c_leverage', 'c_tail'],
    },
    {
      name: '执行与成本',
      hint: '怎么下手',
      ids: ['c_hedge', 'c_cost', 'c_discipline'],
    },
  ],
  review: [
    {
      name: '归因与偏差',
      hint: '为什么错',
      ids: ['c_hindsight', 'c_luck', 'c_process'],
    },
    {
      name: '复盘机制',
      hint: '怎么修正',
      ids: ['c_djournal', 'c_review_cadence', 'c_infohygiene'],
    },
  ],
  factors: [
    {
      name: '方法与前设',
      hint: '怎么用、何时失效',
      ids: ['f_slow_fast', 'f_data_lag', 'f_regime', 'f_crowding'],
    },
    {
      name: '长期结构',
      hint: '十年以上的边界',
      ids: ['f_population', 'f_tfp', 'f_gpt', 'f_debt', 'f_credit_trend', 'f_energy', 'f_institution'],
    },
    {
      name: '周期与政策',
      hint: '一到三年的位置',
      ids: ['f_inventory', 'f_money', 'f_fiscal', 'f_rates', 'f_global', 'f_inflation'],
    },
    {
      name: '市场定价',
      hint: '价格已经反映什么',
      ids: ['f_valuation_factor', 'f_sentiment', 'f_rotation', 'f_earnings', 'f_market_structure'],
    },
  ],
};

/** 卡片 id → 所属主题，供 3D 布局做同主题弱聚拢 */
export const TOPIC_INDEX = new Map();
Object.entries(CARD_TOPICS).forEach(([domain, topics]) => {
  topics.forEach((t, order) => {
    t.ids.forEach((id) => TOPIC_INDEX.set(id, { domain, topic: t.name, order }));
  });
});

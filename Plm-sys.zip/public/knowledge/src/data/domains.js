/**
 * 知识域（domain）—— 9 个领域，按 L0–L5 依赖层级排列。
 * 数据源：个人投资认知知识库建设方案 · 第二节（9 域版）
 *
 * 关键认知：领域不是并列的书架，而是一条有方向的依赖链。
 * 下层决定上层能否被正确使用；这个顺序不能倒着学。
 *
 * 相对 8 域版的调整：
 *  - 新增「变量与因子」：把慢变量、快变量与中周期从宏观中独立出来
 *  - 其余 8 域保持原依赖顺序；财务/行业/市场仍在 L3
 */

export const LAYERS = [
  { id: 'L0', name: '元层',   hint: '我如何判断' },
  { id: 'L1', name: '结构层', hint: '系统如何运转' },
  { id: 'L2', name: '解释层', hint: '世界为何如此' },
  { id: 'L3', name: '应用层', hint: '市场如何表现' },
  { id: 'L4', name: '操作层', hint: '我如何行动' },
  { id: 'L5', name: '反馈层', hint: '我为何对错' },
];

export const DOMAINS = [
  {
    id: 'cognition',
    name: '认知与行为',
    layer: 'L0',
    question: '我如何认识世界、处理信息、避免自欺与情绪化犯错',
    miss: '后面所有知识变成「背下来但不会用」',
    color: '#b08fd6',
  },
  {
    id: 'systems',
    name: '系统与复杂',
    layer: 'L1',
    question: '用什么语言描述复杂系统（反馈、延迟、非线性、临界点）',
    miss: '无法解释「为什么这次和上次不一样」',
    color: '#5b7fd6',
  },
  {
    id: 'economics',
    name: '经济学与宏观',
    layer: 'L2',
    question: '世界如何配置资源、形成价格、产生周期；当下处在什么位置',
    miss: '只有现象没有因果，判断无法外推',
    color: '#4fc4d4',
  },
  {
    id: 'factors',
    name: '变量与因子',
    layer: 'L2',
    question: '用哪些慢变量划定长期边界、哪些快变量判断当下位置，数据是否可信',
    miss: '只有叙事没有位置感，判断无法量化，也无法复盘',
    color: '#5ec8b0',
  },
  {
    id: 'finance',
    name: '财务与估值',
    layer: 'L3',
    question: '这门生意赚不赚钱、值多少钱，价格里隐含了什么预期',
    miss: '估值没有输入，只能凭感觉拍倍数',
    color: '#5fbf7f',
  },
  {
    id: 'industry',
    name: '行业与公司',
    layer: 'L3',
    question: '生意的商业模式、竞争格局与产业链位置',
    miss: '看不懂竞争优势的来源，护城河变成口号',
    color: '#9fbf4f',
  },
  {
    id: 'market',
    name: '投资与市场',
    layer: 'L3',
    question: '上述规律在资本市场如何具体表现',
    miss: '理论悬空，落不到标的上',
    color: '#c9a44f',
  },
  {
    id: 'operations',
    name: '操作与风控',
    layer: 'L4',
    question: '如何把判断转成动作（仓位、风控、执行成本）',
    miss: '有观点无动作，看对了也赚不到',
    color: '#d67e58',
  },
  {
    id: 'review',
    name: '决策与复盘',
    layer: 'L5',
    question: '上次为什么对/错，运气还是能力',
    miss: '各块知识互相打架，永远不修正',
    color: '#d26886',
  },
];

export const layerOfDomain = (domainId) => {
  const d = DOMAINS.find((x) => x.id === domainId);
  return d ? d.layer : null;
};

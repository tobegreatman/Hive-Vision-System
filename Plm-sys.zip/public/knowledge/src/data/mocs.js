/**
 * 六个决策场景 MOC —— 知识库的「入口」，不是「学科目录」。
 * 数据源：个人投资认知知识库建设方案 · 决策链路
 *
 * 决策链路：观察现象 → 形成假设 → 寻找解释 → 建立判断 → 定价 → 决策 → 复盘归因
 */

export const MOCS = [
  {
    id: 'moc_check',
    name: '决策前查证',
    icon: '🔍',
    question: '我准备做点什么，先确认有没有依据，还是只是在响应情绪',
    checks: [
      '我的判断能写成「如果 A 则 B」吗（不能 = 还只是感觉）',
      '反方最强的论点是什么，我能复述吗',
      '这个依据是多久以前的，过期了吗',
      '如果我现在空仓，我还会做同样的事吗',
    ],
    // 该场景要翻的卡片（卡片库入口，按顺序即推荐阅读顺序）
    cards: ['c_checklist', 'c_falsify', 'c_baserate', 'c_confirm', 'c_capability', 'c_second', 'c_premortem', 'c_djournal', 'f_data_lag', 'f_slow_fast'],
  },
  {
    id: 'moc_buy',
    name: '买入判断',
    icon: '📈',
    question: '这门生意值多少钱、现在贵不贵、我凭什么比市场更懂',
    checks: [
      '我能用一句话说清它怎么赚钱吗',
      '我的估值假设里，哪一条最可能错',
      '如果它明天跌 30%，我会加仓还是怀疑自己',
      '我的认错条件写下来了吗（写不出 = 不该买）',
    ],
    cards: ['c_bizmodel', 'c_moat', 'c_intrinsic', 'c_dcf', 'c_implied', 'c_margin', 'c_roic', 'c_capability', 'f_valuation_factor', 'f_earnings'],
  },
  {
    id: 'moc_sell',
    name: '卖出与止损',
    icon: '📉',
    question: '当初买入的理由现在还在吗？不在了，我为什么还拿着',
    checks: [
      '买入时的三条依据，现在哪条破了',
      '如果今天空仓，我会买它吗（不会 = 该卖）',
      '我是在执行纪律，还是给临时决定找理由',
      '卖出后如果它涨了，我会后悔吗（会 = 我还没想清楚）',
    ],
    cards: ['c_disposition', 'c_sunk', 'm_exit', 'c_stop', 'c_moat', 'c_falsify', 'c_errors', 'dec_sell', 'f_valuation_factor'],
  },
  {
    id: 'moc_risk',
    name: '仓位与风险管理',
    icon: '⚖️',
    question: '下多重、怎么分散、我能承受多少回撤（只谈规则，不谈金额）',
    checks: [
      '这笔最多亏多少，我会睡不着吗',
      '如果这个判断完全错，我还能活下来吗',
      '我的标的，是否都押在同一个变量上',
      '仓位是根据信心调的，还是根据"想赚多少"调的',
    ],
    cards: ['m_position', 'c_riskbudget', 'm_kelly', 'c_concentration_risk', 'c_drawdown', 'c_leverage', 'c_tail', 'c_layering', 'f_regime', 'f_signal_position'],
  },
  {
    id: 'moc_review',
    name: '复盘归因',
    icon: '🧭',
    question: '上次为什么对/错，是能力还是运气，下次改哪条笔记',
    checks: [
      '我当时的依据，现在还能复述吗（不能 = 当时就没有依据）',
      '结果好/坏，多少来自我控制之外的因素',
      '这次错在哪一层（选错层 = 改错地方）',
      '因此改了哪条笔记，改成了什么',
    ],
    cards: ['m_attr', 'c_hindsight', 'c_luck', 'c_process', 'c_errors', 'c_djournal', 'c_review_cadence', 'dec_add', 'f_pitfalls', 'f_data_lag'],
  },
  {
    id: 'moc_macro',
    name: '宏观与市场判断',
    icon: '🌐',
    question: '现在处在什么位置，该激进还是防守（用途是避免大错，不是预测）',
    checks: [
      '这个判断多久会失效（超 1 年 = 它可能是原理，不是判断）',
      '如果只对了方向、错了时点，会怎样',
      '它如何具体改变我的仓位（改变不了 = 只是谈资）',
      '我是在分析，还是在为已有仓位找理由',
    ],
    cards: ['c_cycle', 'c_creditcycle', 'c_debtcycle', 'c_monetary', 'c_fiscal', 'c_inflation', 'c_liquidity', 'c_erp', 'c_valuation', 'c_participants', 'f_dashboard', 'f_slow_fast', 'f_inventory', 'f_global'],
  },
];

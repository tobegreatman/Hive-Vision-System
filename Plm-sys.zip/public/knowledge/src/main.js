/**
 * 应用入口：创建 3D 宇宙 + 初始化 UI。
 */
import { createUniverse } from './scene/universe.js';
import { initUI } from './ui/ui.js';

const container = document.getElementById('scene');

let uiRef;

const universe = createUniverse(container, {
  onSelectCard: (card) => uiRef?.showCard(card),
  onSelectDomain: (domain) => uiRef?.showDomain(domain),
  onHover: (card, e) => uiRef?.showTooltip(card, e),
  onHoverOut: () => uiRef?.hideTooltip(),
});

uiRef = initUI(universe);

window.addEventListener('resize', () => universe.resize());

// 暴露到全局，便于调试与扩展
window.__mindlib = { universe, ui: uiRef };

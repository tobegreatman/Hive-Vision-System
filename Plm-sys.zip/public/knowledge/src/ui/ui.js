/**
 * UI 层：导航、图例、统计、详情面板、tooltip、多视图。
 * 全部 UI 由 JS 动态生成到 #ui-root，与 3D 场景解耦。
 */

import { DOMAINS, LAYERS } from '../data/domains.js';
import { CARD_TYPES, CARD_TYPE_LIST } from '../data/cardTypes.js';
import { CARDS, cardsByDomain, cardById } from '../data/cards.js';
import { MOCS } from '../data/mocs.js';
import { CARD_TOPICS } from '../data/topics.js';
import { ROADMAP, PIPELINE, PITFALLS } from '../data/roadmap.js';
import {
  RELATIONS, ATTRIBUTION, DECAY, NORTH_STAR, CONCLUSIONS, FIELDS, DECAY_COLOR,
} from '../data/schema.js';

const el = (html) => {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
};

export function initUI(universe, { onNavigate } = {}) {
  const root = document.getElementById('ui-root');
  const sceneEl = document.getElementById('scene');

  let currentView = 'universe';
  let currentType = 'all';

  // ================= 顶部导航 =================
  const nav = el(`
    <header class="topbar glass">
      <div class="brand-group">
        <a class="nav-back" href="/" target="_top" title="返回蜂巢盘面">
          <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M10.5 3.5 6 8l4.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>蜂巢</span>
        </a>
        <div class="brand">
          <div class="brand-mark">◈</div>
          <div class="brand-text">
            <h1>Mind-Lib</h1>
            <p>个人投资认知知识库 · 3D 知识宇宙</p>
          </div>
        </div>
      </div>
      <div class="search-wrap" id="search-wrap">
        <input class="search-input" id="card-search" type="search" placeholder="检索卡片：概念 / 模型 / 案例…" autocomplete="off" />
        <div class="search-results" id="search-results"></div>
      </div>
      <nav class="nav" id="nav"></nav>
    </header>
  `);
  root.appendChild(nav);

  const VIEWS = [
    { id: 'universe', label: '知识宇宙', icon: '✦' },
    { id: 'pipeline', label: '决策场景', icon: '◎' },
    { id: 'roadmap', label: '路线图', icon: '➤' },
    { id: 'schema', label: '字段体系', icon: '▤' },
  ];
  const navEl = nav.querySelector('#nav');
  VIEWS.forEach((v) => {
    const btn = el(`<button class="nav-btn" data-view="${v.id}"><span>${v.icon}</span>${v.label}</button>`);
    if (v.id === 'universe') btn.classList.add('active');
    btn.addEventListener('click', () => switchView(v.id));
    navEl.appendChild(btn);
  });

  // ================= 全站检索 =================
  const searchWrap = nav.querySelector('#search-wrap');
  const searchInput = nav.querySelector('#card-search');
  const searchResults = nav.querySelector('#search-results');

  // 预建索引：标题 / 描述 / 要点 / 来源 / 领域 / 类型，输入时只做一次 includes
  const SEARCH_INDEX = CARDS.map((c) => {
    const d = DOMAINS.find((x) => x.id === c.domain);
    const text = [
      c.title, c.desc, ...(c.points || []), c.source, c.boundary, c.signal,
      d?.name, CARD_TYPES[c.type].name,
    ].filter(Boolean).join(' ').toLowerCase();
    return { card: c, text };
  });

  function runSearch(raw) {
    const q = raw.trim().toLowerCase();
    if (!q) {
      searchResults.classList.remove('show');
      return;
    }
    const hits = SEARCH_INDEX.filter((it) => it.text.includes(q)).slice(0, 8).map((it) => it.card);
    if (!hits.length) {
      searchResults.innerHTML = '<div class="search-empty">没有匹配的卡片</div>';
    } else {
      searchResults.innerHTML = hits.map((c) => {
        const d = DOMAINS.find((x) => x.id === c.domain);
        return `<button class="search-hit" data-id="${c.id}">
          <span class="legend-dot" style="background:${CARD_TYPES[c.type].color}"></span>
          <span><b>${c.title}</b><i>${d ? d.name : ''} · ${CARD_TYPES[c.type].name}</i></span>
        </button>`;
      }).join('');
    }
    searchResults.classList.add('show');
  }

  searchInput.addEventListener('input', (e) => runSearch(e.target.value));
  searchInput.addEventListener('focus', () => {
    if (searchInput.value.trim()) runSearch(searchInput.value);
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      searchResults.classList.remove('show');
      searchInput.blur();
    } else if (e.key === 'Enter') {
      const first = searchResults.querySelector('.search-hit');
      if (first) first.click();
    }
  });
  searchResults.addEventListener('click', (e) => {
    const hit = e.target.closest('.search-hit');
    if (!hit) return;
    const target = cardById(hit.dataset.id);
    if (target) showCard(target);
    searchResults.classList.remove('show');
  });
  document.addEventListener('click', (e) => {
    if (!searchWrap.contains(e.target)) searchResults.classList.remove('show');
  });

  // ================= 图例 =================
  const legend = el(`
    <aside class="legend glass">
      <h3>卡片类型</h3>
      <div class="legend-list"></div>
    </aside>
  `);
  const legendList = legend.querySelector('.legend-list');
  const allItem = el(`
    <button class="legend-item active" data-type="all">
      <span class="legend-dot" style="background:conic-gradient(#67e8f9,#818cf8,#f0abfc,#67e8f9);box-shadow:0 0 8px #818cf8"></span>
      <span class="legend-name">全部</span>
      <span class="legend-desc">显示所有卡片</span>
    </button>
  `);
  allItem.addEventListener('click', () => filterByType('all'));
  legendList.appendChild(allItem);
  CARD_TYPE_LIST.forEach((t) => {
    const item = el(`
      <button class="legend-item" data-type="${t.id}">
        <span class="legend-dot" style="background:${t.color};box-shadow:0 0 8px ${t.color}"></span>
        <span class="legend-name">${t.name}</span>
        <span class="legend-desc">${t.desc}</span>
      </button>
    `);
    item.addEventListener('click', () => filterByType(t.id));
    legendList.appendChild(item);
  });
  root.appendChild(legend);

  // ================= 统计条 =================
  const stats = el(`
    <aside class="stats glass">
      <div class="stat"><b>${DOMAINS.length}</b><span>知识域</span></div>
      <div class="stat"><b>${CARDS.length}</b><span>卡片</span></div>
      <div class="stat"><b>${CARD_TYPE_LIST.length}</b><span>类型</span></div>
      <div class="stat"><b>${MOCS.length}</b><span>决策场景</span></div>
    </aside>
  `);
  root.appendChild(stats);

  // ================= tooltip =================
  const tooltip = el(`<div class="tooltip glass" id="tooltip"></div>`);
  root.appendChild(tooltip);

  // ================= 详情面板 =================
  const panel = el(`<aside class="panel glass" id="panel"></aside>`);
  root.appendChild(panel);

  // ================= 视图容器 =================
  const viewBox = el(`<div class="view-box" id="view-box"></div>`);
  root.appendChild(viewBox);

  // ================= 视图切换 =================
  function switchView(id) {
    currentView = id;
    navEl.querySelectorAll('.nav-btn').forEach((b) =>
      b.classList.toggle('active', b.dataset.view === id));
    const isUniverse = id === 'universe';
    sceneEl.classList.toggle('dimmed', !isUniverse);
    viewBox.classList.toggle('show', !isUniverse);
    // 非宇宙视图下隐藏 HUD（图例/统计），避免与视图内容重叠
    legend.style.display = isUniverse ? '' : 'none';
    stats.style.display = isUniverse ? '' : 'none';
    if (isUniverse) {
      universe.setAutoRotate(true);
    } else {
      viewBox.innerHTML = '';
      viewBox.appendChild(renderView(id));
      universe.setAutoRotate(false);
    }
    closePanel();
    if (onNavigate) onNavigate(id);
  }

  function renderView(id) {
    if (id === 'pipeline') return renderPipeline();
    if (id === 'roadmap') return renderRoadmap();
    if (id === 'schema') return renderSchema();
    return el('<div></div>');
  }

  // ================= 决策场景视图 =================
  function renderPipeline() {
    const wrap = el(`<div class="view pipeline-view"><h2 class="view-title">六个决策场景 · 从这里进，不按学科翻</h2>
      <p class="view-sub">检索时人想的是「我遇到什么问题」，不是「这属于哪个学科」。</p>
      <div class="moc-grid"></div></div>`);
    const grid = wrap.querySelector('.moc-grid');
    MOCS.forEach((m) => {
      const related = (m.cards || []).map((id) => cardById(id)).filter(Boolean);
      const mocEl = el(`
        <div class="moc-card glass">
          <div class="moc-head"><span class="moc-icon">${m.icon}</span><h3>${m.name}</h3></div>
          <p class="moc-q">${m.question}</p>
          <ul class="moc-checks">${m.checks.map((c) => `<li>${c}</li>`).join('')}</ul>
          ${related.length ? `<div class="moc-cards">
            <div class="moc-cards-title">相关卡片 · 点开查依据（${related.length}）</div>
            <div class="moc-card-links">${related.map((c) => `
              <button class="moc-card-link" data-id="${c.id}" title="${c.desc}">
                <span class="legend-dot" style="background:${CARD_TYPES[c.type].color}"></span>${c.title}
              </button>`).join('')}</div>
          </div>` : ''}
        </div>
      `);
      mocEl.querySelectorAll('.moc-card-link').forEach((b) =>
        b.addEventListener('click', () => showCard(cardById(b.dataset.id))));
      grid.appendChild(mocEl);
    });
    return wrap;
  }

  // ================= 路线图视图 =================
  function renderRoadmap() {
    const wrap = el(`<div class="view roadmap-view">
      <h2 class="view-title">三阶段路线图</h2>
      <div class="roadmap"></div>
      <h2 class="view-title">加工流水线 · 输入即加工（单条 ≤25 分钟）</h2>
      <div class="pipeline"></div>
      <h2 class="view-title">三个高发失败模式</h2>
      <div class="pitfalls"></div>
    </div>`);

    const rm = wrap.querySelector('.roadmap');
    ROADMAP.forEach((r, i) => {
      const node = el(`
        <div class="rm-node glass">
          <div class="rm-phase">${r.phase}</div>
          <h3>${r.name}</h3>
          <p class="rm-goal">${r.goal}</p>
          <div class="rm-week">周投入 ${r.weekly}</div>
          <ul class="rm-actions">${r.actions.map((a) => `<li>${a}</li>`).join('')}</ul>
          <div class="rm-accept"><b>验收</b>${r.accept}</div>
        </div>
      `);
      rm.appendChild(node);
      if (i < ROADMAP.length - 1) rm.appendChild(el(`<div class="rm-arrow">→</div>`));
    });

    const pl = wrap.querySelector('.pipeline');
    PIPELINE.forEach((s) => {
      pl.appendChild(el(`
        <div class="pl-step glass">
          <div class="pl-num">${s.step}</div>
          <div class="pl-body"><h4>${s.name}</h4><p>${s.desc}</p></div>
          <div class="pl-time">${s.time}</div>
        </div>
      `));
    });

    const pf = wrap.querySelector('.pitfalls');
    PITFALLS.forEach((p) => {
      pf.appendChild(el(`
        <div class="pitfall glass">
          <h4>${p.name}</h4>
          <p class="pf-sym">${p.symptom}</p>
          <p class="pf-pre"><b>预防</b>${p.prevent}</p>
        </div>
      `));
    });
    return wrap;
  }

  // ================= 字段体系视图 =================
  function renderSchema() {
    const wrap = el(`<div class="view schema-view"><h2 class="view-title">字段体系 · 人只判断三个</h2>
      <p class="view-sub">能自动填的绝不让人填——每多一个必填字段，第一次建卡就被劝退一次。</p>
      <div class="schema-cols"></div></div>`);
    const cols = wrap.querySelector('.schema-cols');

    // 字段表
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>frontmatter 字段</h3>
        <table class="sc-table"><thead><tr><th>字段</th><th>谁填</th><th>取值</th><th>含义</th></tr></thead>
        <tbody>${FIELDS.map((f) => `
          <tr class="${f.core ? 'core' : ''}">
            <td><code>${f.key}</code></td>
            <td>${f.who}</td>
            <td>${f.value}</td>
            <td>${f.note}</td>
          </tr>`).join('')}</tbody></table>
      </section>
    `));

    // 关系词
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>六个关系词（方向「从我出发」）</h3>
        <div class="rel-list">${RELATIONS.map((r) => `
          <div class="rel-item"><span class="rel-dot" style="background:${r.color}"></span><b>${r.id}</b><span>${r.hint}</span></div>
        `).join('')}</div>
      </section>
    `));

    // 归因四格
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>归因四格</h3>
        <div class="attr-grid">${ATTRIBUTION.map((a) => `
          <div class="attr-cell" style="border-color:${a.color}">
            <b>${a.id}</b><span class="attr-tag" style="color:${a.color}">${a.tag}</span><span>${a.action}</span>
          </div>
        `).join('')}</div>
        <p class="sc-note">「运气」不是第五格，它就是「判断对-结果错」。</p>
      </section>
    `));

    // decay
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>decay 三档 · 半衰期</h3>
        <div class="decay-list">${DECAY.map((d) => `
          <div class="decay-item"><span class="decay-badge" style="background:${DECAY_COLOR[d.id]}">${d.id}</span>
          <b>${d.name}</b><span>${d.half}</span><span class="decay-desc">${d.desc}</span></div>
        `).join('')}</div>
      </section>
    `));

    // 北极星
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>北极星指标</h3>
        <div class="ns-list">${NORTH_STAR.map((n) => `
          <div class="ns-item"><b>${n.name}</b><span>${n.healthy}</span><p>${n.why}</p></div>
        `).join('')}</div>
      </section>
    `));

    // 五条判断
    cols.appendChild(el(`
      <section class="glass sc-block">
        <h3>五条判断</h3>
        <ol class="conclusions">${CONCLUSIONS.map((c) => `<li><b>${c.t}</b> —— ${c.d}</li>`).join('')}</ol>
      </section>
    `));

    return wrap;
  }

  // ================= 详情面板 =================
  function closePanel() {
    panel.classList.remove('show');
    universe.resetHighlight();
  }

  // 反链：哪些卡片以某种关系指向本卡
  function backlinksOf(id) {
    return CARDS.flatMap((c) => (c.links || [])
      .filter((l) => l.to === id && c.id !== id)
      .map((l) => ({ from: c, rel: l.rel })));
  }

  function showCard(card) {
    if (!card) return;
    const t = CARD_TYPES[card.type];
    const d = DOMAINS.find((x) => x.id === card.domain);
    const outLinks = (card.links || []).filter((l) => cardById(l.to));
    const inLinks = backlinksOf(card.id);
    const chip = (id, rel, dir) => {
      const target = cardById(id);
      if (!target) return '';
      const color = REL_COLOR(rel);
      return `<button class="link-chip" data-goto="${target.id}" style="border-color:${color}">
        <span class="link-rel" style="color:${color}">${dir === 'in' ? `← ${rel}` : `${rel} →`}</span>${target.title}
      </button>`;
    };
    panel.innerHTML = `
      <button class="panel-close" id="panel-close">×</button>
      <div class="badge" style="background:${t.color}22;color:${t.color};border-color:${t.color}">${t.name}</div>
      <h2 class="panel-title">${card.title}</h2>
      <p class="panel-desc">${card.desc}</p>
      <div class="panel-meta">
        <span><i>域</i>${d.name} · ${d.layer}</span>
        <span><i>时效</i>${card.decay} · ${DECAY.find((x) => x.id === card.decay)?.name}</span>
        <span><i>到期</i>${card.expires}</span>
        <span><i>状态</i>${card.status}</span>
        <span><i>证据</i>${card.confidence}</span>
        <span><i>押注</i>${card.conviction}/5</span>
      </div>
      ${card.points?.length ? `<div class="panel-section">
        <div class="panel-section-title">要点</div>
        <ul class="panel-points">${card.points.map((p) => `<li>${p}</li>`).join('')}</ul>
      </div>` : ''}
      ${card.boundary ? `<div class="panel-section">
        <div class="panel-section-title">失效边界</div>
        <p class="panel-note">${card.boundary}</p>
      </div>` : ''}
      ${card.signal ? `<div class="panel-section">
        <div class="panel-section-title">可验证信号</div>
        <p class="panel-note">${card.signal}</p>
      </div>` : ''}
      ${card.source ? `<div class="panel-section">
        <div class="panel-section-title">来源</div>
        <p class="panel-note panel-source">${card.source}</p>
      </div>` : ''}
      ${outLinks.length ? `<div class="panel-links">
        <div class="panel-links-title">出链 · 本卡指向（${outLinks.length}）</div>
        ${outLinks.map((l) => chip(l.to, l.rel, 'out')).join('')}
      </div>` : ''}
      ${inLinks.length ? `<div class="panel-links">
        <div class="panel-links-title">被引用 · 谁指向本卡（${inLinks.length}）</div>
        ${inLinks.map((b) => chip(b.from.id, b.rel, 'in')).join('')}
      </div>` : ''}
      ${!outLinks.length && !inLinks.length ? `<div class="panel-links">
        <div class="panel-links-title">关联</div>
        <p class="panel-note">暂无关联卡片</p>
      </div>` : ''}
    `;
    panel.querySelector('#panel-close').addEventListener('click', closePanel);
    panel.scrollTop = 0;
    panel.classList.add('show');
    // 面板打开期间保持该卡的连线强调（含跨域连线），关闭时由 closePanel 复原
    universe.highlightCard(card.id);
  }

  // 出链/反链 chip 统一事件委托：点击跳到目标卡片
  panel.addEventListener('click', (e) => {
    const chipEl = e.target.closest('.link-chip[data-goto]');
    if (!chipEl) return;
    showCard(cardById(chipEl.dataset.goto));
  });

  function showDomain(d) {
    universe.resetHighlight();
    const cards = cardsByDomain(d.id);
    const li = LAYERS.findIndex((l) => l.id === d.layer);
    const prev = li > 0 ? LAYERS[li - 1] : null;
    const next = li >= 0 && li < LAYERS.length - 1 ? LAYERS[li + 1] : null;
    const topics = CARD_TOPICS[d.id] || null;

    // 链接数作为「枢纽度」：主题内被引用越多，越接近这张关系簇的中心
    const linkCount = (c) => (c.links || []).length + backlinksOf(c.id).length;
    const byHub = (a, b) => linkCount(b) - linkCount(a);
    const cardButton = (c) => `<button class="panel-card" data-id="${c.id}">
      <span class="panel-card-title">${c.title}</span>
      <i>${linkCount(c)} 链</i>
    </button>`;

    // 按卡片形态分组，而不是平铺：同类先放在一起，组内由枢纽到边缘排序
    const groups = CARD_TYPE_LIST
      .map((t) => ({
        type: t,
        cards: cards.filter((c) => c.type === t.id).sort(byHub),
      }))
      .filter((g) => g.cards.length);

    // 概念组再按主题分一层：领域 → 类型 → 主题 → 卡片
    const conceptBlock = (list) => {
      if (!topics) return `<div class="panel-cards">${list.map(cardButton).join('')}</div>`;
      const covered = new Set();
      topics.forEach((t) => t.ids.forEach((id) => covered.add(id)));
      const sections = topics.map((t) => {
        const items = list.filter((c) => t.ids.includes(c.id));
        if (!items.length) return '';
        return `<div class="domain-topic">
          <div class="domain-topic-head">
            <b>${t.name}</b><i>${items.length}</i><em>${t.hint || ''}</em>
          </div>
          <div class="panel-cards">${items.map(cardButton).join('')}</div>
        </div>`;
      }).join('');
      const rest = list.filter((c) => !covered.has(c.id));
      const restBlock = rest.length ? `<div class="domain-topic">
        <div class="domain-topic-head"><b>其他</b><i>${rest.length}</i></div>
        <div class="panel-cards">${rest.map(cardButton).join('')}</div>
      </div>` : '';
      return `<div class="domain-topics">${sections}${restBlock}</div>`;
    };

    panel.innerHTML = `
      <button class="panel-close" id="panel-close">×</button>
      <div class="badge" style="background:${d.color}22;color:${d.color};border-color:${d.color}">${d.layer} ${LAYERS[li]?.name || ''}</div>
      <h2 class="panel-title">${d.name}</h2>
      <p class="panel-desc">${d.question}</p>
      <div class="panel-meta">
        <span><i>依赖</i>${prev ? `${prev.id} ${prev.name}` : '无（最底层）'}</span>
        <span><i>支撑</i>${next ? `${next.id} ${next.name}` : '无（最顶层）'}</span>
        <span><i>规模</i>${cards.length} 张卡 · ${groups.length} 类</span>
      </div>
      <p class="panel-miss">缺失后果：${d.miss}</p>
      <div class="domain-card-groups">
        ${groups.map((g) => `
          <section class="domain-card-group">
            <div class="domain-card-group-head">
              <span class="legend-dot" style="background:${g.type.color};box-shadow:0 0 8px ${g.type.color}"></span>
              <b>${g.type.name}</b>
              <i>${g.cards.length}</i>
              <em>${g.type.desc}</em>
            </div>
            ${g.type.id === 'concept'
              ? conceptBlock(g.cards)
              : `<div class="panel-cards">${g.cards.map(cardButton).join('')}</div>`}
          </section>`).join('')}
      </div>
    `;
    panel.querySelector('#panel-close').addEventListener('click', closePanel);
    panel.querySelectorAll('.panel-card').forEach((b) =>
      b.addEventListener('click', () => showCard(cards.find((c) => c.id === b.dataset.id))));
    panel.scrollTop = 0;
    panel.classList.add('show');
  }

  // ================= tooltip =================
  let tooltipTimer = null;
  function showTooltip(card, e) {
    const t = CARD_TYPES[card.type];
    const d = DOMAINS.find((x) => x.id === card.domain);
    tooltip.innerHTML = `<b>${card.title}</b><span class="tt-type" style="color:${t.color}">${t.name}</span><span>${d.name}</span>`;
    tooltip.classList.add('show');
    moveTooltip(e);
  }
  function moveTooltip(e) {
    tooltip.style.left = `${Math.min(e.clientX + 16, window.innerWidth - 220)}px`;
    tooltip.style.top = `${e.clientY + 16}px`;
  }
  function hideTooltip() {
    tooltip.classList.remove('show');
  }

  // ================= 类型筛选 =================
  function filterByType(type) {
    currentType = type === 'all' ? 'all' : (currentType === type ? 'all' : type);
    legendList.querySelectorAll('.legend-item').forEach((b) =>
      b.classList.toggle('active', b.dataset.type === currentType));
    // 交由 3D 层在动画循环里处理高亮/淡化
    universe.setFilter(currentType === 'all' ? null : currentType);
  }

  function REL_COLOR(rel) {
    return RELATIONS.find((r) => r.id === rel)?.color || '#888';
  }

  // ================= 鼠标移动 tooltip =================
  document.addEventListener('mousemove', (e) => {
    if (tooltip.classList.contains('show')) moveTooltip(e);
  });

  // 支持通过 URL hash 直达视图（#pipeline / #roadmap / #schema）
  const initialView = location.hash.slice(1);
  if (['pipeline', 'roadmap', 'schema'].includes(initialView)) {
    switchView(initialView);
  }

  return { showCard, showDomain, showTooltip, hideTooltip, switchView, closePanel };
}

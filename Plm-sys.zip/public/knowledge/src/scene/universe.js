/**
 * 3D 知识宇宙（Knowledge Universe）核心场景 —— 银河星云主题
 *
 * 视觉设计：
 *  - 深空渐变背景 + 星云光斑 + 星空粒子 + 雾（深度感）
 *  - 7 个领域能量球沿 L0→L5 螺旋上升（Fresnel 边缘光 + 轨道环）
 *  - 卡片按 6 种类型以不同几何体环绕所属领域
 *  - 双链关系用彩色光带连接
 *  - UnrealBloom 辉光
 *  - OrbitControls 旋转/缩放 + 自动环绕
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { DOMAINS, LAYERS } from '../data/domains.js';
import { CARD_TYPES } from '../data/cardTypes.js';
import { CARDS } from '../data/cards.js';
import { RELATION_COLOR } from '../data/schema.js';
import { TOPIC_INDEX } from '../data/topics.js';

const LAYER_INDEX = { L0: 0, L1: 1, L2: 2, L3: 3, L4: 4, L5: 5 };
const LAYER_HEIGHT = 4.5;      // 层间垂直距离（黄金角已分散投影，适度降低避免顶部遮挡）
const ORBIT_BASE = 9.5;        // 领域轨道基础半径（增大，拉开球体间距减少交叉）
const CARD_ORBIT = 3.0;        // 卡片环绕领域半径
const RING_RADIUS = 3.8;       // 领域球轨道环半径（贴合收紧后的卡片云，减少相邻领域视觉重叠）

/** 柔化颜色：只限制亮度避免过曝，保留饱和度以保证领域辨识度 */
function soften(hex, sat = 1.0, maxLight = 0.72) {
  const c = new THREE.Color(hex);
  const hsl = { h: 0, s: 0, l: 0 };
  c.getHSL(hsl);
  return new THREE.Color().setHSL(hsl.h, hsl.s * sat, Math.min(hsl.l, maxLight));
}

/** 边缘光（Fresnel）球壳：边缘光在领域色与青/紫之间流动，营造炫彩「能量球」质感 */
function makeRimMaterial(hex, strength = 0.9) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(hex) },
      uAccentA: { value: new THREE.Color('#35e7ff') },
      uAccentB: { value: new THREE.Color('#cf6bff') },
      uStrength: { value: strength },
      uTime: auroraTime,
    },
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vWorldPos;
      void main() {
        // 法线保持世界空间，与 vWorldPos / cameraPosition 的视线方向同坐标系；
        // 若用 normalMatrix（视图空间）与视线混算，相机旋转时边缘光会随视角偏移，
        // 看起来像球体表面被扭动
        vNormal = normalize(mat3(modelMatrix) * normal);
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform vec3 uAccentA;
      uniform vec3 uAccentB;
      uniform float uStrength;
      uniform float uTime;
      varying vec3 vNormal;
      varying vec3 vWorldPos;
      void main() {
        vec3 viewDir = normalize(cameraPosition - vWorldPos);
        float fresnel = 1.0 - abs(dot(normalize(vNormal), viewDir));
        fresnel = pow(fresnel, 2.2);
        float wave = 0.5 + 0.5 * sin(vNormal.y * 4.0 + vNormal.x * 3.0 + uTime * 0.8);
        vec3 accent = mix(uAccentA, uAccentB, wave);
        vec3 rimColor = mix(uColor, accent, 0.35);
        gl_FragColor = vec4(rimColor, fresnel * uStrength);
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.FrontSide,
  });
}

/** 领域球表面纹理层：FBM 云纹 + 大理石流纹，叠加在球体表面（随球体自转） */
function makeDomainSurfaceMaterial(hex) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(hex) },
      uTime: auroraTime,
    },
    vertexShader: `
      varying vec3 vLocal;
      varying vec3 vNormalW;
      varying vec3 vWorldPos;
      void main() {
        vLocal = position;
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uTime;
      varying vec3 vLocal;
      varying vec3 vNormalW;
      varying vec3 vWorldPos;

      float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
      }

      float noise3(vec3 x) {
        vec3 i = floor(x);
        vec3 f = fract(x);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(mix(hash(i), hash(i + vec3(1.0, 0.0, 0.0)), f.x),
              mix(hash(i + vec3(0.0, 1.0, 0.0)), hash(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
          mix(mix(hash(i + vec3(0.0, 0.0, 1.0)), hash(i + vec3(1.0, 0.0, 1.0)), f.x),
              mix(hash(i + vec3(0.0, 1.0, 1.0)), hash(i + vec3(1.0, 1.0, 1.0)), f.x), f.y),
          f.z);
      }

      float fbm(vec3 p) {
        float v = 0.0;
        float amp = 0.5;
        for (int i = 0; i < 4; i++) {
          v += amp * noise3(p);
          p *= 2.0;
          amp *= 0.5;
        }
        return v;
      }

      void main() {
        vec3 N = normalize(vNormalW);
        vec3 V = normalize(cameraPosition - vWorldPos);
        vec3 L = normalize(vec3(0.45, 0.85, 0.5));
        float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.0);
        // 昼夜明暗：收紧晨昏线，让受光面/背光面分界更明确
        float day = smoothstep(-0.12, 0.26, dot(N, L));

        // 域扭曲云涡：大尺度柔和纹理，避免规则条纹
        float base = fbm(vLocal * 1.25 + vec3(0.0, uTime * 0.04, 0.0));
        float cloud = fbm(vLocal * 2.6 + vec3(base * 1.8, uTime * 0.06, base * 1.4));
        float swirl = smoothstep(0.32, 0.82, cloud + base * 0.25);

        vec3 deep = uColor * 0.32;
        vec3 light = mix(uColor, vec3(1.0), 0.42);
        vec3 col = mix(deep, light, swirl);
        // 纹理中透出的青紫高光（仅受光面）
        col += vec3(0.2, 0.55, 0.8) * swirl * fres * 0.35 * day;
        // 背光面沉入浓阴影，受光边缘微亮，塑造球体体积感
        col *= 0.02 + 1.05 * day;
        col += uColor * fres * day * 0.3;

        float alpha = (0.16 + 0.38 * swirl) * (0.55 + 0.45 * fres);
        // 阴影侧覆盖更实，让暗面更深
        alpha *= mix(2.2, 0.85, day);
        gl_FragColor = vec4(col, clamp(alpha, 0.0, 0.92));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    transparent: true,
    depthWrite: false,
    side: THREE.FrontSide,
  });
}

/** 共享时间 uniform：驱动概念卡表面虹彩缓慢流动 */
const auroraTime = { value: 0 };

/** 极光珍珠材质：类型色本体 + 流动虹彩 + 镜面高光（卡片通用，可传入自定义配色与表面纹理） */
function makeAuroraMaterial(hex, accents = {}, texture = 0) {
  const a = {
    cyan: '#35e7ff',
    azure: '#4f8dff',
    violet: '#9d6bff',
    purple: '#cf6bff',
    ...accents,
  };
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(hex) },
      uCyan: { value: new THREE.Color(a.cyan) },
      uAzure: { value: new THREE.Color(a.azure) },
      uViolet: { value: new THREE.Color(a.violet) },
      uPurple: { value: new THREE.Color(a.purple) },
      uTime: auroraTime,
      uOpacity: { value: 1 },
      uTexture: { value: texture },
    },
    vertexShader: `
      varying vec3 vNormalW;
      varying vec3 vWorldPos;
      varying vec3 vLocal;
      void main() {
        vNormalW = normalize(mat3(modelMatrix) * normal);
        vLocal = position;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform vec3 uCyan;
      uniform vec3 uAzure;
      uniform vec3 uViolet;
      uniform vec3 uPurple;
      uniform float uTime;
      uniform float uOpacity;
      uniform float uTexture;
      varying vec3 vNormalW;
      varying vec3 vWorldPos;
      varying vec3 vLocal;

      float hash(vec3 p) {
        p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
        p *= 17.0;
        return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
      }

      float noise3(vec3 x) {
        vec3 i = floor(x);
        vec3 f = fract(x);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(mix(hash(i), hash(i + vec3(1.0, 0.0, 0.0)), f.x),
              mix(hash(i + vec3(0.0, 1.0, 0.0)), hash(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
          mix(mix(hash(i + vec3(0.0, 0.0, 1.0)), hash(i + vec3(1.0, 0.0, 1.0)), f.x),
              mix(hash(i + vec3(0.0, 1.0, 1.0)), hash(i + vec3(1.0, 1.0, 1.0)), f.x), f.y),
          f.z);
      }

      float fbm(vec3 p) {
        float v = 0.0;
        float amp = 0.5;
        for (int i = 0; i < 4; i++) {
          v += amp * noise3(p);
          p *= 2.0;
          amp *= 0.5;
        }
        return v;
      }

      // 四段色带：青 → 蓝 → 紫 → 紫红，形成流动的极光光谱
      vec3 auroraRamp(float t) {
        vec3 c = mix(uCyan, uAzure, smoothstep(0.0, 0.33, t));
        c = mix(c, uViolet, smoothstep(0.32, 0.66, t));
        c = mix(c, uPurple, smoothstep(0.65, 1.0, t));
        return c;
      }

      void main() {
        vec3 N = normalize(vNormalW);
        vec3 V = normalize(cameraPosition - vWorldPos);
        vec3 L = normalize(vec3(0.45, 0.85, 0.5));

        // 极光虹彩：两道不同频率的波纹叠加，颜色随时间在青→蓝→紫→紫红间流动
        float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.0);
        float flow = 0.5 + 0.5 * sin(N.y * 3.5 + N.x * 2.0 + uTime * 0.7);
        float ripple = 0.5 + 0.5 * sin(N.y * 8.0 - N.x * 5.0 + uTime * 1.3);
        vec3 aurora = auroraRamp(clamp(flow * 0.7 + ripple * 0.3, 0.0, 1.0));

        vec3 color;

        if (uTexture > 0.5) {
          // ===== 星球表面（概念卡）：大尺度大陆 + 云带 + 极冠 + 昼夜明暗 =====
          // 缓慢自转的局部坐标：太阳方向固定在世界空间，自转带动昼夜交替
          float rot = uTime * 0.06;
          float cs = cos(rot), sn = sin(rot);
          vec3 p = vec3(
            vLocal.x * cs + vLocal.z * sn,
            vLocal.y,
            -vLocal.x * sn + vLocal.z * cs
          );

          // 域扭曲 FBM：大陆轮廓（低频、大尺度）
          float warp = fbm(p * 2.1);
          float terrain = fbm(p * 1.6 + vec3(warp * 1.1));
          // 云层：略高频，缓慢漂移
          float clouds = fbm(p * 3.2 + vec3(0.0, uTime * 0.012, warp * 0.8));

          vec3 ocean = mix(uColor * 0.3, vec3(0.03, 0.06, 0.1), 0.55);  // 深海：暗蓝
          vec3 land = mix(uColor, vec3(1.0), 0.32) * 1.35;              // 大陆：亮金属质感
          float landMask = smoothstep(0.46, 0.55, terrain);
          vec3 albedo = mix(ocean, land, landMask);
          // 云带
          albedo = mix(albedo, vec3(0.92, 0.90, 0.86),
                       smoothstep(0.55, 0.78, clouds) * 0.35);
          // 极冠（噪声扰动边缘，避免规整圆帽）
          float polar = smoothstep(0.78, 0.9, abs(vLocal.y) + (warp - 0.5) * 0.2);
          albedo = mix(albedo, vec3(0.86, 0.93, 0.97), polar * 0.6);

          // 昼夜明暗：柔和晨昏线
          float ndl = dot(N, L);
          float day = smoothstep(-0.22, 0.35, ndl);
          color = albedo * (0.05 + 1.35 * day);
          // 洋面镜面反光
          vec3 H = normalize(L + V);
          float spec = pow(max(dot(N, H), 0.0), 40.0);
          color += vec3(1.0, 0.98, 0.94) * spec * (1.0 - landMask * 0.85) * 0.5;
          // 大气层边缘散射：轮廓外透出类型色 + 淡青
          float atmoFres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
          vec3 atmo = mix(uColor, vec3(0.55, 0.82, 1.0), 0.5);
          color += atmo * atmoFres * (0.22 + 0.85 * day);
          // 保留一丝项目虹彩：仅在受光边缘极淡流动
          color += aurora * atmoFres * 0.12 * day;
        } else {
          // ===== 极光珍珠材质（其余卡片类型）=====
          float diff = clamp(dot(N, L) * 0.5 + 0.5, 0.0, 1.0);
          vec3 body = uColor * (0.35 + 0.85 * diff);
          color = mix(body, aurora, fres * 0.88);
          // 边缘再叠一层流动虹彩，让极光更亮、更炫
          color += aurora * pow(fres, 3.0) * 0.9;
          // 中心透出的微光 + 镜面高光点
          color += uColor * 0.3 * pow(max(dot(N, V), 0.0), 3.0);
          vec3 H = normalize(L + V);
          color += vec3(1.0) * pow(max(dot(N, H), 0.0), 48.0) * 0.9;
        }

        gl_FragColor = vec4(color, uOpacity);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    transparent: true,
  });
}

/** 层级光面材质：静态半透明柔光填充（L0–L5 专用，仅用于暗示层级结构） */
function makeLayerDiscMaterial(hex) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(hex) },
    },
    vertexShader: `
      varying vec2 vLocal;
      void main() {
        vLocal = position.xy;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      varying vec2 vLocal;

      void main() {
        float r = length(vLocal);
        if (r > 1.0) discard;

        // 偏侧光：让平面像被一束斜光扫过，而不是均匀发亮
        float side = 0.62 + 0.38 * dot(normalize(vLocal + 0.0001), normalize(vec2(-0.55, 0.84)));
        // 大范围柔光渐变：中心透明 → 中段缓慢变亮 → 外缘长距离消散，不形成边缘光环
        float halo = smoothstep(0.0, 0.55, r) * (1.0 - smoothstep(0.55, 1.0, r));
        float fill = halo * 0.1 * side;

        // 加色混合下颜色与 alpha 相乘，填充色单独加权，避免只剩一圈边
        vec3 col = uColor * fill * 4.5;
        gl_FragColor = vec4(col, fill);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
}


/** 轨道光环材质：极细环 + 两道沿轨道流动的脉冲光弧（领域球专用） */
function makeOrbitRingMaterial(hex, seed = 0) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(hex) },
      uSeed: { value: seed },
      uTime: auroraTime,
    },
    vertexShader: `
      varying vec2 vLocal;
      void main() {
        vLocal = position.xy;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uSeed;
      uniform float uTime;
      varying vec2 vLocal;
      void main() {
        float ang = atan(vLocal.y, vLocal.x);
        // 两道沿轨道流动的光弧
        float wave = 0.5 + 0.5 * sin(ang * 2.0 - uTime * 1.6 + uSeed);
        float pulse = pow(wave, 6.0);
        // 整体亮度的缓慢呼吸
        float breathe = 0.7 + 0.3 * sin(uTime * 1.2 + uSeed);
        vec3 col = uColor * (0.8 + 0.8 * pulse);
        gl_FragColor = vec4(col, (0.25 + 0.75 * pulse) * breathe);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
}

/** 径向渐变光晕贴图（共享）：用于节点发光 */
let _glowTex = null;
function glowTexture() {
  if (_glowTex) return _glowTex;
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.3, 'rgba(255,255,255,0.3)');
  g.addColorStop(0.6, 'rgba(255,255,255,0.06)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  _glowTex = new THREE.CanvasTexture(canvas);
  _glowTex.colorSpace = THREE.SRGBColorSpace;
  return _glowTex;
}

/** 生成领域名 sprite 标签 */
function makeLabel(text, color, scale = 1, { weight = 600, bgAlpha = 0.62 } = {}) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const fontPx = 64;
  const font = `${weight} ${fontPx}px "PingFang SC", "Microsoft YaHei", sans-serif`;
  ctx.font = font;
  const w = Math.ceil(ctx.measureText(text).width) + 48;
  const h = fontPx + 48;
  canvas.width = w;
  canvas.height = h;
  // 改变 canvas 尺寸会重置上下文状态，需重新设置字体
  ctx.font = font;
  // 标签用「暗色胶囊 + 类型色描边」：无论背后是星云、卡片还是光带都能读清
  const base = soften(color, 0.6, 0.78);
  const rgb = `${Math.round(base.r * 255)}, ${Math.round(base.g * 255)}, ${Math.round(base.b * 255)}`;
  ctx.beginPath();
  ctx.roundRect(3, 3, w - 6, h - 6, h * 0.32);
  ctx.fillStyle = `rgba(4, 8, 16, ${bgAlpha})`;
  ctx.fill();
  ctx.strokeStyle = `rgba(${rgb}, 0.5)`;
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const labelColor = '#' + soften(color, 0.45, 0.78).getHexString();
  ctx.strokeStyle = 'rgba(5, 7, 15, 0.85)';
  ctx.lineWidth = 4;
  ctx.strokeText(text, w / 2, h / 2);
  ctx.fillStyle = labelColor;
  ctx.fillText(text, w / 2, h / 2);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.minFilter = THREE.LinearFilter;
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false })
  );
  const aspect = w / h;
  sprite.scale.set(3.4 * aspect * scale, 3.4 * scale, 1);
  return sprite;
}

/** 生成星空粒子（多彩星点） */
function makeStarfield(count = 2400, radius = 130) {
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  const palette = [0xffffff, 0xaaccff, 0xffd9b0, 0xc9b8ff];
  for (let i = 0; i < count; i++) {
    const r = radius * (0.4 + 0.6 * Math.cbrt(Math.random()));
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    pos[i * 3 + 2] = r * Math.cos(phi);
    const c = new THREE.Color(palette[(Math.random() * palette.length) | 0]);
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const mat = new THREE.PointsMaterial({
    size: 0.3, vertexColors: true, transparent: true, opacity: 0.85,
    depthWrite: false, blending: THREE.AdditiveBlending,
  });
  return new THREE.Points(geo, mat);
}

// ---------- 程序化星云：哈希值噪声 + FBM 絮状云纹 ----------

/** 32 位确定性哈希 */
function hash2(x, y, seed) {
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967295;
}

/** 双线性平滑值噪声 */
function valueNoise2(x, y, seed) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
}

/** 多倍频 FBM，叠出丝缕状的云气结构 */
function fbm2(x, y, seed, octaves = 5) {
  let amp = 0.5;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * valueNoise2(x * freq, y * freq, seed + i * 131);
    norm += amp;
    amp *= 0.5;
    freq *= 2.03;
  }
  return sum / norm;
}

/** 星云配色：每个云团在两种高饱和色之间过渡，叠加后形成炫彩层次 */
const NEBULA_PALETTES = [
  ['#21e6ff', '#6a5cff'],   // 冰青 → 电紫
  ['#ff53d4', '#6b7bff'],   // 洋红 → 蓝紫
  ['#ffc94a', '#ff6a5f'],   // 鎏金 → 珊瑚
  ['#25ffcb', '#2f7dff'],   // 青绿 → 宝蓝
  ['#ff74c8', '#3ed1ff'],   // 玫红 → 天青
];

function hexRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** 生成一张絮状星云贴图（径向衰减 + FBM 云纹 + 双色渐变） */
function makeNebulaTexture(palette, seed, size = 256) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);
  const data = img.data;
  const [ar, ag, ab] = hexRgb(palette[0]);
  const [br, bg, bb] = hexRgb(palette[1]);
  const half = size / 2;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const nx = (x / size) * 2.2;   // 横向低频 → 云带更飘逸
      const ny = (y / size) * 4.6;   // 纵向高频 → 细密絮状纹理
      const cloud = fbm2(nx + 5.2, ny + 9.1, seed, 5);
      const wisp = fbm2(nx * 2.6 + 13.7, ny * 2.6 + 3.3, seed + 57, 3);
      const density = Math.max(0, Math.min(1, (cloud - 0.34) * 2.1 + (wisp - 0.5) * 0.8));
      const dist = Math.sqrt((x - half) ** 2 + (y - half) ** 2) / half;
      const mask = Math.max(0, 1 - dist);
      const alpha = Math.pow(mask, 2.4) * Math.pow(density, 1.5) * 2.2;
      if (alpha <= 0.002) continue;
      const t = Math.max(0, Math.min(1, cloud * 1.05 + wisp * 0.35 - 0.2));
      const i = (y * size + x) * 4;
      data[i] = ar + (br - ar) * t;
      data[i + 1] = ag + (bg - ag) * t;
      data[i + 2] = ab + (bb - ab) * t;
      data[i + 3] = Math.min(255, alpha * 255);
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** 生成炫彩星云（多色絮状云团 + 斜向星云带） */
function makeNebulaSpots() {
  const group = new THREE.Group();
  const textures = NEBULA_PALETTES.map((p, i) => makeNebulaTexture(p, 1000 + i * 137));

  const spots = [
    // 四角主云团：青绿 / 鎏金 / 洋红 / 玫红，色彩方向彼此错开
    { tex: 3, pos: [-95, -32, -95], sx: 330, sy: 290, o: 0.15 },
    { tex: 2, pos: [-76, 50, -100], sx: 320, sy: 280, o: 0.14 },
    { tex: 1, pos: [88, 44, -86], sx: 340, sy: 300, o: 0.14 },
    { tex: 4, pos: [72, -34, -96], sx: 340, sy: 300, o: 0.14 },
    { tex: 0, pos: [-10, 12, -120], sx: 380, sy: 300, o: 0.10 },   // 后方中央
    { tex: 3, pos: [110, 2, -64], sx: 220, sy: 200, o: 0.10 },
    { tex: 2, pos: [-112, 6, -60], sx: 220, sy: 200, o: 0.09 },
    // 斜向星云带：大尺寸横向拉伸、低不透明度，勾出银河般的走向
    { tex: 0, pos: [-40, 32, -150], sx: 560, sy: 240, o: 0.06 },
    { tex: 1, pos: [52, -24, -150], sx: 560, sy: 240, o: 0.055 },
    // 高饱和亮核：小尺寸强色点，制造炫彩焦点
    { tex: 4, pos: [-46, 8, -72], sx: 130, sy: 130, o: 0.18 },
    { tex: 2, pos: [34, 54, -78], sx: 110, sy: 110, o: 0.16 },
    { tex: 3, pos: [64, -16, -72], sx: 140, sy: 140, o: 0.16 },
  ];

  spots.forEach((sp, i) => {
    const mat = new THREE.SpriteMaterial({
      map: textures[sp.tex],
      transparent: true,
      opacity: sp.o,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
      rotation: (i * 1.618) % (Math.PI * 2),
    });
    const sprite = new THREE.Sprite(mat);
    sprite.position.set(sp.pos[0], sp.pos[1], sp.pos[2]);
    sprite.scale.set(sp.sx, sp.sy, 1);
    sprite.userData = {
      baseOpacity: sp.o,
      spin: (i % 2 ? 1 : -1) * (0.00035 + 0.0002 * (i % 3)),
      phase: i * 1.37,
    };
    group.add(sprite);
  });
  return group;
}

/** 生成星云渐变背景纹理（深空底色 + 多色雾霭，注入色相层次） */
function makeBackgroundTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');

  // 深空底色
  const base = ctx.createRadialGradient(512, 420, 0, 512, 512, 860);
  base.addColorStop(0, '#0f1c3d');
  base.addColorStop(0.32, '#0b1231');
  base.addColorStop(0.68, '#070a20');
  base.addColorStop(1, '#030510');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 1024, 1024);

  // 多色雾霭：低透明度径向光，让深空在不同方向泛出不同色相
  const haze = (x, y, r, rgba) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, rgba);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1024, 1024);
  };
  haze(790, 210, 560, 'rgba(118, 58, 220, 0.07)');   // 紫
  haze(210, 730, 520, 'rgba(20, 165, 200, 0.09)');   // 青
  haze(250, 250, 460, 'rgba(210, 50, 170, 0.06)');   // 洋红
  haze(930, 880, 520, 'rgba(40, 70, 215, 0.06)');    // 宝蓝
  haze(512, 1040, 620, 'rgba(255, 130, 90, 0.03)');  // 底部暖调

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** 创建卡片几何体（按类型） */
function cardGeometry(type) {
  const r = CARD_TYPES[type].radius;
  switch (CARD_TYPES[type].geometry) {
    case 'octahedron': return new THREE.OctahedronGeometry(r, 0);
    case 'box': return new THREE.BoxGeometry(r, r, r);
    case 'icosahedron': return new THREE.IcosahedronGeometry(r, 0);
    case 'tetrahedron': return new THREE.TetrahedronGeometry(r, 0);
    default: return new THREE.SphereGeometry(r, 24, 24);
  }
}

export function createUniverse(container, handlers = {}) {
  const { onSelectCard, onSelectDomain, onHover, onHoverOut } = handlers;

  // ---------- 基础渲染 ----------
  const scene = new THREE.Scene();
  scene.background = makeBackgroundTexture();
  scene.fog = new THREE.FogExp2(0x04060c, 0.0014);

  // 用更长的焦段（42°）并同步拉远相机，保持构图大小不变：
  // 55° 广角下，结构边缘的领域球会被透视径向拉长，旋转时呈现"变形"感；
  // 收窄 FOV 可显著降低这种边缘拉伸（tan(27.5)/tan(21) ≈ 1.356 倍距离补偿）
  const camera = new THREE.PerspectiveCamera(
    42, container.clientWidth / container.clientHeight, 0.1, 400
  );
  camera.position.set(0, 11.75, 65.1);

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;
  container.appendChild(renderer.domElement);

  // ---------- 后处理辉光 ----------
  // renderer 上的 antialias 对后处理链路无效，EffectComposer 默认目标没有多重采样，
  // 旋转视角时低模卡片与细线边缘会锯齿闪烁，这里显式给渲染目标开 4x MSAA
  const hdrTarget = new THREE.WebGLRenderTarget(
    container.clientWidth, container.clientHeight,
    { type: THREE.HalfFloatType, samples: 4 }
  );
  const composer = new EffectComposer(renderer, hdrTarget);
  composer.setSize(container.clientWidth, container.clientHeight);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(
    new THREE.Vector2(container.clientWidth, container.clientHeight),
    0.55,  // strength：适度，避免白化冲淡色相
    0.75,  // radius：柔和光晕
    0.5    // threshold：亮部发光
  );
  composer.addPass(bloom);

  // ---------- 相机控制 ----------
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 0.35;
  controls.minDistance = 12;
  controls.maxDistance = 90;
  // 环绕中心高度决定构图纵向位置：抬高视点 → 结构在画面中下移，降低 → 上移
  controls.target.set(0, 14.5, 0);

  // ---------- 灯光（主光 + 补光，中性色温避免球体偏色） ----------
  scene.add(new THREE.AmbientLight(0x2a2a35, 0.32));
  const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
  keyLight.position.set(20, 40, 20);
  scene.add(keyLight);
  const fillLight = new THREE.DirectionalLight(0x9aa2b5, 0.22);
  fillLight.position.set(-25, 8, -25);
  scene.add(fillLight);

  // ---------- 星云背景 ----------
  const nebula = makeNebulaSpots();
  scene.add(nebula);
  const starfield = makeStarfield();
  scene.add(starfield);

  // ---------- 领域节点 ----------
  const domainNodes = new Map();   // id -> { group, mesh, halo, label, pos }
  const domainPos = new Map();

  // 领域按层分组：同层领域均匀分布在一个椭圆环上，层与层之间错开相位，
  // 形成清晰的 6 层结构，而不是随机散点。
  const layerGroups = new Map();
  DOMAINS.forEach((d) => {
    const li = LAYER_INDEX[d.layer];
    if (!layerGroups.has(li)) layerGroups.set(li, []);
    layerGroups.get(li).push(d);
  });
  const layerRadii = new Map();

  // 各层领域方位角（度）：L2 的 2 个域（180° 间隔）和 L3 的 3 个域（原本 120° 等分）
  // 无论相位怎么转，总会有一个 L3 域落在 L2 域的 30° 夹角内，水平方向必然贴得过近。
  // 因此给 L3 单独指定方位角（90/240/300），把与 L2 的最小夹角扩大到 60°，同层间距仍然充足。
  const LAYER_ANGLES_DEG = [
    [45],
    [290],
    [0, 180],
    [90, 240, 300],
    [135],
    [250],
  ];

  DOMAINS.forEach((d) => {
    const li = LAYER_INDEX[d.layer];
    const mates = layerGroups.get(li);
    const idx = mates.indexOf(d);
    const deg = LAYER_ANGLES_DEG[li]?.[idx] ?? (idx / mates.length) * 360;
    const angle = THREE.MathUtils.degToRad(deg);
    // 环半径按同层领域数量决定：单领域层收进核心柱，3 个领域的 L3 最外扩，
    // 形成"中间宽、上下收"的纺锤形轮廓，避免顶层单领域被推到画面边缘而裁切
    const radius = ORBIT_BASE + (mates.length - 1) * 1.35;
    // 首尾两层（L0 元层 / L5 复盘层）收在旋转轴上，形成贯穿上下的核心端点
    const onAxis = d.layer === 'L0' || d.layer === 'L5';
    const x = onAxis ? 0 : Math.cos(angle) * radius * 1.55;  // 水平方向拉伸，拉开领域球间距
    const z = onAxis ? 0 : Math.sin(angle) * radius;
    // 层级胶囊固定在原层高，首尾两个球单独向外让位：L0 下沉、L5 上移，
    // 这样轴上标签仍完整保留，且不会被球体挡住
    const y = li * LAYER_HEIGHT + (d.layer === 'L0' ? -2.6 : d.layer === 'L5' ? 3.1 : 0);
    const pos = new THREE.Vector3(x, y, z);
    domainPos.set(d.id, pos);
    // 记录未拉伸的基础半径，供层环使用（x 已在上面乘过 1.55，不能再重复放大）
    layerRadii.set(li, Math.max(layerRadii.get(li) || 0, radius));

    const group = new THREE.Group();
    group.position.copy(pos);

    // 领域球体（发光核心 + 边缘光，能量球质感）
    const sphereGeo = new THREE.SphereGeometry(1.4, 48, 48);
    const sphereColor = soften(d.color, 1.18);
    const sphereMat = new THREE.MeshStandardMaterial({
      color: sphereColor,
      roughness: 0.18,
      metalness: 0.3,
      emissive: sphereColor,
      emissiveIntensity: 0.16,   // 自发光很低，暗面主要靠光晕提亮，突出明暗对比
    });
    const mesh = new THREE.Mesh(sphereGeo, sphereMat);

    // 表面纹理层（略大于球体，随球体一起自转）
    const texShell = new THREE.Mesh(sphereGeo, makeDomainSurfaceMaterial(d.color));
    texShell.scale.setScalar(1.004);
    mesh.add(texShell);
    group.add(mesh);

    // 边缘光球壳（Fresnel rim，边缘在领域色与青/紫之间流动）
    const rimGeo = new THREE.SphereGeometry(1.55, 48, 48);
    const rim = new THREE.Mesh(rimGeo, makeRimMaterial(soften(d.color), 1.35));
    group.add(rim);

    // 光晕（内圈半透明外壳）
    const haloGeo = new THREE.SphereGeometry(1.8, 32, 32);
    const haloMat = new THREE.MeshBasicMaterial({
      color: sphereColor, transparent: true, opacity: 0.08,
      depthWrite: false,
    });
    const halo = new THREE.Mesh(haloGeo, haloMat);
    group.add(halo);

    // 外层彩色光晕（billboard，让领域球在星云中更亮眼）
    const aura = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTexture(), color: sphereColor, transparent: true, opacity: 0.34,
      blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    // 光晕直径 6.2 < 最近领域间距 7.6：相邻球的光晕不再互相叠加
    aura.scale.setScalar(6.2);
    group.add(aura);

    // 轨道环（领域球周围的醒目发光圆环）
    const ringGeo = new THREE.RingGeometry(RING_RADIUS - 0.035, RING_RADIUS + 0.035, 128);
    const ringMat = makeOrbitRingMaterial(sphereColor, li * 1.9 + idx * 0.7);
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    group.add(ring);

    // 结构环：两道竖向细环，把卡片云与领域球绑成一个整体，减少「漂浮节点」感
    const cageMat = new THREE.LineBasicMaterial({
      color: sphereColor, transparent: true, opacity: 0.12,
      depthWrite: false, blending: THREE.AdditiveBlending,
    });
    for (let ci = 0; ci < 2; ci++) {
      const cagePts = [];
      for (let s = 0; s <= 96; s++) {
        const a = (s / 96) * Math.PI * 2;
        cagePts.push(new THREE.Vector3(Math.cos(a) * CARD_ORBIT, Math.sin(a) * CARD_ORBIT, 0));
      }
      const cage = new THREE.Line(new THREE.BufferGeometry().setFromPoints(cagePts), cageMat);
      cage.rotation.y = ci * Math.PI / 3;
      group.add(cage);
    }

    // 标签（缩小并贴近球体，避免多个领域名在屏幕上互相遮挡）
    // 首尾轴上领域：L0 标题放在球体下方，L5 放在球体上方
    const titleY = d.layer === 'L0' ? -2.6 : 2.7;
    const label = makeLabel(d.name, d.color, 0.56);
    label.position.y = titleY;
    group.add(label);

    scene.add(group);
    domainNodes.set(d.id, { group, mesh, halo, aura, label, pos, data: d });
  });

  // ---------- 层级光面：L0–L5 的依赖链变成六层带涟漪脉冲的透明眩光面 ----------
  const layerStructure = new THREE.Group();
  scene.add(layerStructure);
  const layerAnchors = [];
  // 层级刻度配色：L0 紫 → L5 青，跟星云的冷暖过渡一致
  const LAYER_LABEL_COLORS = ['#b79bdd', '#9c9ce2', '#84a9e2', '#6fb9dc', '#66c8cf', '#74d4bf'];
  LAYERS.forEach((layer, li) => {
    const R = (layerRadii.get(li) || ORBIT_BASE) + 1.8;
    const y = li * LAYER_HEIGHT;

    const disc = new THREE.Mesh(
      new THREE.CircleGeometry(1, 128),
      makeLayerDiscMaterial('#7c8fb8'),
    );
    disc.rotation.x = -Math.PI / 2;
    disc.scale.set(R * 1.55, R, 1);
    disc.position.y = y;
    // 光面先于标签/卡片绘制，避免加色亮度把上层文字洗淡
    disc.renderOrder = -1;
    layerStructure.add(disc);

    // 层标签收敛到旋转轴：更小字号 + 更轻字重 + 更低底衬，作为低调的层级刻度
    const label = makeLabel(
      `${layer.id} · ${layer.name}`,
      LAYER_LABEL_COLORS[li] || '#93a6c9',
      0.42,
      { weight: 500, bgAlpha: 0.4 },
    );
    label.position.set(0, y + 0.75, 0);
    label.material.opacity = 0.55;
    layerStructure.add(label);
    layerAnchors.push(new THREE.Vector3(0, y, 0));
  });

  if (layerAnchors.length > 1) {
    const spineGeo = new THREE.BufferGeometry().setFromPoints(layerAnchors);
    const spine = new THREE.Line(spineGeo, new THREE.LineBasicMaterial({
      color: new THREE.Color('#7c8fb8'), transparent: true, opacity: 0.16,
      depthWrite: false, blending: THREE.AdditiveBlending,
    }));
    layerStructure.add(spine);
  }

  // ---------- 卡片节点 ----------
  const cardMeshes = new Map();   // id -> { mesh, data, basePos, worldGroup }
  const cardWorldPos = new Map();

  // 按域分组；域内用「双链弹簧 + 斥力」布局，让有关系的卡片聚成可读的关系簇
  const domainCardGroups = new Map();
  CARDS.forEach((c) => {
    if (!domainCardGroups.has(c.domain)) domainCardGroups.set(c.domain, []);
    domainCardGroups.get(c.domain).push(c);
  });

  function layoutDomainCards(cards) {
    const n = cards.length;
    const pos = new Map();
    const golden = Math.PI * (3 - Math.sqrt(5));

    // 初始：球壳上的斐波那契分布，避免从同一点起步
    cards.forEach((c, j) => {
      const yOff = (j / Math.max(n - 1, 1)) * 2 - 1;
      const r = Math.sqrt(Math.max(0, 1 - yOff * yOff)) * CARD_ORBIT;
      const theta = j * golden * 2;
      pos.set(c.id, new THREE.Vector3(Math.cos(theta) * r, yOff * 2.3, Math.sin(theta) * r));
    });

    const ids = cards.map((c) => c.id);
    const adjSets = new Map(ids.map((id) => [id, new Set()]));
    cards.forEach((c) => {
      (c.links || []).forEach((l) => {
        if (l.to === c.id || !adjSets.has(l.to)) return;
        adjSets.get(c.id).add(l.to);
        adjSets.get(l.to).add(c.id);
      });
    });
    const adj = new Map([...adjSets].map(([id, set]) => [id, [...set]]));

    // 同主题弱聚拢：在双链关系簇内部再分出可读的子类团
    const topicGroups = new Map();
    cards.forEach((c) => {
      const t = TOPIC_INDEX.get(c.id);
      if (!t) return;
      if (!topicGroups.has(t.topic)) topicGroups.set(t.topic, []);
      topicGroups.get(t.topic).push(c.id);
    });

    const disp = new Map(ids.map((id) => [id, new THREE.Vector3()]));
    const tmp = new THREE.Vector3();
    const MAX_STEP = 0.16;

    // 球壳与高度约束：卡片必须留在领域球外围的环壳内
    function clampToShell(p) {
      const nr = Math.hypot(p.x, p.z);
      const maxR = CARD_ORBIT * 1.2;
      if (nr > maxR) { p.x *= maxR / nr; p.z *= maxR / nr; }
      if (nr < 1.9) {
        const scale = 1.9 / Math.max(nr, 0.01);
        p.x *= scale; p.z *= scale;
      }
      p.y = Math.max(-2.3, Math.min(2.3, p.y));
    }

    for (let iter = 0; iter < 110; iter++) {
      ids.forEach((id) => disp.get(id).set(0, 0, 0));

      // 斥力：保证卡片之间有间距
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          tmp.subVectors(pos.get(ids[i]), pos.get(ids[j]));
          let dist = tmp.length();
          if (dist < 0.02) {
            // 用确定性抖动打破重合，避免随机布局导致每次刷新位置不同
            tmp.set(
              Math.sin(i * 12.9898 + j * 4.1414),
              Math.cos(i * 78.233 + j * 2.7183),
              Math.sin(j * 37.719 + i * 1.618)
            );
            dist = tmp.length() || 1;
          }
          const rep = 0.055 / (dist * dist + 0.06);
          tmp.normalize().multiplyScalar(rep);
          disp.get(ids[i]).add(tmp);
          disp.get(ids[j]).sub(tmp);
        }
      }

      // 引力：域内双链把相关卡片拉近，形成关系簇
      adj.forEach((neighbors, id) => {
        neighbors.forEach((nid) => {
          if (id > nid) return;
          tmp.subVectors(pos.get(nid), pos.get(id));
          const dist = tmp.length() || 0.01;
          const force = (dist - 1.75) * 0.03;
          tmp.normalize().multiplyScalar(force);
          disp.get(id).add(tmp);
          disp.get(nid).sub(tmp);
        });
      });

      // 主题引力：同主题卡片保持一臂距离，形成类型之下的二级子簇
      topicGroups.forEach((members) => {
        for (let i = 0; i < members.length; i++) {
          for (let j = i + 1; j < members.length; j++) {
            tmp.subVectors(pos.get(members[j]), pos.get(members[i]));
            const dist = tmp.length() || 0.01;
            const force = (dist - 2.45) * 0.01;
            tmp.normalize().multiplyScalar(force);
            disp.get(members[i]).add(tmp);
            disp.get(members[j]).sub(tmp);
          }
        }
      });

      // 约束：保持球壳分布，避免塌进领域球或飞散
      ids.forEach((id) => {
        const p = pos.get(id);
        const d = disp.get(id);
        const r = Math.hypot(p.x, p.z);
        if (r > 0.01) {
          const radial = (CARD_ORBIT * 0.92 - r) * 0.05;
          d.x += (p.x / r) * radial;
          d.z += (p.z / r) * radial;
        }
        d.y -= p.y * 0.02;
        if (d.length() > MAX_STEP) d.setLength(MAX_STEP);
        p.add(d);
        clampToShell(p);
      });
    }

    // 均匀化收尾：弹簧布局容易在关系密集处结块，用硬间距迭代把过近的卡片推开
    const MIN_GAP = 0.92;
    for (let pass = 0; pass < 28; pass++) {
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          const a = pos.get(ids[i]);
          const b = pos.get(ids[j]);
          tmp.subVectors(b, a);
          let dist = tmp.length();
          if (dist >= MIN_GAP) continue;
          if (dist < 0.02) {
            tmp.set(
              Math.sin(i * 12.9898 + j * 4.1414),
              Math.cos(i * 78.233 + j * 2.7183),
              Math.sin(j * 37.719 + i * 1.618)
            );
            dist = tmp.length() || 1;
          }
          tmp.normalize().multiplyScalar((MIN_GAP - dist) * 0.5);
          a.sub(tmp);
          b.add(tmp);
        }
      }
      ids.forEach((id) => clampToShell(pos.get(id)));
    }
    return pos;
  }

  domainCardGroups.forEach((cards, domainId) => {
    const layout = layoutDomainCards(cards);
    cards.forEach((c) => {
      const local = layout.get(c.id);

      const geo = cardGeometry(c.type);
      const cardColor = soften(CARD_TYPES[c.type].color);
      // 概念卡：星球表面材质（开启纹理）；其余类型：极光珍珠材质
      const mat = makeAuroraMaterial(cardColor, undefined, c.type === 'concept' ? 1 : 0);
      const mesh = new THREE.Mesh(geo, mat);
      // 发光光晕（弱化，让领域球成为视觉主角）
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTexture(), color: cardColor, transparent: true, opacity: 0.3,
        blending: THREE.AdditiveBlending, depthWrite: false,
      }));
      glow.scale.setScalar(1.25);
      mesh.add(glow);
      mesh.position.copy(local);
      mesh.userData = { cardId: c.id };
      // 挂到领域 group，随领域公转
      const dg = domainNodes.get(domainId).group;
      dg.add(mesh);

      const baseScale = c.type === 'concept' ? 0.40 : 0.31;   // 概念卡略大，纹理更可见
      mesh.scale.setScalar(baseScale);
      cardMeshes.set(c.id, { mesh, data: c, basePos: local.clone(), baseScale, domainId, glow });
      cardWorldPos.set(c.id, mesh);
    });
  });

  // ---------- 双链光带 ----------
  const linkLines = [];
  const linkGroup = new THREE.Group();
  scene.add(linkGroup);
  const seenLinks = new Set();
  const uniqueLinks = [];

  CARDS.forEach((c) => {
    (c.links || []).forEach((ln) => {
      // 双向关系只画一条线，避免重叠加亮
      const key = [c.id, ln.to].sort().join('|');
      if (seenLinks.has(key)) return;
      const a = cardMeshes.get(c.id);
      const b = cardMeshes.get(ln.to);
      if (!a || !b) return;
      seenLinks.add(key);
      uniqueLinks.push({ from: c.id, to: ln.to, rel: ln.rel, a, b });
    });
  });

  // 枢纽度：连接越多的卡片，连线越淡，避免中心卡片炸出一团光带
  const linkDegree = new Map();
  uniqueLinks.forEach(({ from, to }) => {
    linkDegree.set(from, (linkDegree.get(from) || 0) + 1);
    linkDegree.set(to, (linkDegree.get(to) || 0) + 1);
  });

  const LINK_SEGMENTS = 20;

  /** 弧形连线：域内绕开域球向外鼓出，跨域沿世界轴向外扩散，避免直线穿球 */
  function makeLinkCurve(a, b, intra, domainId) {
    const mid = new THREE.Vector3().addVectors(a, b).multiplyScalar(0.5);
    const out = new THREE.Vector3();
    if (intra) {
      const center = domainNodes.get(domainId).pos;
      out.subVectors(mid, center);
      out.y *= 0.35;
    } else {
      out.set(mid.x, 0, mid.z);
    }
    if (out.lengthSq() < 0.04) {
      out.crossVectors(new THREE.Vector3().subVectors(b, a), new THREE.Vector3(0, 1, 0));
    }
    if (out.lengthSq() < 0.001) out.set(0, 1, 0);
    out.normalize().multiplyScalar(0.55 + a.distanceTo(b) * 0.1);
    const ctrl = mid.add(out);
    return new THREE.QuadraticBezierCurve3(a.clone(), ctrl, b.clone());
  }

  uniqueLinks.forEach(({ from, to, rel, a, b }) => {
    const intra = a.data.domain === b.data.domain;
    const deg = Math.min(linkDegree.get(from) || 1, linkDegree.get(to) || 1);
    const hubFade = 1 / Math.sqrt(Math.max(1, deg - 1));
    // 跨域连线默认完全隐藏，只在悬停卡片时点亮；默认画面只保留域内结构
    const baseOpacity = intra ? 0.20 * hubFade : 0;

    const pa = a.mesh.getWorldPosition(new THREE.Vector3());
    const pb = b.mesh.getWorldPosition(new THREE.Vector3());
    const pts = makeLinkCurve(pa, pb, intra, a.data.domain).getPoints(LINK_SEGMENTS);

    const positions = new Float32Array(pts.length * 3);
    const colors = new Float32Array(pts.length * 3);
    const base = soften(RELATION_COLOR[rel] || '#38bdf8', 0.8, 0.62);
    pts.forEach((p, i) => {
      positions[i * 3] = p.x;
      positions[i * 3 + 1] = p.y;
      positions[i * 3 + 2] = p.z;
      // 两端渐隐、中段最亮：线头不会在卡片表面形成硬结
      const fade = 0.2 + 0.8 * Math.pow(Math.sin((Math.PI * i) / (pts.length - 1)), 0.8);
      colors[i * 3] = base.r * fade;
      colors[i * 3 + 1] = base.g * fade;
      colors[i * 3 + 2] = base.b * fade;
    });

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const mat = new THREE.LineBasicMaterial({
      vertexColors: true, transparent: true, opacity: baseOpacity,
      depthWrite: false, blending: THREE.AdditiveBlending,
    });
    const line = new THREE.Line(geo, mat);
    line.userData = { from, to, rel, intra, baseOpacity };
    line.visible = baseOpacity > 0;
    linkGroup.add(line);
    linkLines.push(line);
  });

  // ---------- 拾取 ----------
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  let hovered = null;
  let filterType = null;
  let emphasisCard = null;
  let emphasisDomain = null;
  let selectedCardId = null;   // 详情面板打开的卡片：连线强调需跨 hover 持续保留

  function pick(event) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const candidates = [...cardMeshes.values()]
      .filter((m) => filterType === null || m.data.type === filterType)
      .map((m) => m.mesh)
      .concat([...domainNodes.values()].map((d) => d.mesh));
    const hits = raycaster.intersectObjects(candidates, false);
    return hits.length ? hits[0].object : null;
  }

  function onPointerMove(e) {
    const obj = pick(e);
    if (obj && obj.userData && obj.userData.cardId) {
      if (hovered !== obj) {
        clearHover();
        hovered = obj;
        const entry = cardMeshes.get(obj.userData.cardId);
        obj.scale.setScalar(entry.baseScale * 1.5);
        renderer.domElement.style.cursor = 'pointer';
        setEmphasis(obj.userData.cardId, null);
        if (onHover) onHover(entry.data, e);
      }
      return;
    }
    if (obj && domainNodes.has(findDomainByMesh(obj))) {
      clearHover();
      setEmphasis(null, findDomainByMesh(obj));
      renderer.domElement.style.cursor = 'pointer';
      return;
    }
    clearHover();
    renderer.domElement.style.cursor = 'grab';
  }

  // 清除卡片 hover 状态与 tooltip，避免卡片→领域球、卡片→UI 时悬停残留
  function clearHover() {
    if (hovered) {
      resetHover();
      if (onHoverOut) onHoverOut();
    }
    setEmphasis(null, null);
  }

  // 连线分层显隐：默认只留很淡的底噪，hover 时只点亮当前卡片/领域的相关连线
  function setEmphasis(cardId, domainId) {
    if (emphasisCard === cardId && emphasisDomain === domainId) return;
    emphasisCard = cardId;
    emphasisDomain = domainId;
    refreshLinkStyles();
  }

  function refreshLinkStyles() {
    linkLines.forEach((line) => {
      const { from, to, baseOpacity } = line.userData;
      const a = cardMeshes.get(from);
      const b = cardMeshes.get(to);
      let op = baseOpacity;

      if (filterType) {
        const connected = (a && a.data.type === filterType) || (b && b.data.type === filterType);
        if (!connected) op = Math.min(op, 0.012);
      }
      if (emphasisCard) {
        const hit = from === emphasisCard || to === emphasisCard;
        op = hit ? Math.max(op, 0.9) : Math.min(op, 0.018);
      } else if (selectedCardId) {
        const hit = from === selectedCardId || to === selectedCardId;
        op = hit ? Math.max(op, 0.9) : Math.min(op, 0.018);
      } else if (emphasisDomain) {
        const inside = a && b && a.data.domain === emphasisDomain && b.data.domain === emphasisDomain;
        op = inside ? Math.max(op, 0.45) : Math.min(op, 0.015);
      }
      line.material.opacity = op;
      line.visible = op > 0.001;
    });
  }

  function findDomainByMesh(mesh) {
    for (const [id, d] of domainNodes) if (d.mesh === mesh) return id;
    return null;
  }

  function resetHover() {
    if (hovered && hovered.userData) {
      const entry = cardMeshes.get(hovered.userData.cardId);
      if (entry) hovered.scale.setScalar(entry.baseScale);
    }
    hovered = null;
  }

  let pointerDown = null;

  function onPointerDown(e) {
    pointerDown = { x: e.clientX, y: e.clientY };
  }

  function onPointerCancel() {
    pointerDown = null;
  }

  function onPointerLeave() {
    pointerDown = null;
    resetHover();
    setEmphasis(null, null);
    if (onHoverOut) onHoverOut();
    renderer.domElement.style.cursor = 'grab';
  }

  function onClick(e) {
    if (!pointerDown) return;
    const dx = e.clientX - pointerDown.x;
    const dy = e.clientY - pointerDown.y;
    pointerDown = null;
    // 拖动旋转视角后不触发选中
    if (dx * dx + dy * dy > 36) return;
    const obj = pick(e);
    if (!obj) return;
    if (obj.userData && obj.userData.cardId) {
      clearHover();
      const card = cardMeshes.get(obj.userData.cardId).data;
      if (onSelectCard) onSelectCard(card);
      return;
    }
    const did = findDomainByMesh(obj);
    if (did && onSelectDomain) onSelectDomain(domainNodes.get(did).data);
  }

  renderer.domElement.addEventListener('pointerdown', onPointerDown);
  renderer.domElement.addEventListener('pointermove', onPointerMove);
  renderer.domElement.addEventListener('pointerleave', onPointerLeave);
  renderer.domElement.addEventListener('pointercancel', onPointerCancel);
  renderer.domElement.addEventListener('click', onClick);

  // ---------- 动画 ----------
  const clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);
    const t = clock.getElapsedTime();

    // 星空粒子呼吸
    starfield.material.opacity = 0.75 + 0.15 * Math.sin(t * 0.4);

    // 星云缓慢公转 + 云雾翻涌（旋转贴图 + 明暗呼吸）
    nebula.rotation.y = t * 0.004;
    nebula.children.forEach((sp) => {
      sp.material.rotation += sp.userData.spin;
      sp.material.opacity = sp.userData.baseOpacity
        * (0.86 + 0.14 * Math.sin(t * 0.35 + sp.userData.phase));
    });

    // 领域自转 + 光晕呼吸
    domainNodes.forEach((d) => {
      d.mesh.rotation.y += 0.004;
      d.halo.rotation.y -= 0.002;
      const s = 1 + 0.05 * Math.sin(t * 1.2 + d.pos.x);
      d.halo.scale.setScalar(s);
      d.aura.material.opacity = 0.4 + 0.12 * Math.sin(t * 1.2 + d.pos.x);
      d.mesh.material.emissiveIntensity = 0.16 + 0.05 * Math.sin(t * 1.2 + d.pos.x);
    });

    // 卡片自转 + 呼吸（受类型筛选影响）
    auroraTime.value = t;
    cardMeshes.forEach((entry) => {
      if (entry.mesh === hovered) return;
      if (entry.data.type === 'concept') {
        // 概念卡是星球：只绕自身轴自转，保持极轴稳定
        entry.mesh.rotation.y += 0.006;
      } else {
        entry.mesh.rotation.x += 0.008;
        entry.mesh.rotation.y += 0.011;
      }
      const match = filterType === null || entry.data.type === filterType;
      const pulse = match ? 1 + 0.18 * Math.sin(t * 2 + entry.basePos.x * 3) : 0.9;
      entry.mesh.scale.setScalar(entry.baseScale * pulse * (match ? 1 : 0.28));
      if (entry.mesh.material.uniforms) {
        entry.mesh.material.uniforms.uOpacity.value = match ? 1 : 0.16;
      } else {
        entry.mesh.material.opacity = match ? 1 : 0.16;
        entry.mesh.material.transparent = true;
      }
      if (entry.glow) {
        entry.glow.material.opacity = match
          ? 0.28 + 0.08 * Math.sin(t * 2.2 + entry.basePos.x * 3)
          : 0.03;
      }
    });

    // 连线位置在创建时已烘焙为世界坐标（卡片不自转位移），无需每帧重算
    controls.update();
    composer.render();
  }

  // ---------- 对外接口 ----------
  function resize() {
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    composer.setSize(w, h);
  }

  function highlightCard(id) {
    const entry = cardMeshes.get(id);
    if (!entry) return;
    resetHover();
    hovered = entry.mesh;
    entry.mesh.scale.setScalar(entry.baseScale * 1.6);
    selectedCardId = id;
    refreshLinkStyles();
  }

  function resetHighlight() {
    resetHover();
    selectedCardId = null;
    refreshLinkStyles();
  }

  function setAutoRotate(v) {
    controls.autoRotate = v;
  }

  function setFilter(type) {
    filterType = type || null;
    if (hovered) {
      const entry = cardMeshes.get(hovered.userData.cardId);
      if (filterType && entry && entry.data.type !== filterType) {
        clearHover();
        renderer.domElement.style.cursor = 'grab';
      }
    }
    // 连线随筛选同步淡化，避免筛选后仍留下满屏关系线
    refreshLinkStyles();
  }

  function dispose() {
    renderer.domElement.removeEventListener('pointerdown', onPointerDown);
    renderer.domElement.removeEventListener('pointermove', onPointerMove);
    renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
    renderer.domElement.removeEventListener('pointercancel', onPointerCancel);
    renderer.domElement.removeEventListener('click', onClick);
    renderer.dispose();
    if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
  }

  animate();

  return {
    scene, camera, renderer, composer, controls,
    cardMeshes, domainNodes,
    highlightCard, resetHighlight, setAutoRotate, setFilter, resize, dispose,
  };
}

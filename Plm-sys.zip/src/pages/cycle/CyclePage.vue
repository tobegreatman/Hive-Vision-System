<template>
  <div class="cycle-desk">
    <iframe
      class="cycle-desk__frame"
      src="/cycle/index.html"
      title="经济周期定位 · 经济周期"
    />
  </div>
</template>

<style scoped>
.cycle-desk {
  position: relative;
  width: 100%;
  height: 100%;
  background: #f6f9fc;
}

.cycle-desk__frame {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
}
</style>

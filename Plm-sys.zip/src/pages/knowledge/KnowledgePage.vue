<template>
  <div class="knowledge-desk">
    <iframe
      class="knowledge-desk__frame"
      src="/knowledge/index.html"
      title="知识宇宙 · 个人投资认知知识库"
    />
  </div>
</template>

<style scoped>
.knowledge-desk {
  position: relative;
  width: 100%;
  height: 100%;
  /* 与知识宇宙的深空底色一致：iframe 首帧未绘制时不闪白 */
  background: #05070f;
}

.knowledge-desk__frame {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
}
</style>

<script setup lang="ts">
import type {
  MarketBoard,
  MarketExchange,
  MarketStockCandidate,
  MarketStockQuote,
} from '@platform/contracts'
import { storeToRefs } from 'pinia'
import { computed, onUnmounted, ref, watch } from 'vue'

import { BOARD_LABEL, tint, useMarketStore } from '@/entities/market-node'
import { fetchStockQuote, searchMarketStocks } from '@/shared/api'
import { formatPct, formatPrice } from '@/shared/lib/format'
import { AppButton } from '@/shared/ui'

const store = useMarketStore()
const { isCreating, error } = storeToRefs(store)

const query = ref('')
const candidates = ref<MarketStockCandidate[]>([])
const searching = ref(false)
const picked = ref<MarketStockCandidate | null>(null)
const quote = ref<MarketStockQuote | null>(null)
const quoting = ref(false)
const localError = ref<string | null>(null)

let searchTimer: ReturnType<typeof setTimeout> | null = null
let searchController: AbortController | null = null
let quoteController: AbortController | null = null

function isAbort(cause: unknown): boolean {
  return cause instanceof Error && cause.name === 'AbortError'
}

function describeError(cause: unknown, fallback: string): string {
  return cause instanceof Error && cause.message ? cause.message : fallback
}

/**
 * 按 A 股代码段推断交易所与板块：
 * 600/601/603/605 沪主板，688 科创板，000/001/002/003 深主板，300/301 创业板，8xx/4xx 北交所。
 */
function inferMarket(symbol: string): { exchange: MarketExchange; board: MarketBoard } | null {
  if (!/^\d{6}$/.test(symbol)) return null
  if (/^(600|601|603|605)/.test(symbol)) return { exchange: 'SH', board: 'main' }
  if (/^68[89]/.test(symbol)) return { exchange: 'SH', board: 'star' }
  if (/^(300|301)/.test(symbol)) return { exchange: 'SZ', board: 'gem' }
  if (/^(000|001|002|003)/.test(symbol)) return { exchange: 'SZ', board: 'main' }
  if (/^(4|8|92)/.test(symbol)) return { exchange: 'BJ', board: 'bse' }
  return null
}

const inferred = computed(() => (picked.value ? inferMarket(picked.value.code) : null))
const boardLabel = computed(() => (inferred.value ? BOARD_LABEL[inferred.value.board] : '待识别'))

const quoteColor = computed(() => {
  const value = quote.value?.changePct ?? 0
  if (value > 0.005) return '#ff5d73'
  if (value < -0.005) return '#2ee6a6'
  return '#8ba3c2'
})

const canSubmit = computed(
  () => picked.value !== null && quote.value !== null && !quoting.value && !isCreating.value,
)

async function runSearch(keyword: string): Promise<void> {
  searchController?.abort()
  const controller = new AbortController()
  searchController = controller
  searching.value = true

  try {
    const response = await searchMarketStocks(keyword, controller.signal)
    if (searchController !== controller) return
    candidates.value = response.items
  } catch (cause) {
    if (isAbort(cause) || searchController !== controller) return
    candidates.value = []
    localError.value = describeError(cause, '搜索暂不可用')
  } finally {
    if (searchController === controller) {
      searching.value = false
      searchController = null
    }
  }
}

/** 选中候选后再取一次报价：现价 / 涨跌幅由服务端补齐，用户不需要手填。 */
async function loadQuote(candidate: MarketStockCandidate): Promise<void> {
  quoteController?.abort()
  const controller = new AbortController()
  quoteController = controller
  quoting.value = true

  try {
    const response = await fetchStockQuote(candidate.secid, controller.signal)
    if (quoteController !== controller) return
    quote.value = response.item
  } catch (cause) {
    if (isAbort(cause) || quoteController !== controller) return
    quote.value = null
    localError.value = describeError(cause, '行情暂不可用，请稍后重试')
  } finally {
    if (quoteController === controller) {
      quoting.value = false
      quoteController = null
    }
  }
}

function choose(candidate: MarketStockCandidate): void {
  picked.value = candidate
  quote.value = null
  localError.value = null
  candidates.value = []
  void loadQuote(candidate)
}

function reset(): void {
  quoteController?.abort()
  quoteController = null
  searching.value = false
  quoting.value = false
  query.value = ''
  candidates.value = []
  picked.value = null
  quote.value = null
  localError.value = null
}

async function submit(): Promise<void> {
  const candidate = picked.value
  const current = quote.value
  const market = inferred.value

  if (!candidate || !current) {
    localError.value = '请先搜索并选择一只个股'
    return
  }
  if (!market) {
    localError.value = '无法识别的证券代码，请输入 6 位 A 股代码'
    return
  }

  localError.value = null
  const created = await store.create({
    symbol: candidate.code,
    name: candidate.name,
    exchange: market.exchange,
    board: market.board,
    price: current.price,
    changePct: current.changePct,
    heat: 0.5,
  })

  if (created) reset()
}

watch(query, (value) => {
  // 编辑关键词意味着重新选股：把上一次选中的报价一起丢掉，避免张冠李戴
  picked.value = null
  quote.value = null
  localError.value = null
  quoteController?.abort()
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()

  const keyword = value.trim()
  if (!keyword) {
    candidates.value = []
    searching.value = false
    return
  }

  searching.value = true
  searchTimer = setTimeout(() => void runSearch(keyword), 260)
})

onUnmounted(() => {
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()
  quoteController?.abort()
})
</script>

<template>
  <form class="watch-form" @submit.prevent="submit">
    <div class="field">
      <label class="field__label" for="watch-query">证券代码 / 简称</label>
      <input
        id="watch-query"
        v-model="query"
        class="text-input"
        type="search"
        maxlength="24"
        placeholder="600519 / 贵州茅台"
        autocomplete="off"
      />
    </div>

    <div v-if="searching" class="watch-form__note">搜索中…</div>

    <ul v-else-if="candidates.length && !picked" class="watch-form__list">
      <li v-for="candidate in candidates" :key="candidate.secid">
        <button type="button" class="watch-form__item" @click="choose(candidate)">
          <span class="watch-form__item-name">{{ candidate.name }}</span>
          <span class="watch-form__item-meta mono">
            {{ candidate.code }} · {{ candidate.typeLabel }}
          </span>
        </button>
      </li>
    </ul>

    <p v-else-if="query.trim() && !picked" class="watch-form__note">没有匹配的个股</p>

    <div v-if="picked" class="watch-form__picked">
      <div class="watch-form__picked-main">
        <span class="watch-form__picked-name">{{ picked.name }}</span>
        <span class="watch-form__picked-code mono">{{ picked.code }} · {{ boardLabel }}</span>
      </div>

      <div v-if="quoting" class="watch-form__note">行情获取中…</div>
      <div v-else-if="quote" class="watch-form__quote mono">
        <span>{{ formatPrice(quote.price) }}</span>
        <span
          class="watch-form__pct"
          :style="{ color: quoteColor, background: tint(quoteColor, 0.14) }"
        >
          {{ formatPct(quote.changePct) }}
        </span>
        <span v-if="quote.quoteStatus === 'delayed'" class="watch-form__delay">延时</span>
      </div>

      <button type="button" class="watch-form__reset" @click="reset">重选</button>
    </div>

    <p class="watch-form__hint mono">现价与涨跌幅由行情源自动补齐</p>

    <p v-if="localError || error" class="watch-form__error">{{ localError ?? error }}</p>

    <AppButton type="submit" :loading="isCreating" :disabled="!canSubmit">
      {{ isCreating ? '入池中…' : '加入自选盘面' }}
    </AppButton>
  </form>
</template>

<style scoped>
.watch-form {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.watch-form__note {
  font-size: 10px;
  line-height: 1.5;
  color: var(--text-dim);
}

.watch-form__list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 168px;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  list-style: none;
}

.watch-form__item {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  padding: 5px 7px;
  border: 1px solid transparent;
  border-radius: 7px;
  background: transparent;
  text-align: left;
  cursor: pointer;
  transition:
    background 0.16s ease,
    border-color 0.16s ease;
}

.watch-form__item:hover {
  border-color: var(--line-soft);
  background: rgba(96, 196, 255, 0.1);
}

.watch-form__item-name {
  overflow: hidden;
  font-size: 11.5px;
  color: var(--text-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.watch-form__item-meta {
  flex: none;
  font-size: 9px;
  color: var(--text-dim);
}

.watch-form__picked {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 7px 8px;
  border: 1px solid var(--line-soft);
  border-radius: 9px;
  background: rgba(8, 18, 34, 0.45);
}

.watch-form__picked-main {
  display: flex;
  align-items: baseline;
  gap: 6px;
  padding-right: 34px;
}

.watch-form__picked-name {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-strong);
}

.watch-form__picked-code {
  font-size: 9px;
  color: var(--text-dim);
}

.watch-form__quote {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  color: var(--text);
}

.watch-form__pct {
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
}

.watch-form__delay {
  padding: 0 3px;
  border: 1px solid rgba(139, 163, 194, 0.35);
  border-radius: 3px;
  font-size: 8px;
  line-height: 12px;
  color: var(--text-dim);
}

.watch-form__reset {
  position: absolute;
  top: 6px;
  right: 7px;
  padding: 0;
  border: 0;
  background: transparent;
  font-size: 9.5px;
  color: var(--text-dim);
  cursor: pointer;
}

.watch-form__reset:hover {
  color: var(--accent-gold);
}

.watch-form__hint {
  font-size: 9.5px;
  color: var(--text-muted);
}

.watch-form__error {
  font-size: 11.5px;
  color: var(--up);
}
</style>

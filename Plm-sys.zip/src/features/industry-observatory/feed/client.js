/**
 * 浏览器端取数通道
 *
 * 只保留两条通道，任何一级失败都不影响渲染：
 *   live     ── 同源代理 /api/feed（服务端抓取 + 缓存 + 透传聚合所需原始行）
 *   snapshot ── 内置快照（离线兜底，明确标注数据时间）
 *
 * 曾经有第三条 `jsonp` 直连：那等于让第三方数据源在本页上下文里执行任意脚本，
 * 还绕过了服务端的缓存与限流。上游访问现在全部收口到 Hono，
 * 前端 CSP 也就能把 script-src 收成 'self'。
 */
import { INDUSTRY_PROVIDER } from '@platform/contracts'
import { decodeRow } from '../adapters/eastmoney.js'
import { build } from '../core/build.js'

const CACHE_KEY = 'industry-flow:v1'

function readCache(period) {
  try {
    const raw = localStorage.getItem(`${CACHE_KEY}:${period}`)
    if (!raw) return null
    const obj = JSON.parse(raw)
    if (!obj || typeof obj.ts !== 'number' || Date.now() - obj.ts > 60_000) return null
    return obj.payload
  } catch {
    return null
  }
}

function writeCache(period, payload) {
  try {
    localStorage.setItem(`${CACHE_KEY}:${period}`, JSON.stringify({ ts: Date.now(), payload }))
  } catch {
    /* 配额溢出时静默跳过，不影响主流程 */
  }
}

/**
 * 通道一：同源代理。
 * 服务端只回「原始行情行 + 抓取元信息」，聚合仍在这里做，
 * 保证业务规则（分组、评分、质量门禁）只有一份实现。
 */
async function viaApi(period, signal) {
  const startedAt = Date.now()
  const res = await fetch(`/api/feed?period=${encodeURIComponent(period)}`, { signal })
  if (!res.ok) throw new Error(`api ${res.status}`)

  const contentType = res.headers.get('content-type') || ''
  if (!contentType.includes('application/json')) throw new Error('api not json')

  const body = await res.json()
  if (body?.schema !== 'industry-flow/rows-v1') throw new Error('schema mismatch')
  if (!Array.isArray(body.records)) throw new Error('records missing')

  const records = body.records.map(decodeRow).filter(Boolean)
  if (!records.length) throw new Error('records empty')

  return build(records, {
    period,
    expected: body.total || INDUSTRY_PROVIDER.expected,
    total: body.total || records.length,
    channel: 'live',
    latencyMs: body.latencyMs ?? Date.now() - startedAt,
    pages: body.pages ?? null,
    failovers: 0,
  })
}

/** 通道二：内置快照 */
async function viaSnapshot(period) {
  const res = await fetch(`./data/snapshot-${period}.json`, { cache: 'no-store' })
  if (!res.ok) throw new Error('snapshot missing')
  const payload = await res.json()
  payload.source = { ...payload.source, channel: 'snapshot' }
  payload.audit = { ...payload.audit, degraded: true }
  return payload
}

/**
 * 统一取数入口
 * @param {'d1'|'d5'|'d10'} period
 * @param {{force?:boolean, signal?:AbortSignal}} opt
 */
export async function loadFeed(period, opt = {}) {
  if (!opt.force) {
    const cached = readCache(period)
    if (cached) return { payload: cached, channel: 'cache' }
  }

  const errors = []

  try {
    // 代理层自身有 55s 缓存，这里只兜住「上游挂住不回」的情况
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 9000)
    const onAbort = () => controller.abort()
    opt.signal?.addEventListener('abort', onAbort, { once: true })

    try {
      const payload = await viaApi(period, controller.signal)
      writeCache(period, payload)
      return { payload, channel: 'live' }
    } finally {
      clearTimeout(timer)
      opt.signal?.removeEventListener('abort', onAbort)
    }
  } catch (e) {
    errors.push(`live: ${e.message}`)
  }

  try {
    const payload = await viaSnapshot(period)
    return { payload, channel: 'snapshot', errors }
  } catch (e) {
    errors.push(`snapshot: ${e.message}`)
  }

  throw new Error(errors.join(' | '))
}

/** 板块分钟级资金流：同样走同源代理，服务端已做代码校验与字段解码。 */
export async function loadIntraday(code) {
  const res = await fetch(`/api/intraday?code=${encodeURIComponent(code)}`)
  if (!res.ok) throw new Error(`api ${res.status}`)
  const body = await res.json()
  return { code: body.code ?? code, points: Array.isArray(body.points) ? body.points : [] }
}

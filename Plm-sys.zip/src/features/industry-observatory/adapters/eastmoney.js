/**
 * 数据源适配器：东方财富行情/资金流（push2 系）
 *
 * 这里只剩「原始行 → 规范化记录」的字段映射。
 * 端点、字段表、分页参数已上移到 `@platform/contracts`（`INDUSTRY_PROVIDER`），
 * 由服务端代理 `/api/feed` 统一抓取——浏览器不再直连第三方，也不再注入 JSONP 脚本。
 */

const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null)

/**
 * 字符串字段清洗。
 * 板块名来自外部数据源，会被塞进 DOM 与 Canvas：这里限长，
 * 避免一段超长文本把 3D 标签或标签栏撑爆（XSS 由渲染层用 textContent 兜住）。
 */
const str = (v) => {
  if (v === undefined || v === null || v === '-' || v === '') return ''
  return String(v).slice(0, 64)
}

/**
 * 原始行 → 规范化记录（纯函数，无副作用）
 * 所有金额单位为元，比率为百分数。
 */
export function decodeRow(row) {
  if (!row || !row.f12) return null
  return {
    id: str(row.f12),
    name: str(row.f14),
    price: num(row.f2),
    chg: num(row.f3),
    turnoverRate: num(row.f8),
    open: num(row.f17),
    high: num(row.f15),
    low: num(row.f16),
    prevClose: num(row.f18),
    mcap: num(row.f20),
    up: num(row.f104),
    down: num(row.f105),
    flat: num(row.f106),
    leaderName: str(row.f128),
    leaderCode: str(row.f140),
    leaderChg: num(row.f136),
    d1: {
      net: num(row.f62),
      netPct: num(row.f184),
      tiers: { xl: num(row.f66), lg: num(row.f72), md: num(row.f78), sm: num(row.f84) },
    },
    d5: {
      net: num(row.f164),
      netPct: num(row.f165),
      tiers: { xl: num(row.f166), lg: num(row.f168), md: num(row.f170), sm: num(row.f172) },
    },
    d10: {
      net: num(row.f174),
      netPct: num(row.f175),
      tiers: null,
    },
    ts: num(row.f124),
  }
}

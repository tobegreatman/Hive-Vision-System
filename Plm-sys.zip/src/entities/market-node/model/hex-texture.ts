import type { MarketBoardSummary, MarketExchange, MarketNode } from '@platform/contracts'
import { CanvasTexture, SRGBColorSpace } from 'three'

import { formatAmount, formatPct, formatPrice } from '@/shared/lib/format'
import { sparkAxisMinutes } from '@/shared/lib/trading-session'

import { sceneTrendColor, symbolLabel, tint } from './presentation'

const WIDTH = 512
const HEIGHT = 320

/** 行情牌宽高比，供 HexTile 计算 Sprite 尺寸，避免文字被压扁。 */
export const HEX_LABEL_ASPECT = WIDTH / HEIGHT

const MONO = 'ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace'
const SANS = '"PingFang SC", "Microsoft YaHei", "Segoe UI", sans-serif'

/** 左右内边距：贴图两侧留白，避免文字贴到六边形棱线。 */
const PAD = 44
/** 同一行两段文字之间的最小呼吸距离。 */
const GAP = 18

function measure(
  ctx: CanvasRenderingContext2D,
  text: string,
  size: number,
  family: string,
  weight = 700,
): number {
  ctx.font = `${weight} ${size}px ${family}`
  return ctx.measureText(text).width
}

/**
 * 一行排不下时按比例整体缩字号（同排行共用缩放，避免大小悬殊），
 * 最低缩到 `minScale`；仍放不下由调用方截断。
 */
function fitScale(
  ctx: CanvasRenderingContext2D,
  parts: readonly { text: string; size: number; family: string; weight?: number }[],
  maxWidth: number,
  minScale = 0.6,
): number {
  const total =
    parts.reduce((sum, part) => sum + measure(ctx, part.text, part.size, part.family, part.weight), 0) +
    GAP * (parts.length - 1)
  if (total <= maxWidth) return 1
  return Math.max(minScale, maxWidth / total)
}

/** 名称过长时逐级降字号，仍超宽则截断加省略号。 */
function fitText(
  ctx: CanvasRenderingContext2D,
  text: string,
  size: number,
  minSize: number,
  family: string,
  weight: number,
  maxWidth: number,
): { text: string; size: number } {
  let current = size
  while (current > minSize && measure(ctx, text, current, family, weight) > maxWidth) {
    current -= 2
  }
  if (measure(ctx, text, current, family, weight) <= maxWidth) return { text, size: current }

  let clipped = text
  while (clipped.length > 1 && measure(ctx, `${clipped}…`, current, family, weight) > maxWidth) {
    clipped = clipped.slice(0, -1)
  }
  return { text: `${clipped}…`, size: current }
}

function createCanvas(): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D | null } {
  const canvas = document.createElement('canvas')
  canvas.width = WIDTH
  canvas.height = HEIGHT
  return { canvas, ctx: canvas.getContext('2d') }
}

/**
 * 行情牌底卡：深空场景下是一块半透明深色玻璃，
 * 用主题色的描边 + 外发光把卡片从同样暗的蜂巢面上「提」起来，同时保证文字对比度。
 */
function paintInnerShade(ctx: CanvasRenderingContext2D, accent: string): void {
  const inset = 16
  const width = WIDTH - inset * 2
  const height = HEIGHT - inset * 2
  const radius = 34

  ctx.beginPath()
  ctx.moveTo(inset + radius, inset)
  ctx.lineTo(inset + width - radius, inset)
  ctx.quadraticCurveTo(inset + width, inset, inset + width, inset + radius)
  ctx.lineTo(inset + width, inset + height - radius)
  ctx.quadraticCurveTo(inset + width, inset + height, inset + width - radius, inset + height)
  ctx.lineTo(inset + radius, inset + height)
  ctx.quadraticCurveTo(inset, inset + height, inset, inset + height - radius)
  ctx.lineTo(inset, inset + radius)
  ctx.quadraticCurveTo(inset, inset, inset + radius, inset)
  ctx.closePath()

  ctx.save()
  ctx.shadowColor = accent
  ctx.shadowBlur = 24
  ctx.fillStyle = 'rgba(6, 12, 24, 0.68)'
  ctx.fill()
  ctx.restore()

  ctx.save()
  const sheen = ctx.createLinearGradient(0, inset, 0, inset + height)
  sheen.addColorStop(0, 'rgba(255, 255, 255, 0.1)')
  sheen.addColorStop(0.4, 'rgba(255, 255, 255, 0)')
  sheen.addColorStop(1, 'rgba(0, 0, 0, 0.24)')
  ctx.fillStyle = sheen
  ctx.fill()
  ctx.restore()

  ctx.save()
  ctx.globalAlpha = 0.9
  ctx.strokeStyle = accent
  ctx.lineWidth = 3
  ctx.stroke()
  ctx.restore()
}

function finalize(canvas: HTMLCanvasElement): CanvasTexture {
  const texture = new CanvasTexture(canvas)
  texture.colorSpace = SRGBColorSpace
  texture.needsUpdate = true
  return texture
}

/** 分时区域：右下角，避开左侧「成交」文字与大号价格。 */
const SPARK_BOX = { left: 300, top: 236, width: WIDTH - PAD - 300, height: 52 } as const

/** 指数格子右下角的微型分时：昨收虚线 + 面积 + 折线，形状比数值更直观。 */
function paintSparkline(
  ctx: CanvasRenderingContext2D,
  points: readonly number[],
  base: number,
  accent: string,
  exchange: MarketExchange,
  axis?: number | null,
): void {
  if (points.length < 2) return

  // 240 个分钟点画进 168px 只会糊成一条；等距抽样到 ~80 点，末点单独补回。
  // 抽样必须带着原始序号——X 轴按「全天第几分钟」定位，一旦把序号压成 0..n，
  // 盘中只有几十个点也会被拉满整条轴，看起来像已经收盘。
  const step = Math.max(1, Math.ceil(points.length / 80))
  const sampled: { at: number; value: number }[] = []
  for (let index = 0; index < points.length; index += step) {
    const value = points[index]
    if (value !== undefined) sampled.push({ at: index, value })
  }
  const tail = points[points.length - 1]
  if (tail !== undefined && sampled[sampled.length - 1]?.at !== points.length - 1) {
    sampled.push({ at: points.length - 1, value: tail })
  }
  if (sampled.length < 2) return

  const series = sampled.map((point) => point.value)
  const values = base > 0 ? [...series, base] : series
  let min = Math.min(...values)
  let max = Math.max(...values)
  if (max - min < 1e-6) {
    min -= 1
    max += 1
  }
  const padding = (max - min) * 0.08
  min -= padding
  max += padding

  const { left, top, width, height } = SPARK_BOX
  // 分母是全天分钟数而不是点数：没走完的时间留在右侧空白，与详情图口径一致
  const axisMinutes = sparkAxisMinutes(exchange, points.length, axis)
  const xAt = (at: number): number => left + Math.min(1, at / axisMinutes) * width
  const yAt = (value: number): number => top + height - ((value - min) / (max - min)) * height

  if (base > 0) {
    ctx.save()
    ctx.strokeStyle = 'rgba(139, 163, 194, 0.42)'
    ctx.lineWidth = 1.5
    ctx.setLineDash([4, 5])
    ctx.beginPath()
    ctx.moveTo(left, yAt(base))
    ctx.lineTo(left + width, yAt(base))
    ctx.stroke()
    ctx.restore()
  }

  const last = sampled[sampled.length - 1]!
  const lastX = xAt(last.at)

  ctx.save()
  // 未走完的时间段铺一层极淡底纹，让留白看着是「还没到」而不是「图没画出来」。
  // 贴图会被缩到屏幕上（512px → 约 200px），透明度比详情图略高才留得住。
  if (last.at < axisMinutes) {
    ctx.fillStyle = 'rgba(139, 163, 194, 0.1)'
    ctx.fillRect(lastX, top, left + width - lastX, height)
  }

  ctx.beginPath()
  ctx.moveTo(xAt(sampled[0]!.at), top + height)
  sampled.forEach((point) => ctx.lineTo(xAt(point.at), yAt(point.value)))
  // 面积收在当前点，不铺到右边缘，否则留白区被填满，一眼看不出当天还没走完
  ctx.lineTo(lastX, top + height)
  ctx.closePath()
  const fill = ctx.createLinearGradient(0, top, 0, top + height)
  fill.addColorStop(0, tint(accent, 0.3))
  fill.addColorStop(1, tint(accent, 0))
  ctx.fillStyle = fill
  ctx.fill()

  ctx.beginPath()
  sampled.forEach((point, index) => {
    if (index === 0) ctx.moveTo(xAt(point.at), yAt(point.value))
    else ctx.lineTo(xAt(point.at), yAt(point.value))
  })
  ctx.strokeStyle = accent
  ctx.lineWidth = 2.5
  ctx.lineJoin = 'round'
  ctx.lineCap = 'round'
  ctx.stroke()

  ctx.beginPath()
  ctx.arc(xAt(last.at), yAt(last.value), 3.2, 0, Math.PI * 2)
  ctx.fillStyle = accent
  ctx.fill()
  ctx.restore()
}

/** 个股 / 指数格子：名称 + 代码 + 最新价 + 涨跌幅 + 成交额。 */
export function createNodeHexTexture(node: MarketNode): CanvasTexture {
  const { canvas, ctx } = createCanvas()
  if (!ctx) return new CanvasTexture(canvas)

  const accent = sceneTrendColor(node)
  const contentWidth = WIDTH - PAD * 2
  paintInnerShade(ctx, accent)
  ctx.textBaseline = 'middle'

  // 名称（左）与代码（右）：先按名称实测宽度收窄，再让代码右对齐
  const code = symbolLabel(node)
  const codeWidth = measure(ctx, code, 24, MONO, 400)
  const name = fitText(ctx, node.name, 46, 30, SANS, 600, contentWidth - codeWidth - GAP)

  ctx.fillStyle = '#ecf5ff'
  ctx.font = `600 ${name.size}px ${SANS}`
  ctx.fillText(name.text, PAD, 86)

  ctx.font = `400 24px ${MONO}`
  ctx.fillStyle = '#8ba4c5'
  ctx.fillText(code, WIDTH - codeWidth - PAD, 88)

  // 最新价（大号等宽）与涨跌幅（右对齐，颜色即方向）
  // 长价格（如 1,586.00）与 `-10.00%` 同排会超出贴图宽度，按比例收字号
  const price = formatPrice(node.price)
  const pct = formatPct(node.changePct)
  const scale = fitScale(
    ctx,
    [
      { text: price, size: 70, family: MONO },
      { text: pct, size: 56, family: MONO },
    ],
    contentWidth,
    0.62,
  )
  const priceSize = Math.round(70 * scale)
  const pctSize = Math.round(56 * scale)

  ctx.font = `700 ${priceSize}px ${MONO}`
  ctx.fillStyle = '#ffffff'
  ctx.fillText(price, PAD, 196)

  ctx.font = `700 ${pctSize}px ${MONO}`
  ctx.fillStyle = accent
  ctx.fillText(pct, WIDTH - measure(ctx, pct, pctSize, MONO) - PAD, 198)

  // 成交额：导航时的「活跃度」提示
  ctx.font = `400 24px ${MONO}`
  ctx.fillStyle = '#7f97b7'
  ctx.fillText(`成交 ${formatAmount(node.turnover)}`, PAD, 268)

  // 指数格子右下角画当日分时：昨收取自当前涨跌幅，全球指数同样适用
  if (node.kind === 'index' && node.spark && node.spark.length >= 2) {
    const base = node.changePct > -99.9 ? node.price / (1 + node.changePct / 100) : 0
    paintSparkline(ctx, node.spark, base, accent, node.exchange, node.sparkAxis)
  }

  return finalize(canvas)
}

/** 板块格子：板块名 + 家数 + 均涨幅 + 涨跌分布 + 领涨股。 */
export function createBoardHexTexture(board: MarketBoardSummary): CanvasTexture {
  const { canvas, ctx } = createCanvas()
  if (!ctx) return new CanvasTexture(canvas)

  const accent = board.count === 0 ? '#7f97b7' : sceneTrendColor({ changePct: board.avgChangePct })
  const contentWidth = WIDTH - PAD * 2
  paintInnerShade(ctx, accent)
  ctx.textBaseline = 'middle'

  const count = board.board === 'index' ? `${board.count} 条` : `${board.count} 只`
  const countWidth = measure(ctx, count, 26, MONO, 400)
  const label = fitText(ctx, board.label, 56, 34, SANS, 700, contentWidth - countWidth - GAP)

  ctx.fillStyle = '#ecf5ff'
  ctx.font = `700 ${label.size}px ${SANS}`
  ctx.fillText(label.text, PAD, 92)

  ctx.font = `400 26px ${MONO}`
  ctx.fillStyle = '#8ba4c5'
  ctx.fillText(count, WIDTH - countWidth - PAD, 94)

  const pct = board.count === 0 ? '—' : formatPct(board.avgChangePct)
  const breadth = board.count === 0 ? '暂无标的' : `涨 ${board.up} · 跌 ${board.down}`
  const scale = fitScale(
    ctx,
    [
      { text: pct, size: 62, family: MONO },
      { text: breadth, size: 26, family: MONO, weight: 400 },
    ],
    contentWidth,
    0.66,
  )
  const pctSize = Math.round(62 * scale)
  const breadthSize = Math.round(26 * scale)

  ctx.font = `700 ${pctSize}px ${MONO}`
  ctx.fillStyle = accent
  ctx.fillText(pct, PAD, 190)

  ctx.font = `400 ${breadthSize}px ${MONO}`
  ctx.fillStyle = '#8ba4c5'
  ctx.fillText(breadth, WIDTH - measure(ctx, breadth, breadthSize, MONO, 400) - PAD, 192)

  ctx.fillStyle = '#7f97b7'
  ctx.font = `400 24px ${MONO}`
  const leader = board.leader
  const hint =
    board.count === 0
      ? '点击查看空板块'
      : leader
        ? `领涨 ${leader.name} ${formatPct(leader.changePct)}`
        : `成交 ${formatAmount(board.turnover)}`
  const fitted = fitText(ctx, hint, 24, 18, MONO, 400, contentWidth)
  ctx.font = `400 ${fitted.size}px ${MONO}`
  ctx.fillText(fitted.text, PAD, 264)

  return finalize(canvas)
}

<script setup lang="ts">
import type { MarketNode } from '@platform/contracts'
import { computed, onUnmounted, shallowRef, watch } from 'vue'

import HexTile from '@/shared/lib/three/HexTile.vue'
import { clamp } from '@/shared/lib/format'

import { createNodeHexTexture, HEX_LABEL_ASPECT } from '../model/hex-texture'
import { sceneTrendColor } from '../model/presentation'

const props = withDefaults(
  defineProps<{
    node: MarketNode
    position: [number, number, number]
    radius: number
    selected?: boolean
    hovered?: boolean
  }>(),
  { selected: false, hovered: false },
)

const emit = defineEmits<{
  pick: [id: string]
  hover: [id: string | null]
}>()

const accent = computed(() => sceneTrendColor(props.node))
/** 涨跌幅越极端，格子越亮：一眼看出哪些标的在异动 */
const glow = computed(() => clamp(Math.abs(props.node.changePct) / 10, 0, 1))

/**
 * 贴图上真正会画的字段。关注度（heat）只影响辉光、不进贴图，
 * 所以拖动滑块不会打穿这里——只有价格 / 涨跌幅 / 成交额 / 名称变化才重建。
 */
const textureKey = computed(() => {
  // 分时序列只认长度与末点：盘中一分钟才多一个点，足够触发重绘又不拼大字符串
  const spark = props.node.spark
  return [
    props.node.name,
    props.node.price,
    props.node.changePct,
    props.node.turnover,
    spark?.length ?? 0,
    spark?.[spark.length - 1] ?? 0,
  ].join('|')
})

// shallowRef：CanvasTexture 是 Three 对象，被 Vue 深度代理后写进 GL 会出怪问题
const texture = shallowRef(createNodeHexTexture(props.node))

watch(textureKey, () => {
  const previous = texture.value
  texture.value = createNodeHexTexture(props.node)
  // 先建新的再放旧的：中间态短暂多占一张贴图，好过让材质短暂指向已释放的纹理
  previous?.dispose()
})

onUnmounted(() => {
  texture.value?.dispose()
})
</script>

<template>
  <HexTile
    :position="position"
    :radius="radius"
    :accent="accent"
    :glow="glow"
    :selected="selected"
    :hovered="hovered"
    :texture="texture"
    :label-aspect="HEX_LABEL_ASPECT"
    @pick="emit('pick', node.id)"
    @hover="(value) => emit('hover', value ? node.id : null)"
  />
</template>

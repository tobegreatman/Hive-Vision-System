<script setup lang="ts">
import type { MarketBoardSummary } from '@platform/contracts'
import { computed, onUnmounted, shallowRef, watch } from 'vue'

import { createBoardHexTexture, HEX_LABEL_ASPECT } from '@/entities/market-node'
import { clamp } from '@/shared/lib/format'
import HexTile from '@/shared/lib/three/HexTile.vue'

import { boardAccent, boardGlow } from '../model/presentation'

const props = withDefaults(
  defineProps<{
    board: MarketBoardSummary
    position: [number, number, number]
    radius: number
    hovered?: boolean
  }>(),
  { hovered: false },
)

const emit = defineEmits<{
  pick: [board: MarketBoardSummary]
  hover: [board: MarketBoardSummary | null]
}>()

const accent = computed(() => boardAccent(props.board))
const glow = computed(() => clamp(boardGlow(props.board), 0, 1))
const muted = computed(() => props.board.count === 0)

/** 贴图上会画的字段；家数 / 涨跌家数 / 均涨幅 / 领涨股任一变化都要重绘。 */
const textureKey = computed(() =>
  [
    props.board.count,
    props.board.up,
    props.board.down,
    props.board.avgChangePct,
    props.board.turnover,
    props.board.leader?.name ?? '',
    props.board.leader?.changePct ?? '',
  ].join('|'),
)

// shallowRef：CanvasTexture 是 Three 对象，不能让 Vue 深度代理
const texture = shallowRef(createBoardHexTexture(props.board))

watch(textureKey, () => {
  const previous = texture.value
  texture.value = createBoardHexTexture(props.board)
  previous?.dispose()
})

onUnmounted(() => {
  texture.value?.dispose()
})
</script>

<template>
  <HexTile
    :position="position"
    :radius="radius"
    :accent="accent"
    :glow="glow"
    :muted="muted"
    :hovered="hovered"
    :texture="texture"
    :label-aspect="HEX_LABEL_ASPECT"
    @pick="emit('pick', board)"
    @hover="(value) => emit('hover', value ? board : null)"
  />
</template>

<script setup lang="ts">
import type { MarketKlineBar, MarketKlinePeriod } from '@platform/contracts'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'

import { formatPrice } from '@/shared/lib/format'

const props = defineProps<{
  bars: MarketKlineBar[]
  period: MarketKlinePeriod
}>()

/**
 * 宽度按容器实测，viewBox 与 CSS 像素 1:1。
 *
 * 所有历史 K 线不再强行挤进一屏：每根蜡烛占固定槽宽，
 * 一屏只显示约 60 根，想看更早的行情按住图表左右拖动即可。
 */
const FALLBACK_WIDTH = 460
const HEIGHT = 178
/** 左侧价格刻度、右侧均线列各占一条窄栏，中间全部留给蜡烛。 */
const PAD = { top: 8, right: 48, bottom: 18, left: 42 }
/** 单根蜡烛的固定槽宽（含间隙）：太密会糊成色块，太疏一屏装不下多少根。 */
const SLOT = 6

const UP = '#ff5d73'
const DOWN = '#2ee6a6'
/** clipPath 的 id 必须唯一：同页面可能有多个图表实例 */
const clipId = `candle-clip-${Math.random().toString(36).slice(2, 9)}`

const host = ref<HTMLElement | null>(null)
const measured = ref(0)
const width = computed(() => Math.max(280, Math.round(measured.value || FALLBACK_WIDTH)))

/** 视口左边缘在整段 K 线里的像素偏移；0 = 最早一根，max = 最新一根贴右边。 */
const viewOffset = ref(0)
const dragging = ref(false)
let dragOriginX = 0
let dragOriginOffset = 0

let observer: ResizeObserver | null = null

function plotWidthOf(containerWidth: number): number {
  return Math.max(0, containerWidth - PAD.left - PAD.right)
}

function maxOffsetOf(plotW: number): number {
  return Math.max(0, props.bars.length * SLOT - plotW)
}

onMounted(() => {
  const element = host.value
  if (!element || typeof ResizeObserver === 'undefined') return

  measured.value = element.clientWidth
  observer = new ResizeObserver((entries) => {
    const entry = entries[0]
    if (entry) measured.value = entry.contentRect.width
  })
  observer.observe(element)
})

onUnmounted(() => {
  observer?.disconnect()
  observer = null
})

// 换粒度 / 刷新数据：默认停在最新一段，用户不用先拖到最右边
watch(
  () => props.bars,
  () => {
    viewOffset.value = maxOffsetOf(plotWidthOf(width.value))
  },
  { immediate: true },
)

// 面板变宽变窄：原本贴着右边的继续贴右边，正在看历史的保持当前位置
watch(width, (next, previous) => {
  const previousMax = maxOffsetOf(plotWidthOf(previous))
  const nextMax = maxOffsetOf(plotWidthOf(next))
  const pinnedRight = viewOffset.value >= previousMax - 0.5
  viewOffset.value = pinnedRight ? nextMax : Math.min(viewOffset.value, nextMax)
})

function onPointerDown(event: PointerEvent): void {
  const plotW = geometry.value?.plotW
  if (plotW === undefined || maxOffsetOf(plotW) <= 0) return

  const target = event.currentTarget as SVGSVGElement
  target.setPointerCapture?.(event.pointerId)
  dragging.value = true
  dragOriginX = event.clientX
  dragOriginOffset = viewOffset.value
  event.preventDefault()
}

function onPointerMove(event: PointerEvent): void {
  if (!dragging.value) return

  const plotW = geometry.value?.plotW ?? 0
  const next = dragOriginOffset - (event.clientX - dragOriginX)
  viewOffset.value = Math.min(Math.max(0, next), maxOffsetOf(plotW))
}

function onPointerUp(event: PointerEvent): void {
  if (!dragging.value) return

  dragging.value = false
  const target = event.currentTarget as SVGSVGElement
  if (target.hasPointerCapture?.(event.pointerId)) target.releasePointerCapture(event.pointerId)
}

const geometry = computed(() => {
  const bars = props.bars
  if (bars.length < 2) return null

  const W = width.value
  const H = HEIGHT
  const plotLeft = PAD.left
  const plotRight = W - PAD.right
  const plotTop = PAD.top
  const plotBottom = H - PAD.bottom
  const plotW = plotRight - plotLeft
  const plotH = plotBottom - plotTop
  const contentW = bars.length * SLOT
  const offset = Math.min(Math.max(0, viewOffset.value), maxOffsetOf(plotW))
  const bodyW = Math.max(1, Math.min(SLOT * 0.68, 9))

  // 只渲染视口附近的蜡烛：250 根全画出来既浪费也没必要
  const start = Math.max(0, Math.floor(offset / SLOT) - 1)
  const end = Math.min(bars.length - 1, Math.ceil((offset + plotW) / SLOT) + 1)

  // 纵轴按当前视口取高低点：翻到历史区间时也能看清细节，而不是被全历史压扁
  let high = Number.NEGATIVE_INFINITY
  let low = Number.POSITIVE_INFINITY
  for (let index = start; index <= end; index += 1) {
    const bar = bars[index]!
    if (bar.high > high) high = bar.high
    if (bar.low < low) low = bar.low
  }
  const span = high - low || Math.max(high * 0.001, 0.01)

  const yAt = (price: number): number => plotTop + (1 - (price - low) / span) * plotH
  const xAt = (index: number): number => plotLeft + (index + 0.5) * SLOT - offset

  const candles = []
  for (let index = start; index <= end; index += 1) {
    const bar = bars[index]!
    const top = yAt(Math.max(bar.open, bar.close))
    const bottom = yAt(Math.min(bar.open, bar.close))
    candles.push({
      key: index,
      x: xAt(index),
      wickTop: yAt(bar.high),
      wickBottom: yAt(bar.low),
      bodyTop: top,
      bodyHeight: Math.max(0.9, bottom - top),
      color: bar.close >= bar.open ? UP : DOWN,
    })
  }

  /** 简单移动平均：窗口不足时不出点，避免前半段画一条假的 0 线。 */
  const movingAverage = (window: number): string => {
    const segments: string[] = []
    let sum = 0
    for (let index = 0; index <= end; index += 1) {
      sum += bars[index]!.close
      if (index >= window) sum -= bars[index - window]!.close
      if (index < window - 1 || index < start) continue
      const command = segments.length === 0 ? 'M' : 'L'
      segments.push(`${command}${xAt(index).toFixed(2)},${yAt(sum / window).toFixed(2)}`)
    }
    return segments.join(' ')
  }

  const label = (at: string): string => (props.period === 'month' ? at.slice(0, 7) : at.slice(5))

  const firstVisible = Math.min(bars.length - 1, Math.floor(offset / SLOT))
  const lastVisible = Math.min(bars.length - 1, Math.ceil((offset + plotW) / SLOT) - 1)
  const midVisible = Math.floor((firstVisible + lastVisible) / 2)

  const thumbWidth = contentW > plotW ? Math.max(14, (plotW / contentW) * plotW) : 0

  return {
    W,
    H,
    plotLeft,
    plotRight,
    plotTop,
    plotBottom,
    plotW,
    bodyW,
    candles,
    ma5: movingAverage(5),
    ma10: movingAverage(10),
    ma20: movingAverage(20),
    grid: [0.25, 0.5, 0.75].map((ratio) => plotTop + plotH * ratio),
    ticks: [
      { y: yAt(high), text: formatPrice(high) },
      { y: yAt((high + low) / 2), text: formatPrice((high + low) / 2) },
      { y: yAt(low), text: formatPrice(low) },
    ],
    axis: {
      first: { text: label(bars[firstVisible]!.at), x: Math.max(plotLeft + 1, xAt(firstVisible)) },
      mid: { text: label(bars[midVisible]!.at), x: (plotLeft + plotRight) / 2 },
      last: { text: label(bars[lastVisible]!.at), x: Math.min(plotRight - 1, xAt(lastVisible)) },
    },
    scroll:
      thumbWidth > 0
        ? {
            trackX: plotLeft,
            trackWidth: plotW,
            thumbX: plotLeft + (offset / contentW) * plotW,
            thumbWidth,
          }
        : null,
    pannable: contentW > plotW + 0.5,
  }
})
</script>

<template>
  <div v-if="geometry" ref="host" class="candle">
    <svg
      class="candle__svg"
      :class="{ 'candle__svg--dragging': dragging }"
      :viewBox="`0 0 ${geometry.W} ${geometry.H}`"
      :style="{ height: `${geometry.H}px` }"
      role="img"
      aria-label="K 线走势，可左右拖动查看更早行情"
      @pointerdown="onPointerDown"
      @pointermove="onPointerMove"
      @pointerup="onPointerUp"
      @pointercancel="onPointerUp"
      @dragstart.prevent
    >
      <defs>
        <!-- 拖拽时视口边缘会出现半根蜡烛，裁掉绘图区外的部分，别压到价格刻度和均线栏 -->
        <clipPath :id="clipId">
          <rect
            :x="geometry.plotLeft"
            :y="geometry.plotTop"
            :width="geometry.plotW"
            :height="geometry.plotBottom - geometry.plotTop"
          />
        </clipPath>
      </defs>

      <line
        v-for="(y, index) in geometry.grid"
        :key="`grid-${index}`"
        class="candle__grid"
        :x1="geometry.plotLeft"
        :y1="y"
        :x2="geometry.plotRight"
        :y2="y"
      />

      <g :clip-path="`url(#${clipId})`">
        <g v-for="candle in geometry.candles" :key="candle.key">
          <line
            :x1="candle.x"
            :x2="candle.x"
            :y1="candle.wickTop"
            :y2="candle.wickBottom"
            :stroke="candle.color"
            stroke-width="1"
          />
          <rect
            :x="candle.x - geometry.bodyW / 2"
            :y="candle.bodyTop"
            :width="geometry.bodyW"
            :height="candle.bodyHeight"
            :fill="candle.color"
          />
        </g>

        <path v-if="geometry.ma5" class="candle__ma candle__ma--5" :d="geometry.ma5" />
        <path v-if="geometry.ma10" class="candle__ma candle__ma--10" :d="geometry.ma10" />
        <path v-if="geometry.ma20" class="candle__ma candle__ma--20" :d="geometry.ma20" />
      </g>

      <!-- 价格刻度在左侧，右侧一整条窄栏留给竖排均线，蜡烛可用宽度最大化 -->
      <text
        v-for="tick in geometry.ticks"
        :key="tick.text"
        class="candle__tick"
        :x="geometry.plotLeft - 6"
        :y="tick.y + 2.5"
        text-anchor="end"
      >
        {{ tick.text }}
      </text>

      <text
        class="candle__tick candle__axis"
        :x="geometry.axis.first.x"
        :y="geometry.H - 4"
        text-anchor="start"
      >
        {{ geometry.axis.first.text }}
      </text>
      <text
        class="candle__tick candle__axis"
        :x="geometry.axis.mid.x"
        :y="geometry.H - 4"
        text-anchor="middle"
      >
        {{ geometry.axis.mid.text }}
      </text>
      <text
        class="candle__tick candle__axis"
        :x="geometry.axis.last.x"
        :y="geometry.H - 4"
        text-anchor="end"
      >
        {{ geometry.axis.last.text }}
      </text>

      <!-- 提示可以横向拖动：放在绘图区上方的留白里，不压住蜡烛 -->
      <text
        v-if="geometry.pannable"
        class="candle__hint"
        :x="geometry.plotLeft + 3"
        :y="geometry.plotTop - 1"
      >
        拖动查看历史
      </text>

      <template v-if="geometry.scroll">
        <rect
          class="candle__scroll-track"
          :x="geometry.scroll.trackX"
          :y="geometry.H - 3"
          :width="geometry.scroll.trackWidth"
          height="2"
          rx="1"
        />
        <rect
          class="candle__scroll-thumb"
          :x="geometry.scroll.thumbX"
          :y="geometry.H - 3"
          :width="geometry.scroll.thumbWidth"
          height="2"
          rx="1"
        />
      </template>
    </svg>

    <!-- 均线图例竖排在右侧信息栏，不再横向占掉一行高度 -->
    <div class="candle__legend mono" aria-hidden="true">
      <span class="candle__legend-item candle__legend-item--5">MA5</span>
      <span class="candle__legend-item candle__legend-item--10">MA10</span>
      <span class="candle__legend-item candle__legend-item--20">MA20</span>
    </div>
  </div>

  <div v-else class="candle__empty mono">K 线数据不足</div>
</template>

<style scoped>
.candle {
  position: relative;
  user-select: none;
}

.candle__svg {
  display: block;
  width: 100%;
  overflow: hidden;
  cursor: grab;
  /* 横向拖拽交给图表，纵向滑动仍能滚动页面 */
  touch-action: pan-y;
}

.candle__svg--dragging {
  cursor: grabbing;
}

.candle__grid {
  stroke: var(--text-dim, #8ba3c2);
  stroke-width: 0.6;
  opacity: 0.16;
  vector-effect: non-scaling-stroke;
}

.candle__ma {
  fill: none;
  stroke-width: 1;
  stroke-linejoin: round;
  stroke-linecap: round;
  opacity: 0.75;
}

.candle__ma--5 {
  stroke: #f2c25c;
}

.candle__ma--10 {
  stroke: #7fe6ff;
}

.candle__ma--20 {
  stroke: #ff9ecb;
}

.candle__tick {
  fill: var(--text-dim, #8ba3c2);
  font-family: ui-monospace, 'SFMono-Regular', Menlo, Consolas, monospace;
  font-size: 7.5px;
  opacity: 0.9;
}

.candle__scroll-track {
  fill: var(--text-dim, #8ba3c2);
  opacity: 0.18;
}

.candle__scroll-thumb {
  fill: var(--accent-gold, #f2c25c);
  opacity: 0.55;
}

.candle__hint {
  fill: var(--text-dim, #8ba3c2);
  font-family: ui-monospace, 'SFMono-Regular', Menlo, Consolas, monospace;
  font-size: 7px;
  letter-spacing: 0.04em;
  opacity: 0.5;
}

.candle__legend {
  position: absolute;
  top: 4px;
  right: 2px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: 8px;
  line-height: 1.25;
  pointer-events: none;
}

.candle__legend-item {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  white-space: nowrap;
}

.candle__legend-item::before {
  content: '';
  width: 7px;
  height: 1px;
  background: currentcolor;
}

.candle__legend-item--5 {
  color: #f2c25c;
}

.candle__legend-item--10 {
  color: #7fe6ff;
}

.candle__legend-item--20 {
  color: #ff9ecb;
}

.candle__empty {
  display: grid;
  place-items: center;
  height: 178px;
  border: 1px dashed var(--line-soft);
  border-radius: 8px;
  font-size: 10px;
  color: var(--text-dim);
}
</style>

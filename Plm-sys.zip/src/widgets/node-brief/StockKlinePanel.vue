<script setup lang="ts">
import type { MarketKlineBar, MarketKlinePeriod, MarketNode } from '@platform/contracts'
import { computed, onUnmounted, ref, watch } from 'vue'

import { tint } from '@/entities/market-node'
import { fetchMarketKline } from '@/shared/api'
import { formatPct, formatPrice } from '@/shared/lib/format'

import CandleChart from './CandleChart.vue'
import IndexTrendChart from './IndexTrendChart.vue'

const props = defineProps<{ node: MarketNode }>()

const TAB_ITEMS = [
  { key: 'intraday', label: '分时' },
  { key: 'day', label: '日K' },
  { key: 'week', label: '周K' },
  { key: 'month', label: '月K' },
] as const

type TabKey = (typeof TAB_ITEMS)[number]['key']

const tab = ref<TabKey>('intraday')
const cache = ref<Partial<Record<MarketKlinePeriod, MarketKlineBar[]>>>({})
const loading = ref(false)
const error = ref('')

let controller: AbortController | null = null

const tone = computed<'up' | 'down' | 'flat'>(() => {
  if (props.node.changePct > 0.005) return 'up'
  if (props.node.changePct < -0.005) return 'down'
  return 'flat'
})

/** 昨收由涨跌幅反推，与指数分时图共用同一套基准线口径。 */
const base = computed(() =>
  props.node.changePct > -99.9 ? props.node.price / (1 + props.node.changePct / 100) : 0,
)

const bars = computed<MarketKlineBar[]>(() =>
  tab.value === 'intraday' ? [] : (cache.value[tab.value] ?? []),
)

const summary = computed(() => {
  const list = bars.value
  if (list.length < 2) return null

  const first = list[0]!
  const last = list[list.length - 1]!
  let high = Number.NEGATIVE_INFINITY
  let low = Number.POSITIVE_INFINITY
  for (const bar of list) {
    if (bar.high > high) high = bar.high
    if (bar.low < low) low = bar.low
  }

  return {
    range: `${first.at} → ${last.at}`,
    changePct: first.close > 0 ? ((last.close - first.close) / first.close) * 100 : 0,
    high,
    low,
  }
})

function isAbort(cause: unknown): boolean {
  return cause instanceof Error && cause.name === 'AbortError'
}

async function load(period: MarketKlinePeriod): Promise<void> {
  const secid = props.node.secid
  if (!secid || cache.value[period]) return

  controller?.abort()
  const next = new AbortController()
  controller = next
  loading.value = true
  error.value = ''

  try {
    const response = await fetchMarketKline(secid, period, next.signal)
    if (controller !== next) return
    cache.value = { ...cache.value, [period]: response.bars }
  } catch (cause) {
    if (controller !== next || isAbort(cause)) return
    error.value = cause instanceof Error && cause.message ? cause.message : 'K 线加载失败'
  } finally {
    if (controller === next) {
      loading.value = false
      controller = null
    }
  }
}

watch(tab, (value) => {
  if (value !== 'intraday') void load(value)
})

/** 换一只票：清空缓存与图表粒度，避免把上一只的 K 线留在面板里。 */
watch(
  () => props.node.id,
  () => {
    controller?.abort()
    controller = null
    loading.value = false
    error.value = ''
    cache.value = {}
    tab.value = 'intraday'
  },
)

onUnmounted(() => {
  controller?.abort()
})
</script>

<template>
  <section class="stock-kline" aria-label="个股 K 线">
    <header class="stock-kline__head">
      <span class="stock-kline__eyebrow">K 线走势</span>
      <div class="stock-kline__tabs" role="tablist">
        <button
          v-for="item in TAB_ITEMS"
          :key="item.key"
          type="button"
          role="tab"
          class="stock-kline__tab"
          :class="{ 'stock-kline__tab--active': tab === item.key }"
          :aria-selected="tab === item.key"
          @click="tab = item.key"
        >
          {{ item.label }}
        </button>
      </div>
    </header>

    <IndexTrendChart
      v-if="tab === 'intraday'"
      :points="node.spark ?? []"
      :base="base"
      :tone="tone"
      :exchange="node.exchange"
      :axis="node.sparkAxis"
    />

    <template v-else>
      <div v-if="loading" class="stock-kline__state mono">K 线加载中…</div>
      <div v-else-if="error" class="stock-kline__state stock-kline__state--error mono">
        {{ error }}
      </div>
      <CandleChart v-else-if="bars.length" :bars="bars" :period="tab" />
      <div v-else class="stock-kline__state mono">暂无 K 线数据</div>
    </template>

    <footer v-if="summary" class="stock-kline__meta mono">
      <span>{{ summary.range }}</span>
      <span
        class="stock-kline__change"
        :style="{
          color: summary.changePct >= 0 ? '#ff5d73' : '#2ee6a6',
          background: tint(summary.changePct >= 0 ? '#ff5d73' : '#2ee6a6', 0.14),
        }"
      >
        {{ formatPct(summary.changePct) }}
      </span>
      <span>高 {{ formatPrice(summary.high) }} · 低 {{ formatPrice(summary.low) }}</span>
    </footer>
  </section>
</template>

<style scoped>
.stock-kline {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 9px 10px 8px;
  border: 1px solid var(--line-soft);
  border-radius: 12px;
  background: rgba(8, 18, 34, 0.5);
}

.stock-kline__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.stock-kline__eyebrow {
  font-size: 9px;
  font-weight: 600;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: var(--accent-gold);
  opacity: 0.85;
}

.stock-kline__tabs {
  display: inline-flex;
  gap: 2px;
  padding: 2px;
  border: 1px solid var(--line-soft);
  border-radius: 999px;
  background: rgba(6, 12, 24, 0.6);
}

.stock-kline__tab {
  padding: 2px 8px;
  border: 0;
  border-radius: 999px;
  background: transparent;
  font-size: 9.5px;
  letter-spacing: 0.02em;
  color: var(--text-dim);
  cursor: pointer;
  transition:
    color 0.16s ease,
    background 0.16s ease;
}

.stock-kline__tab:hover {
  color: var(--text-strong);
}

.stock-kline__tab--active {
  background: rgba(242, 194, 92, 0.16);
  color: var(--accent-gold);
}

.stock-kline__state {
  display: grid;
  place-items: center;
  height: 178px;
  border: 1px dashed var(--line-soft);
  border-radius: 8px;
  font-size: 10px;
  color: var(--text-dim);
}

.stock-kline__state--error {
  color: #ff8a9a;
}

.stock-kline__meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  font-size: 8.5px;
  color: var(--text-dim);
  white-space: nowrap;
}

.stock-kline__change {
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 9px;
  font-weight: 600;
}
</style>

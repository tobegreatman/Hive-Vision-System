import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'

import IndexTrendChart from './IndexTrendChart.vue'

/** 从 SVG path 里取出所有 x 坐标，用于断言曲线画到哪儿为止 */
function xValues(d: string): number[] {
  return [...d.matchAll(/[ML](-?[\d.]+),(-?[\d.]+)/g)].map((match) => Number(match[1]))
}

function mountChart(
  points: number[],
  exchange: 'SH' | 'SZ' | 'BJ' | 'GL' = 'SH',
  axis?: number | null,
) {
  return mount(IndexTrendChart, {
    props: { points, base: 3200, tone: 'up', exchange, axis },
  })
}

describe('IndexTrendChart 时间轴', () => {
  it('盘中只画到当前分钟，不把已有数据拉伸成走完全天', () => {
    // 10:30 前后 ≈ 全天第 60 分钟，上游只回来 60 个点
    const points = Array.from({ length: 60 }, (_, index) => 3200 + index)
    const wrapper = mountChart(points)

    const line = wrapper.find('.index-trend__line').attributes('d') ?? ''
    const xs = xValues(line)
    expect(xs).toHaveLength(60)
    // 最后一个点落在 59/240 ≈ 24.58%，不是 100%
    expect(Math.max(...xs)).toBeCloseTo((59 / 240) * 100, 1)
  })

  it('面积同样收在当前点，不铺到右边缘', () => {
    const points = Array.from({ length: 60 }, (_, index) => 3200 + index)
    const wrapper = mountChart(points)

    const area = wrapper.find('.index-trend__area').attributes('d') ?? ''
    // 面积路径末尾有回落到基线的直角，但最右端仍应停在第 60 分钟
    expect(Math.max(...xValues(area))).toBeCloseTo((59 / 240) * 100, 1)
  })

  it('收盘后 240 个点铺满整个交易时段', () => {
    const points = Array.from({ length: 240 }, (_, index) => 3200 + index)
    const wrapper = mountChart(points)

    const xs = xValues(wrapper.find('.index-trend__line').attributes('d') ?? '')
    expect(Math.max(...xs)).toBeCloseTo((239 / 240) * 100, 1)
  })

  it('中途缺行不会把后面的点挤到左边', () => {
    // 第 20 个点缺失，第 119 个点（11:29 前后）仍应落在全天一半附近
    const points = Array.from({ length: 120 }, (_, index) => 3200 + index)
    points[20] = Number.NaN

    const xs = xValues(mountChart(points).find('.index-trend__line').attributes('d') ?? '')
    expect(xs).toHaveLength(119)
    expect(Math.max(...xs)).toBeCloseTo((119 / 240) * 100, 1)
  })

  it('端点落在曲线终点上，不贴在右边缘', () => {
    const points = Array.from({ length: 60 }, (_, index) => 3200 + index)
    const dot = mountChart(points).find('.index-trend__dot')

    expect(dot.attributes('style')).toContain(`left: ${((59 / 240) * 100).toFixed(2)}%`)
  })

  it('全球指数拿不到交易时段，仍按已有点数铺满', () => {
    const points = Array.from({ length: 60 }, (_, index) => 3200 + index)
    const xs = xValues(
      mountChart(points, 'GL').find('.index-trend__line').attributes('d') ?? '',
    )
    expect(Math.max(...xs)).toBeCloseTo(100, 1)
  })

  it('未走完的时间段铺极淡底纹，收盘后不再出现', () => {
    const intraday = mountChart(Array.from({ length: 60 }, (_, index) => 3200 + index))
    const pending = intraday.find('.index-trend__pending')
    expect(pending.exists()).toBe(true)
    expect(Number(pending.attributes('x'))).toBeCloseTo((59 / 240) * 100, 1)
    expect(Number(pending.attributes('width'))).toBeCloseTo(100 - (59 / 240) * 100, 1)

    // 收盘形态：09:30–15:00 共 242 点，末点落在 15:00 并被夹到 100%，底纹宽度归零
    const closed = mountChart(Array.from({ length: 242 }, (_, index) => 3200 + index))
    expect(closed.find('.index-trend__pending').exists()).toBe(false)
  })

  it('服务端给出轴长时以它为准：板块指数被归到 GL 也能停在正确位置', () => {
    // 证券Ⅱ（90.BK0473）在节点上 exchange 是 GL，但服务端给 sparkAxis=240
    const points = Array.from({ length: 60 }, (_, index) => 3200 + index)
    const xs = xValues(
      mountChart(points, 'GL', 240).find('.index-trend__line').attributes('d') ?? '',
    )
    expect(Math.max(...xs)).toBeCloseTo((59 / 240) * 100, 1)
  })
})

<script setup lang="ts">
import type { MarketExchange } from '@platform/contracts'
import { computed } from 'vue'

import { formatPrice } from '@/shared/lib/format'
import { sparkAxisMinutes } from '@/shared/lib/trading-session'

const props = defineProps<{
  /** 当日分钟收盘序列 */
  points: number[]
  /** 昨收，用于画横向基准线 */
  base: number
  tone: 'up' | 'down' | 'flat'
  exchange: MarketExchange
  /** X 轴总长（分钟）；由服务端按 secid 判定，缺省时按 exchange 兜底 */
  axis?: number | null
}>()

const color = computed(() => {
  if (props.tone === 'up') return 'var(--up, #ff5d73)'
  if (props.tone === 'down') return 'var(--down, #2ee6a6)'
  return 'var(--flat, #8ba3c2)'
})

/** 分钟点没有自带时间戳，A 股按固定交易时段标轴；全球指数只知道开盘/收盘 */
const timeLabels = computed(() =>
  props.exchange === 'GL' ? ['开盘', '收盘'] : ['09:30', '11:30 / 13:00', '15:00'],
)

const geometry = computed(() => {
  // 保留原始索引：X 轴按「全天第几分钟」定位，过滤无效值不能把点挤到一起，
  // 否则盘中少几个点就会被重新拉伸成走完全天。
  const valid: { at: number; value: number }[] = []
  props.points.forEach((value, index) => {
    if (Number.isFinite(value) && value > 0) valid.push({ at: index, value })
  })
  const first = valid[0]
  if (first === undefined || valid.length < 2) return null

  const base = props.base > 0 ? props.base : first.value
  const high = Math.max(...valid.map((point) => point.value), base)
  const low = Math.min(...valid.map((point) => point.value), base)
  // 全天一字时 high === low，给一个最小跨度避免除以 0
  const span = high - low || Math.max(high * 0.001, 1)
  const toY = (value: number): number => 2 + (1 - (value - low) / span) * 96

  // 分母是全天分钟数而不是点数：盘中只画到当前分钟，右侧留白表示尚未走完
  const axis = sparkAxisMinutes(props.exchange, valid.length, props.axis)
  const xAt = (at: number): number => Math.min(100, (at / axis) * 100)

  let line = ''
  valid.forEach((point, index) => {
    line += `${index === 0 ? 'M' : 'L'}${xAt(point.at).toFixed(2)},${toY(point.value).toFixed(2)} `
  })
  const path = line.trim()
  const last = valid[valid.length - 1]!
  const lastX = xAt(last.at)

  return {
    line: path,
    // 面积也收在当前点，不能拉到 100——否则留白区被填满，看起来仍像走完全天
    area: `${path} L${lastX.toFixed(2)},98 L0,98 Z`,
    baseY: toY(base).toFixed(2),
    lastX: lastX.toFixed(2),
    lastY: toY(last.value).toFixed(2),
    // 未走完的时间段铺一层极淡底纹，让留白看起来是「还没到」而不是「数据缺了」
    pendingWidth: (100 - lastX).toFixed(2),
    high: formatPrice(high),
    low: formatPrice(low),
  }
})
</script>

<template>
  <div class="index-trend">
    <div v-if="geometry" class="index-trend__plot" :style="{ color }">
      <div class="index-trend__canvas">
        <svg
          class="index-trend__svg"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          role="img"
          aria-label="当日分时走势"
        >
          <rect
            v-if="Number(geometry.pendingWidth) > 0"
            class="index-trend__pending"
            :x="geometry.lastX"
            y="0"
            :width="geometry.pendingWidth"
            height="100"
          />
          <line class="index-trend__grid" x1="0" y1="25" x2="100" y2="25" />
          <line class="index-trend__grid" x1="0" y1="50" x2="100" y2="50" />
          <line class="index-trend__grid" x1="0" y1="75" x2="100" y2="75" />
          <line
            class="index-trend__base"
            x1="0"
            :y1="geometry.baseY"
            x2="100"
            :y2="geometry.baseY"
          />
          <path class="index-trend__area" :d="geometry.area" />
          <path class="index-trend__line" :d="geometry.line" />
        </svg>

        <span
          class="index-trend__dot"
          :style="{ left: `${geometry.lastX}%`, top: `${geometry.lastY}%` }"
          aria-hidden="true"
        />
      </div>

      <div class="index-trend__axis">
        <span class="mono">{{ geometry.high }}</span>
        <span class="mono">{{ geometry.low }}</span>
      </div>
    </div>

    <div v-else class="index-trend__empty mono">暂无分时数据</div>

    <div v-if="geometry" class="index-trend__times mono">
      <span v-for="label in timeLabels" :key="label">{{ label }}</span>
    </div>
  </div>
</template>

<style scoped>
.index-trend {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.index-trend__plot {
  position: relative;
  height: 66px;
}

/* 绘图区（含未走完的留白）单独一层，横向让出右侧 54px 价格刻度：
   dot 按百分比定位，必须相对这个盒子算，才能和曲线终点对齐 */
.index-trend__canvas {
  position: absolute;
  inset: 0 54px 0 0;
}

.index-trend__svg {
  width: 100%;
  height: 100%;
  overflow: visible;
}

.index-trend__grid {
  stroke: currentColor;
  stroke-width: 0.7;
  opacity: 0.08;
  vector-effect: non-scaling-stroke;
}

/* 未走完的时间段：中性灰极淡底纹。不用涨跌色——那里还没有数据，不该带方向暗示 */
.index-trend__pending {
  fill: var(--text-dim, #8ba3c2);
  opacity: 0.06;
}

.index-trend__base {
  stroke: currentColor;
  stroke-width: 1;
  stroke-dasharray: 3 4;
  opacity: 0.3;
  vector-effect: non-scaling-stroke;
}

.index-trend__area {
  fill: currentColor;
  opacity: 0.12;
}

.index-trend__line {
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}

.index-trend__dot {
  position: absolute;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: currentColor;
  box-shadow: 0 0 8px currentColor;
  transform: translate(-50%, -50%);
  /* 每分钟新增一个点，端点平滑右移，避免整条线跳一格 */
  transition:
    left 0.35s ease,
    top 0.35s ease;
}

.index-trend__axis {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-left: 6px;
  font-size: 8.5px;
  line-height: 1;
  color: var(--text-dim);
}

.index-trend__times {
  display: flex;
  justify-content: space-between;
  padding-right: 54px;
  font-size: 8.5px;
  line-height: 1;
  color: var(--text-dim);
}

.index-trend__empty {
  display: grid;
  place-items: center;
  height: 95px;
  border: 1px dashed var(--line-soft);
  border-radius: 8px;
  font-size: 10px;
  color: var(--text-dim);
}

@media (max-width: 860px) {
  .index-trend__plot,
  .index-trend__empty {
    height: 75px;
  }
}
</style>

import type { MarketKlineBar } from '@platform/contracts'
import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'

import CandleChart from './CandleChart.vue'

function makeBars(count: number): MarketKlineBar[] {
  return Array.from({ length: count }, (_, index) => {
    const at = new Date(Date.UTC(2025, 0, 1 + index)).toISOString().slice(0, 10)
    const close = 10 + index * 0.1
    return {
      at,
      open: close - 0.2,
      close,
      high: close + 0.4,
      low: close - 0.5,
      volume: 1000,
      amount: 1_000_000,
      changePct: 1,
    }
  })
}

function axisLabels(wrapper: ReturnType<typeof mount>): string[] {
  return wrapper.findAll('.candle__axis').map((node) => node.text())
}

/** 25 年只有 250 个交易日，MM-DD 不会重复，可以反查下标 */
function labelIndex(bars: MarketKlineBar[], label: string): number {
  return bars.findIndex((bar) => bar.at.slice(5) === label)
}

describe('CandleChart 拖拽平移', () => {
  it('默认停在最新一段，一屏只渲染视口内的蜡烛', () => {
    const bars = makeBars(250)
    const wrapper = mount(CandleChart, { props: { bars, period: 'day' } })

    const labels = axisLabels(wrapper)
    expect(labels[2]).toBe(bars[bars.length - 1]!.at.slice(5))
    expect(labels[0]).not.toBe(bars[0]!.at.slice(5))

    // 250 根全渲染会挤回色块：视口内只应该出现几十根
    const candles = wrapper.findAll('g > rect')
    expect(candles.length).toBeGreaterThan(30)
    expect(candles.length).toBeLessThan(100)
  })

  it('向右拖动后视口移到更早的行情，滚动条同步左移', async () => {
    const bars = makeBars(250)
    const wrapper = mount(CandleChart, { props: { bars, period: 'day' } })
    const svg = wrapper.find('svg')

    const before = labelIndex(bars, axisLabels(wrapper)[0]!)
    const thumbBefore = Number(wrapper.find('.candle__scroll-thumb').attributes('x'))

    await svg.trigger('pointerdown', { clientX: 300, pointerId: 1 })
    await svg.trigger('pointermove', { clientX: 500, pointerId: 1 })
    await svg.trigger('pointerup', { clientX: 500, pointerId: 1 })

    const after = labelIndex(bars, axisLabels(wrapper)[0]!)
    const thumbAfter = Number(wrapper.find('.candle__scroll-thumb').attributes('x'))

    // 拖动 200px：视口应明显左移，但不会跳过整段历史
    expect(before - after).toBeGreaterThan(25)
    expect(before - after).toBeLessThan(45)
    expect(thumbAfter).toBeLessThan(thumbBefore)
    // 最新一根仍在数据里，只是不在屏幕上
    expect(axisLabels(wrapper)[2]).not.toBe(bars[bars.length - 1]!.at.slice(5))
  })

  it('拖过头会夹在最早一根，不会出现空白视口', async () => {
    const bars = makeBars(250)
    const wrapper = mount(CandleChart, { props: { bars, period: 'day' } })
    const svg = wrapper.find('svg')

    await svg.trigger('pointerdown', { clientX: 300, pointerId: 1 })
    await svg.trigger('pointermove', { clientX: 3000, pointerId: 1 })
    await svg.trigger('pointerup', { clientX: 3000, pointerId: 1 })

    expect(axisLabels(wrapper)[0]).toBe(bars[0]!.at.slice(5))
    expect(Number(wrapper.find('.candle__scroll-thumb').attributes('x'))).toBe(42)
  })
})

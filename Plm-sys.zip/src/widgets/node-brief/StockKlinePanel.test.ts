import type { MarketKlineBar, MarketNode } from '@platform/contracts'
import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { fetchMarketKline } from '@/shared/api'

import CandleChart from './CandleChart.vue'
import IndexTrendChart from './IndexTrendChart.vue'
import StockKlinePanel from './StockKlinePanel.vue'

vi.mock('@/shared/api', () => ({
  fetchMarketKline: vi.fn(),
}))

const node: MarketNode = {
  id: '0b1e6b1e-5c1a-5f2d-9a44-1b7f20a0d1c2',
  symbol: '600519',
  exchange: 'SH',
  name: '贵州茅台',
  kind: 'stock',
  board: 'main',
  price: 1402.3,
  changePct: -2.55,
  amplitude: 2.4,
  turnoverRate: 0.37,
  volumeRatio: 0.92,
  turnover: 67.5,
  marketCap: 17612.4,
  mainNetInflow: -2.3,
  heat: 0.62,
  tags: [],
  secid: '1.600519',
  custom: true,
  spark: [1400, 1405, 1402.3],
  sparkAxis: 240,
  createdAt: '2026-11-12T01:30:00.000Z',
  updatedAt: '2026-11-12T05:30:00.000Z',
}

function bar(at: string, close: number): MarketKlineBar {
  return {
    at,
    open: close - 2,
    close,
    high: close + 3,
    low: close - 4,
    volume: 1000,
    amount: 1_400_000,
    changePct: 1,
  }
}

describe('StockKlinePanel', () => {
  beforeEach(() => {
    vi.mocked(fetchMarketKline).mockReset()
  })

  it('默认展示分时，直接复用节点自带的当日分钟序列', () => {
    const wrapper = mount(StockKlinePanel, { props: { node } })

    const trend = wrapper.findComponent(IndexTrendChart)
    expect(trend.exists()).toBe(true)
    expect(trend.props('points')).toEqual(node.spark)
    expect(trend.props('tone')).toBe('down')
    expect(wrapper.findComponent(CandleChart).exists()).toBe(false)
  })

  it('切到日 K 时按 secid 取数并渲染蜡烛图', async () => {
    vi.mocked(fetchMarketKline).mockResolvedValue({
      secid: '1.600519',
      period: 'day',
      bars: [bar('2026-11-10', 1400), bar('2026-11-11', 1402.3)],
      asOf: '2026-11-12T05:30:00.000Z',
    })

    const wrapper = mount(StockKlinePanel, { props: { node } })
    const dayTab = wrapper.findAll('button[role="tab"]').find((item) => item.text() === '日K')
    expect(dayTab).toBeDefined()

    await dayTab!.trigger('click')
    await flushPromises()

    expect(fetchMarketKline).toHaveBeenCalledWith('1.600519', 'day', expect.any(AbortSignal))
    expect(wrapper.findComponent(CandleChart).exists()).toBe(true)
    expect(wrapper.findAllComponents(CandleChart)[0]!.props('bars')).toHaveLength(2)
    expect(wrapper.text()).toContain('2026-11-10 → 2026-11-11')
  })

  it('粒度数据只取一次，来回切换不重复打上游', async () => {
    vi.mocked(fetchMarketKline).mockResolvedValue({
      secid: '1.600519',
      period: 'week',
      bars: [bar('2026-11-06', 1398), bar('2026-11-13', 1402.3)],
      asOf: '2026-11-12T05:30:00.000Z',
    })

    const wrapper = mount(StockKlinePanel, { props: { node } })
    const tabs = wrapper.findAll('button[role="tab"]')
    const weekTab = tabs.find((item) => item.text() === '周K')!
    const intradayTab = tabs.find((item) => item.text() === '分时')!

    await weekTab.trigger('click')
    await flushPromises()
    await intradayTab.trigger('click')
    await weekTab.trigger('click')
    await flushPromises()

    expect(fetchMarketKline).toHaveBeenCalledTimes(1)
  })

  it('上游失败时在面板内提示，不把整个详情打空', async () => {
    vi.mocked(fetchMarketKline).mockRejectedValue(new Error('K 线暂不可用，请稍后重试'))

    const wrapper = mount(StockKlinePanel, { props: { node } })
    const monthTab = wrapper.findAll('button[role="tab"]').find((item) => item.text() === '月K')!

    await monthTab.trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('K 线暂不可用，请稍后重试')
  })
})

<script setup lang="ts">
import type { MarketIndex, MarketIndexCandidate } from '@platform/contracts'
import { storeToRefs } from 'pinia'
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'

import { tint, useMarketStore } from '@/entities/market-node'
import {
  addMarketIndex,
  fetchMarketIndices,
  removeMarketIndex,
  searchMarketIndices,
} from '@/shared/api'
import { formatPct, formatPrice } from '@/shared/lib/format'

interface IndexRow {
  secid: string
  name: string
  price: number
  changePct: number
  removable: boolean
}

interface IndexPreset {
  secid: string
  name: string
}

/** 常用指数快捷入口；想加别的直接搜，不受这张表限制。 */
const PRESETS: IndexPreset[] = [
  { secid: '100.KS11', name: '韩国KOSPI' },
  { secid: '100.HSI', name: '恒生指数' },
  { secid: '100.N225', name: '日经225' },
  { secid: '90.BK0473', name: '证券Ⅱ' },
  { secid: '0.399975', name: '证券公司' },
  { secid: '1.000300', name: '沪深300' },
  { secid: '1.000688', name: '科创50' },
  { secid: '100.NDX', name: '纳斯达克' },
]

const POLL_INTERVAL_MS = 15_000
const TONE_COLOR = { up: '#ff5d73', down: '#2ee6a6', flat: '#8ba3c2' } as const

const store = useMarketStore()
const { indices } = storeToRefs(store)

const items = ref<IndexRow[]>([])
const loaded = ref(false)
const pickerOpen = ref(false)
const query = ref('')
const candidates = ref<MarketIndexCandidate[]>([])
const searching = ref(false)
const busy = ref(false)
const notice = ref('')
const searchInput = ref<HTMLInputElement | null>(null)

/** 后端不可用时退回 store 里的三大指数，保证面板不空。 */
const fallbackRows = computed<IndexRow[]>(() =>
  indices.value.map((node) => ({
    secid: `${node.exchange === 'SH' ? 1 : 0}.${node.symbol}`,
    name: node.name,
    price: node.price,
    changePct: node.changePct,
    removable: false,
  })),
)

const rows = computed(() => (loaded.value ? items.value : fallbackRows.value))
const watched = computed(() => new Set(items.value.map((item) => item.secid)))

function toneOf(changePct: number): 'up' | 'down' | 'flat' {
  if (changePct > 0.005) return 'up'
  if (changePct < -0.005) return 'down'
  return 'flat'
}

function colorOf(changePct: number): string {
  return TONE_COLOR[toneOf(changePct)]
}

function toRow(item: MarketIndex): IndexRow {
  return {
    secid: item.secid,
    name: item.name,
    price: item.price,
    changePct: item.changePct,
    removable: true,
  }
}

function isAbort(error: unknown): boolean {
  return error instanceof Error && error.name === 'AbortError'
}

function describeError(error: unknown, fallback: string): string {
  return error instanceof Error && error.message ? error.message : fallback
}

const lifecycle = new AbortController()
let pollTimer: ReturnType<typeof setInterval> | null = null
let searchTimer: ReturnType<typeof setTimeout> | null = null
let searchController: AbortController | null = null

async function refresh(): Promise<void> {
  try {
    const response = await fetchMarketIndices(lifecycle.signal)
    items.value = response.items.map(toRow)
    loaded.value = true
    notice.value = ''
  } catch (error) {
    if (isAbort(error)) return
    // 首屏失败保留兜底；已有数据时只提示，不清空已有指数
    if (loaded.value) notice.value = '指数行情刷新失败'
  }
}

async function runSearch(keyword: string): Promise<void> {
  searchController?.abort()
  const controller = new AbortController()
  searchController = controller
  searching.value = true

  try {
    const response = await searchMarketIndices(keyword, controller.signal)
    if (searchController !== controller) return
    candidates.value = response.items
    notice.value = ''
  } catch (error) {
    if (isAbort(error) || searchController !== controller) return
    candidates.value = []
    notice.value = describeError(error, '搜索暂不可用')
  } finally {
    if (searchController === controller) {
      searching.value = false
      searchController = null
    }
  }
}

async function onAdd(secid: string, name?: string): Promise<void> {
  if (busy.value || watched.value.has(secid)) return

  busy.value = true
  notice.value = ''
  try {
    await addMarketIndex(name ? { secid, name } : { secid })
    await refresh()
    query.value = ''
    candidates.value = []
  } catch (error) {
    notice.value = describeError(error, '添加失败')
  } finally {
    busy.value = false
  }
}

async function onRemove(secid: string): Promise<void> {
  if (busy.value) return

  busy.value = true
  notice.value = ''
  try {
    await removeMarketIndex(secid)
    await refresh()
  } catch (error) {
    notice.value = describeError(error, '移除失败')
  } finally {
    busy.value = false
  }
}

watch(query, (value) => {
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()

  const keyword = value.trim()
  if (!keyword) {
    candidates.value = []
    searching.value = false
    return
  }

  searching.value = true
  searchTimer = setTimeout(() => void runSearch(keyword), 260)
})

watch(pickerOpen, async (open) => {
  if (!open) {
    query.value = ''
    candidates.value = []
    notice.value = ''
    return
  }
  await nextTick()
  searchInput.value?.focus()
})

onMounted(() => {
  void refresh()
  pollTimer = setInterval(() => {
    if (document.visibilityState === 'visible') void refresh()
  }, POLL_INTERVAL_MS)
})

onUnmounted(() => {
  lifecycle.abort()
  if (pollTimer) clearInterval(pollTimer)
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()
})
</script>

<template>
  <div class="index-strip" role="list" aria-label="大盘指数">
    <button
      type="button"
      class="index-strip__add"
      :aria-expanded="pickerOpen"
      @click="pickerOpen = !pickerOpen"
    >
      {{ pickerOpen ? '收起' : '+ 添加指数' }}
    </button>

    <div v-if="pickerOpen" class="index-picker">
      <input
        ref="searchInput"
        v-model="query"
        class="text-input index-picker__input"
        type="search"
        maxlength="24"
        placeholder="搜索指数 / 板块"
      />

      <div v-if="searching" class="index-picker__note">搜索中…</div>

      <ul v-else-if="candidates.length" class="index-picker__list">
        <li v-for="candidate in candidates" :key="candidate.secid">
          <button
            type="button"
            class="index-picker__item"
            :disabled="busy || watched.has(candidate.secid)"
            @click="onAdd(candidate.secid, candidate.name)"
          >
            <span class="index-picker__item-main">
              <span class="index-picker__item-name">{{ candidate.name }}</span>
              <span class="index-picker__item-meta mono">
                {{ candidate.code }} · {{ candidate.typeLabel }}
              </span>
            </span>
            <span class="index-picker__item-state mono">
              {{ watched.has(candidate.secid) ? '已添加' : '+' }}
            </span>
          </button>
        </li>
      </ul>

      <div v-else-if="query.trim()" class="index-picker__note">没有匹配的指数或板块</div>

      <div v-else class="index-picker__presets">
        <button
          v-for="preset in PRESETS"
          :key="preset.secid"
          type="button"
          class="index-picker__preset"
          :disabled="busy || watched.has(preset.secid)"
          @click="onAdd(preset.secid, preset.name)"
        >
          {{ preset.name }}
        </button>
      </div>

      <p v-if="notice" class="index-picker__notice">{{ notice }}</p>
    </div>

    <p v-else-if="notice" class="index-strip__notice">{{ notice }}</p>

    <div v-for="row in rows" :key="row.secid" class="index-row" role="listitem">
      <div class="index-row__top">
        <span class="index-row__label">
          <span
            class="index-row__mark"
            :style="{ background: colorOf(row.changePct) }"
            aria-hidden="true"
          />
          <span class="index-row__name" :title="row.name">{{ row.name }}</span>
        </span>
        <span class="index-row__price mono">{{ formatPrice(row.price) }}</span>
        <span
          class="index-row__pct mono"
          :style="{
            color: colorOf(row.changePct),
            background: tint(colorOf(row.changePct), 0.14),
          }"
        >
          {{ formatPct(row.changePct) }}
        </span>
        <button
          v-if="row.removable"
          type="button"
          class="index-row__remove"
          title="移除该指数"
          :disabled="busy"
          @click.stop="onRemove(row.secid)"
        >
          ×
        </button>
      </div>
    </div>

    <p v-if="loaded && rows.length === 0" class="index-strip__empty">暂无指数，可搜索添加</p>
  </div>
</template>

<style scoped>
.index-strip {
  display: flex;
  flex-direction: column;
  gap: 2px;
  pointer-events: auto;
}

.index-row {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 3px;
  padding: 5px 6px;
  border: 1px solid transparent;
  border-radius: 10px;
  transition:
    background 0.16s ease,
    border-color 0.16s ease;
}

.index-row:hover {
  background: rgba(15, 23, 42, 0.04);
}

.index-row__top {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 6px;
  padding-right: 10px;
}

.index-row__label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.index-row__mark {
  width: 6px;
  height: 6px;
  flex: none;
  clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}

.index-row__name {
  overflow: hidden;
  font-size: 11px;
  letter-spacing: 0.02em;
  color: var(--text-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.index-row__price {
  font-size: 11px;
  color: var(--text);
}

.index-row__pct {
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
  white-space: nowrap;
}

.index-row__remove {
  position: absolute;
  top: 1px;
  right: 0;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--text-dim);
  font-size: 12px;
  line-height: 12px;
  cursor: pointer;
  opacity: 0;
  transition:
    opacity 0.16s ease,
    color 0.16s ease;
}

.index-row:hover .index-row__remove,
.index-row__remove:focus-visible {
  opacity: 1;
}

.index-row__remove:hover {
  color: var(--up);
}

.index-strip__empty,
.index-strip__notice {
  margin: 2px 4px;
  font-size: 10px;
  color: var(--text-dim);
}

.index-strip__notice {
  color: var(--up);
}

.index-strip__add {
  margin-bottom: 2px;
  padding: 4px 8px;
  border: 1px dashed rgba(120, 170, 220, 0.3);
  border-radius: 8px;
  background: transparent;
  color: var(--text-dim);
  font-size: 10.5px;
  letter-spacing: 0.04em;
  cursor: pointer;
  transition:
    color 0.16s ease,
    border-color 0.16s ease,
    background 0.16s ease;
}

.index-strip__add:hover {
  color: var(--accent-gold);
  border-color: rgba(242, 194, 92, 0.5);
  background: rgba(242, 194, 92, 0.06);
}

.index-picker {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 4px;
  padding: 8px;
  border: 1px solid rgba(120, 170, 220, 0.22);
  border-radius: 10px;
  background: rgba(8, 18, 34, 0.92);
  box-shadow: 0 16px 32px -22px rgba(0, 0, 0, 0.9);
}

.index-picker__input {
  width: 100%;
  height: 26px;
  padding: 0 8px;
  font-size: 11px;
}

.index-picker__note {
  font-size: 10px;
  color: var(--text-dim);
}

.index-picker__presets {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.index-picker__preset {
  padding: 3px 7px;
  border: 1px solid rgba(120, 170, 220, 0.22);
  border-radius: 6px;
  background: rgba(96, 196, 255, 0.06);
  color: var(--text-muted);
  font-size: 10px;
  cursor: pointer;
  transition:
    color 0.16s ease,
    border-color 0.16s ease,
    background 0.16s ease;
}

.index-picker__preset:hover:not(:disabled) {
  color: var(--text-strong);
  border-color: rgba(96, 196, 255, 0.5);
  background: rgba(96, 196, 255, 0.14);
}

.index-picker__preset:disabled {
  opacity: 0.42;
  cursor: default;
}

.index-picker__list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 180px;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  list-style: none;
}

.index-picker__item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  padding: 5px 6px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  text-align: left;
  cursor: pointer;
}

.index-picker__item:hover:not(:disabled) {
  background: rgba(96, 196, 255, 0.12);
}

.index-picker__item:disabled {
  opacity: 0.5;
  cursor: default;
}

.index-picker__item-main {
  display: flex;
  flex-direction: column;
  gap: 1px;
  min-width: 0;
}

.index-picker__item-name {
  overflow: hidden;
  font-size: 11px;
  color: var(--text-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.index-picker__item-meta {
  font-size: 9px;
  color: var(--text-dim);
}

.index-picker__item-state {
  flex: none;
  font-size: 10px;
  color: var(--accent-gold);
}

.index-picker__notice {
  margin: 0;
  font-size: 10px;
  line-height: 1.5;
  color: var(--up);
}
</style>

<script setup lang="ts">
import type { MarketStock, MarketStockCandidate } from '@platform/contracts'
import { storeToRefs } from 'pinia'
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'

import { tint, useMarketStore } from '@/entities/market-node'
import { useHiveNavigation } from '@/features/navigate-hive/use-hive-navigation'
import {
  addMarketStock,
  fetchMarketStocks,
  removeMarketStock,
  searchMarketStocks,
} from '@/shared/api'
import { formatPct, formatPrice } from '@/shared/lib/format'

const POLL_INTERVAL_MS = 15_000
const TONE_COLOR = { up: '#ff5d73', down: '#2ee6a6', flat: '#8ba3c2' } as const

const store = useMarketStore()
const { selectedId } = storeToRefs(store)
const { openNode } = useHiveNavigation()

const items = ref<MarketStock[]>([])
const loaded = ref(false)
const pickerOpen = ref(false)
const query = ref('')
const candidates = ref<MarketStockCandidate[]>([])
const searching = ref(false)
const busy = ref(false)
const notice = ref('')
const searchInput = ref<HTMLInputElement | null>(null)

const watched = computed(() => new Set(items.value.map((item) => item.secid)))

function toneOf(changePct: number): 'up' | 'down' | 'flat' {
  if (changePct > 0.005) return 'up'
  if (changePct < -0.005) return 'down'
  return 'flat'
}

function colorOf(changePct: number): string {
  return TONE_COLOR[toneOf(changePct)]
}

/** 待行情的行不参与涨跌着色，避免 0.00% 被误读成平盘。 */
function rowColor(item: MarketStock): string {
  if (item.price <= 0 || item.quoteStatus === 'pending') return TONE_COLOR.flat
  return colorOf(item.changePct)
}

function priceText(item: MarketStock): string {
  return item.price > 0 ? formatPrice(item.price) : '—'
}

function pctText(item: MarketStock): string {
  if (item.quoteStatus === 'pending' && item.price <= 0) return '待行情'
  return formatPct(item.changePct)
}

function isAbort(error: unknown): boolean {
  return error instanceof Error && error.name === 'AbortError'
}

function describeError(error: unknown, fallback: string): string {
  return error instanceof Error && error.message ? error.message : fallback
}

const lifecycle = new AbortController()
let pollTimer: ReturnType<typeof setInterval> | null = null
let searchTimer: ReturnType<typeof setTimeout> | null = null
let searchController: AbortController | null = null

async function refresh(): Promise<void> {
  try {
    const response = await fetchMarketStocks(lifecycle.signal)
    items.value = response.items
    loaded.value = true
    notice.value = ''
  } catch (error) {
    if (isAbort(error)) return
    // 已有数据时只提示，不把列表清空
    if (loaded.value) notice.value = '自选股行情刷新失败'
  }
}

async function runSearch(keyword: string): Promise<void> {
  searchController?.abort()
  const controller = new AbortController()
  searchController = controller
  searching.value = true

  try {
    const response = await searchMarketStocks(keyword, controller.signal)
    if (searchController !== controller) return
    candidates.value = response.items
    notice.value = ''
  } catch (error) {
    if (isAbort(error) || searchController !== controller) return
    candidates.value = []
    notice.value = describeError(error, '搜索暂不可用')
  } finally {
    if (searchController === controller) {
      searching.value = false
      searchController = null
    }
  }
}

async function onAdd(secid: string, name?: string): Promise<void> {
  if (busy.value || watched.value.has(secid)) return

  busy.value = true
  notice.value = ''
  try {
    await addMarketStock(name ? { secid, name } : { secid })
    await refresh()
    // 蜂巢节点与板块聚合走另一条轮询：静默补一帧，避免新加的票要等 10s 才出现在盘面
    void store.load(undefined, { silent: true })
    query.value = ''
    candidates.value = []
  } catch (error) {
    notice.value = describeError(error, '添加失败')
  } finally {
    busy.value = false
  }
}

async function onRemove(secid: string): Promise<void> {
  if (busy.value) return

  busy.value = true
  notice.value = ''
  try {
    await removeMarketStock(secid)
    await refresh()
    void store.load(undefined, { silent: true })
  } catch (error) {
    notice.value = describeError(error, '移除失败')
  } finally {
    busy.value = false
  }
}

function onOpen(item: MarketStock): void {
  if (item.price <= 0) {
    notice.value = '实时行情恢复后才能查看该股详情'
    return
  }
  openNode('custom', item.nodeId)
}

watch(query, (value) => {
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()

  const keyword = value.trim()
  if (!keyword) {
    candidates.value = []
    searching.value = false
    return
  }

  searching.value = true
  searchTimer = setTimeout(() => void runSearch(keyword), 260)
})

watch(pickerOpen, async (open) => {
  if (!open) {
    query.value = ''
    candidates.value = []
    notice.value = ''
    return
  }
  await nextTick()
  searchInput.value?.focus()
})

onMounted(() => {
  void refresh()
  pollTimer = setInterval(() => {
    if (document.visibilityState === 'visible') void refresh()
  }, POLL_INTERVAL_MS)
})

onUnmounted(() => {
  lifecycle.abort()
  if (pollTimer) clearInterval(pollTimer)
  if (searchTimer) clearTimeout(searchTimer)
  searchController?.abort()
})
</script>

<template>
  <div class="stock-strip" role="list" aria-label="自定义板块个股">
    <button
      type="button"
      class="stock-strip__add"
      :aria-expanded="pickerOpen"
      @click="pickerOpen = !pickerOpen"
    >
      {{ pickerOpen ? '收起' : '+ 添加个股' }}
    </button>

    <div v-if="pickerOpen" class="stock-picker">
      <input
        ref="searchInput"
        v-model="query"
        class="text-input stock-picker__input"
        type="search"
        maxlength="24"
        placeholder="搜索个股代码 / 名称"
      />

      <div v-if="searching" class="stock-picker__note">搜索中…</div>

      <ul v-else-if="candidates.length" class="stock-picker__list">
        <li v-for="candidate in candidates" :key="candidate.secid">
          <button
            type="button"
            class="stock-picker__item"
            :disabled="busy || watched.has(candidate.secid)"
            @click="onAdd(candidate.secid, candidate.name)"
          >
            <span class="stock-picker__item-main">
              <span class="stock-picker__item-name">{{ candidate.name }}</span>
              <span class="stock-picker__item-meta mono">
                {{ candidate.code }} · {{ candidate.typeLabel }}
              </span>
            </span>
            <span class="stock-picker__item-state mono">
              {{ watched.has(candidate.secid) ? '已添加' : '+' }}
            </span>
          </button>
        </li>
      </ul>

      <div v-else-if="query.trim()" class="stock-picker__note">没有匹配的个股</div>
      <div v-else class="stock-picker__note">输入 6 位代码或证券简称，选中后加入自定义板块</div>

      <p v-if="notice" class="stock-picker__notice">{{ notice }}</p>
    </div>

    <p v-else-if="notice" class="stock-strip__notice">{{ notice }}</p>

    <div v-for="item in items" :key="item.secid" class="stock-row" role="listitem">
      <button
        type="button"
        class="stock-row__main"
        :class="{ 'stock-row__main--active': item.nodeId === selectedId }"
        :title="item.price > 0 ? `查看 ${item.name} 的 K 线` : '实时行情恢复后可查看'"
        @click="onOpen(item)"
      >
        <span class="stock-row__label">
          <span
            class="stock-row__mark"
            :style="{ background: colorOf(item.changePct) }"
            aria-hidden="true"
          />
          <span class="stock-row__name">{{ item.name }}</span>
          <span v-if="item.quoteStatus === 'pending'" class="stock-row__badge">延时</span>
        </span>
        <span class="stock-row__price mono">{{ priceText(item) }}</span>
        <span
          class="stock-row__pct mono"
          :style="{
            color: rowColor(item),
            background: tint(rowColor(item), 0.14),
          }"
        >
          {{ pctText(item) }}
        </span>
      </button>
      <button
        type="button"
        class="stock-row__remove"
        title="从自定义板块移除"
        :disabled="busy"
        @click.stop="onRemove(item.secid)"
      >
        ×
      </button>
    </div>

    <p v-if="loaded && items.length === 0" class="stock-strip__empty">
      自选池为空，搜索个股加入后即可查看分时与 K 线
    </p>
  </div>
</template>

<style scoped>
.stock-strip {
  display: flex;
  flex-direction: column;
  gap: 2px;
  pointer-events: auto;
}

.stock-row {
  position: relative;
  display: flex;
  align-items: stretch;
}

.stock-row__main {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding: 5px 16px 5px 6px;
  border: 1px solid transparent;
  border-radius: 10px;
  background: transparent;
  text-align: left;
  cursor: pointer;
  transition:
    background 0.16s ease,
    border-color 0.16s ease;
}

.stock-row__main:hover {
  background: rgba(96, 196, 255, 0.08);
}

.stock-row__main--active {
  border-color: rgba(242, 194, 92, 0.32);
  background: rgba(242, 194, 92, 0.1);
}

.stock-row__label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.stock-row__mark {
  width: 6px;
  height: 6px;
  flex: none;
  clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}

.stock-row__name {
  overflow: hidden;
  font-size: 11px;
  letter-spacing: 0.02em;
  color: var(--text-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.stock-row__badge {
  flex: none;
  padding: 0 3px;
  border: 1px solid rgba(139, 163, 194, 0.35);
  border-radius: 3px;
  font-size: 8px;
  line-height: 12px;
  color: var(--text-dim);
}

.stock-row__price {
  font-size: 11px;
  color: var(--text);
}

.stock-row__pct {
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
  white-space: nowrap;
}

.stock-row__remove {
  position: absolute;
  top: 1px;
  right: 0;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--text-dim);
  font-size: 12px;
  line-height: 12px;
  cursor: pointer;
  opacity: 0;
  transition:
    opacity 0.16s ease,
    color 0.16s ease;
}

.stock-row:hover .stock-row__remove,
.stock-row__remove:focus-visible {
  opacity: 1;
}

.stock-row__remove:hover {
  color: var(--up);
}

.stock-strip__empty,
.stock-strip__notice {
  margin: 2px 4px;
  font-size: 10px;
  line-height: 1.5;
  color: var(--text-dim);
}

.stock-strip__notice {
  color: var(--up);
}

.stock-strip__add {
  margin-bottom: 2px;
  padding: 4px 8px;
  border: 1px dashed rgba(120, 170, 220, 0.3);
  border-radius: 8px;
  background: transparent;
  color: var(--text-dim);
  font-size: 10.5px;
  letter-spacing: 0.04em;
  cursor: pointer;
  transition:
    color 0.16s ease,
    border-color 0.16s ease,
    background 0.16s ease;
}

.stock-strip__add:hover {
  color: var(--accent-gold);
  border-color: rgba(242, 194, 92, 0.5);
  background: rgba(242, 194, 92, 0.06);
}

.stock-picker {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 4px;
  padding: 8px;
  border: 1px solid rgba(120, 170, 220, 0.22);
  border-radius: 10px;
  background: rgba(8, 18, 34, 0.92);
  box-shadow: 0 16px 32px -22px rgba(0, 0, 0, 0.9);
}

.stock-picker__input {
  width: 100%;
  height: 26px;
  padding: 0 8px;
  font-size: 11px;
}

.stock-picker__note {
  font-size: 10px;
  line-height: 1.5;
  color: var(--text-dim);
}

.stock-picker__list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 180px;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  list-style: none;
}

.stock-picker__item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  padding: 5px 6px;
  border: 0;
  border-radius: 6px;
  background: transparent;
  text-align: left;
  cursor: pointer;
}

.stock-picker__item:hover:not(:disabled) {
  background: rgba(96, 196, 255, 0.12);
}

.stock-picker__item:disabled {
  opacity: 0.5;
  cursor: default;
}

.stock-picker__item-main {
  display: flex;
  flex-direction: column;
  gap: 1px;
  min-width: 0;
}

.stock-picker__item-name {
  overflow: hidden;
  font-size: 11px;
  color: var(--text-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}

.stock-picker__item-meta {
  font-size: 9px;
  color: var(--text-dim);
}

.stock-picker__item-state {
  flex: none;
  font-size: 10px;
  color: var(--accent-gold);
}

.stock-picker__notice {
  margin: 0;
  font-size: 10px;
  line-height: 1.5;
  color: var(--up);
}
</style>

import {
  API_ROUTES,
  listMarketIndicesResponseSchema,
  marketIndexResponseSchema,
  removeMarketIndexResponseSchema,
  searchMarketIndicesResponseSchema,
} from '@platform/contracts'
import type {
  AddMarketIndexPayload,
  ListMarketIndicesResponse,
  MarketIndexResponse,
  RemoveMarketIndexResponse,
  SearchMarketIndicesResponse,
} from '@platform/contracts'

import { apiRequest } from './client'

/** 自选指数列表：一次请求拿回全部指数的快照 + 当日分时。 */
export function fetchMarketIndices(signal?: AbortSignal): Promise<ListMarketIndicesResponse> {
  return apiRequest(API_ROUTES.indices, listMarketIndicesResponseSchema, signal ? { signal } : {})
}

/** 搜索指数 / 板块（服务端只保留「指数」「板块」类型）。 */
export function searchMarketIndices(
  query: string,
  signal?: AbortSignal,
): Promise<SearchMarketIndicesResponse> {
  const path = `${API_ROUTES.indexSearch}?q=${encodeURIComponent(query)}`
  return apiRequest(path, searchMarketIndicesResponseSchema, signal ? { signal } : {})
}

export function addMarketIndex(payload: AddMarketIndexPayload): Promise<MarketIndexResponse> {
  return apiRequest(API_ROUTES.indices, marketIndexResponseSchema, {
    method: 'POST',
    body: payload,
  })
}

export function removeMarketIndex(secid: string): Promise<RemoveMarketIndexResponse> {
  return apiRequest(API_ROUTES.index(secid), removeMarketIndexResponseSchema, {
    method: 'DELETE',
  })
}

import { apiErrorSchema } from '@platform/contracts'
import type { z } from 'zod'

import { appEnv } from '../config/env'

export class ApiError extends Error {
  readonly code: string
  readonly status: number
  readonly details: unknown

  constructor(code: string, message: string, status: number, details?: unknown) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.status = status
    this.details = details
  }
}

export interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE'
  body?: unknown
  signal?: AbortSignal
  /** 单次请求超时，默认 15s。没有它，一次挂起的请求会永远占着 UI 的 loading 态。 */
  timeoutMs?: number
}

const DEFAULT_TIMEOUT_MS = 15_000

/**
 * 唯一的网络出口：请求 → 状态码 → Zod 校验 → 强类型返回值。
 * 任何越过 Schema 的响应都会在这里被拦下，而不是在组件里炸开。
 */
export async function apiRequest<T>(
  path: string,
  schema: z.ZodType<T>,
  options: ApiRequestOptions = {},
): Promise<T> {
  const { method = 'GET', body, signal, timeoutMs = DEFAULT_TIMEOUT_MS } = options

  const headers: Record<string, string> = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  // 写接口令牌只在配置后附加：本地回环开发态后端不校验，别发一个空头过去
  if (appEnv.writeToken && method !== 'GET') headers['X-Write-Token'] = appEnv.writeToken

  const controller = new AbortController()
  let timedOut = false
  const timer = setTimeout(() => {
    timedOut = true
    controller.abort()
  }, timeoutMs)
  const forwardAbort = (): void => controller.abort()
  if (signal) {
    if (signal.aborted) controller.abort()
    else signal.addEventListener('abort', forwardAbort, { once: true })
  }

  let response: Response
  try {
    response = await fetch(`${appEnv.apiOrigin}${path}`, {
      method,
      signal: controller.signal,
      headers,
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    })
  } catch (error) {
    if (timedOut) {
      throw new ApiError('timeout', `请求超时（${Math.round(timeoutMs / 1000)}s）`, 0)
    }
    if (error instanceof DOMException && error.name === 'AbortError') throw error
    throw new ApiError('network_error', '无法连接后端服务，请确认 3600 端口是否已启动', 0)
  } finally {
    clearTimeout(timer)
    signal?.removeEventListener('abort', forwardAbort)
  }

  const payload: unknown = await response.json().catch(() => null)

  if (!response.ok) {
    const parsed = apiErrorSchema.safeParse(payload)
    if (parsed.success) {
      throw new ApiError(
        parsed.data.error.code,
        parsed.data.error.message,
        response.status,
        parsed.data.error.details,
      )
    }
    throw new ApiError('http_error', `请求失败（HTTP ${response.status}）`, response.status)
  }

  const parsed = schema.safeParse(payload)
  if (!parsed.success) {
    throw new ApiError(
      'invalid_response',
      '响应结构与共享 Schema 不匹配',
      response.status,
      parsed.error.flatten(),
    )
  }

  return parsed.data
}

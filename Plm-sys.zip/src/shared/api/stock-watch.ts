import {
  API_ROUTES,
  listMarketStocksResponseSchema,
  marketKlineResponseSchema,
  marketStockQuoteResponseSchema,
  marketStockResponseSchema,
  removeMarketStockResponseSchema,
  searchMarketStocksResponseSchema,
} from '@platform/contracts'
import type {
  AddMarketStockPayload,
  ListMarketStocksResponse,
  MarketKlinePeriod,
  MarketKlineResponse,
  MarketStockQuoteResponse,
  MarketStockResponse,
  RemoveMarketStockResponse,
  SearchMarketStocksResponse,
} from '@platform/contracts'

import { apiRequest } from './client'

/** 自定义板块：一次请求拿回自选池全部个股的快照 + 当日分时。 */
export function fetchMarketStocks(signal?: AbortSignal): Promise<ListMarketStocksResponse> {
  return apiRequest(API_ROUTES.stocks, listMarketStocksResponseSchema, signal ? { signal } : {})
}

/** 搜索 A 股（服务端只保留沪深北个股）。 */
export function searchMarketStocks(
  query: string,
  signal?: AbortSignal,
): Promise<SearchMarketStocksResponse> {
  const path = `${API_ROUTES.stockSearch}?q=${encodeURIComponent(query)}`
  return apiRequest(path, searchMarketStocksResponseSchema, signal ? { signal } : {})
}

export function addMarketStock(payload: AddMarketStockPayload): Promise<MarketStockResponse> {
  return apiRequest(API_ROUTES.stocks, marketStockResponseSchema, {
    method: 'POST',
    body: payload,
  })
}

/** 加入自选盘面前的单只个股报价：现价 / 涨跌幅由服务端补齐。 */
export function fetchStockQuote(
  secid: string,
  signal?: AbortSignal,
): Promise<MarketStockQuoteResponse> {
  return apiRequest(
    API_ROUTES.stockQuote(secid),
    marketStockQuoteResponseSchema,
    signal ? { signal } : {},
  )
}

export function removeMarketStock(secid: string): Promise<RemoveMarketStockResponse> {
  return apiRequest(API_ROUTES.stock(secid), removeMarketStockResponseSchema, {
    method: 'DELETE',
  })
}

export function fetchMarketKline(
  secid: string,
  period: MarketKlinePeriod,
  signal?: AbortSignal,
): Promise<MarketKlineResponse> {
  const path = `${API_ROUTES.stockKline(secid)}?period=${period}`
  return apiRequest(path, marketKlineResponseSchema, signal ? { signal } : {})
}

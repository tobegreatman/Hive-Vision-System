import type { MarketExchange } from '@platform/contracts'

/**
 * A 股连续竞价时段：09:30–11:30 + 13:00–15:00，午休折叠后共 240 分钟。
 *
 * 分时图的 X 轴按这个总长固定，曲线只画到「当前已走到的分钟」，右侧留白表示
 * 当天还没走完——否则盘中 10:30 和收盘 15:00 画出来长得一模一样。
 * 折叠午休也正好对上「09:30 / 11:30·13:00 / 15:00」三等分的刻度标签。
 */
export const A_SHARE_SESSION_MINUTES = 240

/**
 * 分时 X 轴分母（单位为分钟槽位），`pointCount` 是上游返回的分钟点数。
 *
 * 优先用服务端给出的 `axis`：它按 secid 的市场号与指数代码判定，能正确覆盖
 * `90.BKxxxx`（字段上是 GL、实际走 A 股时段）以及港股 / 韩国 / 日本 / 美股。
 *
 * 没有 `axis` 时只能兜底：A 股三所按 240 分钟，`GL` 按已有点数铺满——服务端
 * 时段表里没有的海外市场，无法判断「现在走到第几分钟」。
 */
export function sparkAxisMinutes(
  exchange: MarketExchange,
  pointCount: number,
  axis?: number | null,
): number {
  if (typeof axis === 'number' && Number.isFinite(axis) && axis > 0) return axis
  if (exchange === 'GL') return Math.max(1, pointCount - 1)
  return A_SHARE_SESSION_MINUTES
}

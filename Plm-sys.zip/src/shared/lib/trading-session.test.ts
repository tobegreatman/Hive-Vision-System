import { describe, expect, it } from 'vitest'

import { A_SHARE_SESSION_MINUTES, sparkAxisMinutes } from './trading-session'

describe('sparkAxisMinutes', () => {
  it('A 股固定用全天 240 分钟，与点数无关', () => {
    // 盘中 10:30 只回来 60 个点，分母仍是 240——曲线才会停在四分之一处
    expect(sparkAxisMinutes('SH', 60)).toBe(A_SHARE_SESSION_MINUTES)
    expect(sparkAxisMinutes('SZ', 60)).toBe(240)
    expect(sparkAxisMinutes('BJ', 240)).toBe(240)
  })

  it('GL 没有交易时段信息，按已有点数铺满', () => {
    expect(sparkAxisMinutes('GL', 60)).toBe(59)
    expect(sparkAxisMinutes('GL', 2)).toBe(1)
  })

  it('服务端给出的轴长优先于 exchange 推断', () => {
    // 90.BKxxxx 板块在字段上是 GL，但走 A 股时段——只有服务端按 secid 判定得出来
    expect(sparkAxisMinutes('GL', 28, 240)).toBe(240)
    // 海外指数服务端给 null，回到铺满
    expect(sparkAxisMinutes('GL', 28, null)).toBe(27)
    // 非法值不采信，退回兜底
    expect(sparkAxisMinutes('SH', 28, 0)).toBe(240)
    expect(sparkAxisMinutes('SH', 28, Number.NaN)).toBe(240)
  })

  it('GL 只有 1 个点时不会把分母算成 0', () => {
    expect(sparkAxisMinutes('GL', 1)).toBe(1)
    expect(sparkAxisMinutes('GL', 0)).toBe(1)
  })
})

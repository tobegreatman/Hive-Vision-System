function normalizeOrigin(value: string | undefined): string {
  if (!value) return ''
  return value.replace(/\/+$/, '')
}

export const appEnv = {
  /** 生产可指向独立 API 域名；开发态留空走 Vite proxy，避免 CORS 噪声。 */
  apiOrigin: normalizeOrigin(import.meta.env.VITE_API_ORIGIN),
  /**
   * 写接口令牌：与后端 `WRITE_TOKEN` 对应。
   * 后端未配置时（本地回环）留空即可；一旦后端对外开放，这一项必须配上，
   * 否则 POST / PATCH 会被 401 挡回。
   */
  writeToken: (import.meta.env.VITE_WRITE_TOKEN ?? '').trim(),
  isDev: import.meta.env.DEV,
} as const

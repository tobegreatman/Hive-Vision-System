<script setup lang="ts">
import type { MarketNode } from '@platform/contracts'
import { storeToRefs } from 'pinia'
import { computed } from 'vue'

import { symbolLabel, tint, useMarketStore } from '@/entities/market-node'
import { useHiveNavigation } from '@/features/navigate-hive/use-hive-navigation'
import { formatAmount, formatPct, formatPrice } from '@/shared/lib/format'
import { AppButton } from '@/shared/ui'

import IndexTrendChart from './IndexTrendChart.vue'

const props = defineProps<{ node: MarketNode }>()

const store = useMarketStore()
const { selectedNeighbors } = storeToRefs(store)
const { step, clearNode } = useHiveNavigation()

const tone = computed<'up' | 'down' | 'flat'>(() => {
  if (props.node.changePct > 0.005) return 'up'
  if (props.node.changePct < -0.005) return 'down'
  return 'flat'
})

const accent = computed(() => {
  if (tone.value === 'up') return '#ff5d73'
  if (tone.value === 'down') return '#2ee6a6'
  return '#8ba3c2'
})

/** 昨收由涨跌幅反推：节点不再单独携带 preClose，避免多一个跨端字段 */
const base = computed(() =>
  props.node.changePct > -99.9 ? props.node.price / (1 + props.node.changePct / 100) : 0,
)

const change = computed(() => (base.value > 0 ? props.node.price - base.value : 0))
const changeLabel = computed(() => {
  const sign = change.value > 0 ? '+' : change.value < 0 ? '-' : ''
  return `${sign}${formatPrice(Math.abs(change.value))}`
})

const range = computed(() => {
  const values = (props.node.spark ?? []).filter((value) => Number.isFinite(value) && value > 0)
  if (values.length === 0) return { high: props.node.price, low: props.node.price }
  return {
    high: Math.max(...values, props.node.price),
    low: Math.min(...values, props.node.price),
  }
})

const stats = computed(() => [
  { label: '昨收', value: base.value > 0 ? formatPrice(base.value) : '—' },
  { label: '涨跌额', value: changeLabel.value },
  { label: '最高', value: formatPrice(range.value.high) },
  { label: '最低', value: formatPrice(range.value.low) },
  { label: '振幅', value: `${props.node.amplitude.toFixed(2)}%` },
  { label: '成交额', value: formatAmount(props.node.turnover) },
])
</script>

<template>
  <div class="index-brief">
    <header class="index-brief__head">
      <div class="index-brief__title">
        <span class="index-brief__hex" aria-hidden="true" />
        <div>
          <h2 class="index-brief__name">{{ node.name }}</h2>
          <p class="index-brief__code mono">{{ symbolLabel(node) }} · 指数</p>
        </div>
      </div>
      <button type="button" class="index-brief__close" aria-label="取消选中" @click="clearNode">
        ×
      </button>
    </header>

    <div class="index-brief__price">
      <span class="index-brief__value mono" :style="{ color: accent }">
        {{ formatPrice(node.price) }}
      </span>
      <span
        class="index-brief__pct mono"
        :style="{ color: accent, background: tint(accent, 0.16) }"
      >
        {{ formatPct(node.changePct) }}
      </span>
    </div>

    <IndexTrendChart
      :points="node.spark ?? []"
      :base="base"
      :tone="tone"
      :exchange="node.exchange"
    />

    <dl class="index-brief__grid">
      <div v-for="row in stats" :key="row.label">
        <dt>{{ row.label }}</dt>
        <dd class="mono">{{ row.value }}</dd>
      </div>
    </dl>

    <!-- 指数之间也支持键盘 ← → 连续切换 -->
    <div class="index-brief__step">
      <AppButton variant="ghost" size="sm" @click="step(-1)">‹ 上一只</AppButton>
      <AppButton variant="ghost" size="sm" @click="step(1)">下一只 ›</AppButton>
    </div>

    <p class="index-brief__note mono">
      {{ selectedNeighbors.position }} / {{ selectedNeighbors.total }} · 当日分时走势
    </p>
  </div>
</template>

<style scoped>
.index-brief {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.index-brief__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
}

.index-brief__title {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}

.index-brief__hex {
  width: 22px;
  height: 24px;
  flex-shrink: 0;
  background: linear-gradient(160deg, rgba(242, 194, 92, 0.34), rgba(96, 196, 255, 0.18));
  clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}

.index-brief__name {
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.01em;
  color: var(--text-strong);
}

.index-brief__code {
  font-size: 9.5px;
  letter-spacing: 0.04em;
  color: var(--text-dim);
}

.index-brief__close {
  width: 22px;
  height: 22px;
  flex-shrink: 0;
  border: 1px solid var(--line-soft);
  border-radius: 6px;
  background: transparent;
  color: var(--text-dim);
  font-size: 13px;
  line-height: 1;
  cursor: pointer;
  transition:
    color 0.16s ease,
    border-color 0.16s ease;
}

.index-brief__close:hover {
  color: var(--text-strong);
  border-color: var(--line);
}

.index-brief__price {
  display: flex;
  align-items: baseline;
  gap: 8px;
}

.index-brief__value {
  font-size: 26px;
  font-weight: 700;
  letter-spacing: -0.01em;
}

.index-brief__pct {
  padding: 2px 7px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 600;
}

.index-brief__grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin: 0;
}

.index-brief__grid div {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.index-brief__grid dt {
  font-size: 9.5px;
  color: var(--text-dim);
}

.index-brief__grid dd {
  margin: 0;
  font-size: 12px;
  color: var(--text);
  white-space: nowrap;
}

.index-brief__step {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
}

.index-brief__note {
  margin: 0;
  font-size: 9px;
  color: var(--text-dim);
  opacity: 0.85;
}
</style>

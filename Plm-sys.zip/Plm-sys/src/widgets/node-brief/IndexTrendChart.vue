<script setup lang="ts">
import type { MarketExchange } from '@platform/contracts'
import { computed } from 'vue'

import { formatPrice } from '@/shared/lib/format'

const props = defineProps<{
  /** 当日分钟收盘序列 */
  points: number[]
  /** 昨收，用于画横向基准线 */
  base: number
  tone: 'up' | 'down' | 'flat'
  exchange: MarketExchange
}>()

const color = computed(() => {
  if (props.tone === 'up') return 'var(--up, #ff5d73)'
  if (props.tone === 'down') return 'var(--down, #2ee6a6)'
  return 'var(--flat, #8ba3c2)'
})

/** 分钟点没有自带时间戳，A 股按固定交易时段标轴；全球指数只知道开盘/收盘 */
const timeLabels = computed(() =>
  props.exchange === 'GL' ? ['开盘', '收盘'] : ['09:30', '11:30 / 13:00', '15:00'],
)

const geometry = computed(() => {
  const values = props.points.filter((value) => Number.isFinite(value) && value > 0)
  const first = values[0]
  if (first === undefined || values.length < 2) return null

  const base = props.base > 0 ? props.base : first
  const high = Math.max(...values, base)
  const low = Math.min(...values, base)
  // 全天一字时 high === low，给一个最小跨度避免除以 0
  const span = high - low || Math.max(high * 0.001, 1)
  const step = 100 / (values.length - 1)
  const toY = (value: number): number => 2 + (1 - (value - low) / span) * 96

  let line = ''
  values.forEach((value, index) => {
    line += `${index === 0 ? 'M' : 'L'}${(index * step).toFixed(2)},${toY(value).toFixed(2)} `
  })
  const path = line.trim()
  const last = values[values.length - 1] ?? base

  return {
    line: path,
    area: `${path} L100,98 L0,98 Z`,
    baseY: toY(base).toFixed(2),
    lastY: toY(last).toFixed(2),
    high: formatPrice(high),
    low: formatPrice(low),
  }
})
</script>

<template>
  <div class="index-trend">
    <div v-if="geometry" class="index-trend__plot" :style="{ color }">
      <svg
        class="index-trend__svg"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        role="img"
        aria-label="当日分时走势"
      >
        <line class="index-trend__grid" x1="0" y1="25" x2="100" y2="25" />
        <line class="index-trend__grid" x1="0" y1="50" x2="100" y2="50" />
        <line class="index-trend__grid" x1="0" y1="75" x2="100" y2="75" />
        <line
          class="index-trend__base"
          x1="0"
          :y1="geometry.baseY"
          x2="100"
          :y2="geometry.baseY"
        />
        <path class="index-trend__area" :d="geometry.area" />
        <path class="index-trend__line" :d="geometry.line" />
      </svg>

      <span class="index-trend__dot" :style="{ top: `${geometry.lastY}%` }" aria-hidden="true" />

      <div class="index-trend__axis">
        <span class="mono">{{ geometry.high }}</span>
        <span class="mono">{{ geometry.low }}</span>
      </div>
    </div>

    <div v-else class="index-trend__empty mono">暂无分时数据</div>

    <div v-if="geometry" class="index-trend__times mono">
      <span v-for="label in timeLabels" :key="label">{{ label }}</span>
    </div>
  </div>
</template>

<style scoped>
.index-trend {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.index-trend__plot {
  position: relative;
  height: 190px;
}

.index-trend__svg {
  position: absolute;
  inset: 0 54px 0 0;
  width: calc(100% - 54px);
  height: 100%;
  overflow: visible;
}

.index-trend__grid {
  stroke: currentColor;
  stroke-width: 0.7;
  opacity: 0.08;
  vector-effect: non-scaling-stroke;
}

.index-trend__base {
  stroke: currentColor;
  stroke-width: 1;
  stroke-dasharray: 3 4;
  opacity: 0.3;
  vector-effect: non-scaling-stroke;
}

.index-trend__area {
  fill: currentColor;
  opacity: 0.12;
}

.index-trend__line {
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}

.index-trend__dot {
  position: absolute;
  right: 54px;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: currentColor;
  box-shadow: 0 0 8px currentColor;
  transform: translate(50%, -50%);
}

.index-trend__axis {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-left: 6px;
  font-size: 8.5px;
  line-height: 1;
  color: var(--text-dim);
}

.index-trend__times {
  display: flex;
  justify-content: space-between;
  padding-right: 54px;
  font-size: 8.5px;
  line-height: 1;
  color: var(--text-dim);
}

.index-trend__empty {
  display: grid;
  place-items: center;
  height: 190px;
  border: 1px dashed var(--line-soft);
  border-radius: 8px;
  font-size: 10px;
  color: var(--text-dim);
}

@media (max-width: 860px) {
  .index-trend__plot,
  .index-trend__empty {
    height: 150px;
  }
}
</style>

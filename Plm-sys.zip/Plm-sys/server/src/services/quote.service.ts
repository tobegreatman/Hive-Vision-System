import { request as httpsRequest } from 'node:https'

import {
  limitStatusOf,
  MARKET_PROVIDER,
  type MarketBoard,
  type MarketExchange,
} from '@platform/contracts'

import { upstreamLimiter, backoffDelay, parseRetryAfter, UpstreamBreakerOpenError } from './upstream-limiter.js'

/**
 * 盘面行情源代理（东方财富）。
 *
 * ## 为什么是「两条腿」
 *
 * 全市场行情走 `ulist.np`（按代码批量快照），一次 500 个代码、约 100ms，
 * 全 A 约 6000 只只需 12 批。代码清单另走 `clist` 分页，但**只取 f12/f13/f14**
 * 并缓存 30 分钟——因为全 A 代码日内几乎不变，没必要每 20 秒重扫 60 页。
 *
 * 这不是优化，是修正一个真实的线上故障：`clist` 只有 `push2delay2` 一个节点接受，
 * 而它是延迟行情源，盘中 f6（成交额）/f15–f17 全返回 `-`、指数 f3 恒为 0。
 * 于是「按成交额降序取前 60」退化成按代码排序，板块成交额、主力净流入、
 * 涨跌家数全错，指数看起来永远停在昨收。
 *
 * ## 传输层为什么不用 fetch
 *
 * undici 默认 keep-alive 复用连接，`push2` 三个实时域会在复用连接上直接
 * `other side closed`（ECONNRESET）。同样 URL 用 curl 或 `node:https` 都 200，
 * 所以改用 `https.request` + `agent: false`（每次新建连接），牺牲少量 TLS 握手
 * 换稳定。60 页时代价明显，12 批之后几乎可以忽略。
 *
 * 抓取失败的处理原则和 industry.service 一致：手里有旧帧就发旧帧并标 degraded，
 * 一帧都没有才向路由层抛错，由 market.service 退回内置演示快照。
 *
 * 防限流：所有请求先过 `upstreamLimiter`（令牌桶 + 熔断），重试用带抖动的
 * 指数退避；收到 429/503 不换域名硬撞，而是直接闭闸到 `Retry-After` 之后再动。
 */

/** 单请求超时。上游偶发挂住，必须自己切断，否则一轮扫描会被一批拖死。 */
const REQUEST_TIMEOUT_MS = 8_000
/** 并发请求数：5 路足以喂满令牌桶，再高只会堆在闸门后面排队。 */
const PAGE_CONCURRENCY = 5
/** 单请求重试次数（每次换一台镜像域）。 */
const MAX_ATTEMPTS = 3
/** 重试退避基数与上限：第一次最多等 400ms，之后 800ms，抖动后不会同步重发。 */
const RETRY_BASE_MS = 400
const RETRY_CAP_MS = 2_000
/** 一轮扫描里缺批超过这个比例就整轮作废，改用上一帧（残缺数据比旧数据更误导）。 */
const MAX_INCOMPLETE_RATIO = 0.2
/** 代码清单缓存时长：全 A 代码日内基本不变，30 分钟足够，新股上市也不会漏太久。 */
const UNIVERSE_TTL_MS = 30 * 60_000

/** 上游错误：把「能不能重试」和「是不是被限流」变成结构化信息，不再靠字符串判断。 */
class UpstreamError extends Error {
  constructor(
    message: string,
    readonly detail: {
      status?: number
      /** 上游明确表达了「请求太快」 */
      rateLimited?: boolean
      retryAfterMs?: number
      /** 换域名换批次都没用（403/404），重试纯属浪费额度 */
      fatal?: boolean
    } = {},
  ) {
    super(message)
    this.name = 'UpstreamError'
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

export interface QuoteRow {
  symbol: string
  exchange: MarketExchange
  name: string
  board: MarketBoard
  /** 最新价（指数为点位） */
  price: number
  changePct: number
  /** 振幅 %：(最高 - 最低) / 昨收 */
  amplitude: number
  turnoverRate: number
  volumeRatio: number
  /** 成交额（亿元） */
  turnover: number
  /** 总市值（亿元） */
  marketCap: number
  /** 主力净流入（亿元） */
  mainNetInflow: number
  /** 所属行业（上游 f100，缺失时为空串） */
  industry: string
}

export interface BoardStats {
  /** 板块真实家数（有报价的标的，停牌不计） */
  universe: number
  up: number
  down: number
  limitUp: number
  limitDown: number
  /** 板块成交额合计（亿元） */
  turnover: number
  /** 板块主力净流入合计（亿元） */
  mainNetInflow: number
  /** 板块涨幅合计，用于算均涨幅（避免逐次求平均的浮点漂移） */
  changeSum: number
  leader: QuoteRow | null
}

export interface QuoteSnapshot {
  /** 抓取完成时间戳 */
  at: number
  latencyMs: number
  /** 本轮行情请求批次数 */
  pages: number
  /** 失败的批次数 */
  failedPages: number
  /** 全 A 家数（有报价的行数） */
  universe: number
  /** 全量行，按成交额降序 */
  rows: QuoteRow[]
  rowBySymbol: Map<string, QuoteRow>
  indices: QuoteRow[]
  boardStats: Map<MarketBoard, BoardStats>
  breadth: { up: number; down: number; flat: number; limitUp: number; limitDown: number }
  /** 全市场主力净流入（亿元） */
  mainNetInflow: number
  /** 全市场成交额排名，1 表示成交额最大 */
  rankBySymbol: Map<string, number>
  degraded: boolean
}

interface RawPage {
  rows: unknown[]
  total: number
}

/** 代码清单条目：只保留「批量快照要用」的三样东西。 */
interface UniverseEntry {
  symbol: string
  /** 上游市场标识：1 = 沪市，0 = 深市/北交所 */
  market: number
}

interface HttpResponse {
  status: number
  headers: Record<string, string | string[] | undefined>
  body: string
}

let cache: QuoteSnapshot | null = null
let inflight: Promise<QuoteSnapshot> | null = null
let universeCache: { at: number; entries: UniverseEntry[] } | null = null
let universeInflight: Promise<UniverseEntry[]> | null = null
/** 镜像游标：失败过的域先让位给下一个，避免连续撞同一台坏主机。 */
let hostCursor = 0

function pickQuoteHost(attempt: number): string {
  const hosts = MARKET_PROVIDER.quoteHosts
  return hosts[(hostCursor + attempt) % hosts.length] ?? hosts[0]
}

function pickListHost(attempt: number): string {
  const hosts = MARKET_PROVIDER.listHosts
  return hosts[attempt % hosts.length] ?? hosts[0]
}

/** 列表分页（仅代码清单用）。 */
function clistUrl(host: string, page: number): string {
  const params = new URLSearchParams({
    pn: String(page),
    pz: String(MARKET_PROVIDER.pageSize),
    po: '1',
    np: '1',
    fltt: '2',
    invt: '2',
    // 按成交额降序只对「取到哪些代码」有意义；清单本身是全量的
    fid: 'f6',
    fs: MARKET_PROVIDER.universeFs,
    fields: MARKET_PROVIDER.clistFields,
  })
  return `https://${host}${MARKET_PROVIDER.listPath}?${params.toString()}`
}

/** 按代码批量取快照（行情主通道）。 */
function quoteUrl(host: string, secids: string[], fields: string): string {
  const params = new URLSearchParams({
    fltt: '2',
    secids: secids.join(','),
    fields,
  })
  return `https://${host}${MARKET_PROVIDER.quotePath}?${params.toString()}`
}

function upstreamHeaders(): Record<string, string> {
  return {
    Accept: 'application/json, text/plain, */*',
    Referer: MARKET_PROVIDER.referer,
    'User-Agent': 'Mozilla/5.0 (compatible; platform-sys/0.1)',
  }
}

/**
 * 用 `node:https` 而不是 `fetch`：undici 会复用 keep-alive 连接，
 * 而上游实时域在复用连接上直接 `other side closed`。
 * `agent: false` 表示每请求新建连接，绕开连接池。
 */
function httpGet(url: string): Promise<HttpResponse> {
  return new Promise((resolve, reject) => {
    const req = httpsRequest(
      url,
      {
        method: 'GET',
        headers: upstreamHeaders(),
        agent: false,
        timeout: REQUEST_TIMEOUT_MS,
      },
      (res) => {
        const chunks: Buffer[] = []
        res.on('data', (chunk: Buffer) => chunks.push(chunk))
        res.on('end', () => {
          resolve({
            status: res.statusCode ?? 0,
            headers: res.headers,
            body: Buffer.concat(chunks).toString('utf8'),
          })
        })
        res.on('error', reject)
      },
    )
    req.on('timeout', () => req.destroy(new Error('upstream timeout')))
    req.on('error', reject)
    req.end()
  })
}

/** 上游 `diff` 可能是数组，也可能是以序号为键的对象。 */
function extractDiff(payload: unknown): RawPage {
  const data = (payload as { data?: { diff?: unknown; total?: number } } | null)?.data
  const diff = data?.diff
  let rows: unknown[] = []
  if (Array.isArray(diff)) rows = diff
  else if (diff && typeof diff === 'object') rows = Object.values(diff as Record<string, unknown>)
  return { rows, total: Number(data?.total ?? 0) }
}

/**
 * 单次请求：过闸 → 发请求 → 回报成功/失败。
 *
 * 状态码语义化很关键：把所有非 2xx 都当普通失败，就会在 429 之后立刻重试，
 * 把「限流」升级成「封禁」。这里把 429/503/403 与 `Retry-After` 单独拎出来，
 * 直接触发熔断冷却。
 */
async function requestJson(url: string): Promise<unknown> {
  await upstreamLimiter.acquire()

  let response: HttpResponse
  try {
    response = await httpGet(url)
  } catch (error) {
    // 连接被掐断 / 超时：既没拿到响应也算一次失败，连续多次会触发熔断
    upstreamLimiter.reportFailure()
    throw new UpstreamError(error instanceof Error ? error.message : 'upstream unreachable', { status: 0 })
  }

  if (response.status < 200 || response.status >= 300) {
    const raw = response.headers['retry-after']
    const retryAfterMs = parseRetryAfter(Array.isArray(raw) ? (raw[0] ?? null) : (raw ?? null)) ?? undefined
    const rateLimited =
      response.status === 429 || response.status === 503 || response.status === 403 || (retryAfterMs ?? 0) > 0

    upstreamLimiter.reportFailure({ rateLimited, retryAfterMs })
    throw new UpstreamError(`upstream ${response.status}`, {
      status: response.status,
      rateLimited,
      retryAfterMs,
      // 403 是「不给你了」，404 是「这个接口没了」：重试和换镜像都不会变
      fatal: response.status === 403 || response.status === 404,
    })
  }

  try {
    const payload: unknown = JSON.parse(response.body)
    upstreamLimiter.reportSuccess()
    return payload
  } catch {
    upstreamLimiter.reportFailure()
    throw new UpstreamError('upstream returned non-json', { status: response.status })
  }
}

/** 带镜像轮换 + 抖动退避的请求；熔断打开或上游明确拒绝时立刻抛。 */
async function requestWithRetry(url: (host: string) => string, pickHost: (attempt: number) => string): Promise<unknown> {
  let lastError: unknown = new Error('upstream unreachable')

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
    try {
      return await requestJson(url(pickHost(attempt)))
    } catch (error) {
      lastError = error

      if (error instanceof UpstreamBreakerOpenError) throw error
      if (error instanceof UpstreamError && error.detail.fatal) throw error

      // 最后一次失败后不必再等，直接把错误交给调用方
      if (attempt < MAX_ATTEMPTS - 1) {
        await sleep(backoffDelay(attempt, RETRY_BASE_MS, RETRY_CAP_MS))
      }
    }
  }

  throw lastError
}

/** 列表分页：镜像只有一台，游标仍按尝试递进，便于将来加备选。 */
async function requestListPage(page: number): Promise<RawPage> {
  const payload = await requestWithRetry(
    (host) => clistUrl(host, page),
    (attempt) => pickListHost(attempt),
  )
  return extractDiff(payload)
}

/** 批量快照：一次 `batchSize` 个代码。 */
async function requestBatch(secids: string[], fields: string): Promise<unknown[]> {
  const payload = await requestWithRetry(
    (host) => quoteUrl(host, secids, fields),
    (attempt) => {
      const host = pickQuoteHost(attempt)
      if (attempt > 0) hostCursor = (hostCursor + attempt) % MARKET_PROVIDER.quoteHosts.length
      return host
    },
  )
  return extractDiff(payload).rows
}

function toNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value === 'string') {
    const trimmed = value.trim()
    if (!trimmed || trimmed === '-' || trimmed === '--') return null
    const parsed = Number(trimmed)
    return Number.isFinite(parsed) ? parsed : null
  }
  return null
}

function round2(value: number): number {
  return Number(value.toFixed(2))
}

/**
 * 代码 → 板块。批量接口是一张 `fs` 打天下，上游不再告诉我们板块归属，
 * 只能按代码段反推：688/689 科创、300/301/302 创业板、4/8/9 开头北交所（含 920 新段），其余沪深主板。
 */
export function boardOfCode(symbol: string): MarketBoard {
  if (/^(688|689)/.test(symbol)) return 'star'
  if (/^(300|301|302)/.test(symbol)) return 'gem'
  if (/^[489]/.test(symbol)) return 'bse'
  return 'main'
}

function exchangeOf(board: MarketBoard, marketFlag: number | null): MarketExchange {
  if (board === 'bse') return 'BJ'
  return marketFlag === 1 ? 'SH' : 'SZ'
}

/** 涨跌幅都限幅在契约允许的区间内：新股首日无涨跌停，原始值可能远超 ±30%。 */
function clampPct(value: number): number {
  return round2(Math.min(Math.max(value, -100), 500))
}

/** 一行原始行情 → 规范化行；无报价（停牌 / 未上市）返回 null 直接丢弃。 */
export function normalizeRow(raw: unknown): QuoteRow | null {
  if (!raw || typeof raw !== 'object') return null
  const row = raw as Record<string, unknown>

  const symbol = String(row.f12 ?? '')
  if (!/^\d{6}$/.test(symbol)) return null

  const price = toNumber(row.f2)
  const changePct = toNumber(row.f3)
  // 停牌票 f2 / f3 是 '-'：留在列表里会污染家数与均涨幅
  if (price === null || price <= 0 || changePct === null) return null

  const prevClose = toNumber(row.f18) ?? 0
  const high = toNumber(row.f15)
  const low = toNumber(row.f16)
  const amplitude =
    prevClose > 0 && high !== null && low !== null
      ? round2(Math.min(((high - low) / prevClose) * 100, 500))
      : round2(Math.min(Math.abs(changePct) * 1.8, 500))

  const board = boardOfCode(symbol)
  const industry = String(row.f100 ?? '').trim()

  return {
    symbol,
    exchange: exchangeOf(board, toNumber(row.f13)),
    name: String(row.f14 ?? symbol).trim().slice(0, 16) || symbol,
    board,
    price,
    changePct: clampPct(changePct),
    amplitude: Math.max(amplitude, 0),
    turnoverRate: Math.min(Math.max(toNumber(row.f8) ?? 0, 0), 100),
    volumeRatio: Math.min(Math.max(toNumber(row.f10) ?? 0, 0), 50),
    // 上游成交额 / 市值 / 净流入单位都是「元」，盘面统一用亿元
    turnover: round2((toNumber(row.f6) ?? 0) / 1e8),
    marketCap: round2((toNumber(row.f20) ?? 0) / 1e8),
    mainNetInflow: round2((toNumber(row.f62) ?? 0) / 1e8),
    industry: industry === '-' ? '' : industry.slice(0, 12),
  }
}

function normalizeIndex(raw: unknown): QuoteRow | null {
  if (!raw || typeof raw !== 'object') return null
  const row = raw as Record<string, unknown>

  const symbol = String(row.f12 ?? '')
  if (!/^\d{6}$/.test(symbol)) return null

  const price = toNumber(row.f2)
  const changePct = toNumber(row.f3)
  if (price === null || price <= 0 || changePct === null) return null

  const prevClose = toNumber(row.f18) ?? 0
  const high = toNumber(row.f15)
  const low = toNumber(row.f16)

  return {
    symbol,
    exchange: toNumber(row.f13) === 1 ? 'SH' : 'SZ',
    name: String(row.f14 ?? symbol).trim().slice(0, 16) || symbol,
    board: 'index',
    price,
    changePct,
    amplitude: prevClose > 0 && high !== null && low !== null ? round2(((high - low) / prevClose) * 100) : 0,
    turnoverRate: 0,
    volumeRatio: 0,
    turnover: round2((toNumber(row.f6) ?? 0) / 1e8),
    marketCap: 0,
    mainNetInflow: round2((toNumber(row.f62) ?? 0) / 1e8),
    industry: '',
  }
}

/** 自选指数行情：与 A 股 QuoteRow 分开，secid 可指向沪 / 深 / 板块 / 全球指数。 */
export interface WatchedIndexQuote {
  secid: string
  code: string
  market: number
  name: string
  price: number
  change: number
  changePct: number
  preClose: number
  high: number
  low: number
  /** 成交额（亿元） */
  turnover: number
}

export function normalizeWatchedIndex(raw: unknown): WatchedIndexQuote | null {
  if (!raw || typeof raw !== 'object') return null
  const row = raw as Record<string, unknown>

  const code = String(row.f12 ?? '').trim()
  const market = toNumber(row.f13)
  const price = toNumber(row.f2)
  const changePct = toNumber(row.f3)
  if (!code || market === null || price === null || price <= 0 || changePct === null) return null

  return {
    secid: `${market}.${code}`,
    code,
    market,
    name: String(row.f14 ?? code).trim().slice(0, 24) || code,
    price,
    change: round2(toNumber(row.f4) ?? 0),
    changePct: round2(changePct),
    preClose: round2(toNumber(row.f18) ?? 0),
    high: round2(toNumber(row.f15) ?? 0),
    low: round2(toNumber(row.f16) ?? 0),
    turnover: round2((toNumber(row.f6) ?? 0) / 1e8),
  }
}

/** 当日分时：`points` 为分钟收盘价，`preClose` 用于画基准线。 */
export interface WatchedIndexTrend {
  points: number[]
  preClose: number | null
}

export function parseIndexTrend(payload: unknown): WatchedIndexTrend {
  const data = (payload as { data?: { trends?: unknown; preClose?: unknown } } | null)?.data
  const trends = Array.isArray(data?.trends) ? data.trends : []
  const preClose = toNumber(data?.preClose)

  const points: number[] = []
  for (const line of trends) {
    if (typeof line !== 'string') continue
    // fields2 = f51 时间, f52 开, f53 收, f54 高, f55 低, f56 量, f57 额, f58 均价
    const close = toNumber(line.split(',')[2])
    if (close !== null && close > 0) points.push(close)
  }

  return {
    points: points.length > 600 ? points.slice(-600) : points,
    preClose: preClose !== null && preClose > 0 ? preClose : (points[0] ?? null),
  }
}

function trendUrl(host: string, secid: string): string {
  const params = new URLSearchParams({
    secid,
    fields1: MARKET_PROVIDER.trendFields1,
    fields2: MARKET_PROVIDER.trendFields2,
    iscr: '0',
    ndays: '1',
  })
  return `https://${host}${MARKET_PROVIDER.trendPath}?${params.toString()}`
}

function emptyBoardStats(): BoardStats {
  return {
    universe: 0,
    up: 0,
    down: 0,
    limitUp: 0,
    limitDown: 0,
    turnover: 0,
    mainNetInflow: 0,
    changeSum: 0,
    leader: null,
  }
}

/** 行集合 → 快照。纯函数，便于用固定样本做断言。 */
export function buildSnapshot(
  rows: QuoteRow[],
  indices: QuoteRow[],
  meta: { at: number; latencyMs: number; pages: number; failedPages: number },
): QuoteSnapshot {
  // 成交额降序：蜂巢「取前 N」与全局排名都依赖这个顺序，只排一次
  const ordered = [...rows].sort((a, b) => b.turnover - a.turnover)

  const rowBySymbol = new Map<string, QuoteRow>()
  const rankBySymbol = new Map<string, number>()
  const boardStats = new Map<MarketBoard, BoardStats>()
  const breadth = { up: 0, down: 0, flat: 0, limitUp: 0, limitDown: 0 }
  let mainNetInflow = 0

  ordered.forEach((row, index) => {
    rowBySymbol.set(row.symbol, row)
    rankBySymbol.set(row.symbol, index + 1)
    mainNetInflow += row.mainNetInflow

    const stats = boardStats.get(row.board) ?? emptyBoardStats()
    stats.universe += 1
    stats.turnover += row.turnover
    stats.mainNetInflow += row.mainNetInflow
    stats.changeSum += row.changePct
    if (!stats.leader || row.changePct > stats.leader.changePct) stats.leader = row

    if (row.changePct > 0.005) {
      stats.up += 1
      breadth.up += 1
    } else if (row.changePct < -0.005) {
      stats.down += 1
      breadth.down += 1
    } else {
      breadth.flat += 1
    }

    const limit = limitStatusOf(row)
    if (limit === 'limit-up') {
      stats.limitUp += 1
      breadth.limitUp += 1
    } else if (limit === 'limit-down') {
      stats.limitDown += 1
      breadth.limitDown += 1
    }

    boardStats.set(row.board, stats)
  })

  return {
    ...meta,
    universe: ordered.length,
    rows: ordered,
    rowBySymbol,
    indices,
    boardStats,
    breadth,
    mainNetInflow: round2(mainNetInflow),
    rankBySymbol,
    degraded: meta.failedPages > 0,
  }
}

/** 三大指数（走实时域，不能碰 delay2）。失败不致命：前端显示「—」。 */
async function fetchIndices(): Promise<QuoteRow[]> {
  try {
    const rows = await requestBatch([...MARKET_PROVIDER.indexSecids], MARKET_PROVIDER.indexFields)
    return rows.map(normalizeIndex).filter((row): row is QuoteRow => row !== null)
  } catch {
    return []
  }
}

/**
 * 自选指数快照：一次批量请求取回所有 secid（沪 / 深 / 板块 / 全球混排也行），
 * 避免为每只指数单独打一个请求。
 */
export async function fetchWatchedIndexQuotes(secids: string[]): Promise<WatchedIndexQuote[]> {
  if (secids.length === 0) return []
  const rows = await requestBatch(secids, MARKET_PROVIDER.indexWatchFields)
  const bySecid = new Map<string, WatchedIndexQuote>()
  for (const raw of rows) {
    const quote = normalizeWatchedIndex(raw)
    if (quote) bySecid.set(quote.secid, quote)
  }
  // 按调用方给的顺序返回，上游 diff 的顺序不保证稳定
  return secids.flatMap((secid) => {
    const quote = bySecid.get(secid)
    return quote ? [quote] : []
  })
}

/** 单只指数的当日分钟分时。上游偶发缺数据时返回空点列，由调用方决定是否保留旧帧。 */
export async function fetchWatchedIndexTrend(secid: string): Promise<WatchedIndexTrend> {
  const payload = await requestWithRetry(
    (host) => trendUrl(host, secid),
    (attempt) => pickQuoteHost(attempt),
  )
  return parseIndexTrend(payload)
}

/**
 * 代码清单：clist 分页，只取 f12/f13。
 *
 * 缺页超过 20% 直接判废——清单少 20 页意味着少 2000 只股票，
 * 「全市场 5574 只」会变成 3500 只，比用旧清单误导得多。
 */
async function fetchUniverse(): Promise<UniverseEntry[]> {
  const first = await requestListPage(1)
  const pages = Math.min(
    MARKET_PROVIDER.maxPages,
    Math.max(1, Math.ceil((first.total || first.rows.length) / MARKET_PROVIDER.pageSize)),
  )

  const entries = new Map<string, UniverseEntry>()
  const absorb = (rows: unknown[]): void => {
    for (const raw of rows) {
      if (!raw || typeof raw !== 'object') continue
      const row = raw as Record<string, unknown>
      const symbol = String(row.f12 ?? '')
      if (!/^\d{6}$/.test(symbol) || entries.has(symbol)) continue
      entries.set(symbol, { symbol, market: toNumber(row.f13) ?? 0 })
    }
  }

  absorb(first.rows)

  let failedPages = 0
  let cursor = 2

  async function worker(): Promise<void> {
    while (cursor <= pages) {
      const page = cursor
      cursor += 1
      try {
        absorb((await requestListPage(page)).rows)
      } catch {
        failedPages += 1
      }
    }
  }

  await Promise.all(Array.from({ length: PAGE_CONCURRENCY }, () => worker()))

  if (failedPages / pages > MAX_INCOMPLETE_RATIO) {
    throw new Error(`代码清单残缺 ${failedPages}/${pages} 页，本轮作废`)
  }
  if (entries.size === 0) throw new Error('代码清单为空')

  return [...entries.values()]
}

/**
 * 取代码清单：30 分钟内复用，过期但刷新失败时继续用旧的。
 * 并发调用共享同一次拉取，冷启动多个前端同时进来也只扫一轮。
 */
async function universe(): Promise<UniverseEntry[]> {
  if (universeCache && Date.now() - universeCache.at < UNIVERSE_TTL_MS) return universeCache.entries
  if (universeInflight) return universeInflight

  universeInflight = fetchUniverse()
    .then((entries) => {
      universeCache = { at: Date.now(), entries }
      return entries
    })
    .catch((error: unknown) => {
      // 清单过期但还能用：新股漏几只，总好过整页空白
      if (universeCache) return universeCache.entries
      throw error
    })
    .finally(() => {
      universeInflight = null
    })

  return universeInflight
}

async function collect(): Promise<QuoteSnapshot> {
  const startedAt = Date.now()

  // 代码清单（多半命中缓存）与指数并行，省掉一次串行等待
  const [entries, indices] = await Promise.all([universe(), fetchIndices()])

  const secids = entries.map((entry) => `${entry.market}.${entry.symbol}`)
  const batches: string[][] = []
  for (let i = 0; i < secids.length; i += MARKET_PROVIDER.batchSize) {
    batches.push(secids.slice(i, i + MARKET_PROVIDER.batchSize))
  }

  const rawRows: unknown[] = []
  let failedBatches = 0

  for (let i = 0; i < batches.length; i += PAGE_CONCURRENCY) {
    const slice = batches.slice(i, i + PAGE_CONCURRENCY)
    const results = await Promise.all(
      slice.map(async (batch) => {
        try {
          return await requestBatch(batch, MARKET_PROVIDER.clistFields)
        } catch {
          return null
        }
      }),
    )
    for (const rows of results) {
      if (rows) rawRows.push(...rows)
      else failedBatches += 1
    }
  }

  /**
   * 残缺过半的结果比上一帧更误导：家数会凭空少掉几千只，
   * 前端却照样显示 LIVE。缺批超过 20% 就整轮作废，
   * 让 `snapshot()` 的 catch 分支继续发旧帧并标 degraded。
   */
  if (batches.length > 0 && failedBatches / batches.length > MAX_INCOMPLETE_RATIO) {
    throw new Error(`行情批次残缺 ${failedBatches}/${batches.length} 批，本轮作废`)
  }

  const seen = new Set<string>()
  const rows: QuoteRow[] = []
  for (const raw of rawRows) {
    const row = normalizeRow(raw)
    if (!row || seen.has(row.symbol)) continue
    seen.add(row.symbol)
    rows.push(row)
  }

  return buildSnapshot(rows, indices, {
    at: Date.now(),
    latencyMs: Date.now() - startedAt,
    pages: batches.length,
    failedPages: failedBatches,
  })
}

export const quoteService = {
  /** 当前缓存（不做新鲜度判断），供健康检查与调试读取。 */
  peek(): QuoteSnapshot | null {
    return cache
  },

  /** 上游闸门状态（令牌桶速率 / 熔断 / 最近一次被限流的时间）。 */
  limiterStats() {
    return upstreamLimiter.stats()
  },

  /**
   * 取一份快照。`ttlMs` 内直接复用缓存；并发请求共享同一次抓取。
   * 抓取失败但有旧帧时返回旧帧并标 degraded——宁可发旧数据也不整页空白。
   */
  async snapshot(ttlMs: number): Promise<QuoteSnapshot> {
    if (cache && Date.now() - cache.at < ttlMs) return cache
    if (inflight) return inflight

    inflight = collect()
      .then((snapshot) => {
        cache = snapshot
        return snapshot
      })
      .catch((error: unknown) => {
        if (cache) return { ...cache, degraded: true }
        throw error
      })
      .finally(() => {
        inflight = null
      })

    return inflight
  },

  /** 仅用于测试：清空缓存与并发锁。 */
  reset(): void {
    cache = null
    inflight = null
    universeCache = null
    universeInflight = null
    hostCursor = 0
    upstreamLimiter.reset()
  },
}

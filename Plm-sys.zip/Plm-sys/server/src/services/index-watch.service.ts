import type { MarketIndex, MarketIndexCandidate } from '@platform/contracts'
import { MARKET_PROVIDER } from '@platform/contracts'

import {
  fetchWatchedIndexQuotes,
  fetchWatchedIndexTrend,
  type WatchedIndexQuote,
  type WatchedIndexTrend,
} from './quote.service.js'

/**
 * 自选指数（板块导航里的「大盘指数」）。
 *
 * 与 A 股盘面拆开的原因：盘面的 MarketNode 契约要求 6 位 A 股代码 + 沪深北交易所，
 * 而用户想加的是「韩国KOSPI」「证券Ⅱ」这类 secid 完全不同的标的。
 * 这里只维护一份 secid 白名单，行情仍走 quote.service 的统一上游通道：
 * - 快照：`ulist.np` 一次批量取回（沪 / 深 / 板块 / 全球混排都行）
 * - 分时：`trends2` 每只一次，缓存 60s（分钟数据本身一分钟才变一次）
 *
 * 列表存内存，与「加入自选」保持一致：服务重启后回到默认三大指数。
 */

const DEFAULT_SECIDS = ['1.000001', '0.399001', '0.399006']
/** 上限既保护上游额度，也避免左侧面板无限拉长。 */
const MAX_WATCHED = 10
const QUOTE_TTL_MS = 15_000
const TREND_TTL_MS = 60_000
const SEARCH_TTL_MS = 5 * 60_000
const SEARCH_TIMEOUT_MS = 6_000
const SECID_PATTERN = /^\d{1,3}\.[A-Za-z0-9]{1,16}$/

export type IndexWatchErrorCode = 'limit' | 'not_found' | 'upstream'

export class IndexWatchError extends Error {
  constructor(
    readonly code: IndexWatchErrorCode,
    message: string,
  ) {
    super(message)
    this.name = 'IndexWatchError'
  }
}

function toItem(
  quote: WatchedIndexQuote,
  trend: WatchedIndexTrend | null,
  asOf = new Date().toISOString(),
): MarketIndex {
  return {
    ...quote,
    spark: trend?.points ?? [],
    asOf,
  }
}

interface SuggestRow {
  QuoteID?: unknown
  Code?: unknown
  Name?: unknown
  MktNum?: unknown
  SecurityTypeName?: unknown
}

function toCandidate(raw: SuggestRow): MarketIndexCandidate | null {
  const secid = String(raw.QuoteID ?? '').trim()
  const code = String(raw.Code ?? '').trim()
  const name = String(raw.Name ?? '').trim()
  const market = Number(raw.MktNum)
  const typeLabel = String(raw.SecurityTypeName ?? '').trim()

  if (!SECID_PATTERN.test(secid) || !code || !name || !Number.isInteger(market)) return null

  const kind = typeLabel.includes('板块') ? 'sector' : typeLabel.includes('指数') ? 'index' : null
  if (!kind) return null

  return {
    secid,
    code,
    market,
    name: name.slice(0, 24),
    kind,
    typeLabel: (typeLabel || '指数').slice(0, 12),
  }
}

export class IndexWatchService {
  private readonly secids: string[] = [...DEFAULT_SECIDS]

  private quotesCache: { at: number; key: string; value: WatchedIndexQuote[] } | null = null
  private quotesInflight: { key: string; promise: Promise<WatchedIndexQuote[]> } | null = null

  private readonly trendCache = new Map<string, { at: number; value: WatchedIndexTrend }>()
  private readonly trendInflight = new Map<string, Promise<WatchedIndexTrend>>()

  private readonly searchCache = new Map<string, { at: number; value: MarketIndexCandidate[] }>()

  secidList(): string[] {
    return [...this.secids]
  }

  async list(): Promise<MarketIndex[]> {
    const secids = [...this.secids]
    if (secids.length === 0) return []

    const quotes = await this.ensureQuotes(secids)
    const trends = await Promise.all(
      secids.map(async (secid) => {
        try {
          return [secid, await this.ensureTrend(secid)] as const
        } catch {
          // 分时挂了不影响主列表：前端会画一条空基线
          return [secid, null] as const
        }
      }),
    )

    const quoteBySecid = new Map(quotes.map((quote) => [quote.secid, quote]))
    const trendBySecid = new Map(trends)
    const asOf = new Date().toISOString()

    return secids.flatMap((secid) => {
      const quote = quoteBySecid.get(secid)
      return quote ? [toItem(quote, trendBySecid.get(secid) ?? null, asOf)] : []
    })
  }

  async add(input: { secid: string; name?: string }): Promise<MarketIndex> {
    if (!SECID_PATTERN.test(input.secid)) {
      throw new IndexWatchError('not_found', '指数代码格式应为「市场.代码」，如 100.KS11')
    }

    if (this.secids.includes(input.secid)) {
      const existing = (await this.list()).find((item) => item.secid === input.secid)
      if (existing) return existing
    }

    if (this.secids.length >= MAX_WATCHED) {
      throw new IndexWatchError('limit', `最多同时监控 ${MAX_WATCHED} 个指数，请先移除一个`)
    }

    const [quote] = await fetchWatchedIndexQuotes([input.secid])
    if (!quote) throw new IndexWatchError('not_found', '行情源没有这个指数的报价')

    if (input.name && quote.name === quote.code) quote.name = input.name

    this.secids.push(input.secid)
    this.quotesCache = null
    this.trendCache.delete(input.secid)

    let trend: WatchedIndexTrend | null = null
    try {
      trend = await this.ensureTrend(input.secid, true)
    } catch {
      // 分时首次失败不阻塞添加，下一轮 list 会再试
    }

    return toItem(quote, trend)
  }

  remove(secid: string): boolean {
    const index = this.secids.indexOf(secid)
    if (index < 0) return false

    this.secids.splice(index, 1)
    this.quotesCache = null
    this.trendCache.delete(secid)
    this.trendInflight.delete(secid)
    return true
  }

  /** 搜索指数 / 板块；只保留上游类型为「指数」「板块」的结果，个股直接过滤掉。 */
  async search(query: string): Promise<MarketIndexCandidate[]> {
    const keyword = query.trim()
    if (!keyword) return []

    const cached = this.searchCache.get(keyword)
    if (cached && Date.now() - cached.at < SEARCH_TTL_MS) return cached.value

    const params = new URLSearchParams({
      input: keyword,
      type: '14',
      token: MARKET_PROVIDER.searchToken,
      count: '12',
    })
    const url = `https://${MARKET_PROVIDER.searchHost}${MARKET_PROVIDER.searchPath}?${params.toString()}`

    let response: Response
    try {
      response = await fetch(url, {
        headers: {
          Accept: 'application/json, text/plain, */*',
          Referer: MARKET_PROVIDER.referer,
        },
        signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
      })
    } catch (error) {
      throw new IndexWatchError(
        'upstream',
        `指数搜索暂不可用：${error instanceof Error ? error.message : String(error)}`,
      )
    }
    if (!response.ok) throw new IndexWatchError('upstream', `指数搜索暂不可用（${response.status}）`)

    const payload = (await response.json().catch(() => null)) as
      | { QuotationCodeTable?: { Data?: unknown } }
      | null
    const rawRows = payload?.QuotationCodeTable?.Data
    const rows = Array.isArray(rawRows) ? (rawRows as SuggestRow[]) : []

    const seen = new Set<string>()
    const value: MarketIndexCandidate[] = []
    for (const row of rows) {
      const candidate = toCandidate(row)
      if (!candidate || seen.has(candidate.secid)) continue
      seen.add(candidate.secid)
      value.push(candidate)
      if (value.length >= 12) break
    }

    this.searchCache.set(keyword, { at: Date.now(), value })
    return value
  }

  private async ensureQuotes(secids: string[]): Promise<WatchedIndexQuote[]> {
    const key = secids.join(',')

    if (this.quotesCache && this.quotesCache.key === key && Date.now() - this.quotesCache.at < QUOTE_TTL_MS) {
      return this.quotesCache.value
    }
    if (this.quotesInflight?.key === key) return this.quotesInflight.promise

    const promise = fetchWatchedIndexQuotes(secids)
      .then((value) => {
        this.quotesCache = { at: Date.now(), key, value }
        return value
      })
      .finally(() => {
        if (this.quotesInflight?.promise === promise) this.quotesInflight = null
      })

    this.quotesInflight = { key, promise }
    return promise
  }

  private async ensureTrend(secid: string, force = false): Promise<WatchedIndexTrend> {
    const cached = this.trendCache.get(secid)
    if (!force && cached && Date.now() - cached.at < TREND_TTL_MS) return cached.value

    const inflight = this.trendInflight.get(secid)
    if (inflight) return inflight

    const promise = fetchWatchedIndexTrend(secid)
      .then((value) => {
        this.trendCache.set(secid, { at: Date.now(), value })
        return value
      })
      .finally(() => {
        if (this.trendInflight.get(secid) === promise) this.trendInflight.delete(secid)
      })

    this.trendInflight.set(secid, promise)
    return promise
  }
}

export const indexWatchService = new IndexWatchService()

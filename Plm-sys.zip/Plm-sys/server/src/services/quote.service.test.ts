import { describe, expect, it } from 'vitest'

import {
  boardOfCode,
  buildSnapshot,
  normalizeRow,
  normalizeWatchedIndex,
  parseIndexTrend,
  type QuoteRow,
} from './quote.service.js'

/** 上游 clist 的真实返回形状（数值单位：元 / %）。 */
const RAW_MOUTAI = {
  f2: 1446.44,
  f3: -2.27,
  f6: 18081680309.5,
  f8: 0.52,
  f10: 1.1,
  f12: '600519',
  f13: 1,
  f14: '贵州茅台',
  f15: 1480.6,
  f16: 1439,
  f18: 1480,
  f20: 1808168030950,
  f62: -565105168,
  f100: '酿酒行业',
}

function row(overrides: Partial<QuoteRow>): QuoteRow {
  return {
    symbol: '600519',
    exchange: 'SH',
    name: '贵州茅台',
    board: 'main',
    price: 100,
    changePct: 1,
    amplitude: 2,
    turnoverRate: 1,
    volumeRatio: 1,
    turnover: 10,
    marketCap: 1000,
    mainNetInflow: 0,
    industry: '酿酒行业',
    ...overrides,
  }
}

describe('normalizeRow', () => {
  it('把上游字段换算成盘面口径（元 → 亿元）', () => {
    const parsed = normalizeRow(RAW_MOUTAI)
    expect(parsed).not.toBeNull()
    expect(parsed).toMatchObject({
      symbol: '600519',
      exchange: 'SH',
      name: '贵州茅台',
      board: 'main',
      price: 1446.44,
      changePct: -2.27,
      turnover: 180.82,
      marketCap: 18081.68,
      mainNetInflow: -5.65,
      industry: '酿酒行业',
    })
    // 振幅 = (1480.6 - 1439) / 1480
    expect(parsed?.amplitude).toBe(2.81)
  })

  it('丢掉停牌行：f2 / f3 是 "-" 时不能进盘面', () => {
    expect(normalizeRow({ ...RAW_MOUTAI, f2: '-', f3: '-' })).toBeNull()
  })

  it('北交所按代码段归板块，交易所落到 BJ', () => {
    const parsed = normalizeRow({ ...RAW_MOUTAI, f12: '920045', f13: 0, f14: '蘅东光' })
    expect(parsed?.board).toBe('bse')
    expect(parsed?.exchange).toBe('BJ')
  })

  it('新股首日涨幅超出 ±30% 时按契约定价而不是丢弃', () => {
    const parsed = normalizeRow({ ...RAW_MOUTAI, f2: 88, f3: 420 })
    expect(parsed?.changePct).toBe(420)
  })
})

describe('normalizeWatchedIndex', () => {
  it('保留全球指数的 secid 与点位口径', () => {
    const parsed = normalizeWatchedIndex({
      f2: 4002.1,
      f3: 1.23,
      f4: 48.5,
      f6: 12345678900,
      f12: 'KS11',
      f13: 100,
      f14: '韩国KOSPI',
      f15: 4010,
      f16: 3940,
      f18: 3953.6,
    })
    expect(parsed).toMatchObject({
      secid: '100.KS11',
      code: 'KS11',
      market: 100,
      name: '韩国KOSPI',
      price: 4002.1,
      changePct: 1.23,
      turnover: 123.46,
    })
  })

  it('板块指数同样走 secid 口径', () => {
    const parsed = normalizeWatchedIndex({ f2: 1234.5, f3: -0.5, f12: 'BK0473', f13: 90, f14: '证券Ⅱ' })
    expect(parsed?.secid).toBe('90.BK0473')
  })

  it('停牌或无效报价返回 null', () => {
    expect(normalizeWatchedIndex({ f2: '-', f3: '-', f12: 'KS11', f13: 100 })).toBeNull()
  })
})

describe('parseIndexTrend', () => {
  it('取分钟收盘价并保留昨收', () => {
    const parsed = parseIndexTrend({
      data: {
        preClose: 3953.6,
        trends: [
          '2026-11-06 09:30,3953.6,3954.1,3955,3953,0,0,0',
          '2026-11-06 09:31,3954.1,3960.2,3961,3954,0,0,0',
        ],
      },
    })
    expect(parsed).toEqual({ points: [3954.1, 3960.2], preClose: 3953.6 })
  })

  it('缺少昨收时用首个分钟价兜底', () => {
    const parsed = parseIndexTrend({
      data: { trends: ['2026-11-06 09:30,10,11.2,11.3,9.9,0,0,0'] },
    })
    expect(parsed.preClose).toBe(11.2)
  })

  it('上游无数据时返回空序列', () => {
    expect(parseIndexTrend(null)).toEqual({ points: [], preClose: null })
  })
})

describe('boardOfCode', () => {
  it('按代码段区分四个板块', () => {
    expect(boardOfCode('600519')).toBe('main')
    expect(boardOfCode('300750')).toBe('gem')
    expect(boardOfCode('688981')).toBe('star')
    expect(boardOfCode('920045')).toBe('bse')
    expect(boardOfCode('835185')).toBe('bse')
  })
})

describe('buildSnapshot', () => {
  const rows = [
    row({ symbol: '600519', turnover: 180, changePct: 1.2 }),
    row({ symbol: '601318', turnover: 120, changePct: -0.7 }),
    row({ symbol: '601127', turnover: 90, changePct: 10 }),
    row({ symbol: '300750', board: 'gem', turnover: 200, changePct: 2.8 }),
    row({ symbol: '300059', board: 'gem', turnover: 150, changePct: 5.1 }),
    row({ symbol: '688981', board: 'star', turnover: 60, changePct: 4.6 }),
    row({ symbol: '920045', board: 'bse', turnover: 30, changePct: 30 }),
  ]

  const snapshot = buildSnapshot(rows, [], {
    at: Date.now(),
    latencyMs: 420,
    pages: 60,
    failedPages: 0,
  })

  it('全市场口径：家数、广度、涨停都按真实行统计', () => {
    expect(snapshot.universe).toBe(7)
    expect(snapshot.breadth).toEqual({ up: 6, down: 1, flat: 0, limitUp: 2, limitDown: 0 })
  })

  it('板块聚合按板块分桶，涨停阈值按板块规则判定', () => {
    const main = snapshot.boardStats.get('main')
    expect(main?.universe).toBe(3)
    expect(main?.up).toBe(2)
    expect(main?.limitUp).toBe(1)
    expect(main?.leader?.symbol).toBe('601127')

    // 创业板 +5.1% 不是涨停，+20% 才是
    expect(snapshot.boardStats.get('gem')?.limitUp).toBe(0)
    expect(snapshot.boardStats.get('bse')?.limitUp).toBe(1)
  })

  it('排名与排序都按成交额降序', () => {
    expect(snapshot.rows[0]?.symbol).toBe('300750')
    expect(snapshot.rankBySymbol.get('300750')).toBe(1)
    expect(snapshot.rankBySymbol.get('600519')).toBe(2)
  })

  it('翻页失败即降级，但仍然返回已有行', () => {
    const degraded = buildSnapshot(rows, [], {
      at: Date.now(),
      latencyMs: 900,
      pages: 60,
      failedPages: 2,
    })
    expect(degraded.degraded).toBe(true)
    expect(degraded.rows).toHaveLength(7)
  })
})

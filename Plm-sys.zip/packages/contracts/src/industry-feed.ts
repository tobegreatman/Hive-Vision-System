import { z } from 'zod'

/**
 * 行业资金流：第三方数据源协议常量。
 *
 * 浏览器不再直连数据源（JSONP 等于允许对端在本页执行任意脚本），
 * 统一由 Hono 的 `/api/feed` 代理取数；端点、字段表、分页参数放这里，
 * 前后端共用一份，避免代理层与解码层字段漂移。
 */
export const INDUSTRY_PROVIDER = {
  id: 'eastmoney.push2',
  label: '东方财富 · 行情中心',
  /** 主域在部分网络下会重置连接或触发 IP 级限流，故维持一组镜像域并按健康度轮换 */
  hosts: [
    'push2delay2.eastmoney.com',
    'push2delay.eastmoney.com',
    'push2his.eastmoney.com',
    'push2.eastmoney.com',
  ],
  referer: 'https://quote.eastmoney.com/',
  path: '/api/qt/clist/get',
  pageSize: 100,
  /** 板块筛选串：m:90 t:2 = 申万行业分类（496 个节点，三级树） */
  universeFs: 'm:90+t:2',
  /** 预期节点数（数据源自报 total，用作覆盖度门禁） */
  expected: 496,
} as const

/** 一次请求取回全周期字段，避免多次调用触发限流。 */
export const INDUSTRY_FEED_FIELDS = [
  'f2', 'f3', 'f8', 'f12', 'f14', 'f15', 'f16', 'f17', 'f18', 'f20',
  'f62', 'f66', 'f69', 'f72', 'f75', 'f78', 'f81', 'f84', 'f87', 'f184',
  'f104', 'f105', 'f106', 'f128', 'f136', 'f140',
  'f164', 'f165', 'f166', 'f168', 'f170', 'f172', 'f174', 'f175',
  'f124',
].join(',')

export const industryPeriodSchema = z.enum(['d1', 'd5', 'd10'])
export type IndustryPeriod = z.infer<typeof industryPeriodSchema>

/** 代理层输出：原始行情行（字段解码仍由前端的 decodeRow 负责，保持单一实现）。 */
export const industryFeedRowsSchema = z.object({
  schema: z.literal('industry-flow/rows-v1'),
  period: industryPeriodSchema,
  /** 服务端抓取完成时间 */
  asOf: z.string(),
  /** 数据源自报总数 */
  total: z.number().int().nonnegative(),
  pages: z.number().int().nonnegative(),
  latencyMs: z.number().nonnegative(),
  /** 上游部分页失败、但仍有可用样本时为 true（前端据此降级提示） */
  degraded: z.boolean(),
  records: z.array(z.unknown()),
})

export type IndustryFeedRows = z.infer<typeof industryFeedRowsSchema>

/** 分钟级资金流：代理层原样透传上游 payload，由前端 decodeIntraday 解析。 */
export const industryIntradaySchema = z.object({
  code: z.string().regex(/^\d{6}$/),
  points: z.array(
    z.object({
      t: z.string(),
      main: z.number().nullable(),
      sm: z.number().nullable(),
      md: z.number().nullable(),
      lg: z.number().nullable(),
      xl: z.number().nullable(),
    }),
  ),
})

export type IndustryIntraday = z.infer<typeof industryIntradaySchema>

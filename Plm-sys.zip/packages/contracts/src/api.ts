import { z } from 'zod'

import { isoDateSchema } from './primitives.js'
import { marketBoardSchema, marketNodeSchema, updateMarketNodeInputSchema } from './market.js'
import { quoteStatusSchema } from './market-feed.js'

/** 路由表前后端共用，避免魔法字符串漂移。 */
export const API_ROUTES = {
  health: '/api/health',
  overview: '/api/market/overview',
  boards: '/api/market/boards',
  nodes: '/api/market/nodes',
  node: (id: string) => `/api/market/nodes/${id}`,
  nodeDetail: (id: string) => `/api/market/nodes/${id}/detail`,
  indices: '/api/market/indices',
  indexSearch: '/api/market/indices/search',
  index: (secid: string) => `/api/market/indices/${encodeURIComponent(secid)}`,
  stocks: '/api/market/stocks',
  stockSearch: '/api/market/stocks/search',
  stock: (secid: string) => `/api/market/stocks/${encodeURIComponent(secid)}`,
  stockQuote: (secid: string) => `/api/market/stocks/${encodeURIComponent(secid)}/quote`,
  stockKline: (secid: string) => `/api/market/stocks/${encodeURIComponent(secid)}/kline`,
} as const

export const apiErrorSchema = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    details: z.unknown().optional(),
  }),
})

export type ApiError = z.infer<typeof apiErrorSchema>

/** 交易时段，用于顶部状态栏与「是否实时」提示。 */
export const marketSessionSchema = z.enum([
  'pre-open',
  'auction',
  'open',
  'lunch-break',
  'closed',
  'holiday',
])

export type MarketSession = z.infer<typeof marketSessionSchema>

export const healthResponseSchema = z.object({
  status: z.literal('ok'),
  runtime: z.string(),
  uptimeMs: z.number().nonnegative(),
  timestamp: z.string(),
  session: marketSessionSchema,
  tradeDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  /** 明确标注数据来源：live = 上游真实行情，demo = 内置教学快照（上游不可用时的兜底） */
  dataMode: z.enum(['demo', 'live']),
  /** 行情源运行状态；demo 模式下为 null */
  quote: quoteStatusSchema.nullable(),
})

export type HealthResponse = z.infer<typeof healthResponseSchema>

export const marketBreadthSchema = z.object({
  up: z.number().int().nonnegative(),
  down: z.number().int().nonnegative(),
  flat: z.number().int().nonnegative(),
  limitUp: z.number().int().nonnegative(),
  limitDown: z.number().int().nonnegative(),
})

export type MarketBreadth = z.infer<typeof marketBreadthSchema>

export const marketOverviewSchema = z.object({
  indices: z.array(marketNodeSchema),
  breadth: marketBreadthSchema,
  /** 两市成交额（亿元） */
  turnover: z.number().nonnegative(),
  /** 主力净流入合计（亿元） */
  mainNetInflow: z.number(),
  session: marketSessionSchema,
  tradeDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  asOf: isoDateSchema,
})

export type MarketOverview = z.infer<typeof marketOverviewSchema>

export const marketOverviewResponseSchema = z.object({
  overview: marketOverviewSchema,
})

export type MarketOverviewResponse = z.infer<typeof marketOverviewResponseSchema>

/**
 * 自选指数：与 A 股主线拆开，支持沪 / 深 / 板块 / 全球任意 secid。
 * `spark` 是当日分钟收盘序列，前端画微型分时；抓不到时为空数组而不是报错。
 */
export const marketIndexSchema = z.object({
  /** 东财 secid：`1.000001` / `90.BK0473` / `100.KS11` */
  secid: z.string().min(3).max(24),
  code: z.string().min(1).max(16),
  market: z.number().int().nonnegative(),
  name: z.string().min(1).max(24),
  price: z.number().positive(),
  change: z.number(),
  changePct: z.number().min(-100).max(500),
  preClose: z.number().nonnegative(),
  high: z.number().nonnegative(),
  low: z.number().nonnegative(),
  /** 成交额（亿元） */
  turnover: z.number().nonnegative(),
  /** 当日分钟收盘价（点位），最多 600 点 */
  spark: z.array(z.number().nonnegative()).max(600),
  /**
   * 分时 X 轴总长（分钟）。A 股（沪 / 深 / 北 / `90.BKxxxx` 板块）为 240，
   * 海外指数为 `null`（无交易时段信息，前端按已有点数铺满）。
   */
  sparkAxis: z.number().int().positive().max(600).nullable(),
  asOf: isoDateSchema,
})

export type MarketIndex = z.infer<typeof marketIndexSchema>

export const listMarketIndicesResponseSchema = z.object({
  items: z.array(marketIndexSchema),
  asOf: isoDateSchema,
})

export type ListMarketIndicesResponse = z.infer<typeof listMarketIndicesResponseSchema>

export const marketIndexCandidateSchema = z.object({
  secid: z.string().min(3).max(24),
  code: z.string().min(1).max(16),
  market: z.number().int().nonnegative(),
  name: z.string().min(1).max(24),
  kind: z.enum(['index', 'sector']),
  /** 上游类型名，如「指数」「板块」 */
  typeLabel: z.string().min(1).max(12),
})

export type MarketIndexCandidate = z.infer<typeof marketIndexCandidateSchema>

export const searchMarketIndicesResponseSchema = z.object({
  items: z.array(marketIndexCandidateSchema),
})

export type SearchMarketIndicesResponse = z.infer<typeof searchMarketIndicesResponseSchema>

export const addMarketIndexInputSchema = z.object({
  secid: z.string().regex(/^\d{1,3}\.[A-Za-z0-9]{1,16}$/, 'secid 格式应为「市场.代码」'),
  /** 可选名称：仅在行情源没返回名称时作为兜底 */
  name: z.string().trim().min(1).max(24).optional(),
})

export type AddMarketIndexPayload = z.input<typeof addMarketIndexInputSchema>

export const marketIndexResponseSchema = z.object({
  item: marketIndexSchema,
})

export type MarketIndexResponse = z.infer<typeof marketIndexResponseSchema>

export const removeMarketIndexResponseSchema = z.object({
  removed: z.boolean(),
})

export type RemoveMarketIndexResponse = z.infer<typeof removeMarketIndexResponseSchema>

/* ------------------------------------------------------------------ *
 * 自定义板块：个股自选池 + 日 / 周 / 月 K 线
 * ------------------------------------------------------------------ */

/**
 * 自选池个股快照：行情字段与自选指数完全同构（批量快照同一条上游通道），
 * 额外带 `nodeId`——与 `/api/market/nodes` 里的蜂巢节点同一身份，
 * 导航面板点一下就能直接定位到那只票。
 */
export const marketStockSchema = marketIndexSchema.extend({
  nodeId: z.string().min(1),
  /**
   * live    = 实时快照正常
   * pending = 实时源暂不可用，价格来自最近一根日线收盘兜底；兜底也拿不到时为 0
   */
  quoteStatus: z.enum(['live', 'pending']),
  // 待行情时允许 0：搜索选中的个股先入池，等实时源恢复再补齐
  price: z.number().nonnegative(),
})

export type MarketStock = z.infer<typeof marketStockSchema>

export const listMarketStocksResponseSchema = z.object({
  items: z.array(marketStockSchema),
  asOf: isoDateSchema,
})

export type ListMarketStocksResponse = z.infer<typeof listMarketStocksResponseSchema>

export const marketStockCandidateSchema = z.object({
  secid: z.string().min(3).max(24),
  code: z.string().min(1).max(16),
  market: z.number().int().nonnegative(),
  name: z.string().min(1).max(24),
  /** 上游类型名，如「沪A」「深A」「京A」 */
  typeLabel: z.string().min(1).max(12),
})

export type MarketStockCandidate = z.infer<typeof marketStockCandidateSchema>

export const searchMarketStocksResponseSchema = z.object({
  items: z.array(marketStockCandidateSchema),
})

export type SearchMarketStocksResponse = z.infer<typeof searchMarketStocksResponseSchema>

/**
 * 加入自选前的单只个股报价：搜索选中后由服务端补齐现价 / 涨跌幅，
 * 前端不再让用户手填行情字段。
 */
export const marketStockQuoteSchema = z.object({
  secid: z.string().min(3).max(24),
  code: z.string().min(1).max(16),
  name: z.string().min(1).max(24),
  price: z.number().positive(),
  changePct: z.number(),
  preClose: z.number().nonnegative(),
  /** live = 实时快照；delayed = 实时源不可用，用最近一根日线收盘兜底 */
  quoteStatus: z.enum(['live', 'delayed']),
})

export type MarketStockQuote = z.infer<typeof marketStockQuoteSchema>

export const marketStockQuoteResponseSchema = z.object({
  item: marketStockQuoteSchema,
})

export type MarketStockQuoteResponse = z.infer<typeof marketStockQuoteResponseSchema>

export const addMarketStockInputSchema = z.object({
  secid: z.string().regex(/^\d{1,3}\.[A-Za-z0-9]{1,16}$/, 'secid 格式应为「市场.代码」'),
  /** 可选名称：仅在行情源没返回名称时作为兜底 */
  name: z.string().trim().min(1).max(24).optional(),
})

export type AddMarketStockPayload = z.input<typeof addMarketStockInputSchema>

export const marketStockResponseSchema = z.object({
  item: marketStockSchema,
})

export type MarketStockResponse = z.infer<typeof marketStockResponseSchema>

export const removeMarketStockResponseSchema = z.object({
  removed: z.boolean(),
})

export type RemoveMarketStockResponse = z.infer<typeof removeMarketStockResponseSchema>

/** K 线粒度：分时不在这个接口里——当日分钟序列随自选池快照一起下发（`spark`）。 */
export const marketKlinePeriodSchema = z.enum(['day', 'week', 'month'])

export type MarketKlinePeriod = z.infer<typeof marketKlinePeriodSchema>

export const marketKlineBarSchema = z.object({
  /** 交易日 `YYYY-MM-DD`；月线取该月最后一个交易日的日期 */
  at: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  open: z.number().positive(),
  close: z.number().positive(),
  high: z.number().positive(),
  low: z.number().positive(),
  /** 成交量（手） */
  volume: z.number().nonnegative(),
  /** 成交额（元） */
  amount: z.number().nonnegative(),
  /** 相对上一根 K 线的涨跌幅 % */
  changePct: z.number().min(-100).max(500),
})

export type MarketKlineBar = z.infer<typeof marketKlineBarSchema>

export const marketKlineResponseSchema = z.object({
  secid: z.string().min(3).max(24),
  period: marketKlinePeriodSchema,
  bars: z.array(marketKlineBarSchema).max(400),
  asOf: isoDateSchema,
})

export type MarketKlineResponse = z.infer<typeof marketKlineResponseSchema>

export const listMarketNodesResponseSchema = z.object({
  items: z.array(marketNodeSchema),
  total: z.number().int().nonnegative(),
})

export type ListMarketNodesResponse = z.infer<typeof listMarketNodesResponseSchema>

/**
 * 板块聚合：蜂巢导航第一层的单元。
 * 家数 / 涨跌 / 成交额 / 均涨幅 / 领涨股都由服务端算好，前端只负责排布六边形。
 */
export const marketBoardSummarySchema = z.object({
  board: marketBoardSchema,
  label: z.string().min(1),
  /**
   * 板块真实家数（上游全量口径），不是蜂巢里铺了几格。
   * 蜂巢只铺成交额前列的 `sampleCount` 只——5900 个六边形既渲染不动也没法看。
   */
  count: z.number().int().nonnegative(),
  /** 该板块进蜂巢的格子数（成交额降序取前 N） */
  sampleCount: z.number().int().nonnegative(),
  up: z.number().int().nonnegative(),
  down: z.number().int().nonnegative(),
  /** 涨跌停家数合计（涨停 + 跌停），用于板块层面的极端情绪提示 */
  limitCount: z.number().int().nonnegative(),
  /** 板块成交额（亿元） */
  turnover: z.number().nonnegative(),
  /** 板块主力净流入合计（亿元） */
  mainNetInflow: z.number(),
  /** 板块平均涨跌幅 %（全板块真实口径，非蜂巢样本） */
  avgChangePct: z.number().min(-100).max(500),
  /** 领涨标的（按涨跌幅），空板块为 null */
  leader: marketNodeSchema.nullable(),
})

export type MarketBoardSummary = z.infer<typeof marketBoardSummarySchema>

export const listMarketBoardsResponseSchema = z.object({
  items: z.array(marketBoardSummarySchema),
  asOf: isoDateSchema,
})

export type ListMarketBoardsResponse = z.infer<typeof listMarketBoardsResponseSchema>

export const marketNodeResponseSchema = z.object({
  node: marketNodeSchema,
})

export type MarketNodeResponse = z.infer<typeof marketNodeResponseSchema>

/**
 * 拾取后展示的盘口统计：排名、同板块家数、涨跌停状态均由服务端计算，
 * 前端只渲染，不在本地重复实现业务规则。
 */
export const marketNodeDetailSchema = z.object({
  rank: z.number().int().positive(),
  peerCount: z.number().int().nonnegative(),
  limitStatus: z.enum(['limit-up', 'limit-down', 'normal']),
  visits: z.number().int().nonnegative(),
  lastVisitedAt: isoDateSchema.nullable(),
})

export type MarketNodeDetail = z.infer<typeof marketNodeDetailSchema>

export const marketNodeDetailResponseSchema = z.object({
  node: marketNodeSchema,
  detail: marketNodeDetailSchema,
})

export type MarketNodeDetailResponse = z.infer<typeof marketNodeDetailResponseSchema>

export const updateMarketNodePayloadSchema = updateMarketNodeInputSchema

export type ApiRouteKey = keyof typeof API_ROUTES

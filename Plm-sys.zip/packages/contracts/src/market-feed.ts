import { z } from 'zod'

import { isoDateSchema } from './primitives.js'

/**
 * 盘面行情源：东方财富行情中心。
 *
 * 与行业资金流（`industry-feed.ts`）同一套思路——浏览器不直连第三方，
 * 所有上游访问收口在 Hono 的 `quote.service`。这里只放「端点 / 字段 / 分页」
 * 这类协议常量，字段解码与业务聚合实现在服务端，避免两处漂移。
 *
 * **两个端点承担完全不同的职责，别混用：**
 * - `ulist.np`（按代码批量取快照）→ 实时行情，`quoteHosts` 三个域都可用
 * - `clist`（全量列表分页）→ 只用来拿「代码清单」，只有 `listHosts` 一个域接受
 *
 * 实测（2026-11 盘中复核）：`push2` / `push2delay` / `push2his` 对 clist 一律
 * `ECONNRESET`，唯独 `push2delay2` 放行；而 `push2delay2` 是延迟行情节点，
 * 盘中 f6（成交额）/f15…f17 全返回 `-`，f3（涨跌幅）恒为 0。早年只靠 clist
 * 一条通道，于是在盘中拿到一份「价格对、成交额全空、指数涨跌幅恒 0」的数据。
 */
export const MARKET_PROVIDER = {
  id: 'eastmoney.push2',
  label: '东方财富 · 行情中心',
  /**
   * 实时行情域：只用于 ulist.np。按失败次数轮换，
   * 三个域返回同一份实时数据，互为备份。
   */
  quoteHosts: [
    'push2.eastmoney.com',
    'push2delay.eastmoney.com',
    'push2his.eastmoney.com',
  ],
  /**
   * 列表域：唯一接受 clist 全量分页的节点。
   * 只从这里取代码清单（f12/f13/f14），行情字段一律不采信——
   * 它在盘中给不出成交额，按它排序会让「成交额前列」变成按代码排序。
   */
  listHosts: ['push2delay2.eastmoney.com'],
  referer: 'https://quote.eastmoney.com/',
  /** 全市场列表（分页，仅用于代码清单） */
  listPath: '/api/qt/clist/get',
  /** 按代码批量取快照（行情主通道，也用于指数） */
  quotePath: '/api/qt/ulist.np/get',
  /** 列表单页硬上限：实测 pz > 100 仍只回 100 行 */
  pageSize: 100,
  /**
   * 批量快照单次可带的代码数。实测 500 条一次返回、约 100ms；
   * 再往上 URL 会超过 ~8KB 被上游回 HTML 错误页，900 是硬顶，取 500 留余量。
   */
  batchSize: 500,
  /** 全 A 宇宙：深主板 + 创业板 + 沪主板 + 科创板 + 北交所（约 5900 只） */
  universeFs: 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048',
  /** 三大指数：沪、深、创业板 */
  indexSecids: ['1.000001', '0.399001', '0.399006'],
  /**
   * 自选指数行情字段：点位 / 涨跌幅 / 涨跌额 / 成交额 / 代码 / 市场 / 名称 / 最高最低 / 昨收。
   * `f13`（市场号）决定 secid 前缀：1 沪、0 深、90 板块、100 全球指数。
   */
  indexWatchFields: 'f2,f3,f4,f6,f12,f13,f14,f15,f16,f17,f18',
  /** 当日分时：trends2 返回分钟级收盘序列，push2 与 push2his 均可用 */
  trendPath: '/api/qt/stock/trends2/get',
  trendFields1: 'f1,f2,f3,f4,f5,f6',
  trendFields2: 'f51,f52,f53,f54,f55,f56,f57,f58',
  /** 指数/板块搜索：东财 suggest 接口，返回的 QuoteID 直接就是 secid */
  searchHost: 'searchapi.eastmoney.com',
  searchPath: '/api/suggest/get',
  searchToken: 'D43BF722C8E33BDC906FB84D85E326E8',
  /** 列表字段：价格 / 涨跌幅 / 量额 / 换手 / 量比 / 市值 / 主力净流入 / 行业 */
  clistFields: [
    'f2', 'f3', 'f5', 'f6', 'f8', 'f10', 'f12', 'f13', 'f14',
    'f15', 'f16', 'f17', 'f18', 'f20', 'f21', 'f62', 'f100',
  ].join(','),
  /** 指数字段：另加涨跌家数 f104 / f105（真实全市场广度） */
  indexFields: 'f2,f3,f6,f12,f13,f14,f15,f16,f17,f18,f62,f104,f105',
  /** 兜底页数：5927 / 100 ≈ 60 页，留一点余量 */
  maxPages: 72,
} as const

/**
 * 上游闸门状态。响应体里带上它，是为了让「数据为什么变旧」有据可查：
 * 熔断打开时 `breaker = open`、`cooldownRemainingMs` 就是还要等多久，
 * 不用去翻进程日志猜。
 */
export const quoteLimiterSchema = z.object({
  /** 令牌桶稳态速率（个/秒） */
  ratePerSec: z.number().positive(),
  /** 突发容量 */
  burst: z.number().int().positive(),
  breaker: z.enum(['closed', 'open', 'half-open']),
  /** 熔断冷却剩余毫秒 */
  cooldownRemainingMs: z.number().int().nonnegative(),
  /** 连续失败次数（成功即清零） */
  consecutiveFailures: z.number().int().nonnegative(),
  /** 最近一次被上游限流的时间；从未被限流则为 null */
  lastThrottleAt: isoDateSchema.nullable(),
})

/**
 * 行情源运行状态。挂在 `/api/health` 上，前端据此把徽标从 DEMO 切成 LIVE，
 * 并在上游部分页失败时显示「延迟」而不是假装一切正常。
 */
export const quoteStatusSchema = z.object({
  provider: z.string(),
  label: z.string(),
  /** 本轮快照的抓取完成时间 */
  asOf: isoDateSchema,
  /** 距抓取完成的毫秒数 */
  ageMs: z.number().int().nonnegative(),
  /** 一轮全量抓取的总耗时 */
  latencyMs: z.number().nonnegative(),
  /** 一轮行情请求的批次数（每批 `batchSize` 个代码） */
  pages: z.number().int().nonnegative(),
  /** 失败批次数：> 0 即为降级（样本少了几批，但仍在发真实数据） */
  failedPages: z.number().int().nonnegative(),
  /** 上游自报的全 A 家数 */
  universe: z.number().int().nonnegative(),
  degraded: z.boolean(),
  /** 限流闸门状态（可选：老版本服务端不带这个字段） */
  limiter: quoteLimiterSchema.optional(),
})

export type QuoteStatus = z.infer<typeof quoteStatusSchema>

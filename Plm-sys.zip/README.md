# 盘面 · A 股蜂巢导航台

Vue 3 + TresJS 声明式 Three.js 蜂巢 × Hono 后端，同一套 Zod Schema + 涨跌停规则打通端到端类型。
主体是一张**三维蜂巢导航图**：板块 → 个股两级下钻，URL 即层级。

![蜂巢导航预览](docs/preview.png)

> 盘面跑的是**真实行情**：服务端每轮从东方财富行情中心批量拉全 A（约 5900 只 / 12 批，一次 500 个代码），
> 板块家数、涨跌家数、涨停家数、均涨幅都是全市场口径。前端顶栏 `LIVE` 徽标只在拿到上游数据时点亮；
> 上游整体不可用时退回内置教学快照并改标 `DEMO`，部分批次失败标「延迟」，绝不把演示数据装成实时行情。

```
┌──────────────────────────── 浏览器 ─────────────────────────────┐
│ MarketPage (pages)                                              │
│   ├─ HiveCanvas  (widgets) ─ TresCanvas / 六边形瓦片 / 蜂巢地板  │
│   ├─ BoardNav    (widgets) ─ 板块清单 / 指数 / AddWatchPanel     │
│   └─ NodeBrief   (widgets) ─ 选中标的摘要 / 板块内导航 / 关注度   │
│            │            ▲                                       │
│            ▼            │ 板块聚合 + 标的 / Pinia Store           │
│   entities/{market-board, market-node} ── shared/lib/hex         │
│            │            │                                       │
│        shared/api（Zod 反向校验） ── features/navigate-hive       │
└───────────────────────────────┬─────────────────────────────────┘
                                │ fetch + Zod 校验
                    ┌───────────▼───────────┐
                    │ Hono @ :3600          │
                    │ routes → services     │
                    │ @platform/contracts   │
                    └───────────────────────┘
```

## 快速开始

```bash
pnpm install
pnpm dev          # 前端 8080 + 后端 3600（concurrently 同时启动）
```

其他脚本：

| 命令 | 作用 |
| --- | --- |
| `pnpm dev` | 构建共享契约包，然后并行启动 Vite(8080) 与 Hono(3600) |
| `pnpm pm2:start` | 构建契约包后用 PM2 常驻启动 web/api/stockframe，可关闭终端 |
| `pnpm pm2:restart` | 按 ecosystem 配置重新加载三个常驻进程 |
| `pnpm pm2:stop` | 停止三个常驻进程 |
| `pnpm pm2:status` | 查看常驻进程状态 |
| `pnpm pm2:logs` | 持续查看三个进程日志 |
| `pnpm build` | 契约包 → `vue-tsc` 全量类型检查 → `vite build` |
| `pnpm preview` | 预览生产产物（4173，已配置 `/api` 代理） |
| `pnpm test` | Vitest（jsdom）：契约、蜂巢布局、盘面映射、API 客户端 |
| `pnpm lint` / `pnpm lint:fix` | ESLint 9 flat config，含 FSD 边界校验 |
| `pnpm typecheck` | 前端 `vue-tsc` + 构建脚本 tsc + 后端 tsc |
| `pnpm format` | Prettier |

> 端口 8080 被占用时 Vite 会直接报 `Port 8080 is already in use` 并退出（`strictPort` 故意如此），
> 先释放端口再启动；后端端口可用 `PORT=3700 pnpm dev:api` 覆盖。
>
> 后端绑定 3600 时带**退避重试**（24 × 250ms）：`tsx watch` 在多个文件同时变更时会连发两次重启，
> 旧进程尚未释放端口，若此时直接退出，API 会一直死到下一次文件变更（前端只会看到 Vite 代理回 500）。
> 现在这种情况会自动重试并接上，只有端口被外部进程长期占用才会报错退出。
>
> PM2 常驻模式使用项目内 `.pm2` 作为 PM2_HOME（由 `scripts/pm2.cjs` 固定），与全局 PM2 里
> 其他项目的应用互不干扰；日志在 `.pm2/logs/`，关闭终端后进程继续运行。需先确保 `pm2` 已安装到 PATH。

## 蜂巢导航语义

| 概念 | 规则 |
| --- | --- |
| 层级 | `/` 板块层 → `/board/:board` 标的层 → `?node=<id>` 选中某只；浏览器前进/后退天然是「下钻/返回」 |
| 直链 | `?node=<id>` 是分享链接的唯一事实源：冷启动等列表到达后再落位；id 已不存在就摘掉参数；id 属于别的板块则把层级修正到它真正的板块（以更具体的标的为准） |
| 蜂巢几何 | pointy-top 六边形，轴向坐标 `x = √3·r·(q + r/2)`、`z = 1.5·r·r`，与 `CylinderGeometry(r, r, h, 6)` 的顶点朝向一致 |
| 落位 | 同心环填充：环 0 = 中心 1 格，环 n 有 6n 格；末环不满时均匀取样，左右对称不堆在一侧 |
| 涨跌配色 | 红涨绿跌（`--up #ff4d4f` / `--down #00c48c`），平盘走中性灰；UI 装饰色一律用金 `#e8b339`，不与涨跌语义混用 |
| 数据来源 | 顶栏 `LIVE`（绿）= 上游真实行情；「延迟」= 有旧帧但上游翻页失败；`DEMO`（金）= 退回内置快照，旁边的 `HH:mm:ss` 是这帧数据的抓取时间 |
| 格子颜色 | 面板近乎纯黑（只透 1% 量级的方向色）+ 方向色棱线 + 方向色内嵌片；涨跌幅越极端棱线越亮 |
| 行情牌排版 | Canvas 贴图 512×320；名称按实测宽度收窄、仍放不下才截断，价格 + 涨跌幅整行按比例缩字号，避免「1,586.00 −0.24%」这种长组合溢出格面 |
| 贴牌抬升 | Sprite 以自身中心定位的竖直四边形，抬升量必须随贴图高度算（`0.04 + 0.34·h`）：写死 0.16 时下半段沉进六棱柱体内被深度测试吃掉，最下面那行「成交额 / 领涨」永远不显示 |
| 涨跌停 | 主板 ±10%、创业板/科创板 ±20%、北交所 ±30%、指数不设限，规则在 `packages/contracts/src/market-rules.ts` |
| 交易时段 | 按 `Asia/Shanghai` 计算盘前 / 集合竞价 / 交易中 / 午间休市 / 已收盘 / 休市 |
| 板块内导航 | 按成交额降序，「上一只 / 下一只」环绕不停，键盘 ← → 同效 |

## 目录与 FSD 约束

```
src/
├── app/       启动、路由、全局样式、Pinia 实例
├── pages/     路由级页面，只做组合
├── widgets/   hive-canvas（3D 蜂巢 + 地板）、board-nav、node-brief、index-strip
├── features/  navigate-hive（路由↔层级）、create-node、tune-node、market-health、market-metrics
├── entities/  market-board（板块聚合）、market-node（模型 + Store + 六边形瓦片）
├── shared/    ui 组件库、api 客户端、lib/hex（蜂巢布局）、lib/three（渲染器、瓦片、后处理）
└── main.ts
server/        Hono 服务，独立 tsconfig 与 package
packages/contracts/  Zod Schema + 涨跌停规则（前后端唯一事实源）
```

`eslint.config.js` 用 `eslint-plugin-boundaries` 把上述层级编译成硬约束：

- 只允许向下依赖（`app → pages → widgets → features → entities → shared`）；
- 同层之间可以互相引用，`shared` 不得反向依赖；
- `packages/contracts` 独立成 `contracts` 分类，任何层都可以消费；
- 第三方依赖（`node_modules`）不受分层限制。

越界导入会直接失败：

```
src/entities/market-node/model/__probe.ts
  1:29  error  FSD 违规：entities 层不允许依赖 widgets 层（依赖只能自上而下）
```

## 3D 渲染管线

- **模板编译**：`vite.config.ts` 必须把 `@tresjs/core/template-compiler-options` 传给 `@vitejs/plugin-vue`。
  `<TresMesh>`、`<TresPerspectiveCamera>` 这些不是 Vue 组件，而是透传给 TresCanvas 自定义渲染器的标签；
  少了这段配置，浏览器会刷屏 `Failed to resolve component: TresXxx`，整棵场景树静默不渲染。
- **蜂巢瓦片**：`shared/lib/three/HexTile.vue` = 六棱柱（约 0.18 厚度）+ `EdgesGeometry` 棱线 + 无光照内嵌色片
  + Canvas 纹理 Sprite 行情牌；悬停抬升 0.18、选中抬升 0.36 并套一圈六边形光环。
- **蜂巢地板**：`HiveFloor.vue` 按轴向坐标铺一片线框蜂巢，外加一个由内向外扩散并淡出的金色扫描环，
  全部在 `useLoop().onBeforeRender` 里直接改变换与材质透明度，不触发 Vue 响应式更新。
- **机位**：按蜂巢外接半径推导距离（`extent · 2.25 + 4`），俯角约 41°，换层时格子既不会溢出也不会缩成一点。
- **拾取**：`<TresMesh @click.stop>` 命中后交给 `features/navigate-hive`，由路由决定下层铺什么。
- **渲染基线**：`shared/lib/three/renderer-preset.ts` 统一 ACES Filmic 色调映射、sRGB 输出、`dpr: [1, 2]`。
- **后处理**：`ScenePostFx.vue` = `EffectComposer → UnrealBloom → Output`，强度由盘面平均波动驱动（`bloomFactor`）。

> 调色陷阱：three 在**线性空间**混合，再经 sRGB 输出。`opacity: 0.05` 的纯红屏幕上看起来接近 25%，
> `color × 0.07` 的面板也会被染成红板。所以面板底色用 0.012、内嵌色片用 0.02 量级，
> 方向色主要由棱线与文字承担。

## 接口

| Method | Path | 说明 |
| --- | --- | --- |
| GET | `/api/health` | 运行时、交易时段、交易日、`dataMode`（live/demo）、`quote`（数据源 / 数据时间 / 耗时 / 翻页失败数 / 限流熔断状态），前端每 20s 轮询 |
| GET | `/api/market/overview` | 三大指数、涨跌家数、两市成交额、主力净流入（全市场口径） |
| GET | `/api/market/boards` | **蜂巢第一层**：板块聚合（真实家数 / 蜂巢格子数 / 涨跌 / 成交额 / 均涨幅 / 领涨股） |
| GET | `/api/market/nodes` | 盘面标的列表（指数在前，个股按成交额降序） |
| POST | `/api/market/nodes` | 加入自选（已在盘面上的代码幂等返回，Zod 校验代码/板块匹配，非法入参 400） |
| GET | `/api/market/nodes/:id` | 单个标的 |
| PATCH | `/api/market/nodes/:id` | 更新关注度（按代码记住，扛得住行情刷新） |
| GET | `/api/market/nodes/:id/detail` | 成交额排名、同板块家数、涨跌停状态、被检视次数 |
| GET | `/api/feed?period=d1\|d5\|d10` | **行业资金流代理**：服务端抓取、缓存 55s、原样透传原始行（前端做聚合） |
| GET | `/api/intraday?code=<6位>` | 板块分钟级资金流代理，代码合法性在服务端校验 |

> `/api/feed` 不是可有可无的装饰：早期版本没有它，前端会退化成 JSONP 直连第三方数据源，
> 等于让对端在页面上下文里执行任意脚本，还绕过了所有缓存与限流。现在上游访问全部收口在 Hono。

错误统一为 `{ error: { code, message, details? } }`。前端 `shared/api/client.ts` 用同一份 Schema 反向校验响应，
Schema 漂移会立刻变成 `invalid_response` 而不是运行期崩溃。

## 行情数据链路

```
代码清单（clist 分页，缓存 30min）──60 页──┐
                                          ├─▶ quote.service ──快照──▶ market.service ──▶ /api/market/*
行情快照（ulist.np 批量，500/批）──12 批──┘                              │
                                              stableNodeId(交易所+代码) ──┘  id 每次启动都一样
```

| 环节 | 规则 |
| --- | --- |
| 行情通道 | `ulist.np` 按代码批量取快照，一次 500 个、约 100ms，全 A 约 12 批；`clist` 只用来拿代码清单并缓存 30 分钟 |
| 为什么分两条腿 | `clist` 只有 `push2delay2` 一个节点接受，而它是延迟行情源：盘中 f6（成交额）、f15–f17 全返回 `-`，指数 f3 恒为 0。只靠它会让「按成交额取前 60」退化成按代码排序，板块成交额与指数全部失真 |
| 传输层 | `node:https` + `agent: false`，不用 `fetch`：undici 复用 keep-alive 连接会被实时域直接 `other side closed`（ECONNRESET），同 URL 用 curl 或 https 模块都 200 |
| 字段口径 | 上游金额单位是「元」，盘面统一换算成亿元；停牌行（`f2`/`f3` 为 `-`）直接丢弃，不计入家数与均涨幅 |
| 板块归属 | 批量接口是一张 `fs` 打天下，板块按代码段反推：688/689 科创、300/301 创业、4/8/9 开头北交所（含 920 段），其余沪深主板 |
| 蜂巢取样 | 每个板块只铺成交额前 `MARKET_SAMPLE_PER_BOARD`（默认 60）只；真实家数走 `count`，格子数走 `sampleCount`，两者分开渲染 |
| 新鲜度 | 盘中 20s、盘前/午间 60s、收盘后 5min；`ready()` 内做并发去重，页签再多也只扫一轮 |
| 启动预热 | 进程启动即拉首帧（冷启动约 8.5s：代码清单 60 页 5s + 12 批行情），用户首个请求只花 17ms |
| 降级 | 有旧帧就发旧帧并标 `degraded`（顶栏显示「延迟」）；一帧都没有才退回内置快照并标 `DEMO`，不会 502 |
| id 稳定性 | `stableNodeId = UUIDv5(交易所 + 代码)`：行情每 20s 换一帧，但 `?node=<id>` 分享链接不会过夜失效 |
| 关注度 | 上游没有「热度」字段，用成交额在板块内的相对位置 + 离涨跌停的距离合成；用户手动调过的值按代码记住 |
| 涨跌幅上限 | 新股首日没有涨跌停，契约把 `changePct` 放宽到 +500%，涨跌停判定仍走 `market-rules.ts` 的板块阈值 |

### 防限流

行情链路每轮 12 批（历史上是 60 页），限速**不减少**平均负载，只是把瞬时脉冲削平——
持续速率不是问题、尖峰才是风控敏感的形状。四层机制都在 `upstream-limiter.ts`：

| 层 | 行为 |
| --- | --- |
| 令牌桶 | 全局单例（12 批行情 + 代码清单 + 指数共用一个桶），`MARKET_UPSTREAM_QPS` 控制稳态速率、`MARKET_UPSTREAM_BURST` 控制突发；单定时器驱动等待队列，避免一批请求同时醒来抢令牌 |
| 指数退避 | 失败重试用 full jitter：`random() × min(2s, 400ms × 2^n)`。固定间隔会让同一批失败的页在同一瞬间齐刷刷重来，等于把限流节奏复制一遍 |
| 状态码语义化 | 429 / 503 / 403 与 `Retry-After` 单独识别：不换域名硬撞，直接把闸门关到 `Retry-After` 之后再动；403/404 判定为致命，重试和换镜像都不会变 |
| 熔断 | 连续失败 6 次或收到上述状态码就闭闸，冷却 60s 起、连续触发按 2 的幂放大（上限 5min）；冷却结束进半开，只放一个探针，成功即恢复 |

配合两处「宁可旧不可错」的取舍：

- **残缺作废**：一轮扫描缺批超过 20% 就整轮丢弃，继续发上一帧。少了两批的「全市场家数」会凭空少一千只，而前端照样显示 LIVE，比延迟几秒误导得多。
- **旧帧直发**：有旧帧时 `ready()` 走 stale-while-revalidate，立刻返回旧数据、刷新在后台跑。否则一轮扫描（冷启动 8.5s）会把每个接口都拖成同样的延迟（实测有帧后 13ms）。

熔断状态直接暴露在 `/api/health` 的 `quote.limiter` 上（`breaker` / `cooldownRemainingMs` / `lastThrottleAt`），
不用翻进程日志猜「数据为什么变旧」。

配置见 `.env.example`：`MARKET_DATA_MODE`（live/demo）、`MARKET_QUOTE_TTL_MS`、`MARKET_SAMPLE_PER_BOARD`、
`MARKET_UPSTREAM_QPS`、`MARKET_UPSTREAM_BURST`、`MARKET_BREAKER_COOLDOWN_MS`。

## 安全边界

| 面 | 措施 |
| --- | --- |
| XSS | 第三方行情文本一律走 `textContent` / Vue 插值，禁止拼 `innerHTML`；CSP `script-src 'self'` 兜底 |
| 写接口 | `POST`/`PATCH` 需 `X-Write-Token`（或 Bearer）。未配置令牌时：绑回环放行、绑非回环直接 503 |
| 灌包 | 写请求体上限 8KB，超限 413 |
| 刷接口 | 读 240/min、写 30/min（按 IP + 作用域，写请求共用桶，换 id 绕不过）、`/api/feed` 60/min |
| 跨域 | 白名单外的 Origin 不返回 `Access-Control-Allow-Origin`，而不是回退到一个不匹配的值 |
| 取数 | 上游抓取只发生在服务端，浏览器不再注入任何第三方 `<script>` |

配置见 `.env.example`：后端 `WRITE_TOKEN` 与前端 `VITE_WRITE_TOKEN` 成对使用。

### 新增自选时的板块校验

`SH` 市场不接受 `gem`：
```json
{ "error": { "code": "validation_error", "message": "请求参数校验失败",
  "details": { "fieldErrors": { "board": ["SH 市场不支持该板块"] } } } }
```

## 构建产物（three 独立分包）

`vite.config.ts` 的 `manualChunks` 把渲染引擎与框架拆开，主包只留业务代码：

```
dist/assets/three-*.js          817 kB   ← three + postprocessing（gzip 208 kB）
dist/assets/vue-*.js            106 kB
dist/assets/FlowPage-*.js        77 kB   ← 资金流观测台（按路由懒加载）
dist/assets/tres-*.js            63 kB   ← @tresjs/core + cientos
dist/assets/industry-feed-*.js   56 kB   ← 共享契约（含 Zod），前端取数校验用
dist/assets/MarketPage-*.js      48 kB
dist/assets/index-*.js          3.8 kB   ← 入口，不含 three
```

## 质量闸门

`pnpm lint` · `pnpm typecheck` · `pnpm test`（77 个用例）· `pnpm build` 全部通过。

`server/src/services/quote.service.test.ts` 用上游真实返回形状锁住取数语义：字段单位换算（元 → 亿元）、
停牌行必须丢弃、北交所按代码段落板块、新股首日 +420% 不能被契约拦成 `invalid_response`、
以及「翻页失败 → degraded 但仍有数据」。
`server/src/services/market.service.test.ts` 锁住 `stableNodeId` 的确定性（分享链接不能过夜失效）
与自选幂等（已在盘面上的代码不会再造一个格子）。

其中 `server/src/middleware/guards.test.ts` 锁住写接口的安全语义：令牌缺失/错误/前缀冒用、
非回环地址的匿名写入必须 503、写限流在换路径后仍然生效（防止「换个 id 就是一条新配额」）。

`src/features/navigate-hive/use-hive-navigation.test.ts` 用内存路由 + 假 API 锁住四条 URL 语义：
冷启动直链落位、板块与 node 冲突时修正层级、失效 id 摘参、板块内环绕切换。
这组用例的存在理由是一次真实回归——早期版本的 watcher 只依赖 `routeNodeId`，
首屏列表未到时直接 return，而 URL 此后不再变化，于是「复制链接给别人」永远打不开选中态。

import { fileURLToPath, URL } from 'node:url'

import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    include: [
      'src/**/*.{test,spec}.ts',
      'tests/**/*.{test,spec}.ts',
      // 服务端中间件（限流 / 写守卫）的安全语义也要锁住，靠冒烟跑一遍不算
      'server/src/**/*.{test,spec}.ts',
    ],
    restoreMocks: true,
    css: false,
  },
})
